# Shizuku binds GhostlockUserService by component name and talks over the
# generated AIDL stubs; R8 must keep both sides in release builds.
-keep class com.altro.root.shizuku.GhostlockUserService { *; }
-keep interface com.altro.root.shizuku.IGhostlockUserService { *; }
-keep interface com.altro.root.shizuku.IGhostlockCallback { *; }
-keep class com.altro.root.shizuku.IGhostlockUserService$Stub { *; }
-keep class com.altro.root.shizuku.IGhostlockCallback$Stub { *; }
