package com.altro.root

import android.app.Application
import com.altro.root.data.AndroidGhostlockRepository
import com.altro.root.domain.repository.GhostlockRepository

/** Application composition root. It is the only place that binds data implementations to domain ports. */
class GhostlockApplication : Application() {
    fun createRepository(): GhostlockRepository = AndroidGhostlockRepository(this)
}
