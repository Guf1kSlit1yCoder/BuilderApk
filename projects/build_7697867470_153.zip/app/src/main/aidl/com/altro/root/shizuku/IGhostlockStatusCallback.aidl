package com.altro.root.shizuku;

interface IGhostlockStatusCallback {
    void onStatus(String step, String status);
}
