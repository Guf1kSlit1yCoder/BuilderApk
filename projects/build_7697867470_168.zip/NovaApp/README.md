# NovaApp - меню + инжект + ESP (Java, UDP)

Одно приложение: кнопка **INJECT** и все функции. Шелл-скриптов нет.

```
[NovaApp (Java)] --su--> AndKittyInjector --> libnovaesp.so (внутри com.heesoyam.berda)
      ^  меню/настройки --UDP 127.0.0.1:47322-->  |  lib читает игроков через IL2CPP (главный поток)
      +-- ESP рисует оверлей (Java Canvas) <--UDP 127.0.0.1:47321-- кадры: боксы, ники, дистанция
```
## Сборка
* **GitHub (без установки чего-либо):** залей папку в репозиторий -> Actions -> build-apk -> скачай артефакт `NovaApp-apk`.
* **Android Studio:** Open папку -> Build -> Build APK (NDK/CMake студия предложит поставить сама). Или `gradle assembleDebug`.
libnovaesp.so собирается автоматически вместе с APK (app/src/main/cpp), AndKittyInjector лежит в assets.

## Использование
1. Установи APK, дай root приложению Nova, разреши "Поверх других приложений".
2. Нажми **INJECT**: приложение копирует инжектор и либу в /data/local/tmp/nova, запускает игру (или цепляется к уже запущенной) и ждёт связи по UDP.
3. Статус сверху станет CONNECTED, кнопка INJECTED. Переключатели меняют ESP сразу.
Оверлей: тумблер "Overlay" в Advanced. Если боксы смещены - слайдеры "Overlay offset X/Y".

## Что использует игра (из Dump.cs, имена не обфусцированы)
PlayerNameplate: get_ClientSpawned / Nickname / IsNpc / IsHostileNpc / IsLocalTeammatePlayer, NetworkBehaviour.IsOwner;
Camera.main + WorldToScreenPoint + pixelWidth/Height; Transform.position.
Тик на главном потоке: подмена MethodInfo->methodPointer у PlayerController.Update (без хук-библиотек);
если не сработает - запасной тик через eglSwapBuffers.

## Если что-то не так (adb logcat -s NovaESP)
* нет "il2cpp ready" - экспорты il2cpp вырезаны; пришли лог.
* нет "Update hook installed" / ESP дёргается - Unity вызывает Update напрямую; работает запасной тик, но возможны ограничения main-thread.
* CONNECTED не появляется - у игры нет INTERNET (сокет не создаётся) или SELinux; попробуй "Use memfd".
Я не мог собрать и запустить проект здесь: нативный код проверен компилятором на синтаксис, Java - парсером (без Android SDK).
Использовать только на своём приватном сервере.
