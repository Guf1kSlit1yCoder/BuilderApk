// NovaESP native (runs INSIDE the game, arm64). Reads players via IL2CPP and sends them over UDP (127.0.0.1) to the NovaApp
// overlay, which draws the ESP in Java. Read-only: never writes game memory. No GL, no rendering here.
//   lib -> app : 127.0.0.1:47321   "H|1"  hello   |  "F|camW|camH|n\n" + n x "E|cx|top|bottom|type|dist|name\n"   (type 0 player,1 team,2 npc,3 hostile)
//   app -> lib : 127.0.0.1:47322   "C|esp,boxes,names,dist,filled,players,team,npc,hostile|maxDist|boxHeight"  |  "PING"
#include <android/log.h>
#include <dlfcn.h>
#include <link.h>
#include <elf.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <string>
#include <thread>
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "NovaESP", __VA_ARGS__)
static const int kAppPort = 47321, kLibPort = 47322;

struct Config { volatile bool esp = true, boxes = true, names = true, dist = true, filled = false, players = true, team = true, npc = true, hostile = true;
                volatile float maxDist = 250, boxHeight = 1.8f; } cfg;

// ------------------------------------------------------------------ ELF helpers (export lookup + GOT hook)
struct Mod { uintptr_t base = 0; ElfW(Sym)* sym = nullptr; const char* str = nullptr; size_t nsym = 0; ElfW(Rela)* jmp = nullptr; size_t jmpSz = 0; ElfW(Rela)* rela = nullptr; size_t relaSz = 0; };
static bool FindMod(const char* name, Mod* out) {
    struct A { const char* n; Mod* m; bool ok; } a{name, out, false};
    dl_iterate_phdr([](dl_phdr_info* i, size_t, void* d) -> int {
        A* a = (A*)d; if (!i->dlpi_name || !std::strstr(i->dlpi_name, a->n)) return 0;
        uintptr_t base = i->dlpi_addr; ElfW(Dyn)* dyn = nullptr;
        for (int k = 0; k < i->dlpi_phnum; k++) if (i->dlpi_phdr[k].p_type == PT_DYNAMIC) dyn = (ElfW(Dyn)*)(base + i->dlpi_phdr[k].p_vaddr);
        if (!dyn) return 0;
        auto fix = [&](uintptr_t p) { return p < base ? base + p : p; };
        Mod& m = *a->m; m = Mod(); m.base = base;
        for (; dyn->d_tag != DT_NULL; dyn++) switch (dyn->d_tag) {
            case DT_SYMTAB: m.sym = (ElfW(Sym)*)fix(dyn->d_un.d_ptr); break;
            case DT_STRTAB: m.str = (const char*)fix(dyn->d_un.d_ptr); break;
            case DT_JMPREL: m.jmp = (ElfW(Rela)*)fix(dyn->d_un.d_ptr); break;
            case DT_PLTRELSZ: m.jmpSz = dyn->d_un.d_val; break;
            case DT_RELA: m.rela = (ElfW(Rela)*)fix(dyn->d_un.d_ptr); break;
            case DT_RELASZ: m.relaSz = dyn->d_un.d_val; break;
        }
        if (m.sym && m.str && (uintptr_t)m.str > (uintptr_t)m.sym) m.nsym = ((uintptr_t)m.str - (uintptr_t)m.sym) / sizeof(ElfW(Sym));
        a->ok = m.sym && m.str; return 1;
    }, &a);
    return a.ok;
}
static void* Export(const Mod& m, const char* name) {
    for (size_t i = 1; i < m.nsym; i++) if (m.sym[i].st_shndx && !std::strcmp(m.str + m.sym[i].st_name, name)) return (void*)(m.base + m.sym[i].st_value);
    return nullptr;
}
static bool HookGot(const Mod& m, const char* name, void* repl, void** orig) {
    bool ok = false;
    auto scan = [&](ElfW(Rela)* r, size_t sz) {
        for (size_t n = 0; r && n < sz / sizeof(ElfW(Rela)); n++) {
            unsigned t = ELF64_R_TYPE(r[n].r_info); if (t != R_AARCH64_JUMP_SLOT && t != R_AARCH64_GLOB_DAT) continue;
            if (std::strcmp(m.str + m.sym[ELF64_R_SYM(r[n].r_info)].st_name, name)) continue;
            void** slot = (void**)(m.base + r[n].r_offset); long ps = sysconf(_SC_PAGESIZE);
            if (mprotect((void*)((uintptr_t)slot & ~(ps - 1)), ps, PROT_READ | PROT_WRITE)) continue;
            if (*slot != repl) *orig = *slot;
            *slot = repl; ok = true;
        }
    };
    scan(m.jmp, m.jmpSz); scan(m.rela, m.relaSz); return ok;
}

// ------------------------------------------------------------------ IL2CPP (resolved by name -> no offsets)
struct Vec3 { float x, y, z; };
struct IL {
    void* (*domain_get)(); void** (*get_assemblies)(void*, size_t*); void* (*asm_image)(void*); const char* (*image_name)(void*);
    void* (*class_from_name)(void*, const char*, const char*); void* (*class_method)(void*, const char*, int);
    void* (*obj_class)(void*); const char* (*class_name)(void*); void* (*thread_attach)(void*);
} il;
struct Methods { void *spawned, *nick, *isNpc, *isHostile, *isTeam, *transform, *getPos, *camMain, *w2s, *pixW, *pixH; void* isOwner; void* pcUpdate; } M;
static std::atomic<bool> g_ready{false};
template <class R, class... A> static R Call(void* mi, A... a) { return ((R(*)(A..., void*))(*(void**)mi))(a..., mi); }  // MethodInfo->methodPointer is field 0
static bool Alive(void* o) { return o && *(void**)((char*)o + 0x10); }                                                    // UnityEngine.Object::m_CachedPtr

static bool ResolveIl2cpp() {
    Mod m; if (!FindMod("libil2cpp.so", &m)) return false;
#define EXP(f, n) *(void**)&il.f = Export(m, "il2cpp_" n); if (!il.f) { LOG("missing export il2cpp_" n); return false; }
    EXP(domain_get, "domain_get") EXP(get_assemblies, "domain_get_assemblies") EXP(asm_image, "assembly_get_image") EXP(image_name, "image_get_name")
    EXP(class_from_name, "class_from_name") EXP(class_method, "class_get_method_from_name") EXP(obj_class, "object_get_class")
    EXP(class_name, "class_get_name") EXP(thread_attach, "thread_attach")
#undef EXP
    void* dom = il.domain_get(); if (!dom) return false;
    il.thread_attach(dom);
    size_t n = 0; void** asms = il.get_assemblies(dom, &n); void *csharp = nullptr, *core = nullptr;
    for (size_t i = 0; i < n; i++) { void* img = il.asm_image(asms[i]); const char* nm = il.image_name(img);
        if (!std::strcmp(nm, "Assembly-CSharp.dll")) csharp = img; else if (!std::strcmp(nm, "UnityEngine.CoreModule.dll")) core = img; }
    if (!csharp || !core) return false;
    void *np = il.class_from_name(csharp, "", "PlayerNameplate"), *pc = il.class_from_name(csharp, "", "PlayerController"),
         *cam = il.class_from_name(core, "UnityEngine", "Camera"), *tr = il.class_from_name(core, "UnityEngine", "Transform"),
         *co = il.class_from_name(core, "UnityEngine", "Component");
    if (!np || !cam || !tr || !co) return false;
    M.spawned = il.class_method(np, "get_ClientSpawned", 0); M.nick = il.class_method(np, "get_Nickname", 0);
    M.isNpc = il.class_method(np, "get_IsNpc", 0); M.isHostile = il.class_method(np, "get_IsHostileNpc", 0);
    M.isTeam = il.class_method(np, "get_IsLocalTeammatePlayer", 0); M.isOwner = il.class_method(np, "get_IsOwner", 0);
    M.transform = il.class_method(co, "get_transform", 0); M.getPos = il.class_method(tr, "get_position", 0);
    M.camMain = il.class_method(cam, "get_main", 0); M.w2s = il.class_method(cam, "WorldToScreenPoint", 1);
    M.pixW = il.class_method(cam, "get_pixelWidth", 0); M.pixH = il.class_method(cam, "get_pixelHeight", 0);
    M.pcUpdate = pc ? il.class_method(pc, "Update", 0) : nullptr;
    void* req[] = {M.spawned, M.nick, M.isNpc, M.isHostile, M.isTeam, M.transform, M.getPos, M.camMain, M.w2s, M.pixW, M.pixH};
    for (size_t i = 0; i < sizeof(req) / sizeof(req[0]); i++) if (!req[i]) { LOG("method #%zu not found", i); return false; }
    LOG("il2cpp ready"); return true;
}
static void Utf8(void* s, std::string& o, int maxChars) {   // Il2CppString (UTF-16) -> UTF-8, '|' and control chars removed
    if (!s) return; int len = *(int*)((char*)s + 0x10); const char16_t* c = (const char16_t*)((char*)s + 0x14);
    for (int i = 0; i < len && i < maxChars; i++) {
        uint32_t u = c[i];
        if (u >= 0xD800 && u < 0xDC00 && i + 1 < len) { u = 0x10000 + ((u - 0xD800) << 10) + (c[i + 1] - 0xDC00); i++; }
        if (u < 32 || u == '|' || u == 127) { o += ' '; continue; }
        if (u < 0x80) o += (char)u;
        else if (u < 0x800) { o += (char)(0xC0 | (u >> 6)); o += (char)(0x80 | (u & 63)); }
        else if (u < 0x10000) { o += (char)(0xE0 | (u >> 12)); o += (char)(0x80 | ((u >> 6) & 63)); o += (char)(0x80 | (u & 63)); }
        else { o += (char)(0xF0 | (u >> 18)); o += (char)(0x80 | ((u >> 12) & 63)); o += (char)(0x80 | ((u >> 6) & 63)); o += (char)(0x80 | (u & 63)); }
    }
}

// ------------------------------------------------------------------ UDP
static int g_tx = -1; static sockaddr_in g_dst; static std::atomic<bool> g_ping{false};
static void Send(const char* b, size_t n) { if (g_tx >= 0) sendto(g_tx, b, n, MSG_DONTWAIT, (sockaddr*)&g_dst, sizeof g_dst); }
static void ParseCfg(const char* s) {
    int e, b, n, d, f, p, t, np, h; float md, bh;
    if (std::sscanf(s, "C|%d,%d,%d,%d,%d,%d,%d,%d,%d|%f|%f", &e, &b, &n, &d, &f, &p, &t, &np, &h, &md, &bh) == 11) {
        cfg.esp = e; cfg.boxes = b; cfg.names = n; cfg.dist = d; cfg.filled = f; cfg.players = p; cfg.team = t; cfg.npc = np; cfg.hostile = h; cfg.maxDist = md; cfg.boxHeight = bh;
    }
}
static void RxThread() {
    for (;;) {
        int fd = socket(AF_INET, SOCK_DGRAM, 0); if (fd < 0) { std::this_thread::sleep_for(std::chrono::seconds(1)); continue; }
        int one = 1; setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
        sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons(kLibPort); a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        if (bind(fd, (sockaddr*)&a, sizeof a)) { close(fd); std::this_thread::sleep_for(std::chrono::seconds(1)); continue; }
        char buf[256]; ssize_t n;
        while ((n = recv(fd, buf, sizeof buf - 1, 0)) > 0) { buf[n] = 0; if (buf[0] == 'C') ParseCfg(buf); else if (!std::strncmp(buf, "PING", 4)) g_ping = true; }
        close(fd);
    }
}

// ------------------------------------------------------------------ tick (must run on the Unity MAIN thread)
using Clock = std::chrono::steady_clock;
static std::atomic<int64_t> g_mainNs{0};
static int64_t NowNs() { return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now().time_since_epoch()).count(); }

static void Tick() {
    static int64_t last = 0, lastHello = 0; int64_t now = NowNs();
    if (now - last < 12000000) return; last = now;                                   // max ~80 packets/s
    if (g_ping || now - lastHello > 1500000000LL) { g_ping = false; lastHello = now; Send("H|1", 3); }
    if (!g_ready || !cfg.esp) return;
    void* cam = Call<void*>(M.camMain); if (!Alive(cam)) return;
    int cw = Call<int>(M.pixW, cam), ch = Call<int>(M.pixH, cam); if (cw < 1 || ch < 1) return;
    void* list = Call<void*>(M.spawned); if (!list || std::strcmp(il.class_name(il.obj_class(list)), "List`1")) return;
    void* arr = *(void**)((char*)list + 0x10); int cnt = *(int*)((char*)list + 0x18); if (!arr || cnt < 0 || cnt > 512) return;
    void** items = (void**)((char*)arr + 0x20);
    Vec3 me = {0, 0, 0}; { void* ct = Call<void*>(M.transform, cam); if (Alive(ct)) me = Call<Vec3>(M.getPos, ct); }
    std::string body; int sent = 0;
    for (int i = 0; i < cnt && sent < 24; i++) {
        void* np = items[i]; if (!Alive(np)) continue;
        if (M.isOwner && Call<bool>(M.isOwner, np)) continue;
        bool npc = Call<bool>(M.isNpc, np), hostile = Call<bool>(M.isHostile, np), team = Call<bool>(M.isTeam, np);
        if (hostile ? !cfg.hostile : npc ? !cfg.npc : team ? !cfg.team : !cfg.players) continue;
        void* tr = Call<void*>(M.transform, np); if (!Alive(tr)) continue;
        Vec3 p = Call<Vec3>(M.getPos, tr); float dx = p.x - me.x, dy = p.y - me.y, dz = p.z - me.z, dist = std::sqrt(dx * dx + dy * dy + dz * dz);
        if (dist > cfg.maxDist) continue;
        Vec3 foot = Call<Vec3>(M.w2s, cam, p), head = Call<Vec3>(M.w2s, cam, Vec3{p.x, p.y + cfg.boxHeight, p.z});
        if (foot.z <= 0.01f || head.z <= 0.01f) continue;                           // behind camera
        std::string nm; if (cfg.names && M.nick) Utf8(Call<void*>(M.nick, np), nm, 16);
        char line[160]; std::snprintf(line, sizeof line, "E|%.1f|%.1f|%.1f|%d|%d|%s\n", foot.x, ch - head.y, ch - foot.y, hostile ? 3 : npc ? 2 : team ? 1 : 0, (int)dist, nm.c_str());
        if (body.size() + std::strlen(line) > 1250) break; body += line; sent++;
    }
    char hdr[64]; int hl = std::snprintf(hdr, sizeof hdr, "F|%d|%d|%d\n", cw, ch, sent);
    std::string pkt(hdr, hl); pkt += body; Send(pkt.data(), pkt.size());
}

// Primary tick: we replace MethodInfo->methodPointer of PlayerController.Update (a plain data write; Unity calls it on the main thread).
static void (*orig_update)(void*, void*) = nullptr;
static void hk_update(void* self, void* mi) { orig_update(self, mi); g_mainNs = NowNs(); Tick(); }
// Fallback tick (only if the Update hook never fires): eglSwapBuffers. Runs on the render thread -> Unity may refuse some calls there.
static unsigned (*orig_swap)(void*, void*) = nullptr;
static unsigned hk_swap(void* d, void* s) { if (NowNs() - g_mainNs > 1000000000LL) Tick(); return orig_swap(d, s); }

static void Boot() {
    LOG("NovaESP native loaded");
    g_tx = socket(AF_INET, SOCK_DGRAM, 0); std::memset(&g_dst, 0, sizeof g_dst);
    g_dst.sin_family = AF_INET; g_dst.sin_port = htons(kAppPort); g_dst.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (g_tx < 0) LOG("udp socket failed (game has no INTERNET permission?)");
    std::thread(RxThread).detach();
    Mod unity; for (int i = 0; i < 600 && !FindMod("libunity.so", &unity); i++) std::this_thread::sleep_for(std::chrono::milliseconds(100));
    for (int i = 0; i < 1800; i++) {
        if (ResolveIl2cpp()) {
            g_ready = true;
            if (M.pcUpdate && !orig_update) { orig_update = *(void (**)(void*, void*))M.pcUpdate; *(void**)M.pcUpdate = (void*)hk_update; LOG("Update hook installed"); }
            if (FindMod("libunity.so", &unity) && HookGot(unity, "eglSwapBuffers", (void*)hk_swap, (void**)&orig_swap)) LOG("fallback swap hook installed");
            return;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    LOG("il2cpp resolve failed");
}
__attribute__((constructor)) static void Entry() { std::thread(Boot).detach(); }
