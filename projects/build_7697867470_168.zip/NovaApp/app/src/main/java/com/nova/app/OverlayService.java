package com.nova.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import java.net.DatagramSocket;

/** Foreground service: full-screen click-through overlay + UDP receiver feeding it. */
public class OverlayService extends Service {
    public static volatile boolean running = false;
    private WindowManager wm;
    private EspView view;
    private DatagramSocket rx;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable pinger = new Runnable() {
        @Override public void run() {
            Udp.send(Cfg.packet());      // keeps the lib in sync (also after a re-inject)
            Udp.send("PING");
            h.postDelayed(this, 2000);
        }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        if (running) return START_STICKY;
        running = true;
        startForeground(1, notification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        view = new EspView(this);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        try { wm.addView(view, lp); } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    rx = Udp.openReceiver();
                    Udp.receiveLoop(rx, new Udp.Listener() { @Override public void onFrame(Udp.Frame f) { if (view != null) view.setFrame(f); } });
                } catch (Exception ignored) { }
            }
        }, "nova-udp").start();
        h.post(pinger);
        return START_STICKY;
    }

    private Notification notification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel("nova", "Nova", NotificationManager.IMPORTANCE_MIN));
            b = new Notification.Builder(this, "nova");
        } else b = new Notification.Builder(this);
        return b.setContentTitle("Nova overlay").setContentText("ESP overlay is running").setSmallIcon(android.R.drawable.ic_menu_view).build();
    }

    @Override public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (rx != null) rx.close();
        if (wm != null && view != null) { try { wm.removeView(view); } catch (Exception ignored) { } }
        view = null;
        super.onDestroy();
    }
}
