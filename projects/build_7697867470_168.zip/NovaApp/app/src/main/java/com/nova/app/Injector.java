package com.nova.app;

import android.content.Context;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

/** Root injection through the bundled AndKittyInjector binary. */
public final class Injector {
    private Injector() {}
    public interface Log { void line(String s); }
    static final String DIR = "/data/local/tmp/nova";

    /** Runs a command as root, streams output to log, returns the exit code (-1 if su failed). */
    static int su(String cmd, Log log, StringBuilder capture) {
        try {
            Process p = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String l;
            while ((l = r.readLine()) != null) { if (capture != null) capture.append(l).append('\n'); if (log != null) log.line(l); }
            return p.waitFor();
        } catch (Exception e) {
            if (log != null) log.line("su error: " + e.getMessage());
            return -1;
        }
    }

    public static boolean hasRoot() { StringBuilder sb = new StringBuilder(); return su("id -u", null, sb) == 0 && sb.toString().trim().equals("0"); }

    private static void extract(Context c, String asset, File out) throws Exception {
        InputStream in = c.getAssets().open(asset);
        OutputStream os = new FileOutputStream(out);
        byte[] b = new byte[16384]; int n;
        while ((n = in.read(b)) > 0) os.write(b, 0, n);
        os.close(); in.close();
    }

    /** Copies injector + lib to /data/local/tmp/nova and injects (launches the game if it is not running). */
    public static boolean run(Context c, Log log) {
        try {
            if (!hasRoot()) { log.line("No root (su denied)"); return false; }
            File inj = new File(c.getFilesDir(), "AndKittyInjector");
            extract(c, "AndKittyInjector", inj);
            File lib = new File(c.getApplicationInfo().nativeLibraryDir, "libnovaesp.so");
            if (!lib.exists()) { log.line("libnovaesp.so is missing in the APK (native build failed?)"); return false; }
            int rc = su("mkdir -p " + DIR + " && cp '" + inj.getAbsolutePath() + "' " + DIR + "/AndKittyInjector && cp '" + lib.getAbsolutePath()
                + "' " + DIR + "/libnovaesp.so && chmod 755 " + DIR + "/* && (chcon u:object_r:shell_data_file:s0 " + DIR + "/* 2>/dev/null; true)", log, null);
            if (rc != 0) { log.line("copy failed (" + rc + ")"); return false; }
            StringBuilder pid = new StringBuilder();
            su("pidof " + Cfg.GAME_PKG, null, pid);
            String p = pid.toString().trim().split("\\s+")[0];
            StringBuilder cmd = new StringBuilder(DIR + "/AndKittyInjector --libs " + DIR + "/libnovaesp.so");
            if (p.matches("\\d+")) { log.line("game running, pid " + p); cmd.append(" --pid ").append(p); }
            else { log.line("launching game"); cmd.append(" --package ").append(Cfg.GAME_PKG).append(" --launch --delay 3000000"); }
            if (Cfg.memfd) cmd.append(" --memfd");
            log.line("$ " + cmd);
            rc = su(cmd + " 2>&1", log, null);
            log.line(rc == 0 ? "injector finished" : "injector exit code " + rc);
            return rc == 0;
        } catch (Exception e) {
            log.line("error: " + e);
            return false;
        }
    }
}
