package com.nova.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;

/** All settings. Saved in SharedPreferences, sent to the injected lib as one UDP packet. */
public final class Cfg {
    private Cfg() {}
    public static final String GAME_PKG = "com.heesoyam.berda";
    public static boolean esp = true, boxes = true, names = true, dist = true, filled = false;
    public static boolean players = true, team = true, npc = true, hostile = true, memfd = false;
    public static float maxDist = 250, boxHeight = 1.8f, textSize = 13, lineW = 1.5f, offX = 0, offY = 0;
    private static SharedPreferences sp;

    public static void load(Context c) {
        sp = c.getSharedPreferences("nova", Context.MODE_PRIVATE);
        esp = sp.getBoolean("esp", esp); boxes = sp.getBoolean("boxes", boxes); names = sp.getBoolean("names", names);
        dist = sp.getBoolean("dist", dist); filled = sp.getBoolean("filled", filled); players = sp.getBoolean("players", players);
        team = sp.getBoolean("team", team); npc = sp.getBoolean("npc", npc); hostile = sp.getBoolean("hostile", hostile);
        memfd = sp.getBoolean("memfd", memfd); maxDist = sp.getFloat("maxDist", maxDist); boxHeight = sp.getFloat("boxHeight", boxHeight);
        textSize = sp.getFloat("textSize", textSize); lineW = sp.getFloat("lineW", lineW); offX = sp.getFloat("offX", offX); offY = sp.getFloat("offY", offY);
    }

    public static void save() {
        if (sp == null) return;
        sp.edit().putBoolean("esp", esp).putBoolean("boxes", boxes).putBoolean("names", names).putBoolean("dist", dist)
            .putBoolean("filled", filled).putBoolean("players", players).putBoolean("team", team).putBoolean("npc", npc)
            .putBoolean("hostile", hostile).putBoolean("memfd", memfd).putFloat("maxDist", maxDist).putFloat("boxHeight", boxHeight)
            .putFloat("textSize", textSize).putFloat("lineW", lineW).putFloat("offX", offX).putFloat("offY", offY).apply();
    }

    private static int b(boolean v) { return v ? 1 : 0; }

    /** Config packet understood by the native lib. */
    public static String packet() {
        return String.format(Locale.US, "C|%d,%d,%d,%d,%d,%d,%d,%d,%d|%.1f|%.2f",
            b(esp), b(boxes), b(names), b(dist), b(filled), b(players), b(team), b(npc), b(hostile), maxDist, boxHeight);
    }
}
