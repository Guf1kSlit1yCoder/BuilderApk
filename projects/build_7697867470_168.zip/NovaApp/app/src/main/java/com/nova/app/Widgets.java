package com.nova.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;

/** Custom-drawn dark UI widgets: gradient inject button, animated switch, slider, cards. */
public final class Widgets {
    private Widgets() {}
    public static final int BG = 0xFF08080B, CARD = 0xFF111118, BORDER = 0xFF1E1E28, TEXT = 0xFFECECF4, DIM = 0xFF7A7A8E;
    public static final int ACC_A = 0xFF7C5CFF, ACC_B = 0xFFE248D6, OK = 0xFF48D678, ERR = 0xFFFF5470;

    public interface OnBool { void on(boolean v); }
    public interface OnFloat { void on(float v); }

    public static float dp(Context c, float v) { return v * c.getResources().getDisplayMetrics().density; }

    static int mix(int a, int b, float t) {
        return Color.argb((int) (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t), (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t),
            (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t), (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t));
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD); g.setCornerRadius(dp(c, 16)); g.setStroke((int) Math.max(1, dp(c, 1)), BORDER);
        l.setBackground(g);
        int p = (int) dp(c, 16);
        l.setPadding(p, (int) dp(c, 12), p, (int) dp(c, 8));
        return l;
    }

    // ------------------------------------------------------------------ switch
    public static class NSwitch extends View {
        private boolean on; private float t;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private ValueAnimator an;
        private final OnBool cb;

        public NSwitch(Context c, boolean init, OnBool cb) {
            super(c);
            this.on = init; this.t = init ? 1 : 0; this.cb = cb;
            setClickable(true);
            setOnClickListener(new OnClickListener() {
                @Override public void onClick(View v) { on = !on; go(on ? 1 : 0); if (NSwitch.this.cb != null) NSwitch.this.cb.on(on); }
            });
        }

        public void setChecked(boolean v) { on = v; go(v ? 1 : 0); }

        private void go(float to) {
            if (an != null) an.cancel();
            an = ValueAnimator.ofFloat(t, to); an.setDuration(180);
            an.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator a) { t = (Float) a.getAnimatedValue(); invalidate(); }
            });
            an.start();
        }

        @Override protected void onMeasure(int w, int h) { setMeasuredDimension((int) dp(getContext(), 48), (int) dp(getContext(), 28)); }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), r = h / 2, d = dp(getContext(), 1);
            RectF rect = new RectF(d, d, w - d, h - d);
            p.setStyle(Paint.Style.FILL); p.setShader(null); p.setColor(0xFF1C1C26); p.setAlpha(255);
            c.drawRoundRect(rect, r, r, p);
            if (t > 0.01f) {
                p.setShader(new LinearGradient(0, 0, w, 0, ACC_A, ACC_B, Shader.TileMode.CLAMP)); p.setAlpha((int) (255 * t));
                c.drawRoundRect(rect, r, r, p);
                p.setShader(null); p.setAlpha(255);
            }
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(d); p.setColor(mix(BORDER, 0x99E248D6, t));
            c.drawRoundRect(rect, r, r, p);
            float kr = r - dp(getContext(), 5), kx = r + t * (w - 2 * r);
            p.setStyle(Paint.Style.FILL); p.setColor(mix(0xFF6E6E80, 0xFFFFFFFF, t));
            c.drawCircle(kx, h / 2, kr, p);
        }
    }

    // ------------------------------------------------------------------ slider
    public static class NSlider extends View {
        private final float min, max; private float val;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final OnFloat cb;
        private boolean drag;

        public NSlider(Context c, float min, float max, float val, OnFloat cb) {
            super(c);
            this.min = min; this.max = max; this.val = Math.max(min, Math.min(max, val)); this.cb = cb;
        }

        @Override protected void onMeasure(int w, int h) { setMeasuredDimension(MeasureSpec.getSize(w), (int) dp(getContext(), 30)); }

        @Override public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
                drag = true;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                float pad = dp(getContext(), 12);
                float t = (e.getX() - pad) / Math.max(1, getWidth() - 2 * pad);
                t = Math.max(0, Math.min(1, t));
                val = min + (max - min) * t;
                if (cb != null) cb.on(val);
                invalidate();
                return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { drag = false; invalidate(); return true; }
            return super.onTouchEvent(e);
        }

        @Override protected void onDraw(Canvas c) {
            Context ctx = getContext();
            float w = getWidth(), h = getHeight(), pad = dp(ctx, 12), th = dp(ctx, 5), cy = h / 2;
            float t = (val - min) / (max - min), kx = pad + (w - 2 * pad) * t;
            p.setStyle(Paint.Style.FILL); p.setShader(null); p.setColor(0xFF1C1C26);
            c.drawRoundRect(new RectF(pad, cy - th / 2, w - pad, cy + th / 2), th, th, p);
            p.setShader(new LinearGradient(pad, 0, w - pad, 0, ACC_A, ACC_B, Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(pad, cy - th / 2, Math.max(kx, pad + th), cy + th / 2), th, th, p);
            p.setShader(null);
            if (drag) {
                p.setShader(new RadialGradient(kx, cy, dp(ctx, 18), 0x66E248D6, 0x00E248D6, Shader.TileMode.CLAMP));
                c.drawCircle(kx, cy, dp(ctx, 18), p); p.setShader(null);
            }
            p.setColor(0xFFFFFFFF);
            c.drawCircle(kx, cy, dp(ctx, drag ? 9 : 7.5f), p);
        }
    }

    // ------------------------------------------------------------------ big gradient button
    public static final int ST_IDLE = 0, ST_BUSY = 1, ST_OK = 2, ST_ERR = 3;

    public static class GButton extends View {
        private int state = ST_IDLE; private float shimmer, stateT = 0;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private ValueAnimator shim;
        private final Path clip = new Path();

        public GButton(Context c) {
            super(c);
            setLayerType(LAYER_TYPE_SOFTWARE, null);   // needed for the blur glow
            tp.setColor(0xFFFFFFFF); tp.setTextAlign(Paint.Align.CENTER); tp.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            tp.setTextSize(dp(c, 16)); tp.setLetterSpacing(0.12f);
            setClickable(true);
        }

        public int getState() { return state; }

        public void setState(int s) {
            if (s == state) return;
            state = s; invalidate();
            if (s == ST_BUSY) {
                shim = ValueAnimator.ofFloat(0, 1); shim.setDuration(1100); shim.setRepeatCount(ValueAnimator.INFINITE);
                shim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override public void onAnimationUpdate(ValueAnimator a) { shimmer = (Float) a.getAnimatedValue(); invalidate(); }
                });
                shim.start();
            } else if (shim != null) { shim.cancel(); shim = null; }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
            else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            return super.onTouchEvent(e);
        }

        @Override protected void onMeasure(int w, int h) { setMeasuredDimension(MeasureSpec.getSize(w), (int) dp(getContext(), 72)); }

        @Override protected void onDraw(Canvas c) {
            Context ctx = getContext();
            float w = getWidth(), h = getHeight(), m = dp(ctx, 8), r = (h - 2 * m) / 2;
            int a, b; String label;
            switch (state) {
                case ST_BUSY: a = ACC_A; b = ACC_B; label = "INJECTING..."; break;
                case ST_OK: a = 0xFF2FBF6A; b = 0xFF48D6B0; label = "INJECTED"; break;
                case ST_ERR: a = 0xFFFF5470; b = 0xFFFF8A54; label = "FAILED - TAP TO RETRY"; break;
                default: a = ACC_A; b = ACC_B; label = "INJECT";
            }
            RectF rect = new RectF(m, m, w - m, h - m);
            p.setStyle(Paint.Style.FILL); p.setShader(null); p.setColor(mix(a, b, 0.5f)); p.setAlpha(110);
            p.setMaskFilter(new BlurMaskFilter(dp(ctx, 12), BlurMaskFilter.Blur.NORMAL));
            c.drawRoundRect(new RectF(rect.left + dp(ctx, 6), rect.top + dp(ctx, 8), rect.right - dp(ctx, 6), rect.bottom + dp(ctx, 4)), r, r, p);
            p.setMaskFilter(null); p.setAlpha(255);
            p.setShader(new LinearGradient(rect.left, 0, rect.right, 0, a, b, Shader.TileMode.CLAMP));
            c.drawRoundRect(rect, r, r, p);
            p.setShader(null);
            if (state == ST_BUSY) {
                clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW);
                c.save(); c.clipPath(clip);
                float sx = rect.left - rect.width() * 0.4f + shimmer * rect.width() * 1.8f;
                p.setShader(new LinearGradient(sx, 0, sx + rect.width() * 0.4f, 0, 0x00FFFFFF, 0x55FFFFFF, Shader.TileMode.CLAMP));
                c.drawRect(rect, p); p.setShader(null);
                c.restore();
            }
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(ctx, 1)); p.setColor(0x33FFFFFF);
            c.drawRoundRect(rect, r, r, p);
            c.drawText(label, w / 2, h / 2 + tp.getTextSize() * 0.35f, tp);
        }
    }
}
