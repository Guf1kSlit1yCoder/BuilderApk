package com.nova.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Transparent full-screen view that draws the ESP from the latest UDP frame. */
public class EspView extends View {
    private volatile Udp.Frame frame;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG),
        text = new Paint(Paint.ANTI_ALIAS_FLAG), pill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    public EspView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        fill.setStyle(Paint.Style.FILL);
        pill.setColor(0x96000000);
        text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        text.setTextAlign(Paint.Align.CENTER);
    }

    public void setFrame(Udp.Frame f) { frame = f; postInvalidate(); }

    private static int color(int type) {
        switch (type) {
            case 3: return 0xFFFF4646;   // hostile NPC
            case 2: return 0xFFFFBE3C;   // NPC
            case 1: return 0xFF50E678;   // teammate
            default: return 0xFFFFFFFF;  // player
        }
    }

    @Override protected void onDraw(Canvas c) {
        Udp.Frame f = frame;
        if (f == null || f.cw < 1 || f.ch < 1 || !Cfg.esp) return;
        if (System.currentTimeMillis() - f.time > 400) return;     // stale -> draw nothing
        float d = getResources().getDisplayMetrics().density;
        float sx = getWidth() / f.cw, sy = getHeight() / f.ch;
        float lw = Cfg.lineW * d, ts = Cfg.textSize * d;
        text.setTextSize(ts);
        for (Udp.Ent e : f.ents) {
            float cx = e.cx * sx + Cfg.offX * d, top = e.top * sy + Cfg.offY * d, bot = e.bot * sy + Cfg.offY * d;
            float h = bot - top;
            if (h < 4) continue;
            float w = h * 0.5f;
            int col = color(e.type);
            r.set(cx - w / 2, top, cx + w / 2, bot);
            if (Cfg.boxes) {
                if (Cfg.filled) { fill.setColor((col & 0x00FFFFFF) | 0x20000000); c.drawRoundRect(r, 3 * d, 3 * d, fill); }
                stroke.setStrokeWidth(lw + 2 * d); stroke.setColor(0xAA000000); c.drawRoundRect(r, 3 * d, 3 * d, stroke);
                stroke.setStrokeWidth(lw); stroke.setColor(col); c.drawRoundRect(r, 3 * d, 3 * d, stroke);
            }
            if (Cfg.names && e.name.length() > 0) {
                float tw = text.measureText(e.name), ty = top - 5 * d;
                RectF pr = new RectF(cx - tw / 2 - 6 * d, ty - ts, cx + tw / 2 + 6 * d, ty + 4 * d);
                c.drawRoundRect(pr, 6 * d, 6 * d, pill);
                text.setColor(col); c.drawText(e.name, cx, ty, text);
            }
            if (Cfg.dist) {
                text.setTextSize(ts - d); text.setColor((col & 0x00FFFFFF) | 0xE6000000);
                c.drawText(e.dist + "m", cx, bot + ts, text);
                text.setTextSize(ts);
            }
        }
    }
}
