package com.nova.app;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** UDP link with the lib that runs inside the game (loopback only). */
public final class Udp {
    private Udp() {}
    public static final int APP_PORT = 47321, LIB_PORT = 47322;

    public static final class Ent { public float cx, top, bot; public int type, dist; public String name = ""; }
    public static final class Frame { public float cw, ch; public Ent[] ents = new Ent[0]; public long time; }

    public interface Listener { void onFrame(Frame f); }

    private static final ExecutorService TX = Executors.newSingleThreadExecutor();
    private static DatagramSocket tx;
    public static volatile long lastSeen = 0;

    public static boolean connected() { return System.currentTimeMillis() - lastSeen < 4000; }

    /** Fire-and-forget send to the lib (done off the UI thread). */
    public static void send(final String s) {
        TX.execute(new Runnable() {
            @Override public void run() {
                try {
                    if (tx == null) tx = new DatagramSocket();
                    byte[] d = s.getBytes(StandardCharsets.UTF_8);
                    tx.send(new DatagramPacket(d, d.length, InetAddress.getByName("127.0.0.1"), LIB_PORT));
                } catch (Exception ignored) { }
            }
        });
    }

    /** Blocking receive loop; run it on its own thread. Returns when the socket is closed. */
    public static void receiveLoop(DatagramSocket rx, Listener l) {
        byte[] buf = new byte[4096];
        try {
            while (!rx.isClosed()) {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                rx.receive(p);
                lastSeen = System.currentTimeMillis();
                String s = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                if (s.startsWith("F|")) { Frame f = parse(s); if (f != null && l != null) l.onFrame(f); }
            }
        } catch (Exception ignored) { }
    }

    public static DatagramSocket openReceiver() throws Exception {
        DatagramSocket s = new DatagramSocket(null);
        s.setReuseAddress(true);
        s.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), APP_PORT));
        return s;
    }

    static Frame parse(String s) {
        try {
            String[] ls = s.split("\n");
            String[] h = ls[0].split("\\|");
            Frame f = new Frame();
            f.cw = Float.parseFloat(h[1]); f.ch = Float.parseFloat(h[2]); f.time = System.currentTimeMillis();
            List<Ent> list = new ArrayList<Ent>();
            for (int i = 1; i < ls.length; i++) {
                if (!ls[i].startsWith("E|")) continue;
                String[] p = ls[i].split("\\|", 7);
                if (p.length < 7) continue;
                Ent e = new Ent();
                e.cx = Float.parseFloat(p[1]); e.top = Float.parseFloat(p[2]); e.bot = Float.parseFloat(p[3]);
                e.type = Integer.parseInt(p[4]); e.dist = Integer.parseInt(p[5]); e.name = p[6];
                list.add(e);
            }
            f.ents = list.toArray(new Ent[0]);
            return f;
        } catch (Exception e) { return null; }
    }
}
