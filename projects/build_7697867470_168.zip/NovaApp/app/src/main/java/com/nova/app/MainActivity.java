package com.nova.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

/** One screen: INJECT button + all ESP functions. */
public class MainActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Widgets.GButton btn;
    private TextView pill, status, logView;
    private volatile boolean busy = false;
    private final StringBuilder logBuf = new StringBuilder();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Cfg.load(this);
        getWindow().setStatusBarColor(Widgets.BG);
        getWindow().setNavigationBarColor(Widgets.BG);
        build();
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        ui.post(tick);
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            boolean con = Udp.connected();
            pill.setText(con ? "CONNECTED" : "NOT CONNECTED");
            pill.setTextColor(con ? Widgets.OK : Widgets.DIM);
            status.setText(con ? "Lib is running inside the game, ESP overlay is live." : "Press INJECT. Root required. Game starts automatically.");
            if (con && !busy && btn.getState() != Widgets.ST_OK) btn.setState(Widgets.ST_OK);
            if (!con && !busy && btn.getState() == Widgets.ST_OK) btn.setState(Widgets.ST_IDLE);
            ui.postDelayed(this, 700);
        }
    };

    // ------------------------------------------------------------------ UI helpers
    private int dp(float v) { return (int) Widgets.dp(this, v); }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif-medium", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int top) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(w, h);
        l.topMargin = dp(top);
        return l;
    }

    private LinearLayout section(LinearLayout root, String title) {
        LinearLayout c = Widgets.card(this);
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL); head.setGravity(Gravity.CENTER_VERTICAL);
        View tick = new View(this);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Widgets.ACC_A, Widgets.ACC_B});
        g.setCornerRadius(dp(2)); tick.setBackground(g);
        head.addView(tick, new LinearLayout.LayoutParams(dp(3), dp(16)));
        TextView t = text(title, 15, Widgets.TEXT, true);
        t.setPadding(dp(10), 0, 0, 0);
        head.addView(t);
        c.addView(head);
        root.addView(c, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 14));
        return c;
    }

    private void toggle(LinearLayout card, String label, boolean init, final Widgets.OnBool cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(label, 15, Widgets.TEXT, false);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(new Widgets.NSwitch(this, init, new Widgets.OnBool() {
            @Override public void on(boolean v) { cb.on(v); Cfg.save(); Udp.send(Cfg.packet()); }
        }));
        card.addView(row, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(44), 4));
    }

    private void slider(LinearLayout card, String label, float min, float max, float init, final String fmt, final Widgets.OnFloat cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(text(label, 14, Widgets.DIM, false), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        final TextView val = text(String.format(Locale.US, fmt, init), 14, Widgets.ACC_B, false);
        row.addView(val);
        card.addView(row, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 10));
        card.addView(new Widgets.NSlider(this, min, max, init, new Widgets.OnFloat() {
            @Override public void on(float v) { cb.on(v); val.setText(String.format(Locale.US, fmt, v)); Cfg.save(); Udp.send(Cfg.packet()); }
        }), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0));
    }

    // ------------------------------------------------------------------ screen
    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Widgets.BG); sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(28));
        sv.addView(root);

        // header
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("N", 20, Color.WHITE, true);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable lg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Widgets.ACC_A, Widgets.ACC_B});
        lg.setCornerRadius(dp(12)); logo.setBackground(lg);
        head.addView(logo, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL); names.setPadding(dp(12), 0, 0, 0);
        names.addView(text("NOVA", 19, Widgets.TEXT, true));
        names.addView(text(Cfg.GAME_PKG, 11, Widgets.DIM, false));
        head.addView(names, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        pill = text("NOT CONNECTED", 11, Widgets.DIM, true);
        GradientDrawable pg = new GradientDrawable(); pg.setColor(0xFF14141C); pg.setCornerRadius(dp(14)); pg.setStroke(dp(1), Widgets.BORDER);
        pill.setBackground(pg); pill.setPadding(dp(12), dp(6), dp(12), dp(6));
        head.addView(pill);
        root.addView(head);

        // THE inject button
        btn = new Widgets.GButton(this);
        btn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { inject(); } });
        root.addView(btn, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(72), 18));
        status = text("", 12, Widgets.DIM, false);
        status.setGravity(Gravity.CENTER);
        root.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 2));

        // functions
        LinearLayout vis = section(root, "Visual");
        toggle(vis, "ESP", Cfg.esp, new Widgets.OnBool() { @Override public void on(boolean v) { Cfg.esp = v; } });
        toggle(vis, "Boxes", Cfg.boxes, new Widgets.OnBool() { @Override public void on(boolean v) { Cfg.boxes = v; } });
        toggle(vis, "Nicknames", Cfg.names, new Widgets.OnBool() { @Override public void on(boolean v) { Cfg.names = v; } });
        toggle(vis, "Distance", Cfg.dist, new Widgets.OnBool() { @Override public void on(boolean v) { Cfg.dist = v; } });
        toggle(vis, "Filled boxes", Cfg.filled, new Widgets.OnBool() { @Override public void on(boolean v) { Cfg.filled = v; } });

        LinearLayout fil = section(root, "Filters");
        toggle(fil, "Players", Cfg.players, new Widgets.OnBool() { @Override public void on(boolean v) { Cfg.players = v; } });
        toggle(fil, "Teammates", Cfg.team, new Widgets.OnBool() { @Override public void on(boolean v) { Cfg.team = v; } });
        toggle(fil, "NPCs", Cfg.npc, new Widgets.OnBool() { @Override public void on(boolean v) { Cfg.npc = v; } });
        toggle(fil, "Hostile NPCs", Cfg.hostile, new Widgets.OnBool() { @Override public void on(boolean v) { Cfg.hostile = v; } });

        LinearLayout tun = section(root, "Tuning");
        slider(tun, "Max distance", 20, 1000, Cfg.maxDist, "%.0f m", new Widgets.OnFloat() { @Override public void on(float v) { Cfg.maxDist = v; } });
        slider(tun, "Box height", 1f, 3f, Cfg.boxHeight, "%.2f", new Widgets.OnFloat() { @Override public void on(float v) { Cfg.boxHeight = v; } });
        slider(tun, "Text size", 9, 22, Cfg.textSize, "%.0f", new Widgets.OnFloat() { @Override public void on(float v) { Cfg.textSize = v; } });
        slider(tun, "Line width", 1, 4, Cfg.lineW, "%.1f", new Widgets.OnFloat() { @Override public void on(float v) { Cfg.lineW = v; } });
        slider(tun, "Overlay offset X", -60, 60, Cfg.offX, "%.0f", new Widgets.OnFloat() { @Override public void on(float v) { Cfg.offX = v; } });
        slider(tun, "Overlay offset Y", -60, 60, Cfg.offY, "%.0f", new Widgets.OnFloat() { @Override public void on(float v) { Cfg.offY = v; } });

        LinearLayout adv = section(root, "Advanced");
        toggle(adv, "Use memfd (if dlopen is blocked)", Cfg.memfd, new Widgets.OnBool() { @Override public void on(boolean v) { Cfg.memfd = v; } });
        toggle(adv, "Overlay", OverlayService.running, new Widgets.OnBool() {
            @Override public void on(boolean v) {
                if (v) startOverlay(); else stopService(new Intent(MainActivity.this, OverlayService.class));
            }
        });

        LinearLayout log = section(root, "Log");
        logView = text("", 11, Widgets.DIM, false);
        logView.setTypeface(Typeface.MONOSPACE);
        log.addView(logView, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 8));
        setContentView(sv);
    }

    // ------------------------------------------------------------------ actions
    private void appendLog(final String s) {
        ui.post(new Runnable() {
            @Override public void run() {
                logBuf.append(s).append('\n');
                String all = logBuf.toString();
                String[] ls = all.split("\n");
                if (ls.length > 40) { logBuf.setLength(0); for (int i = ls.length - 40; i < ls.length; i++) logBuf.append(ls[i]).append('\n'); }
                logView.setText(logBuf.toString());
            }
        });
    }

    private void startOverlay() {
        Intent i = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void inject() {
        if (busy) return;
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\" for Nova, then press INJECT again", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        busy = true;
        btn.setState(Widgets.ST_BUSY);
        if (!OverlayService.running) startOverlay();
        new Thread(new Runnable() {
            @Override public void run() {
                boolean ok = Injector.run(MainActivity.this, new Injector.Log() { @Override public void line(String s) { appendLog(s); } });
                if (ok) {                                    // wait for the lib to say hello over UDP
                    Udp.send(Cfg.packet());
                    long end = System.currentTimeMillis() + 40000;
                    while (System.currentTimeMillis() < end && !Udp.connected()) {
                        Udp.send("PING");
                        try { Thread.sleep(500); } catch (InterruptedException ignored) { }
                    }
                    ok = Udp.connected();
                    if (!ok) appendLog("No data from the lib: check `logcat -s NovaESP` (Vulkan? il2cpp exports?)");
                }
                final boolean res = ok;
                ui.post(new Runnable() {
                    @Override public void run() { busy = false; btn.setState(res ? Widgets.ST_OK : Widgets.ST_ERR); }
                });
            }
        }, "nova-inject").start();
    }
}
