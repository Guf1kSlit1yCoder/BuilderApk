# ESign Open-Source Cloud Build (Ksign / Feather / XcodeGen)

Готовый архив исходников и облачной сборки (`.ipa`) для **GitHub Actions** на базе открытых проектов:
- **[Nyasami/Ksign](https://github.com/Nyasami/Ksign)** — полноценная open-source копия ESign (подпись и прямая установка `.ipa` на устройство через локальный сервер и `IDeviceKit` / `backloop.dev`, менеджер сертификатов `.p12` + `.mobileprovision`, репозитории ESign/AltStore, инжект `.dylib`/`.deb`).
- **[claration/feather](https://github.com/khcrysalis/Feather)** и **[zhlynn/zsign](https://github.com/zhlynn/zsign)** — ядро подписи Mach-O и упаковки `.ipa`.
- **[ProStore-iOS/ProSign](https://github.com/ProStore-iOS/ProSign)** — конфигурация `project.yml` для генерации проекта через **XcodeGen**.

---

## Быстрый старт: Облачный билд `.ipa` через GitHub Actions (без Mac)

### Вариант 1. Загрузка этого архива в свой GitHub-репозиторий (Рекомендуется)
1. Создайте новый публичный или приватный репозиторий на GitHub.
2. Распакуйте содержимое этого `.zip`-архива и загрузите все файлы (включая папку `.github/workflows`) в корень репозитория.
3. Перейдите во вкладку **Actions** вашего репозитория на GitHub:
   - Выберите воркфлоу **`Cloud Build ESign (Ksign Full Replica IPA)`** — он автоматически подтянет актуальное дерево [Nyasami/Ksign](https://github.com/Nyasami/Ksign) со всеми сабмодулями (`Zsign`, `IDeviceKit`), пропишет ваши `App Name` (например, `ESign`) и `Bundle ID` (например, `p3.xyz.yyyue.esign`), соберет `.ipa` в облаке на `macos-15` и выгрузит готовый `ESign.ipa` в раздел **Artifacts** и **Releases**.
   - Либо выберите воркфлоу **`Cloud Build Standalone XcodeGen IPA`** — он соберет автономный исходник из папки `Sources/ESignApp` через `xcodegen` и `project.yml`.
4. Нажмите **Run workflow**, при желании укажите свое имя приложения и Bundle ID, и через 3–5 минут скачайте готовый `.ipa` из блока **Artifacts** завершенного билда.

### Вариант 2. Автоматическая подпись вашим сертификатом (`.p12` + `.mobileprovision`) прямо в облаке
Если вы хотите, чтобы GitHub Actions сразу выдавал **подписанный** `.ipa` под ваш сертификат:
1. Перейдите в **Settings → Secrets and variables → Actions** вашего репозитория.
2. Добавьте 3 секрета (по желанию):
   - `P12_BASE64` — ваш файл `.p12`, закодированный в Base64 (`base64 -i cert.p12 | pbcopy`).
   - `P12_PASSWORD` — пароль от сертификата `.p12`.
   - `PROVISION_BASE64` — ваш файл `.mobileprovision`, закодированный в Base64 (`base64 -i cert.mobileprovision | pbcopy`).
3. Если эти секреты заданы, воркфлоу автоматически скомпилирует `zsign` и подпишет собранный `.ipa` вашим сертификатом, выдав сразу два файла: `ESign-unsigned.ipa` и `ESign-signed.ipa`.

---

## Структура проекта в архиве

```text
├── .github/
│   └── workflows/
│       ├── build-ksign-cloud.yml        # Облачный билд полной копии ESign (Nyasami/Ksign + Zsign + IDeviceKit)
│       └── build-standalone-ipa.yml     # Облачный билд автономного XcodeGen-проекта из папки Sources/
├── Makefile                             # Сборка локально или в CI одной командой `make` (из Nyasami/Ksign)
├── project.yml                          # Конфигурация XcodeGen для генерации ESign.xcodeproj
├── repo.json                            # Шаблон собственного репозитория источников в формате ESign / AltStore
└── Sources/
    └── ESignApp/                        # Автономный SwiftUI исходник ESign-сайнера и установщика IPA
        ├── App/
        │   ├── ESignApp.swift
        │   └── MainTabView.swift
        ├── Models/
        │   └── ESignModels.swift
        ├── Services/
        │   ├── CertificateManager.swift
        │   ├── IPASignerService.swift
        │   └── OTAInstallerServer.swift
        ├── Views/
        │   ├── FilesView.swift
        │   ├── LibraryView.swift
        │   ├── SignConfigView.swift
        │   ├── SourcesView.swift
        │   └── SettingsCertificatesView.swift
        └── Resources/
            └── Info.plist
```
