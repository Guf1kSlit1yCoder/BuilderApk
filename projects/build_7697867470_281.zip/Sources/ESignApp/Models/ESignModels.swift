import Foundation

struct ImportedIPA: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var fileName: String
    var appName: String
    var bundleIdentifier: String
    var version: String
    var fileSize: Int64
    var localPath: String
    var isSigned: Bool
    var signedDate: Date?
}

struct SigningCertificatePair: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var displayName: String
    var teamName: String
    var bundleIdWildcard: String
    var p12Filename: String
    var provisionFilename: String
    var password: String
    var expirationDate: Date
    var isRevoked: Bool = false
}

struct SigningConfiguration {
    var customAppName: String = ""
    var customBundleId: String = ""
    var customVersion: String = ""
    var enableFileSharing: Bool = true
    var removeMinimumOSCheck: Bool = true
    var injectDylibs: [URL] = []
    var installImmediatelyAfterSigning: Bool = true
}

struct ESignRepoManifest: Codable, Identifiable {
    var id: String { identifier ?? name }
    var name: String
    var identifier: String?
    var subtitle: String?
    var iconURL: String?
    var apps: [ESignRepoApp]
}

struct ESignRepoApp: Codable, Identifiable {
    var id: String { bundleIdentifier + version }
    var name: String
    var bundleIdentifier: String
    var developerName: String?
    var version: String
    var versionDate: String?
    var versionDescription: String?
    var downloadURL: String
    var localizedDescription: String?
    var iconURL: String?
    var size: Int64?
}
