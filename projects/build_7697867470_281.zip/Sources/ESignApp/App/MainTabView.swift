import SwiftUI

struct MainTabView: View {
    @EnvironmentObject var store: ESignStore

    var body: some View {
        TabView {
            FilesView()
                .tabItem {
                    Label("Файлы", systemImage: "folder.fill")
                }

            LibraryView()
                .tabItem {
                    Label("Приложения", systemImage: "square.stack.3d.up.fill")
                }

            SourcesView()
                .tabItem {
                    Label("Источники", systemImage: "globe")
                }

            SettingsCertificatesView()
                .tabItem {
                    Label("Настройки", systemImage: "gearshape.fill")
                }
        }
        .tint(.blue)
    }
}
