import SwiftUI

struct LibraryView: View {
    @EnvironmentObject var store: ESignStore
    @State private var selectedSegment = 0
    @State private var ipaToSign: ImportedIPA?

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("Раздел", selection: $selectedSegment) {
                    Text("Неподписанные (\(store.unsignedIPAs.count))").tag(0)
                    Text("Подписанные (\(store.signedIPAs.count))").tag(1)
                }
                .pickerStyle(.segmented)
                .padding()

                List {
                    if selectedSegment == 0 {
                        ForEach(store.unsignedIPAs) { ipa in
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(ipa.appName)
                                        .font(.headline)
                                    Text(ipa.bundleIdentifier)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                Button("Подписать") {
                                    ipaToSign = ipa
                                }
                                .buttonStyle(.borderedProminent)
                                .controlSize(.small)
                            }
                        }
                    } else {
                        ForEach(store.signedIPAs) { signed in
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(signed.appName)
                                        .font(.headline)
                                    Text("\(signed.bundleIdentifier) • v\(signed.version)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                Button {
                                    OTAInstallerService.shared.triggerOTAInstall(for: signed, store: store)
                                } label: {
                                    Label("Установить", systemImage: "iphone.and.arrow.forward")
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(.green)
                                .controlSize(.small)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Приложения")
            .sheet(item: $ipaToSign) { ipa in
                SignConfigView(ipa: ipa)
            }
        }
    }
}
