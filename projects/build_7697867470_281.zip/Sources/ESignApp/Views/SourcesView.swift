import SwiftUI

struct SourcesView: View {
    @EnvironmentObject var store: ESignStore
    @State private var repoURLInput = ""
    @State private var showAddAlert = false

    var body: some View {
        NavigationStack {
            List {
                if store.repositories.isEmpty {
                    ContentUnavailableView(
                        "Нет подключенных источников",
                        systemImage: "globe.badge.chevron.backward",
                        description: Text("Добавьте JSON-источник в формате ESign или AltStore, чтобы скачивать и подписывать IPA прямо в приложении.")
                    )
                } else {
                    ForEach(store.repositories) { repo in
                        Section(repo.name) {
                            ForEach(repo.apps) { app in
                                HStack {
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(app.name)
                                            .font(.headline)
                                        Text("\(app.bundleIdentifier) • v\(app.version)")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Button {
                                        downloadAppIPA(app)
                                    } label: {
                                        Image(systemName: "icloud.and.arrow.down")
                                    }
                                    .buttonStyle(.bordered)
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Источники")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showAddAlert = true
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .alert("Добавить источник (ESign / AltStore JSON)", isPresented: $showAddAlert) {
                TextField("https://example.com/repo.json", text: $repoURLInput)
                    .textInputAutocapitalization(.never)
                Button("Добавить") {
                    fetchRepository(from: repoURLInput)
                }
                Button("Отмена", role: .cancel) {}
            }
        }
    }

    private func fetchRepository(from urlString: String) {
        guard let url = URL(string: urlString.trimmingCharacters(in: .whitespacesAndNewlines)) else { return }
        Task {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                let manifest = try JSONDecoder().decode(ESignRepoManifest.self, from: data)
                store.repositories.append(manifest)
                store.log("Добавлен репозиторий: \(manifest.name) (\(manifest.apps.count) прил.)")
            } catch {
                store.log("Ошибка загрузки источника: \(error.localizedDescription)")
            }
        }
    }

    private func downloadAppIPA(_ app: ESignRepoApp) {
        guard let url = URL(string: app.downloadURL) else { return }
        store.log("Скачивание \(app.name)...")
        Task {
            do {
                let (tempURL, _) = try await URLSession.shared.download(from: url)
                let namedTemp = FileManager.default.temporaryDirectory.appendingPathComponent("\(app.name)_\(app.version).ipa")
                try? FileManager.default.removeItem(at: namedTemp)
                try FileManager.default.moveItem(at: tempURL, to: namedTemp)
                store.importIPAFile(from: namedTemp)
            } catch {
                store.log("Ошибка скачивания \(app.name): \(error.localizedDescription)")
            }
        }
    }
}
