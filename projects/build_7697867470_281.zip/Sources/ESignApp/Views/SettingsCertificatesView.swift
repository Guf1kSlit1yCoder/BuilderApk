import SwiftUI
import UniformTypeIdentifiers

struct SettingsCertificatesView: View {
    @EnvironmentObject var store: ESignStore
    @State private var p12URL: URL?
    @State private var provisionURL: URL?
    @State private var password = ""
    @State private var alias = ""
    @State private var pickingP12 = false
    @State private var pickingProvision = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Импорт нового сертификата (.p12 + .mobileprovision)") {
                    Button {
                        pickingP12 = true
                    } label: {
                        HStack {
                            Label("Файл .p12", systemImage: "key.fill")
                            Spacer()
                            Text(p12URL?.lastPathComponent ?? "Выбрать")
                                .foregroundStyle(.secondary)
                        }
                    }

                    Button {
                        pickingProvision = true
                    } label: {
                        HStack {
                            Label("Файл .mobileprovision", systemImage: "doc.badge.gearshape")
                            Spacer()
                            Text(provisionURL?.lastPathComponent ?? "Выбрать")
                                .foregroundStyle(.secondary)
                        }
                    }

                    SecureField("Пароль от .p12", text: $password)
                    TextField("Название (необязательно)", text: $alias)

                    Button("Сохранить сертификат") {
                        if let p12URL, let provisionURL {
                            store.importCertificate(p12URL: p12URL, provisionURL: provisionURL, password: password, alias: alias)
                            self.p12URL = nil
                            self.provisionURL = nil
                            self.password = ""
                            self.alias = ""
                        }
                    }
                    .disabled(p12URL == nil || provisionURL == nil)
                }

                Section("Установленные сертификаты (\(store.certificates.count))") {
                    ForEach(store.certificates) { cert in
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text(cert.displayName)
                                    .font(.headline)
                                Spacer()
                                Text("Активен")
                                    .font(.caption2)
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 2)
                                    .background(Color.green.opacity(0.15))
                                    .foregroundStyle(.green)
                                    .clipShape(Capsule())
                            }
                            Text("Team: \(cert.teamName) • App ID: \(cert.bundleIdWildcard)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text("Истекает: \(cert.expirationDate.formatted(date: .abbreviated, time: .omitted))")
                                .font(.caption2)
                                .foregroundStyle(.tertiary)
                        }
                    }
                    .onDelete { offsets in
                        store.certificates.remove(atOffsets: offsets)
                        store.saveStoredState()
                    }
                }
            }
            .navigationTitle("Сертификаты")
            .fileImporter(isPresented: $pickingP12, allowedContentTypes: [.pkcs12, .data]) { res in
                if case .success(let url) = res { p12URL = url }
            }
            .fileImporter(isPresented: $pickingProvision, allowedContentTypes: [.data]) { res in
                if case .success(let url) = res { provisionURL = url }
            }
        }
    }
}
