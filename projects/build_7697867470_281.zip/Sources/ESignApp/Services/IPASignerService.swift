import Foundation
import ZIPFoundation
import ZsignSwift

final class IPASignerService {
    static let shared = IPASignerService()
    private init() {}

    func inspectIPA(at ipaURL: URL) -> (appName: String, bundleId: String, version: String) {
        let fm = FileManager.default
        let tempDir = fm.temporaryDirectory.appendingPathComponent("inspect_\(UUID().uuidString)")
        defer { try? fm.removeItem(at: tempDir) }

        do {
            try fm.createDirectory(at: tempDir, withIntermediateDirectories: true)
            try fm.unzipItem(at: ipaURL, to: tempDir)
            let payloadDir = tempDir.appendingPathComponent("Payload")
            guard let contents = try? fm.contentsOfDirectory(at: payloadDir, includingPropertiesForKeys: nil),
                  let appBundle = contents.first(where: { $0.pathExtension == "app" }) else {
                return (ipaURL.deletingPathExtension().lastPathComponent, "com.unknown.app", "1.0")
            }
            let infoPlistURL = appBundle.appendingPathComponent("Info.plist")
            guard let plistData = try? Data(contentsOf: infoPlistURL),
                  let dict = try? PropertyListSerialization.propertyList(from: plistData, format: nil) as? [String: Any] else {
                return (appBundle.deletingPathExtension().lastPathComponent, "com.unknown.app", "1.0")
            }
            let displayName = (dict["CFBundleDisplayName"] as? String)
                ?? (dict["CFBundleName"] as? String)
                ?? appBundle.deletingPathExtension().lastPathComponent
            let bundleId = (dict["CFBundleIdentifier"] as? String) ?? "com.unknown.app"
            let version = (dict["CFBundleShortVersionString"] as? String)
                ?? (dict["CFBundleVersion"] as? String)
                ?? "1.0"
            return (displayName, bundleId, version)
        } catch {
            return (ipaURL.deletingPathExtension().lastPathComponent, "com.unknown.app", "1.0")
        }
    }

    func signIPA(
        sourceIPA: ImportedIPA,
        certificate: SigningCertificatePair,
        certsDir: URL,
        signedOutputDir: URL,
        config: SigningConfiguration,
        logHandler: @escaping (String) -> Void
    ) async throws -> ImportedIPA {
        let fm = FileManager.default
        let workDir = fm.temporaryDirectory.appendingPathComponent("esign_work_\(UUID().uuidString)")
        try fm.createDirectory(at: workDir, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: workDir) }

        let sourceURL = URL(fileURLWithPath: sourceIPA.localPath)
        logHandler("Распаковка архива \(sourceIPA.fileName)...")
        try fm.unzipItem(at: sourceURL, to: workDir)

        let payloadDir = workDir.appendingPathComponent("Payload")
        let contents = try fm.contentsOfDirectory(at: payloadDir, includingPropertiesForKeys: nil)
        guard let appBundle = contents.first(where: { $0.pathExtension == "app" }) else {
            throw NSError(domain: "ESign", code: 404, userInfo: [NSLocalizedDescriptionKey: "Папка Payload/*.app не найдена внутри IPA"])
        }

        // Apply Info.plist overrides if requested
        let infoPlistURL = appBundle.appendingPathComponent("Info.plist")
        let finalAppName = config.customAppName.isEmpty ? sourceIPA.appName : config.customAppName
        let finalBundleId = config.customBundleId.isEmpty ? sourceIPA.bundleIdentifier : config.customBundleId
        let finalVersion = config.customVersion.isEmpty ? sourceIPA.version : config.customVersion

        if let plistData = try? Data(contentsOf: infoPlistURL),
           var dict = try? PropertyListSerialization.propertyList(from: plistData, options: .mutableContainersAndLeaves, format: nil) as? [String: Any] {
            dict["CFBundleDisplayName"] = finalAppName
            dict["CFBundleIdentifier"] = finalBundleId
            dict["CFBundleShortVersionString"] = finalVersion
            if config.enableFileSharing {
                dict["UIFileSharingEnabled"] = true
                dict["LSSupportsOpeningDocumentsInPlace"] = true
            }
            if config.removeMinimumOSCheck {
                dict["MinimumOSVersion"] = "14.0"
            }
            if let updatedData = try? PropertyListSerialization.data(fromPropertyList: dict, format: .xml, options: 0) {
                try? updatedData.write(to: infoPlistURL)
            }
        }

        let p12Path = certsDir.appendingPathComponent(certificate.p12Filename).path
        let provPath = certsDir.appendingPathComponent(certificate.provisionFilename).path

        logHandler("Подпись Mach-O через Zsign (сертификат: \(certificate.displayName))...")
        let signSuccess = Zsign.sign(
            appPath: appBundle.path,
            provisionPath: provPath,
            p12Path: p12Path,
            p12Password: certificate.password,
            entitlementsPath: "",
            customIdentifier: finalBundleId,
            customName: finalAppName,
            customVersion: finalVersion,
            adhoc: false,
            removeProvision: false
        )

        if !signSuccess {
            throw NSError(domain: "ESign", code: 500, userInfo: [NSLocalizedDescriptionKey: "Zsign вернул ошибку при подписи бинарного файла. Проверьте пароль .p12 и валидность .mobileprovision."])
        }

        let outputFileName = "\(finalAppName.replacingOccurrences(of: " ", with: "_"))_\(finalVersion)_signed.ipa"
        let outputURL = signedOutputDir.appendingPathComponent(outputFileName)
        if fm.fileExists(atPath: outputURL.path) {
            try fm.removeItem(at: outputURL)
        }

        logHandler("Упаковка подписанного IPA: \(outputFileName)...")
        try fm.zipItem(at: payloadDir, to: outputURL, shouldKeepParent: true, compressionMethod: .deflate)

        let attrs = try fm.attributesOfItem(atPath: outputURL.path)
        let size = (attrs[.size] as? Int64) ?? sourceIPA.fileSize

        return ImportedIPA(
            fileName: outputFileName,
            appName: finalAppName,
            bundleIdentifier: finalBundleId,
            version: finalVersion,
            fileSize: size,
            localPath: outputURL.path,
            isSigned: true,
            signedDate: Date()
        )
    }
}
