#pragma once
// ──────────────────────────────────────────────────────────────────────────────
//  Э5.1 — runtime code integrity + page protection.
//
//  At init we locate our own module's executable (r-x) pages and hash them with
//  native SHA-256 -> the clean baseline. Verify() re-hashes and compares. A crack
//  that patches our code in memory (NOPs the Authorized() branch, installs an
//  inline hook on the license path, redirects a call) changes those bytes, so the
//  hash diverges and we report tampering. The auth gate folds this in: a tampered
//  image can never read as authorized.
//
//  We also mprotect the exec pages to R+X (drop any writable bit), so patching in
//  place first requires an mprotect back to writable — one more step, and the
//  result is still caught by the hash.
//
//  Scope (honest): this catches RUNTIME memory patching. A static patch of the
//  .so file before load shifts the baseline too, so that case is covered by the
//  server-side file checksum / killswitch and by Э3 obfuscation, not here.
// ──────────────────────────────────────────────────────────────────────────────
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdio>
#include <atomic>
#include <dlfcn.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <string>
#include "Sha256.h"
#include "Syscalls.h"
#include "ObfStr.h"

namespace AntiCrack {

class Integrity {
public:
    static Integrity& I() { static Integrity g; return g; }

    // Call once after load (background thread). Establishes the clean baseline.
    void Init() {
        if (m_inited.load()) return;
        uint8_t h[32];
        if (HashModule(h, /*enforceRX=*/true)) {
            memcpy(m_baseline, h, 32);
            m_haveBaseline = true;
        }
        m_inited.store(true);
    }

    // Re-hash the exec pages and compare to the baseline. True = intact.
    bool Verify() {
        if (!m_haveBaseline) return true;     // couldn't baseline -> don't brick
        uint8_t h[32];
        if (!HashModule(h, /*enforceRX=*/false)) return true;
        bool ok = (memcmp(h, m_baseline, 32) == 0);
        m_ok.store(ok);
        return ok;
    }

    bool Ok() const { return m_ok.load(); }

private:
    Integrity() : m_inited(false), m_haveBaseline(false), m_ok(true) {}

    // Locate our module's r-x ranges from /proc/self/maps (path == our .so) and
    // SHA-256 them in order. Optionally re-assert R+X on each range.
        bool HashModule(uint8_t out[32], bool enforceRX) {
        // Our own library path, via dladdr on a symbol in this module.
        Dl_info info;
        if (dladdr(reinterpret_cast<void*>(&Integrity::HashModuleAnchor), &info) == 0 || !info.dli_fname)
            return false;
        const char* self = info.dli_fname;

        // Read /proc/self/maps via direct syscalls (no libc fopen in the path).
        int fd = sc::sys_open(OBFSTR("/proc/self/maps"), O_RDONLY);
        if (fd < 0) return false;
        std::string maps; char rb[8192]; ssize_t rn;
        while ((rn = sc::sys_read(fd, rb, sizeof(rb))) > 0) maps.append(rb, (size_t)rn);
        sc::sys_close(fd);

        Sha256 sha;
        bool any = false;
        size_t pos = 0;
        while (pos < maps.size()) {
            size_t nl = maps.find('\n', pos);
            std::string line = maps.substr(pos, nl == std::string::npos ? std::string::npos : nl - pos);
            pos = (nl == std::string::npos) ? maps.size() : nl + 1;

            // format: start-end perms off dev inode   pathname
            uintptr_t start = 0, end = 0;
            char perms[8] = {0};
            char path[256] = {0};
            if (sscanf(line.c_str(), "%lx-%lx %7s %*s %*s %*s %255[^\n]", &start, &end, perms, path) < 3)
                continue;
            if (perms[2] != 'x') continue;               // executable only
            const char* p = path; while (*p == ' ') ++p;
            if (!*p || strcmp(p, self) != 0) continue;
            if (end <= start) continue;

            if (enforceRX) {
                sc::sys_mprotect(reinterpret_cast<void*>(start), end - start, PROT_READ | PROT_EXEC);
            }
            sha.Update(reinterpret_cast<const void*>(start), end - start);
            any = true;
        }
        if (!any) return false;
        sha.Final(out);
        return true;
    }

    // Address anchor used by dladdr to resolve this module.
    static void HashModuleAnchor() {}

    std::atomic<bool> m_inited;
    bool              m_haveBaseline;
    uint8_t           m_baseline[32];
    std::atomic<bool> m_ok;
};

} // namespace AntiCrack
