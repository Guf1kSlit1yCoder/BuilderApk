#pragma once
// GENERATED (position-masked) - session-key check for AntiCrack/VmCore.h.
// Program: returns 1 iff MIX(in0)==in1, i.e. sessionCheck == MIX(sessionKey).
#include <cstdint>
#include <cstddef>
namespace AntiCrack {
static const uint8_t g_SessionBytecode[] = {0x59,0x00,0x38,0x59,0x01,0x78,0xa5};
static const size_t  g_SessionBytecodeLen = sizeof(g_SessionBytecode);
} // namespace AntiCrack