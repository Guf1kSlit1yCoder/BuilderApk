#pragma once
#include "UE4Helper.h"
#include "Config.h"
#include "ActorPipeline.h"
#include "ImGui/imgui.h"
#include <vector>
#include <string>

namespace ESP {
    struct PlayerData {
        SDK::ASGCharacter* actor = nullptr;
        SDK::FVector rootPos{0,0,0};
        SDK::FVector headPos{0,0,0};
        SDK::FVector feetPos{0,0,0};
        SDK::FVector2D rootScreen{0,0};
        SDK::FVector2D headScreen{0,0};
        SDK::FVector2D feetScreen{0,0};
        float boxLeft = 0.0f;
        float boxTop = 0.0f;
        float boxWidth = 0.0f;
        float boxHeight = 0.0f;
        float distance = 0.0f;
        float health = -1.0f;
        float maxHealth = -1.0f;
        int teamId = 0;
        std::string name;
        std::string weapon;
        bool isBot = false;
        bool isNPC = false;      // MFNPCAI actor — shown as "ACTOR"
        bool isTeammate = false;
        bool isKnocked = false;
        bool isVisible = false;
        bool onScreen = false;
        bool stale = false;         // frozen ghost (left relevancy)
        bool proxyOnly = false;     // emitted from a proxy with no loaded character
        uint16_t boneVisible = 0;   // bit i == skeleton bone i
        bool boneVisLive = false;
    };

    extern std::vector<PlayerData> g_Enemies;

    void RenderImGuiESP(ImDrawList* drawList, int screenWidth, int screenHeight);
    
    void DrawPlayerBox(ImDrawList* drawList, const PlayerData& player);
    // With boneVisLive, each half-segment is green (bone open) or grey (bone behind cover).
    void DrawPlayerSkeleton(ImDrawList* drawList, SDK::ASGCharacter* actor, ImU32 color, const UE4Helper::ScreenProjection& projection,
                            bool boneVisLive = false, uint16_t boneVisible = 0,
                            ImU32 openColor = IM_COL32(40, 255, 90, 255),
                            ImU32 coveredColor = IM_COL32(150, 150, 150, 210));
    // style: 0 = PLAYER (vertical, gradient), 1 = BOT (vertical, solid green), 2 = NPC (horizontal, cyan), 3 = TEAM (vertical, blue)
    void DrawHealthBar(ImDrawList* drawList, float x, float y, float width, float height, float health, float maxHealth, bool isVertical = false, int style = 0);
    void DrawRadar(ImDrawList* drawList, const SDK::FVector& localPos, const SDK::FRotator& localRot, const std::vector<PlayerData>& enemies, int screenWidth, int screenHeight);
    
    // ZOLO UpAlert (360° Off-Screen Directional Indicator)
    void DrawUpAlert(ImDrawList* drawList, const SDK::FVector& localPos, float camYaw, const std::vector<PlayerData>& enemies, int screenWidth, int screenHeight);

    // Floating Draggable & Lockable Ammo Counter HUD
    void DrawAmmoHUD(SDK::ASGCharacter* localPlayer, int screenWidth, int screenHeight);
}
