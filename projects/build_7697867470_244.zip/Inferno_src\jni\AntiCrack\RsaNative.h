#pragma once
// ──────────────────────────────────────────────────────────────────────────────
//  Native RSA-2048 PKCS#1 v1.5 (SHA-256) signature verification.
//
//  The old path verified the server signature through java.security.Signature
//  over JNI. That is one Frida hook away from "return true": the entire license
//  check collapsed to a boolean an attacker owns. This verifier runs entirely in
//  native code — there is no Java method in the trust path to hook.
//
//  e = 65537, n = 2048-bit modulus embedded below (XOR-veiled so a static grep
//  for the key bytes / a trivial key-swap is a little harder; real security is
//  that the attacker cannot forge s such that s^e mod n reproduces our padding).
//
//  Verify() returns the recovered 32-byte hash so the caller can fold it into a
//  branchless authorization value instead of branching on a bool.
// ──────────────────────────────────────────────────────────────────────────────
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <string>
#include "Sha256.h"

namespace AntiCrack {

namespace _rsa {

    // 2048-bit modulus n, stored big-endian and XOR-veiled with 0x5A.
    // Deobfuscated once into a local buffer on use.
    static const uint8_t N_VEIL[256] = {
        0xff,0xa4,0x1d,0x2f,0x01,0x0d,0xe7,0xde,0xee,0xb7,0x51,0x94,0x88,0x7b,0xa1,0xfd,
        0xbc,0xb7,0x62,0x26,0x9e,0x9f,0x01,0x52,0x01,0xf6,0x31,0x10,0xeb,0x15,0xd4,0xfc,
        0xf8,0x01,0x49,0x1a,0xfe,0x11,0x92,0xfc,0x51,0x5f,0x3a,0xe0,0xf9,0x07,0x1b,0xdd,
        0xe6,0xf7,0x35,0xc0,0x66,0x09,0x6c,0x35,0x44,0xd7,0x93,0x54,0x1e,0xfa,0xcb,0xf0,
        0x3b,0x10,0x28,0x68,0xdb,0x6e,0x86,0x78,0x79,0xcf,0x66,0xfb,0xa6,0xce,0x6f,0x2f,
        0x37,0xd4,0x68,0x00,0x75,0x8e,0x13,0x6b,0xa0,0xed,0xed,0x80,0x9c,0x72,0x55,0xd3,
        0x07,0x42,0x8c,0xe8,0xb8,0x5d,0x9e,0x07,0xd7,0x7f,0x79,0x99,0x6d,0x53,0x79,0x25,
        0x17,0xa8,0x75,0x88,0x63,0xa1,0x64,0x4d,0x39,0x1c,0x5f,0x83,0x2c,0x7e,0xc9,0xb9,
        0x48,0x97,0x24,0xfc,0x0c,0xc6,0xc4,0x9c,0x2f,0xa5,0xc7,0x19,0xf7,0x48,0x0f,0x7e,
        0x93,0x05,0x75,0x8d,0x60,0x7a,0xeb,0xa8,0x9d,0xfe,0xb0,0x8c,0xbc,0x0d,0x2a,0x39,
        0x25,0x27,0xc4,0x58,0x4f,0xb5,0x79,0xab,0x8b,0xdf,0x78,0x2f,0x85,0xe7,0x6c,0x85,
        0x8f,0xb9,0xe8,0x19,0x16,0x04,0x33,0x0f,0x94,0xc9,0xc5,0x70,0x9d,0x95,0x45,0x9b,
        0x35,0xfd,0x34,0x41,0xe0,0x63,0x8e,0x5d,0xba,0x4b,0x5b,0xe4,0x23,0x5a,0x41,0xb1,
        0x46,0x47,0xd5,0x4f,0xf5,0x26,0x8b,0xfd,0x05,0x8f,0x02,0x22,0x16,0xa6,0xfc,0x62,
        0x6a,0xe9,0xdb,0x22,0x26,0xb0,0x3f,0xf1,0x57,0x28,0x9d,0x40,0xd1,0xc6,0x14,0xc0,
        0xc5,0x99,0x01,0x06,0xa4,0x73,0x5e,0x62,0xf6,0xc3,0x6b,0x94,0x31,0x46,0xce,0xd7
    };
    static const uint8_t N_KEY = 0x5A;

    static const uint8_t DIGEST_PREFIX[19] = {
        0x30,0x31,0x30,0x0d,0x06,0x09,0x60,0x86,0x48,0x01,0x65,0x03,0x04,0x02,0x01,0x05,0x00,0x04,0x20
    };

    static const int LN = 65;  // limbs (little-endian, base 2^32), one extra for add carry

    struct Big { uint32_t d[LN]; };

    static void zero(Big& x) { memset(x.d, 0, sizeof(x.d)); }

    // Big-endian 256-byte buffer -> little-endian limbs.
    static void from_be(Big& x, const uint8_t be[256]) {
        zero(x);
        for (int i = 0; i < 64; ++i) {
            int bo = 256 - 4 - i * 4;
            x.d[i] = ((uint32_t)be[bo] << 24) | ((uint32_t)be[bo+1] << 16)
                   | ((uint32_t)be[bo+2] << 8) | ((uint32_t)be[bo+3]);
        }
    }

    static int cmp(const Big& a, const Big& b) {
        for (int i = LN - 1; i >= 0; --i) {
            if (a.d[i] != b.d[i]) return a.d[i] < b.d[i] ? -1 : 1;
        }
        return 0;
    }

    // r = a - b (assumes a >= b)
    static void sub(Big& r, const Big& a, const Big& b) {
        uint64_t borrow = 0;
        for (int i = 0; i < LN; ++i) {
            uint64_t t = (uint64_t)a.d[i] - b.d[i] - borrow;
            r.d[i] = (uint32_t)t;
            borrow = (t >> 63) & 1;
        }
    }

    // r = (a + b) mod n   (a, b < n)
    static void addmod(Big& r, const Big& a, const Big& b, const Big& n) {
        uint64_t carry = 0;
        for (int i = 0; i < LN; ++i) {
            uint64_t t = (uint64_t)a.d[i] + b.d[i] + carry;
            r.d[i] = (uint32_t)t;
            carry = t >> 32;
        }
        if (cmp(r, n) >= 0) sub(r, r, n);
    }

    static bool is_odd(const Big& x) { return x.d[0] & 1; }
    static void shr1(Big& x) {
        uint32_t carry = 0;
        for (int i = LN - 1; i >= 0; --i) {
            uint32_t nc = x.d[i] & 1;
            x.d[i] = (x.d[i] >> 1) | (carry << 31);
            carry = nc;
        }
    }
    static bool is_zero(const Big& x) {
        for (int i = 0; i < LN; ++i) if (x.d[i]) return false;
        return true;
    }

    // r = (a * b) mod n  via double-and-add (Russian peasant). Robust, constant
    // structure, fine for a one-shot login. a, b < n.
    static void mulmod(Big& r, const Big& a, const Big& b, const Big& n) {
        Big res; zero(res);
        Big acc = a;                 // acc < n
        Big bb  = b;
        while (!is_zero(bb)) {
            if (is_odd(bb)) addmod(res, res, acc, n);
            addmod(acc, acc, acc, n);   // double
            shr1(bb);
        }
        r = res;
    }

    // out = base^65537 mod n  (big-endian 256-byte result)
    static void modexp_e65537(uint8_t out[256], const uint8_t sig_be[256], const Big& n) {
        Big base; from_be(base, sig_be);
        // base must be < n to be a valid signature element
        if (cmp(base, n) >= 0) { memset(out, 0, 256); return; }

        Big res; zero(res); res.d[0] = 1;   // 1
        Big b = base;
        uint32_t e = 65537;
        while (e) {
            if (e & 1) { Big t; mulmod(t, res, b, n); res = t; }
            e >>= 1;
            if (e) { Big t; mulmod(t, b, b, n); b = t; }
        }
        // little-endian limbs -> big-endian bytes
        for (int i = 0; i < 64; ++i) {
            int bo = 256 - 4 - i * 4;
            out[bo]   = (uint8_t)(res.d[i] >> 24);
            out[bo+1] = (uint8_t)(res.d[i] >> 16);
            out[bo+2] = (uint8_t)(res.d[i] >> 8);
            out[bo+3] = (uint8_t)(res.d[i]);
        }
    }

} // namespace _rsa

// Verify a PKCS#1 v1.5 (SHA-256) signature over `payload`.
// sig = raw 256-byte signature (big-endian).
// On a structurally valid recovery, fills recovered[32] with the hash carried
// inside the signature and returns true. The caller folds `recovered` against
// its own SHA-256(payload) to build a branchless gate — a forged/short-circuited
// verify cannot reproduce the padded structure *and* the embedded hash.
inline bool RsaVerifySha256(const std::string& payload, const uint8_t* sig, size_t siglen,
                            uint8_t recovered[32]) {
    memset(recovered, 0, 32);
    if (siglen != 256) return false;

    // Deobfuscate modulus.
    uint8_t n_be[256];
    for (int i = 0; i < 256; ++i) n_be[i] = _rsa::N_VEIL[i] ^ _rsa::N_KEY;
    _rsa::Big n; _rsa::from_be(n, n_be);

    uint8_t em[256];
    _rsa::modexp_e65537(em, sig, n);

    // PKCS#1 v1.5 structure: 00 01 FF..FF 00 DigestInfo(19) Hash(32)
    bool ok = (em[0] == 0x00) && (em[1] == 0x01);
    int i = 2;
    int ffcount = 0;
    while (i < 256 && em[i] == 0xFF) { ++i; ++ffcount; }
    ok = ok && (ffcount >= 8) && (i < 256) && (em[i] == 0x00);
    ++i;
    // DigestInfo
    for (int k = 0; k < 19; ++k) ok = ok && (i < 256) && (em[i++] == _rsa::DIGEST_PREFIX[k]);
    // 32-byte hash must sit exactly at the tail
    ok = ok && (i + 32 == 256);

    // Compare against our own hash of the payload.
    uint8_t have[32]; AntiCrack::Sha256::Hash(payload, have);
    for (int k = 0; k < 32; ++k) {
        recovered[k] = (i + k < 256) ? em[i + k] : 0;
        ok = ok && (recovered[k] == have[k]);
    }
    return ok;
}

} // namespace AntiCrack
