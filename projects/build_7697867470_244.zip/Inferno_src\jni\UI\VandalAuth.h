#pragma once
#include "imgui.h"

namespace VandalAuth {
    void InitFonts(ImGuiIO& io);
    void Render(int screenWidth, int screenHeight);
    bool IsDone();
}
