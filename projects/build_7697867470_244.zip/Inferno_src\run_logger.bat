﻿@echo off
setlocal
set ADB=C:\Users\GAMER\AppData\Local\Android\Sdk\platform-tools\adb.exe

if not exist %ADB% (
    set ADB=adb
)

echo ========================================================
echo  [Arena Android] Запуск логирования в реальном времени
echo  Фильтр: ArenaAndroid, DEBUG, crash_dump
echo  Файловый лог на устройстве: /sdcard/Download/arena_log.txt
echo ========================================================
echo.

%ADB% logcat -v time -s ArenaAndroid:V DEBUG:V crash_dump:V
pause
