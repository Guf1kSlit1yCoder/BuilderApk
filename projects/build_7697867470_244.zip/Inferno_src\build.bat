@echo off
setlocal enabledelayedexpansion

echo ========================================================
echo Building Arena ESP for Android (arm64-v8a)
echo ========================================================

set NDK_PATH=C:\Users\GAMER\AppData\Local\Android\Sdk\ndk\27.0.12077973
set NINJA_PATH=C:\Users\GAMER\AppData\Local\Android\Sdk\cmake\3.22.1\bin\ninja.exe
set TOOLCHAIN=%NDK_PATH%\build\cmake\android.toolchain.cmake

if not exist "%NDK_PATH%" (
    if defined ANDROID_NDK_HOME set NDK_PATH=%ANDROID_NDK_HOME%
    if defined NDK_ROOT set NDK_PATH=%NDK_ROOT%
)

echo [1/3] Preparing build directory...
if not exist build_cmake mkdir build_cmake
cd build_cmake

echo [2/3] Configuring with CMake ^& Ninja...
cmake -G "Ninja" -DCMAKE_MAKE_PROGRAM="%NINJA_PATH%" -DCMAKE_TOOLCHAIN_FILE="%TOOLCHAIN%" -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-21 -DCMAKE_BUILD_TYPE=Release ..
if errorlevel 1 (
    echo [WARNING] CMake configuration failed. Cleaning build cache and retrying...
    cd ..
    rmdir /s /q build_cmake
    mkdir build_cmake
    cd build_cmake
    cmake -G "Ninja" -DCMAKE_MAKE_PROGRAM="%NINJA_PATH%" -DCMAKE_TOOLCHAIN_FILE="%TOOLCHAIN%" -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-21 -DCMAKE_BUILD_TYPE=Release ..
    if errorlevel 1 (
        echo [ERROR] CMake configuration failed after cleaning cache.
        cd ..
        exit /b 1
    )
)

echo [3/3] Building shared library...
cmake --build . -j8
if errorlevel 1 (
    echo [ERROR] Build failed during compilation.
    cd ..
    exit /b 1
)

cd ..

if exist "build_cmake\jni\libarena_esp.so" (
    if not exist "libs\arm64-v8a" mkdir "libs\arm64-v8a"
    copy /Y "build_cmake\jni\libarena_esp.so" "libs\arm64-v8a\libarena_esp.so"
    echo.
    echo ========================================================
    echo [SUCCESS] Build completed successfully!
    echo Binary: libs\arm64-v8a\libarena_esp.so
    echo ========================================================
) else (
    echo [ERROR] Build output libarena_esp.so not found. Check compiler logs.
    exit /b 1
)

