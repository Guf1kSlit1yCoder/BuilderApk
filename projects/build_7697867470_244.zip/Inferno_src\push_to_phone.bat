@echo off
set ADB="C:\Users\GAMER\AppData\Local\Android\Sdk\platform-tools\adb.exe"
echo Waiting for device...
%ADB% wait-for-device
echo Pushing libarena_esp.so to /data/local/tmp/...
%ADB% push libs\arm64-v8a\libarena_esp.so /data/local/tmp/libarena_esp.so
%ADB% push libs\arm64-v8a\libc++_shared.so /data/local/tmp/libc++_shared.so
%ADB% shell "su -c 'chmod 777 /data/local/tmp/libarena_esp.so /data/local/tmp/libc++_shared.so'"
echo [SUCCESS] Libraries deployed to /data/local/tmp/
