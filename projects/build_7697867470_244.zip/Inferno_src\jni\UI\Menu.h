#pragma once
#include <cstdint>
#include <string>
#include "Config.h"
#include "SDK/SDK.hpp"
#include "ImGui/imgui.h"

// Forward declaration: defined in Main.cpp
// Initiates a safe, asynchronous mod unload sequence.
void RequestUnload();

namespace Menu {
    extern bool g_ShowMenu;
    extern bool g_Initialized;

    extern char  g_KeyInput[128];
    extern bool  g_LoginBusy;
    extern bool  g_LoginFailed;

    void InitStyle();
    void UpdateInput(SDK::APlayerController* ctrl);
    void Render(int screenWidth, int screenHeight);
    void RenderFloatingButton(int screenWidth, int screenHeight);
    void RenderMainUI(int screenWidth, int screenHeight);
    void RenderLoginUI(int screenWidth, int screenHeight);
}
