#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/uio.h>
#include <dirent.h>

static pid_t g_Pid = -1;
static uintptr_t g_LibBase = 0;

static bool ReadMem(uintptr_t addr, void* buf, size_t size) {
    if (addr < 0x10000ULL || addr > 0x00007FFFFFFFFFFFULL) return false;
    struct iovec local = { buf, size };
    struct iovec remote = { (void*)addr, size };
    ssize_t n = process_vm_readv(g_Pid, &local, 1, &remote, 1, 0);
    return (n == (ssize_t)size);
}

int main(int argc, char** argv) {
    DIR* dir = opendir("/proc");
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type != DT_DIR) continue;
        int pid = atoi(entry->d_name);
        if (pid <= 0) continue;
        char cmdlinePath[64];
        snprintf(cmdlinePath, sizeof(cmdlinePath), "/proc/%d/cmdline", pid);
        FILE* fp = fopen(cmdlinePath, "r");
        if (fp) {
            char cmdline[256] = {};
            fread(cmdline, 1, sizeof(cmdline) - 1, fp);
            fclose(fp);
            if (strstr(cmdline, "com.eu.mf.uamo")) {
                g_Pid = pid;
                break;
            }
        }
    }
    closedir(dir);
    if (g_Pid <= 0) return 1;

    char mapsPath[64];
    snprintf(mapsPath, sizeof(mapsPath), "/proc/%d/maps", g_Pid);
    FILE* f = fopen(mapsPath, "r");
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, "libUE4.so") && strstr(line, "r--p") && !strstr(line, "anon")) {
            sscanf(line, "%lx-", &g_LibBase);
            break;
        }
    }
    fclose(f);

    uintptr_t addr = 0;
    if (argc > 1) {
        uintptr_t rva = strtoull(argv[1], NULL, 16);
        addr = g_LibBase + rva;
    } else {
        addr = g_LibBase + 0x5865F14;
    }

    uint32_t buf[32] = {};
    ReadMem(addr, buf, sizeof(buf));
    printf("ADDR: 0x%lx (RVA: 0x%lx)\n", addr, addr - g_LibBase);
    for (int i = 0; i < 32; i++) {
        printf("%08X ", buf[i]);
        if ((i + 1) % 8 == 0) printf("\n");
    }
    printf("\n");
    return 0;
}
