#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <math.h>

static pid_t g_Pid = -1;

static bool ReadMem(uintptr_t addr, void* buf, size_t size) {
    if (addr < 0x10000ULL || addr > 0x00007FFFFFFFFFFFULL) return false;
    struct iovec local = { buf, size };
    struct iovec remote = { (void*)addr, size };
    ssize_t n = process_vm_readv(g_Pid, &local, 1, &remote, 1, 0);
    return (n == (ssize_t)size);
}

template<typename T>
static T ReadVal(uintptr_t addr, T defVal = T()) {
    T val = defVal;
    ReadMem(addr, &val, sizeof(T));
    return val;
}

static uintptr_t ReadPtr(uintptr_t addr) {
    return ReadVal<uintptr_t>(addr, 0);
}

static int32_t ReadI32(uintptr_t addr) {
    return ReadVal<int32_t>(addr, 0);
}

struct FVector {
    float X, Y, Z;
};

struct FQuat {
    float X, Y, Z, W;
    FVector RotateVector(const FVector& v) const {
        FVector qv = {X, Y, Z};
        FVector t = {
            2.0f * (qv.Y * v.Z - qv.Z * v.Y),
            2.0f * (qv.Z * v.X - qv.X * v.Z),
            2.0f * (qv.X * v.Y - qv.Y * v.X)
        };
        return {
            v.X + W * t.X + (qv.Y * t.Z - qv.Z * t.Y),
            v.Y + W * t.Y + (qv.Z * t.X - qv.X * t.Z),
            v.Z + W * t.Z + (qv.X * t.Y - qv.Y * t.X)
        };
    }
};

static inline FVector operator+(const FVector& a, const FVector& b) {
    return { a.X + b.X, a.Y + b.Y, a.Z + b.Z };
}

struct FTransform {
    FQuat Rotation;
    FVector Translation;
    FVector Scale3D; // 0x1C, matches CoreUObject.Transform in the SDK dump
    uint8_t Pad_0x28[0x8];

    FVector TransformPosition(const FVector& v) const {
        FVector scaled = { v.X * Scale3D.X, v.Y * Scale3D.Y, v.Z * Scale3D.Z };
        return Rotation.RotateVector(scaled) + Translation;
    }
};

static uintptr_t GetLibBase(const char* libName) {
    char mapsPath[64];
    snprintf(mapsPath, sizeof(mapsPath), "/proc/%d/maps", g_Pid);
    FILE* f = fopen(mapsPath, "r");
    if (!f) return 0;
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, libName) && strstr(line, "r--p") && !strstr(line, "anon")) {
            sscanf(line, "%lx-", &base);
            break;
        }
    }
    fclose(f);
    return base;
}

static void InspectMesh(const char* label, uintptr_t mesh) {
    printf("\n=== [%s] Mesh: 0x%lx ===\n", label, mesh);
    if (!mesh) return;

    FTransform c2w;
    ReadMem(mesh + 0x190, &c2w, sizeof(c2w));
    printf("ComponentToWorld (+0x190):\n");
    printf("  Translation: (%.2f, %.2f, %.2f)\n", c2w.Translation.X, c2w.Translation.Y, c2w.Translation.Z);
    printf("  Rotation: (%.4f, %.4f, %.4f, %.4f)\n", c2w.Rotation.X, c2w.Rotation.Y, c2w.Rotation.Z, c2w.Rotation.W);
    printf("  Scale3D: (%.2f, %.2f, %.2f)\n", c2w.Scale3D.X, c2w.Scale3D.Y, c2w.Scale3D.Z);

    uintptr_t masterPose = ReadPtr(mesh + 0x6D8);
    printf("MasterPoseComponent (+0x6D8): 0x%lx\n", masterPose);
    if (masterPose) {
        printf("  [NOTE] Has MasterPoseComponent! Let's check master:\n");
        uintptr_t masterCst = ReadPtr(masterPose + 0x9B8);
        int32_t masterNum = ReadI32(masterPose + 0x9B8 + 8);
        printf("  Master CST (+0x9B8): data=0x%lx, num=%d\n", masterCst, masterNum);
    }

    uintptr_t cstData = ReadPtr(mesh + 0x9B8);
    int32_t cstNum = ReadI32(mesh + 0x9B8 + 8);
    int32_t cstMax = ReadI32(mesh + 0x9B8 + 12);
    printf("CachedComponentSpaceTransforms (+0x9B8):\n");
    printf("  Data: 0x%lx, Num: %d, Max: %d\n", cstData, cstNum, cstMax);

    for (uintptr_t off = 0x990; off <= 0x9E0; off += 0x10) {
        uintptr_t d = ReadPtr(mesh + off);
        int32_t n = ReadI32(mesh + off + 8);
        int32_t m = ReadI32(mesh + off + 12);
        if (n > 0 && n < 300 && m >= n && m < 1000) {
            printf("  Potential TArray at +0x%lx: Data=0x%lx, Num=%d, Max=%d\n", off, d, n, m);
        }
    }

    uintptr_t bstData = ReadPtr(mesh + 0x9A8);
    int32_t bstNum = ReadI32(mesh + 0x9A8 + 8);
    printf("CachedBoneSpaceTransforms (+0x9A8): Data=0x%lx, Num=%d\n", bstData, bstNum);

    if (cstData && cstNum > 0 && cstNum < 300) {
        printf("Sample Bone Transforms (from CST at 0x%lx):\n", cstData);
        for (int i = 0; i < (cstNum < 16 ? cstNum : 16); i++) {
            FTransform bt;
            ReadMem(cstData + i * sizeof(FTransform), &bt, sizeof(bt));
            FVector worldPos = c2w.TransformPosition(bt.Translation);
            printf("  Bone #%2d: CompTrans=(%7.1f, %7.1f, %7.1f) -> WorldPos=(%7.1f, %7.1f, %7.1f)\n",
                   i, bt.Translation.X, bt.Translation.Y, bt.Translation.Z,
                   worldPos.X, worldPos.Y, worldPos.Z);
        }
    }

    uintptr_t skelMesh = ReadPtr(mesh + 0x6D0);
    printf("SkeletalMesh (+0x6D0): 0x%lx\n", skelMesh);
    if (skelMesh) {
        uintptr_t skeleton = ReadPtr(skelMesh + 0x88);
        printf("USkeleton (+0x88): 0x%lx\n", skeleton);
        if (skeleton) {
            uintptr_t btData = ReadPtr(skeleton + 0x38);
            int32_t btNum = ReadI32(skeleton + 0x38 + 8);
            printf("  BoneTree (+0x38): Data=0x%lx, Num=%d\n", btData, btNum);
        }
    }
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printf("Usage: %s <pid>\n", argv[0]);
        return 1;
    }
    g_Pid = atoi(argv[1]);
    printf("Inspecting PID: %d\n", g_Pid);

    uintptr_t libBase = GetLibBase("libUE4.so");
    if (!libBase) {
        printf("libUE4.so not found!\n");
        return 1;
    }
    printf("libUE4.so base: 0x%lx\n", libBase);

    uintptr_t gEngine = ReadPtr(libBase + 0x0F5D3138);
    printf("GEngine: 0x%lx\n", gEngine);
    if (!gEngine) return 1;

    uintptr_t vp = ReadPtr(gEngine + 0x788);
    printf("ViewportClient (+0x788): 0x%lx\n", vp);
    if (!vp) return 1;

    uintptr_t world = ReadPtr(vp + 0x70);
    printf("World (+0x70): 0x%lx\n", world);
    if (!world) return 1;

    uintptr_t gi = ReadPtr(world + 0x180);
    uintptr_t lpArray = ReadPtr(gi + 0x38);
    uintptr_t lp = ReadPtr(lpArray);
    uintptr_t pc = ReadPtr(lp + 0x30);
    uintptr_t localPawn = ReadPtr(pc + 0x2A0);
    if (!localPawn) localPawn = ReadPtr(pc + 0x298);

    printf("LocalPawn: 0x%lx\n", localPawn);
    if (localPawn) {
        uintptr_t mesh = ReadPtr(localPawn + 0x370);
        InspectMesh("LocalPlayer", mesh);
    }

    uintptr_t level = ReadPtr(world + 0x30);
    uintptr_t actorsData = ReadPtr(level + 0x98);
    int32_t actorsCount = ReadI32(level + 0xA0);
    printf("\nLevel: 0x%lx, Actors.Count: %d\n", level, actorsCount);

    printf("Scanning actors in Level for Character/Pawn...\n");
    int countWithMesh = 0;
    for (int i = 0; i < actorsCount && i < 2000; i++) {
        uintptr_t actor = ReadPtr(actorsData + i * 8);
        if (!actor || actor < 0x1000000000ULL || actor > 0x7FFFFFFFFFFFULL) continue;

        uintptr_t cls = ReadPtr(actor + 0x10);
        if (!cls || cls < 0x1000000000ULL || cls > 0x7FFFFFFFFFFFULL) continue;

        uintptr_t mesh = ReadPtr(actor + 0x370);
        if (mesh >= 0x1000000000ULL && mesh <= 0x7FFFFFFFFFFFULL) {
            uintptr_t meshCls = ReadPtr(mesh + 0x10);
            if (meshCls >= 0x1000000000ULL && meshCls <= 0x7FFFFFFFFFFFULL) {
                countWithMesh++;
                char lbl[64];
                snprintf(lbl, sizeof(lbl), "Actor[%d] 0x%lx", i, actor);
                InspectMesh(lbl, mesh);
                if (countWithMesh >= 3) break;
            }
        }
    }
    printf("Actors with valid Mesh found: %d\n", countWithMesh);
    return 0;
}
