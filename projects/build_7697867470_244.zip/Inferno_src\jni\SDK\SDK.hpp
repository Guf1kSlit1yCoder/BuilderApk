#pragma once

#include <cstdint>
#include <cmath>
#include <string>
#include <vector>
#include <algorithm>
#include "Offsets.hpp"
#include "Basic.hpp"

namespace SDK
{

#define CONST_PI 3.14159265358979323846f
#define RAD2DEG(x) ((float)(x) * (180.f / CONST_PI))
#define DEG2RAD(x) ((float)(x) * (CONST_PI / 180.f))

struct FVector2D
{
    float X = 0.0f;
    float Y = 0.0f;

    inline FVector2D() : X(0.0f), Y(0.0f) {}
    inline FVector2D(float x, float y) : X(x), Y(y) {}

    inline FVector2D operator+(const FVector2D &other) const { return {X + other.X, Y + other.Y}; }
    inline FVector2D operator-(const FVector2D &other) const { return {X - other.X, Y - other.Y}; }
    inline FVector2D operator*(float scalar) const { return {X * scalar, Y * scalar}; }
    inline FVector2D operator/(float scalar) const { return {X / scalar, Y / scalar}; }

    inline float Distance(const FVector2D &v) const
    {
        float dx = X - v.X;
        float dy = Y - v.Y;
        return std::sqrt(dx * dx + dy * dy);
    }
};

struct FVector
{
    float X = 0.0f;
    float Y = 0.0f;
    float Z = 0.0f;

    inline FVector() : X(0.0f), Y(0.0f), Z(0.0f) {}
    inline FVector(float x, float y, float z) : X(x), Y(y), Z(z) {}

    inline FVector operator+(const FVector &other) const { return {X + other.X, Y + other.Y, Z + other.Z}; }
    inline FVector operator-(const FVector &other) const { return {X - other.X, Y - other.Y, Z - other.Z}; }
    inline FVector operator*(float scalar) const { return {X * scalar, Y * scalar, Z * scalar}; }
    inline FVector operator/(float scalar) const { return {X / scalar, Y / scalar, Z / scalar}; }

    inline float Dot(const FVector &v) const { return X * v.X + Y * v.Y + Z * v.Z; }
    inline FVector Cross(const FVector &v) const
    {
        return {
            Y * v.Z - Z * v.Y,
            Z * v.X - X * v.Z,
            X * v.Y - Y * v.X
        };
    }
    inline float SizeSquared() const { return X * X + Y * Y + Z * Z; }
    inline float Size() const { return std::sqrt(SizeSquared()); }
    inline float Size2D() const { return std::sqrt(X * X + Y * Y); }

    inline float Distance(const FVector &v) const
    {
        float dx = X - v.X;
        float dy = Y - v.Y;
        float dz = Z - v.Z;
        return std::sqrt(dx * dx + dy * dy + dz * dz);
    }
};

struct FVector4
{
    float X = 0.0f;
    float Y = 0.0f;
    float Z = 0.0f;
    float W = 0.0f;

    inline FVector4() : X(0), Y(0), Z(0), W(0) {}
    inline FVector4(float x, float y, float z, float w) : X(x), Y(y), Z(z), W(w) {}
};

struct FLinearColor
{
    float R = 0.0f;
    float G = 0.0f;
    float B = 0.0f;
    float A = 1.0f;

    inline FLinearColor() : R(0), G(0), B(0), A(1) {}
    inline FLinearColor(float r, float g, float b, float a = 1.0f) : R(r), G(g), B(b), A(a) {}
};

struct FRotator
{
    float Pitch = 0.0f;
    float Yaw = 0.0f;
    float Roll = 0.0f;

    inline FRotator() : Pitch(0), Yaw(0), Roll(0) {}
    inline FRotator(float pitch, float yaw, float roll) : Pitch(pitch), Yaw(yaw), Roll(roll) {}

    inline FRotator operator+(const FRotator &r) const { return {Pitch + r.Pitch, Yaw + r.Yaw, Roll + r.Roll}; }
    inline FRotator operator-(const FRotator &r) const { return {Pitch - r.Pitch, Yaw - r.Yaw, Roll - r.Roll}; }

    inline void Clamp()
    {
        while (Pitch > 180.0f) Pitch -= 360.0f;
        while (Pitch < -180.0f) Pitch += 360.0f;
        if (Pitch > 89.0f) Pitch = 89.0f;
        if (Pitch < -89.0f) Pitch = -89.0f;

        while (Yaw > 180.0f) Yaw -= 360.0f;
        while (Yaw < -180.0f) Yaw += 360.0f;
        Roll = 0.0f;
    }

    inline FVector RotateVector(const FVector &v) const
    {
        float radPitch = Pitch * (CONST_PI / 180.0f);
        float radYaw = Yaw * (CONST_PI / 180.0f);
        float radRoll = Roll * (CONST_PI / 180.0f);

        float SP = std::sin(radPitch), CP = std::cos(radPitch);
        float SY = std::sin(radYaw), CY = std::cos(radYaw);
        float SR = std::sin(radRoll), CR = std::cos(radRoll);

        FVector res;
        // UE basis: positive pitch raises forward, positive roll lowers right.
        res.X = (CP * CY) * v.X + (SR * SP * CY - CR * SY) * v.Y - (CR * SP * CY + SR * SY) * v.Z;
        res.Y = (CP * SY) * v.X + (SR * SP * SY + CR * CY) * v.Y + (SR * CY - CR * SP * SY) * v.Z;
        res.Z = SP * v.X - (SR * CP) * v.Y + (CR * CP) * v.Z;
        return res;
    }
};

struct FQuat
{
    float X = 0.0f;
    float Y = 0.0f;
    float Z = 0.0f;
    float W = 1.0f;

    inline FQuat() : X(0), Y(0), Z(0), W(1) {}
    inline FQuat(float x, float y, float z, float w) : X(x), Y(y), Z(z), W(w) {}

    // Epic Games official quaternion vector rotation:
    // V' = V + 2*W*(Q_xyz x V) + 2*(Q_xyz x (Q_xyz x V))
    inline FVector RotateVector(const FVector &V) const
    {
        FVector Qv(X, Y, Z);
        FVector T = Qv.Cross(V) * 2.0f;
        return V + (T * W) + Qv.Cross(T);
    }
};

struct FMatrix
{
    float M[4][4];

    inline FMatrix()
    {
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                M[i][j] = (i == j) ? 1.0f : 0.0f;
    }
};

struct FTransform
{
    FQuat Rotation;
    FVector Translation;
    // Matches CoreUObject.Transform in sdk/sdk/SDK/CoreUObject_structs.hpp.
    // This build stores Scale3D at 0x1C, not the SIMD-layout offset 0x20.
    FVector Scale3D = {1.0f, 1.0f, 1.0f};
    uint8_t Pad_0x28[0x8] = {};

    inline bool IsValid() const
    {
        const float qSize = Rotation.X * Rotation.X + Rotation.Y * Rotation.Y +
                            Rotation.Z * Rotation.Z + Rotation.W * Rotation.W;
        return std::isfinite(Translation.X) && std::isfinite(Translation.Y) &&
               std::isfinite(Translation.Z) && std::isfinite(qSize) &&
               qSize >= 0.5f && qSize <= 1.5f &&
               std::isfinite(Scale3D.X) && std::isfinite(Scale3D.Y) && std::isfinite(Scale3D.Z) &&
               std::abs(Scale3D.X) > 0.0001f && std::abs(Scale3D.X) <= 100.0f &&
               std::abs(Scale3D.Y) > 0.0001f && std::abs(Scale3D.Y) <= 100.0f &&
               std::abs(Scale3D.Z) > 0.0001f && std::abs(Scale3D.Z) <= 100.0f;
    }

    inline FVector TransformPosition(const FVector &V) const
    {
        FVector scaled = { V.X * Scale3D.X, V.Y * Scale3D.Y, V.Z * Scale3D.Z };
        return Rotation.RotateVector(scaled) + Translation;
    }
};
static_assert(sizeof(FTransform) == 0x30, "FTransform size must be 0x30");
static_assert(offsetof(FTransform, Rotation) == 0x00, "Rotation offset must be 0x00");
static_assert(offsetof(FTransform, Translation) == 0x10, "Translation offset must be 0x10");
static_assert(offsetof(FTransform, Scale3D) == 0x1C, "Scale3D offset must match the dump (0x1C)");

// Forward Declarations
class AActor;
class APawn;
class ACharacter;
class ASGCharacterBase;
class ASGCharacter;
class ASGAICharacter;
class ASGPickup;
class AController;
class APlayerController;
class ASGPlayerController;
class USGPlayerInput;
class APlayerCameraManager;
class APlayerState;
class ASGPlayerState;
class USceneComponent;
class USkeletalMeshComponent;
class USkeleton;
class USkeletalMesh;
class UAbilitySystemComponent;
class UCameraComponent;
class UWorld;
class ULevel;
class UEngine;
class UGameInstance;
class ULocalPlayer;
class UGameViewportClient;
class AHUD;
class UCanvas;

bool IsLiveSDKObject(const UObject* obj);
bool HasSDKClass(const UObject* obj, const char* name);

// ==================== Components & Attributes ====================

class UActorComponent : public UObject
{
public:
    uint8_t Pad_ActorComp[0xB8]; // 0x28 - 0xE0
    static UClass* StaticClass();
};
static_assert(sizeof(UActorComponent) == 0xE0, "UActorComponent size must be 0xE0");

class UAbilitySystemComponent : public UActorComponent
{
public:
    uint8_t Pad_ASC[0x90]; // 0xE0 - 0x170
    TArray<UObject*> SpawnedAttributes; // 0x170(0x10)
    static UClass* StaticClass();
};
static_assert(offsetof(UAbilitySystemComponent, SpawnedAttributes) == 0x170, "SpawnedAttributes must be at 0x170");

class UAttributeSet : public UObject
{
public:
    uint8_t Pad_Attr[0x1C]; // 0x28 - 0x44
    static UClass* StaticClass();
};

class USGActorHealthAttributeSet : public UAttributeSet
{
public:
    float Health; // 0x44(0x4)
    float HealthMax; // 0x48(0x4)
    uint8_t Pad_0x4C[0x8]; // 0x4C - 0x54

    static UClass* StaticClass();
};
static_assert(offsetof(USGActorHealthAttributeSet, Health) == 0x44, "Health must be at 0x44");
static_assert(offsetof(USGActorHealthAttributeSet, HealthMax) == 0x48, "HealthMax must be at 0x48");

class USGCharacterHealthAttributeSet : public USGActorHealthAttributeSet
{
public:
    float DBNOHealth; // 0x54(0x4)
    float DBNOHealthMax; // 0x58(0x4)
    float DBNOHealthScaleAdder; // 0x5C(0x4)
    uint8_t Pad_CharHealth[0x18]; // 0x60 - 0x78

    static UClass* StaticClass();
};
static_assert(offsetof(USGCharacterHealthAttributeSet, DBNOHealth) == 0x54, "DBNOHealth must be at 0x54");
static_assert(offsetof(USGCharacterHealthAttributeSet, DBNOHealthMax) == 0x58, "DBNOHealthMax must be at 0x58");

class USGActorHealthComponent : public UActorComponent
{
public:
    USGActorHealthAttributeSet* AttributeSetClass; // 0xE0(0x8)

    float GetHealth();
    float GetHealthMax();

    static UClass* StaticClass();
};
static_assert(offsetof(USGActorHealthComponent, AttributeSetClass) == 0xE0, "AttributeSetClass must be at 0xE0");

class USGCharacterHealthComponent : public USGActorHealthComponent
{
public:
    uint8_t Pad_CharHealthComp[0xC0]; // 0xE8 - 0x1A8
    static UClass* StaticClass();
};
static_assert(sizeof(USGCharacterHealthComponent) == 0x1A8, "USGCharacterHealthComponent size must be 0x1A8");



class USceneComponent : public UActorComponent
{
public:
    uint8_t Pad_Scene0[0x10]; // 0xE0 - 0xF0
    USceneComponent* AttachParent; // 0xF0(0x8), dump_Engine_classes.hpp
    FName AttachSocketName; // 0xF8(0x8)
    TArray<USceneComponent*> AttachChildren; // 0x100(0x10)
    uint8_t Pad_SceneAttachment[0x44]; // 0x110 - 0x154
    FVector RelativeLocation; // 0x154(0xC)
    FRotator RelativeRotation; // 0x160(0xC)
    FVector RelativeScale3D; // 0x16C(0xC)
    FVector ComponentVelocity; // 0x178(0xC)
    uint8_t Pad_0x184[0xC]; // 0x184(0xC)
    FTransform ComponentToWorld; // 0x190(0x30)
    uint8_t Pad_Scene1[0x70]; // 0x1C0 - 0x230

    bool TryGetWorldLocation(FVector& outLocation) const;
    FVector K2_GetComponentLocation();
    FRotator K2_GetComponentRotation();
    FVector GetSocketLocation(FName InSocketName);

    static UClass* StaticClass();
};
static_assert(sizeof(USceneComponent) == 0x230, "USceneComponent size must be 0x230");
static_assert(offsetof(USceneComponent, AttachParent) == 0xF0, "AttachParent must be at 0xF0");
static_assert(offsetof(USceneComponent, AttachSocketName) == 0xF8, "AttachSocketName must be at 0xF8");
static_assert(offsetof(USceneComponent, RelativeLocation) == 0x154, "RelativeLocation must be at 0x154");
static_assert(offsetof(USceneComponent, ComponentToWorld) == 0x190, "ComponentToWorld must be at 0x190");

class UPrimitiveComponent : public USceneComponent
{
public:
    uint8_t Pad_Prim[0x450]; // 0x230 - 0x680
    static UClass* StaticClass();
};
static_assert(sizeof(UPrimitiveComponent) == 0x680, "UPrimitiveComponent size must be 0x680");

class UMeshComponent : public UPrimitiveComponent
{
public:
    uint8_t Pad_Mesh[0x50]; // 0x680 - 0x6D0
    static UClass* StaticClass();
};
static_assert(sizeof(UMeshComponent) == 0x6D0, "UMeshComponent size must be 0x6D0");

struct FBoneNode
{
    FName Name; // 0x0(0x8)
    int32_t ParentIndex; // 0x8(0x4)
    uint8_t TranslationRetargetingMode; // 0xC(0x1)
    uint8_t Pad_0xD[0x3]; // 0xD(0x3)
};
static_assert(sizeof(FBoneNode) == 0x10, "FBoneNode size must be 0x10");

class USkeleton : public UObject
{
public:
    uint8_t Pad_0x28[0x10]; // 0x28 - 0x38
    TArray<FBoneNode> BoneTree; // 0x38(0x10)
    TArray<FTransform> RefLocalPoses; // 0x48(0x10)

    static UClass* StaticClass();
};

class USkeletalMesh : public UObject
{
public:
    uint8_t Pad_0x28[0x60]; // 0x28 - 0x88
    USkeleton* Skeleton; // 0x88(0x8)

    static UClass* StaticClass();
};

class USkinnedMeshComponent : public UMeshComponent
{
public:
    USkeletalMesh* SkeletalMesh; // 0x6D0(0x8)
    TWeakObjectPtr<USkinnedMeshComponent> MasterPoseComponent; // 0x6D8(0x8)
    uint8_t Pad_Skinned[0x220]; // 0x6E0 - 0x900
    static UClass* StaticClass();
};
static_assert(sizeof(USkinnedMeshComponent) == 0x900, "USkinnedMeshComponent size must be 0x900");
static_assert(offsetof(USkinnedMeshComponent, SkeletalMesh) == 0x6D0, "SkeletalMesh must be at 0x6D0");
static_assert(offsetof(USkinnedMeshComponent, MasterPoseComponent) == 0x6D8, "MasterPoseComponent must be at 0x6D8");

class USkeletalMeshComponent : public USkinnedMeshComponent
{
public:
    uint8_t Pad_Skel0[0xB8]; // 0x900 - 0x9B8
    TArray<FTransform> CachedComponentSpaceTransforms; // 0x9B8(0x10)
    uint8_t Pad_Skel1[0x828]; // 0x9C8 - 0x11F0

    int32_t GetBoneIndex(FName BoneName);
    int32_t GetBoneIndex(const char* BoneName);
    FVector GetBoneLocation(int boneId);
    FVector GetBoneLocationByName(const char* name);

    static UClass* StaticClass();
};
static_assert(sizeof(USkeletalMeshComponent) == 0x11F0, "USkeletalMeshComponent size must be 0x11F0");
static_assert(offsetof(USkeletalMeshComponent, CachedComponentSpaceTransforms) == 0x9B8, "CachedComponentSpaceTransforms must be at 0x9B8");

class UCameraComponent : public USceneComponent
{
public:
    uint8_t Pad_Cam[0x690]; // 0x230 - 0x8C0
    static UClass* StaticClass();
};
static_assert(sizeof(UCameraComponent) == 0x8C0, "UCameraComponent size must be 0x8C0");

class UCharacterMovementComponent : public UActorComponent
{
public:
    uint8_t Pad_Move[0x1100]; // 0xE0 - 0x11E0
    static UClass* StaticClass();
};

class UCapsuleComponent : public UPrimitiveComponent
{
public:
    float GetScaledCapsuleRadius();
    float GetScaledCapsuleHalfHeight();

    static UClass* StaticClass();
};

// ==================== Actors ====================

class AActor : public UObject
{
public:
    uint8_t Pad_Actor0[0x130]; // 0x28 - 0x158
    USceneComponent* RootComponent; // 0x158(0x8)
    uint8_t Pad_Actor1[0xC0]; // 0x160 - 0x220
    TMap<UObject*, UActorComponent*> OwnedComponentMap; // 0x220(0x50)
    uint8_t Pad_Actor2[0x60]; // 0x270 - 0x2D0
    TArray<UActorComponent*> InstanceComponents; // 0x2D0(0x10)
    TArray<UActorComponent*> BlueprintCreatedComponents; // 0x2E0(0x10)
    uint8_t Pad_Actor3[0x10]; // 0x2F0 - 0x300

    FVector K2_GetActorLocation();
    FRotator K2_GetActorRotation();
    float GetDistanceTo(AActor* OtherActor);

    // Finds the first owned component whose class (or a superclass) is named
    // className. Iterates the instance-component arrays (plain TArray) - no
    // UFUNCTION call, no TMap traversal. Returns nullptr if absent.
    UActorComponent* FindComponentByClassName(const char* className) const;

    static UClass* StaticClass();
};
static_assert(sizeof(AActor) == 0x300, "AActor size must be 0x300");
static_assert(offsetof(AActor, RootComponent) == 0x158, "RootComponent must be at 0x158");
static_assert(offsetof(AActor, OwnedComponentMap) == 0x220, "OwnedComponentMap must be at 0x220");
static_assert(offsetof(AActor, InstanceComponents) == 0x2D0, "InstanceComponents must be at 0x2D0");

class ASGPickup : public AActor
{
public:
    static UClass* StaticClass();
};

class APawn : public AActor
{
public:
    uint8_t Pad_Pawn0[0x30]; // 0x300 - 0x330
    APlayerState* PlayerState; // 0x330(0x8)
    uint8_t Pad_Pawn1[0x10]; // 0x338 - 0x348
    AController* Controller; // 0x348(0x8)
    uint8_t Pad_Pawn2[0x20]; // 0x350 - 0x370

    static UClass* StaticClass();
};
static_assert(sizeof(APawn) == 0x370, "APawn size must be 0x370");
static_assert(offsetof(APawn, PlayerState) == 0x330, "PlayerState must be at 0x330");
static_assert(offsetof(APawn, Controller) == 0x348, "Controller must be at 0x348");

class ACharacter : public APawn
{
public:
    USkeletalMeshComponent* Mesh; // 0x370(0x8)
    UCharacterMovementComponent* CharacterMovement; // 0x378(0x8)
    UCapsuleComponent* CapsuleComponent; // 0x380(0x8)
    uint8_t Pad_Char[0x238]; // 0x388 - 0x5C0

    static UClass* StaticClass();
};
static_assert(sizeof(ACharacter) == 0x5C0, "ACharacter size must be 0x5C0");
static_assert(offsetof(ACharacter, Mesh) == 0x370, "Mesh must be at 0x370");
static_assert(offsetof(ACharacter, CharacterMovement) == 0x378, "CharacterMovement must be at 0x378");
static_assert(offsetof(ACharacter, CapsuleComponent) == 0x380, "CapsuleComponent must be at 0x380");

class ASGCharacterBase : public ACharacter
{
public:
    uint8_t Pad_Base[0x120]; // 0x5C0 - 0x6E0

    static UClass* StaticClass();
};
static_assert(sizeof(ASGCharacterBase) == 0x6E0, "ASGCharacterBase size must be 0x6E0");

struct FSGPlayerInfo
{
    uint64_t gid; // 0x0(0x8)
    int32_t TeamIndex; // 0x8(0x4)
    uint8_t Pad_0xC[0x4]; // 0xC(0x4)
    ASGPlayerState* PlayerState; // 0x10(0x8)
    ASGCharacter* Character; // 0x18(0x8)
    AActor* RemoteActor; // 0x20(0x8)
};

class ASGCharacter;

class ASGCharacterFastRepProxy : public AActor
{
public:
    ASGCharacter* BindingCharacter; // 0x0300(0x8)
    FVector Acceleration; // 0x0308(0xC)
    FVector PredictStopLocation; // 0x0314(0xC)
    float CurrentSlideAlongWeight; // 0x0320(0x4)
    FRotator VehicleCameraRelativeRotation; // 0x0324(0xC)
    // FastReplicatedMovement:
    FVector LinearVelocity; // 0x0330(0xC)
    FVector AngularVelocity; // 0x033C(0xC)
    FVector Location; // 0x0348(0xC)
    FRotator Rotation; // 0x0354(0xC)
    uint8_t RepPhysicsFlags; // 0x0360(0x1)
    uint8_t LocationQuantizationLevel; // 0x0361(0x1)
    uint8_t VelocityQuantizationLevel; // 0x0362(0x1)
    uint8_t RotationQuantizationLevel; // 0x0363(0x1)
    uint32_t RepVersionIndex; // 0x0364(0x4)
    float ReplicatedServerLastTransformUpdateTimeStamp; // 0x0368(0x4)
    int32_t PlayerViewInfo; // 0x036C(0x4)
    uint8_t ReplicatedMovementMode; // 0x0370(0x1)
    uint8_t Pad_0x371[0x3]; // 0x0371(0x3)
    uint8_t WeaponLeanAimTypeInfo[0x8]; // 0x0374(0x8)
    uint8_t MovementFlags; // 0x037C(0x1)
    uint8_t Pad_0x37D[0x15B]; // 0x037D - 0x04D8

    static UClass* StaticClass();
};
static_assert(sizeof(ASGCharacterFastRepProxy) == 0x4D8, "ASGCharacterFastRepProxy size must be 0x4D8");
static_assert(offsetof(ASGCharacterFastRepProxy, Location) == 0x348, "Location must be at 0x348");
static_assert(offsetof(ASGCharacterFastRepProxy, Rotation) == 0x354, "Rotation must be at 0x354");
static_assert(offsetof(ASGCharacterFastRepProxy, MovementFlags) == 0x37C, "MovementFlags must be at 0x37C");

class ASGCharacter : public ASGCharacterBase
{
public:
    uint8_t Pad_SG0[0xEA8]; // 0x6E0 - 0x1588
    UCameraComponent* CharacterCameraComponent; // 0x1588(0x8)
    uint8_t Pad_0x1590[0x18]; // 0x1590(0x18)
    ASGPlayerController* CurrentViewerPC; // 0x15A8(0x8)
    uint8_t Pad_0x15B0[0x30]; // 0x15B0(0x30)
    uint64_t gid; // 0x15E0(0x8)
    uint8_t FactionType; // 0x15E8(0x1)
    uint8_t CharacterSex; // 0x15E9(0x1)
    uint8_t Pad_0x15EA[0x16]; // 0x15EA - 0x1600
    FSGPlayerInfo PlayerInfo; // 0x1600(0x28)
    uint8_t Pad_0x1628[0x18]; // 0x1628 - 0x1640
    UCharacterMovementComponent* SGCharacterMovement; // 0x1640(0x8)
    uint8_t Pad_0x1648[0x50]; // 0x1648 - 0x1698
    UAbilitySystemComponent* AbilitySystemComponent; // 0x1698(0x8)
    uint8_t Pad_0x16A0[0x4B0]; // 0x16A0 - 0x1B50
    float DesiredFOV; // 0x1B50(0x4)
    uint8_t Pad_0x1B54[0x4C]; // 0x1B54 - 0x1BA0
    ASGCharacterFastRepProxy* CharacterFastRepProxy; // 0x1BA0(0x8)
    uintptr_t CharacterProxy; // 0x1BA8(0x8)
    uint8_t Pad_0x1BB0[0x260]; // 0x1BB0 - 0x1E10

    bool IsDead();
    int32_t GetTeamID();
    bool IsAI();
    bool IsNPC(); // true for MFNPCAI package characters (shown as "ACTOR")
    USkeletalMeshComponent* GetMeshComponent();
    FVector GetBonePos(const char* boneName, const FVector& fallback = {0,0,0}, bool allowApproximation = true);
    // One bounded pose read for all requested bones; false entries remain zero.
    bool GetBonePositions(const char* const* names, int count, FVector* positions);
    FVector GetBoneLocation(int boneId);

    // Authoritative networked position via the fast-rep proxy:
    //   this+0x1BA0 (CharacterFastRepProxy*) -> +0x330 FastReplicatedMovement(FRepMovement)
    //   -> +0x18 Location  (i.e. proxy+0x348). Returns false if no live proxy.
    // For remote players the Actor/RootComponent holds a stale/dormant position;
    // this is the real server location (no ghost pawns).
    bool GetFastRepLocation(FVector& out);
    // Combined proxy position: PredictStopLocation (proxy+0x314) when it is a sane
    // lead over FastReplicatedMovement.Location (proxy+0x348), else the replicated
    // location. This is the live networked position for remote players.
    bool GetProxyPosition(FVector& out);
    // Authoritative networked velocity: proxy FastReplicatedMovement.LinearVelocity
    // (proxy+0x330, FRepMovement offset 0x0). For bullet-lead prediction.
    bool GetProxyVelocity(FVector& out);

    USGCharacterHealthComponent* GetCharacterHealthComponent();
    // Read current and maximum from the SAME attribute set. Unknown is -1/-1.
    bool TryGetHealth(float& health, float& maxHealth);
    float GetHealth();
    float GetMaxHealth();
    bool IsKnocked();

    static UClass* StaticClass();
};
static_assert(sizeof(ASGCharacter) == 0x1E10, "ASGCharacter size must be 0x1E10");
static_assert(offsetof(ASGCharacter, CharacterCameraComponent) == 0x1588, "CameraComponent must be at 0x1588");
static_assert(offsetof(ASGCharacter, gid) == 0x15E0, "gid must be at 0x15E0");
static_assert(offsetof(ASGCharacter, FactionType) == 0x15E8, "FactionType must be at 0x15E8");
static_assert(offsetof(ASGCharacter, PlayerInfo) == 0x1600, "PlayerInfo must be at 0x1600");
static_assert(offsetof(ASGCharacter, AbilitySystemComponent) == 0x1698, "AbilitySystemComponent must be at 0x1698");
static_assert(offsetof(ASGCharacter, CharacterFastRepProxy) == 0x1BA0, "CharacterFastRepProxy must be at 0x1BA0");

class ASGAICharacter : public ASGCharacter
{
public:
    uint8_t Pad_AI0[0x48]; // 0x1E10 - 0x1E58
    int32_t AITeamIndex; // 0x1E58(0x4)
    uint8_t Pad_0x1E5C[0x4]; // 0x1E5C(0x4)
    uint64_t MasterPlayerGID; // 0x1E60(0x8)
    int64_t AIUID; // 0x1E68(0x8)
    int64_t PathGroupID; // 0x1E70(0x8)
    uint8_t Pad_0x1E78[0x8]; // 0x1E78(0x8)
    int32_t AILevel; // 0x1E80(0x4)
    uint8_t Pad_0x1E84[0x14C]; // 0x1E84 - 0x1FD0
    FString AIName; // 0x1FD0(0x10)
    uint8_t Pad_0x1FE0[0x180]; // 0x1FE0 - 0x2160

    static UClass* StaticClass();
};
static_assert(sizeof(ASGAICharacter) == 0x2160, "ASGAICharacter size must be 0x2160");
static_assert(offsetof(ASGAICharacter, AITeamIndex) == 0x1E58, "AITeamIndex must be at 0x1E58");
static_assert(offsetof(ASGAICharacter, MasterPlayerGID) == 0x1E60, "MasterPlayerGID must be at 0x1E60");
static_assert(offsetof(ASGAICharacter, AIName) == 0x1FD0, "AIName must be at 0x1FD0");

// ==================== Controllers & Camera ====================

class AController : public AActor
{
public:
    uint8_t Pad_0x300[0x8]; // 0x300(0x8)
    APlayerState* PlayerState; // 0x308(0x8)
    uint8_t Pad_0x310[0x20]; // 0x310(0x20)
    APawn* Pawn; // 0x330(0x8)
    uint8_t Pad_0x338[0x8]; // 0x338(0x8)
    ACharacter* Character; // 0x340(0x8)
    USceneComponent* TransformComponent; // 0x348(0x8)
    uint8_t Pad_0x350[0x18]; // 0x350(0x18)
    FRotator ControlRotation; // 0x368(0xC)
    uint8_t Pad_0x374[0x4]; // 0x374(0x4)

    bool LineOfSightTo(AActor* Other, const FVector& ViewPoint = {0,0,0}, bool bAlternateChecks = false);

    static UClass* StaticClass();
};
static_assert(sizeof(AController) == 0x378, "AController size must be 0x378");
static_assert(offsetof(AController, PlayerState) == 0x308, "PlayerState must be at 0x308");
static_assert(offsetof(AController, Pawn) == 0x330, "Pawn must be at 0x330");
static_assert(offsetof(AController, Character) == 0x340, "Character must be at 0x340");
static_assert(offsetof(AController, ControlRotation) == 0x368, "ControlRotation must be at 0x368");

// Engine.MinimalViewInfo, verified against dump_ClassOffsets.txt and Engine_structs.hpp.
// Keep projection settings in the SAME cache sample as location/rotation/FOV.
struct FCameraView
{
    FVector Location; // 0x00
    FRotator Rotation; // 0x0C
    float FOV = 0.0f; // 0x18
    float DesiredFOV = 0.0f; // 0x1C
    float OrthoWidth = 0.0f; // 0x20
    float OrthoNearClipPlane = 0.0f; // 0x24
    float OrthoFarClipPlane = 0.0f; // 0x28
    float PerspectiveNearClipPlane = 0.0f; // 0x2C
    float AspectRatio = 0.0f; // 0x30
    uint8_t ProjectionFlags = 0; // 0x34: bConstrainAspectRatio = 0x01
    uint8_t ProjectionMode = 0; // 0x35: Perspective=0, Orthographic=1
    uint8_t Pad_0x36[0x62A] = {}; // unused post-process data
    FVector2D OffCenterProjectionOffset; // 0x660
    uint8_t FOVMode = 0; // 0x668: Horizontal=0, Vertical=1, FixedAspectVertical=2
    uint8_t Pad_0x669[0x47] = {};
};
static_assert(sizeof(FCameraView) == 0x6B0, "MinimalViewInfo size must match dump");
static_assert(offsetof(FCameraView, AspectRatio) == 0x30, "POV AspectRatio");
static_assert(offsetof(FCameraView, ProjectionFlags) == 0x34, "POV constraint flags");
static_assert(offsetof(FCameraView, ProjectionMode) == 0x35, "POV projection mode");
static_assert(offsetof(FCameraView, OffCenterProjectionOffset) == 0x660, "POV off-center projection");
static_assert(offsetof(FCameraView, FOVMode) == 0x668, "POV FOV mode");

struct FCameraCacheSample
{
    float Timestamp = 0.0f;
    uint8_t Pad_0x4[0xC] = {};
    FCameraView POV; // 0x10
};
static_assert(offsetof(FCameraCacheSample, POV) == 0x10, "CameraCacheEntry POV must be at 0x10");
static_assert(offsetof(FCameraView, Rotation) == 0x0C, "POV Rotation must be at 0x0C");
static_assert(offsetof(FCameraView, FOV) == 0x18, "POV FOV must be at 0x18");

class APlayerCameraManager : public AActor
{
public:
    APlayerController* PCOwner; // 0x300(0x8)
    uint8_t Pad_CamMgr[0x10]; // 0x308(0x10)
    float DefaultFOV; // 0x318(0x4)
    uint8_t Pad_0x31C[0x54]; // 0x31C(0x54)
    // CameraCache is at 0x370. POV Location is at 0x370 + 0x10 = 0x380, Rotation is at 0x38C, FOV is at 0x398
    uint8_t CameraCache[0x6C0]; // 0x370(0x6C0)
    uint8_t Pad_CamMiddle[0x1490]; // 0xA30 - 0x1EC0
    uint8_t CameraCachePrivate[0x6C0]; // 0x1EC0, reflected in dump_ClassOffsets.txt
    uint8_t Pad_CamEnd[0x7F0]; // 0x2580 - 0x2D70

    bool GetCameraView(FCameraView& outView) const;
    FVector GetCameraLocation() const;
    FRotator GetCameraRotation() const;
    float GetFOVAngle() const;
    void StopAllCameraShakes(bool bImmediately = true);

    static UClass* StaticClass();
};
static_assert(sizeof(APlayerCameraManager) == 0x2D70, "APlayerCameraManager size must be 0x2D70");
static_assert(offsetof(APlayerCameraManager, DefaultFOV) == 0x318, "DefaultFOV must be at 0x318");
static_assert(offsetof(APlayerCameraManager, CameraCache) == 0x370, "CameraCache must be at 0x370");
static_assert(offsetof(APlayerCameraManager, CameraCachePrivate) == 0x1EC0, "CameraCachePrivate must be at 0x1EC0");

class APlayerController : public AController
{
public:
    UObject* Player; // 0x378(0x8)
    APawn* AcknowledgedPawn; // 0x380(0x8)
    UObject* ControllingDirTrackInst; // 0x388(0x8)
    AHUD* MyHUD; // 0x390(0x8)
    APlayerCameraManager* PlayerCameraManager; // 0x398(0x8)
    uint8_t Pad_PC[0x2AC]; // 0x3A0 - 0x64C
    bool bIsLocalPlayerController; // 0x64C, dump_Engine_classes.hpp
    uint8_t Pad_PCEnd[0x23]; // 0x64D - 0x670

    bool ProjectWorldLocationToScreen(const FVector& WorldLocation, bool bPlayerViewportRelative, FVector2D* ScreenLocation);
    void GetInputTouchState(uint8_t FingerIndex, float& LocationX, float& LocationY, bool& bIsCurrentlyPressed);
    void GetPlayerViewPoint(FVector& outLocation, FRotator& outRotation);

    static UClass* StaticClass();
};
static_assert(sizeof(APlayerController) == 0x670, "APlayerController size must be 0x670");
static_assert(offsetof(APlayerController, MyHUD) == 0x390, "MyHUD must be at 0x390");
static_assert(offsetof(APlayerController, PlayerCameraManager) == 0x398, "PlayerCameraManager must be at 0x398");
static_assert(offsetof(APlayerController, AcknowledgedPawn) == 0x380, "AcknowledgedPawn must be at 0x380");

class USGPlayerInput : public UObject
{
public:
    uint8_t Pad_SGPI0[0x3B8]; // 0x28 - 0x3E0 (UObject base is 0x28)
    bool LeftFireBtnPressed;  // 0x3E0(0x1)
    bool RightFireBtnPressed; // 0x3E1(0x1)
    bool bQuickMeleeFireBtnPressed; // 0x3E2(0x1)
    uint8_t Pad_SGPI2[0x1AD]; // 0x3E3 - 0x590
};
static_assert(sizeof(USGPlayerInput) == 0x590, "USGPlayerInput size must be 0x590");
static_assert(offsetof(USGPlayerInput, LeftFireBtnPressed) == 0x3E0, "LeftFireBtnPressed must be at 0x3E0");
static_assert(offsetof(USGPlayerInput, RightFireBtnPressed) == 0x3E1, "RightFireBtnPressed must be at 0x3E1");

class ASGPlayerController : public APlayerController
{
public:
    uint8_t Pad_SGPC0[0x90]; // 0x670 - 0x700
    USGPlayerInput* SGPlayerInput; // 0x700(0x8), dump_ClassOffsets.txt
    uint8_t Pad_SGPC1[0x288]; // 0x708 - 0x990
    ASGCharacter* ControlledCharacter; // 0x990, dump_ClassOffsets.txt
    uint8_t Pad_SGPCEnd[0x88]; // 0x998 - 0xA20
    static UClass* StaticClass();
};
static_assert(sizeof(ASGPlayerController) == 0xA20, "ASGPlayerController size must be 0xA20");
static_assert(offsetof(ASGPlayerController, SGPlayerInput) == 0x700, "SGPlayerInput must be at 0x700");
static_assert(offsetof(ASGPlayerController, ControlledCharacter) == 0x990, "ControlledCharacter must be at 0x990");
static_assert(offsetof(APlayerController, bIsLocalPlayerController) == 0x64C, "Local controller flag must be at 0x64C");

class APlayerState : public AActor
{
public:
    float Score; // 0x300(0x4)
    int32_t PlayerId; // 0x304(0x4)
    uint8_t Pad_PS0[0x138]; // 0x308 - 0x440
    FString PlayerNamePrivate; // 0x440(0x10)
    uint8_t Pad_PS1[0x10]; // 0x450 - 0x460

    static UClass* StaticClass();
};
static_assert(sizeof(APlayerState) == 0x460, "APlayerState size must be 0x460");
static_assert(offsetof(APlayerState, Score) == 0x300, "Score must be at 0x300");
static_assert(offsetof(APlayerState, PlayerId) == 0x304, "PlayerId must be at 0x304");
static_assert(offsetof(APlayerState, PlayerNamePrivate) == 0x440, "PlayerNamePrivate must be at 0x440");

class ASGPlayerState : public APlayerState
{
public:
    uint8_t Pad_SGPS0[0xF0]; // 0x460 - 0x550
    uint64_t gid; // 0x550(0x8)
    uint8_t Pad_SGPS1[0x48]; // 0x558 - 0x5A0
    int32_t TeamIndex; // 0x5A0(0x4)
    uint8_t Pad_SGPS2[0x4]; // 0x5A4(0x4)
    FString TeamName; // 0x5A8(0x10)
    uint8_t Pad_SGPS3[0xB0]; // 0x5B8 - 0x668
    FString ZonePlayerName; // 0x668(0x10)
    uint8_t Pad_SGPS4[0x8A0]; // 0x678 - 0xF18

    static UClass* StaticClass();
};
static_assert(sizeof(ASGPlayerState) == 0xF18, "ASGPlayerState size must be 0xF18");
static_assert(offsetof(ASGPlayerState, gid) == 0x550, "gid must be at 0x550");
static_assert(offsetof(ASGPlayerState, TeamIndex) == 0x5A0, "TeamIndex must be at 0x5A0");
static_assert(offsetof(ASGPlayerState, ZonePlayerName) == 0x668, "ZonePlayerName must be at 0x668");

// ==================== Engine & World ====================

class UPlayer : public UObject
{
public:
    uint8_t Pad_Pl[0x8]; // 0x28(0x8)
    APlayerController* PlayerController; // 0x30(0x8)
    uint8_t Pad_PlEnd[0x10]; // 0x38 - 0x48

    static UClass* StaticClass();
};
static_assert(sizeof(UPlayer) == 0x48, "UPlayer size must be 0x48");

class ULocalPlayer : public UPlayer
{
public:
    uint8_t Pad_LP[0x28]; // 0x48(0x28)
    UGameViewportClient* ViewportClient; // 0x70(0x8)
    uint8_t Pad_LPEnd[0x1E8]; // 0x78 - 0x260

    static UClass* StaticClass();
};

class UGameViewportClient : public UObject
{
public:
    uint8_t Pad_VP[0x48]; // 0x28 - 0x70
    UWorld* World; // 0x70(0x8)
    UGameInstance* GameInstance; // 0x78(0x8)
    uint8_t Pad_VPEnd[0x2E8]; // 0x80 - 0x368

    static UClass* StaticClass();
};
static_assert(sizeof(UGameViewportClient) == 0x368, "UGameViewportClient size must be 0x368");
static_assert(offsetof(UGameViewportClient, World) == 0x70, "World must be at 0x70");
static_assert(offsetof(UGameViewportClient, GameInstance) == 0x78, "GameInstance must be at 0x78");

class UGameInstance : public UObject
{
public:
    uint8_t Pad_GI[0x10]; // 0x28(0x10)
    TArray<ULocalPlayer*> LocalPlayers; // 0x38(0x10)
    uint8_t Pad_GIEnd[0x160]; // 0x48 - 0x1A8

    static UClass* StaticClass();
};
static_assert(sizeof(UGameInstance) == 0x1A8, "UGameInstance size must be 0x1A8");

class UEngine : public UObject
{
public:
    uint8_t Pad_Engine[0x760]; // 0x28 - 0x788
    UGameViewportClient* GameViewport; // 0x788(0x8)
    uint8_t Pad_EngineEnd[0x6D0]; // 0x790 - 0xE60

    static UClass* StaticClass();
};
static_assert(sizeof(UEngine) == 0xE60, "UEngine size must be 0xE60");
static_assert(offsetof(UEngine, GameViewport) == 0x788, "GameViewport must be at 0x788");

class ULevelActorContainer : public UObject
{
public:
    TArray<AActor*> Actors; // 0x28, dump_Engine_classes.hpp: LevelActorContainer
};
static_assert(sizeof(ULevelActorContainer) == 0x38, "LevelActorContainer size");
static_assert(offsetof(ULevelActorContainer, Actors) == 0x28, "Container Actors must be at 0x28");

class ULevel : public UObject
{
public:
    uint8_t Pad_Level0[0x70]; // 0x28 - 0x98
    TArray<AActor*> Actors; // 0x98, existing native array (not reflected by the dump)
    uint8_t Pad_Level1[0x10]; // 0xA8 - 0xB8
    UWorld* OwningWorld; // 0xB8, reflected
    uint8_t Pad_Level2[0x18]; // 0xC0 - 0xD8
    ULevelActorContainer* ActorCluster; // 0xD8, reflected; supplements native Actors
    uint8_t Pad_Level3[0x3A0]; // 0xE0 - 0x480

    static UClass* StaticClass();
};
static_assert(sizeof(ULevel) == 0x480, "ULevel size must be 0x480");
static_assert(offsetof(ULevel, Actors) == 0x98, "Level Actors must be at 0x98");
static_assert(offsetof(ULevel, OwningWorld) == 0xB8, "Level OwningWorld must be at 0xB8");
static_assert(offsetof(ULevel, ActorCluster) == 0xD8, "Level ActorCluster must be at 0xD8");

class UWorld : public UObject
{
public:
    uint8_t Pad_World[0x8];          // 0x28(0x8)
    ULevel* PersistentLevel;          // 0x30(0x8)
    uint8_t Pad_0x38[0x50];           // 0x38 - 0x88
    TArray<ULevel*> StreamingLevelsPad; // 0x88(0x10) - ULevelStreaming* but we skip
    uint8_t Pad_0x98[0xA0];           // 0x98 - 0x138
    TArray<ULevel*> Levels;           // 0x138(0x10)
    uint8_t Pad_0x148[0x38];          // 0x148 - 0x180
    UGameInstance* OwningGameInstance; // 0x180(0x8)
    uint8_t Pad_WorldEnd[0x748];      // 0x188 - 0x8D0

    void GetActors(std::vector<AActor*>& outActors) const;
    static UClass* StaticClass();
};
static_assert(sizeof(UWorld) == 0x8D0, "UWorld size must be 0x8D0");
static_assert(offsetof(UWorld, PersistentLevel) == 0x30, "PersistentLevel must be at 0x30");
static_assert(offsetof(UWorld, Levels) == 0x138, "Levels must be at 0x138");
static_assert(offsetof(UWorld, OwningGameInstance) == 0x180, "OwningGameInstance must be at 0x180");

// ==================== HUD & Canvas ====================

class UCanvas : public UObject
{
public:
    float OrgX; // 0x28(0x4)
    float OrgY; // 0x2C(0x4)
    float ClipX; // 0x30(0x4)
    float ClipY; // 0x34(0x4)
    uint8_t Pad_Canvas0[0x8]; // 0x38(0x8)
    int32_t SizeX; // 0x40(0x4)
    int32_t SizeY; // 0x44(0x4)
    uint8_t Pad_CanvasEnd[0x278]; // 0x48 - 0x2C0

    void K2_DrawLine(const FVector2D& ScreenPositionA, const FVector2D& ScreenPositionB, float Thickness = 1.0f, const FLinearColor& RenderColor = {1,1,1,1});
    void K2_DrawBox(const FVector2D& ScreenPosition, const FVector2D& ScreenSize, float Thickness = 1.0f, const FLinearColor& RenderColor = {1,1,1,1});
    void K2_DrawText(UObject* RenderFont, const FString& RenderText, const FVector2D& ScreenPosition, const FVector2D& Scale = {1,1}, const FLinearColor& RenderColor = {1,1,1,1}, float Kerning = 0.0f, const FLinearColor& ShadowColor = {0,0,0,1}, const FVector2D& ShadowOffset = {1,1}, bool bCentreX = false, bool bCentreY = false, bool bOutlined = false, const FLinearColor& OutlineColor = {0,0,0,1});
    void K2_DrawTexture(UObject* RenderTexture, const FVector2D& ScreenPosition, const FVector2D& ScreenSize, const FVector2D& CoordinatePosition = {0.0f, 0.0f}, const FVector2D& CoordinateSize = {1.0f, 1.0f}, const FLinearColor& RenderColor = {1,1,1,1}, uint8_t BlendMode = 2, float Rotation = 0.0f, const FVector2D& PivotPoint = {0.0f, 0.0f});
    FVector K2_Project(const FVector& WorldLocation);

    static UClass* StaticClass();
};
static_assert(sizeof(UCanvas) == 0x2C0, "UCanvas size must be 0x2C0");
static_assert(offsetof(UCanvas, ClipX) == 0x30, "ClipX must be at 0x30");
static_assert(offsetof(UCanvas, ClipY) == 0x34, "ClipY must be at 0x34");
static_assert(offsetof(UCanvas, SizeX) == 0x40, "SizeX must be at 0x40");
static_assert(offsetof(UCanvas, SizeY) == 0x44, "SizeY must be at 0x44");

class AHUD : public AActor
{
public:
    APlayerController* PlayerOwner; // 0x300(0x8)
    uint8_t Pad_HUD0[0x48]; // 0x308 - 0x350 (0x308 has bShowHUD at bit 1)
    UCanvas* Canvas; // 0x350(0x8)
    UCanvas* DebugCanvas; // 0x358(0x8)
    uint8_t Pad_HUD1[0x90]; // 0x360 - 0x3F0

    static UClass* StaticClass();
};
static_assert(sizeof(AHUD) == 0x3F0, "AHUD size must be 0x3F0");
static_assert(offsetof(AHUD, PlayerOwner) == 0x300, "PlayerOwner must be at 0x300");
static_assert(offsetof(AHUD, Canvas) == 0x350, "Canvas must be at 0x350");

// ==================== GameplayStatics ====================

class UGameplayStatics : public UObject
{
public:
    static void GetAllActorsOfClass(UObject* WorldContextObject, UClass* ActorClass, TArray<AActor*>* OutActors);
    static bool ProjectWorldToScreen(APlayerController* Player, const FVector& WorldPosition, FVector2D& ScreenPosition, bool bPlayerViewportRelative = false);

    static UClass* StaticClass();
};

class USGGameplayStatics : public UObject
{
public:
    static bool ProjectWorldToScreenDualFov(APlayerController* Player, const FVector& WorldPosition, FVector2D& ScreenPosition, bool bPlayerViewportRelative = false);

    static UClass* StaticClass();
};

class USGCharacterStatics : public UObject
{
public:
    static FVector GetBoneLocationByName(ACharacter* Character, const char* BoneName);
    static UClass* StaticClass();
};

// ==================== Pre-cached UFunctions ====================

extern UFunction* g_fnReceiveDrawHUD;
extern UFunction* g_fnDrawHUD;
extern UFunction* g_fnPostRender;
extern UFunction* g_fnCanvasDraw;
extern UFunction* g_fnSetCanCanvasDraw;
extern UFunction* g_fnOnNewWidgetCreated;
extern UFunction* g_fnK2_DrawLine;
extern UFunction* g_fnK2_DrawBox;
extern UFunction* g_fnK2_DrawText;
extern UFunction* g_fnK2_DrawTexture;
extern UFunction* g_fnK2_Project;
extern UFunction* g_fnGetCharacterHealthComponent;
extern UFunction* g_fnGetHealth;
extern UFunction* g_fnGetHealthMax;
extern UFunction* g_fnGetInputTouchState;

// ==================== Parameter Structs for Event Interception ====================

struct SGUserWidget_CanvasDraw_Params
{
    float InDeltaTime; // 0x0(0x4)
    uint8_t Pad_0x4[0x4]; // 0x4(0x4)
    class UCanvas* InCanvas; // 0x8(0x8)
    struct FVector2D InCanvasCenter; // 0x10(0x8)
};

struct SGHUD_OnNewWidgetCreated_Params
{
    class UObject* NewWidget; // 0x0(0x8)
};

struct SGUserWidget_SetCanCanvasDraw_Params
{
    bool bNewCanCanvasDraw; // 0x0(0x1)
};

void PrecacheAllFunctions();

} // namespace SDK
