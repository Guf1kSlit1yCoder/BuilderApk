#!/bin/bash

echo "========================================================"
echo "Arena Breakout ESP - ADB Injector Launcher"
echo "========================================================"

ADB_PATH="C:/Users/GAMER/AppData/Local/Android/Sdk/platform-tools/adb.exe"
if command -v adb &> /dev/null; then
    ADB="adb"
elif [ -f "$ADB_PATH" ]; then
    ADB="$ADB_PATH"
else
    ADB="adb"
fi

echo "[1/3] Checking connected device..."
$ADB wait-for-device

if [ -f "libs/arm64-v8a/libarena_esp.so" ]; then
    echo "[PUSH] Copying libs/arm64-v8a/libarena_esp.so to /data/local/tmp/..."
    $ADB push libs/arm64-v8a/libarena_esp.so /data/local/tmp/libarena_esp.so
    $ADB shell "su -c 'chmod 777 /data/local/tmp/libarena_esp.so'"
fi

echo "[3/3] Executing injector..."
$ADB shell su -c "/data/local/tmp/injector --package com.eu.mf.uamo --libs /data/local/tmp/libarena_esp.so --memfd"
