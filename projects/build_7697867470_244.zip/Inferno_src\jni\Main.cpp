#include <jni.h>
#include <pthread.h>
#include <unistd.h>
#include <atomic>
#include <dlfcn.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <chrono>
#include <cinttypes>
#include <algorithm>

#include "Login.h"
#include "AntiCrack/AntiDebug.h"
#include "Memory/Tools.h"
#include "Memory/Hooks.h"
#include "Config.h"
#include "Core/UE4Helper.h"
#include "Core/ESP.h"
#include "Core/Aimbot.h"
#include "Core/MemoryHacks.h"
#include "Core/ActorPipeline.h"
#include "Core/CrashLog.h"
#include <mutex>
#include "UI/Menu.h"
#include "UI/TouchHelper.h"
#include "UI/liquid_glass_gl.h"
#include "UI/bg_texture.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_opengl3.h"
#include <android/input.h>

static std::atomic<bool> g_ThreadStarted{false};
static std::atomic<bool> g_ShouldUnload{false};
static int g_ScreenWidth = 1920;
static int g_ScreenHeight = 1080;
static std::atomic<uint64_t> g_RenderFrameCounter{0};
static std::atomic<int> g_RealScreenW{0};
static std::atomic<int> g_RealScreenH{0};
JavaVM* g_JavaVM = nullptr;

// Boot trace (diagnostic only): append a milestone to a file so the LAST line
// written before an inject crash tells us exactly how far startup got.
#ifdef ARENA_DIAG
#include <cstdio>
#include <ctime>
static void BOOT(const char* tag) {
    FILE* f = fopen("/sdcard/Download/arena_boot.txt", "a");
    if (f) { fprintf(f, "%llu %s\n", (unsigned long long)time(nullptr), tag); fclose(f); }
}
#else
static inline void BOOT(const char*) {}
#endif

static JavaVM* GetJavaVM() {
    if (g_JavaVM) return g_JavaVM;
    typedef jint (*GetVMs_t)(JavaVM**, jsize, jsize*);
    const char* libs[] = { "libart.so", "libnativehelper.so" };
    for (const char* lib : libs) {
        void* h = dlopen(lib, RTLD_NOW | RTLD_NOLOAD);
        if (!h) h = dlopen(lib, RTLD_NOW);
        if (!h) continue;
        auto fn = reinterpret_cast<GetVMs_t>(dlsym(h, "JNI_GetCreatedJavaVMs"));
        JavaVM* vm = nullptr; jsize n = 0;
        if (fn && fn(&vm, 1, &n) == JNI_OK && n > 0 && vm) { g_JavaVM = vm; break; }
    }
    return g_JavaVM;
}

static bool JniFail(JNIEnv* env) {
    if (env->ExceptionCheck()) { env->ExceptionClear(); return true; }
    return false;
}

static bool QueryRealScreenSize(int& outW, int& outH) {
    JavaVM* vm = GetJavaVM();
    if (!vm) return false;
    JNIEnv* env = nullptr;
    bool attached = false;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return false;
        attached = true;
    }
    bool ok = false;
    env->PushLocalFrame(32);
    do {
        jclass atCls = env->FindClass("android/app/ActivityThread");
        if (JniFail(env) || !atCls) break;
        jmethodID curApp = env->GetStaticMethodID(atCls, "currentApplication", "()Landroid/app/Application;");
        if (JniFail(env) || !curApp) break;
        jobject app = env->CallStaticObjectMethod(atCls, curApp);
        if (JniFail(env) || !app) break;

        jclass ctxCls = env->FindClass("android/content/Context");
        if (JniFail(env)) break;
        jmethodID getSvc = env->GetMethodID(ctxCls, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
        if (JniFail(env)) break;
        jstring wsName = env->NewStringUTF("window");
        jobject wm = env->CallObjectMethod(app, getSvc, wsName);
        if (JniFail(env) || !wm) break;

        jclass wmCls = env->FindClass("android/view/WindowManager");
        if (JniFail(env)) break;
        jmethodID getDisp = env->GetMethodID(wmCls, "getDefaultDisplay", "()Landroid/view/Display;");
        if (JniFail(env)) break;
        jobject disp = env->CallObjectMethod(wm, getDisp);
        if (JniFail(env) || !disp) break;

        jclass dmCls = env->FindClass("android/util/DisplayMetrics");
        if (JniFail(env)) break;
        jmethodID dmCtor = env->GetMethodID(dmCls, "<init>", "()V");
        jobject dm = env->NewObject(dmCls, dmCtor);
        if (JniFail(env) || !dm) break;

        jclass dispCls = env->FindClass("android/view/Display");
        if (JniFail(env)) break;
        jmethodID getReal = env->GetMethodID(dispCls, "getRealMetrics", "(Landroid/util/DisplayMetrics;)V");
        if (JniFail(env)) break;
        env->CallVoidMethod(disp, getReal, dm);
        if (JniFail(env)) break;

        jfieldID fw = env->GetFieldID(dmCls, "widthPixels", "I");
        jfieldID fh = env->GetFieldID(dmCls, "heightPixels", "I");
        if (JniFail(env)) break;
        outW = env->GetIntField(dm, fw);
        outH = env->GetIntField(dm, fh);
        ok = outW > 0 && outH > 0;
    } while (false);
    env->PopLocalFrame(nullptr);
    if (attached) vm->DetachCurrentThread();
    return ok;
}

// ==================== Native Android Input Hook ====================
typedef int32_t (*AInputQueue_getEvent_t)(AInputQueue* queue, AInputEvent** outEvent);
static AInputQueue_getEvent_t orig_AInputQueue_getEvent = nullptr;
static std::atomic<bool> g_InputHooked{false};

int32_t hk_AInputQueue_getEvent(AInputQueue* queue, AInputEvent** outEvent) {
    if (g_ShouldUnload.load()) {
        // Pass through without processing during unload
        return orig_AInputQueue_getEvent ? orig_AInputQueue_getEvent(queue, outEvent) : -1;
    }
    if (!orig_AInputQueue_getEvent || !outEvent) return -1;
    // Consume complete UI gestures. The old hook ignored HandleInputEvent's
    // result, so toggling/sliding the menu also drove the game's touch controls.
    for (int i = 0; i < 64; ++i) {
        const int32_t res = orig_AInputQueue_getEvent(queue, outEvent);
        if (res < 0 || !*outEvent) return res;
        if (!TouchHelper::HandleInputEvent(*outEvent)) return res;
        AInputQueue_finishEvent(queue, *outEvent, 1);
        *outEvent = nullptr;
    }
    return -1;
}

static bool InstallInputHook() {
    if (g_InputHooked.load()) return true;

    void* libAndroid = dlopen("libandroid.so", RTLD_NOW);
    if (!libAndroid) {
        libAndroid = dlopen("libandroid.so", RTLD_LAZY);
    }
    if (!libAndroid) return false;

    void* symEvent = dlsym(libAndroid, "AInputQueue_getEvent");
    if (!symEvent) return false;

    bool success = Hooks::HookFunction(
        symEvent,
        reinterpret_cast<void*>(hk_AInputQueue_getEvent),
        reinterpret_cast<void**>(&orig_AInputQueue_getEvent)
    );
    if (success) {
        LOGI("[Input] Inline hook installed on AInputQueue_getEvent! (trampoline=%p)", orig_AInputQueue_getEvent);
        g_InputHooked.store(true);
    }
    return success;
}

// ==================== EGL Hook & OpenGL ES Render Pipeline ====================
typedef EGLBoolean (*EGLSwapBuffers_t)(EGLDisplay dpy, EGLSurface surface);
typedef EGLBoolean (*EGLSwapBuffersWithDamageKHR_t)(EGLDisplay dpy, EGLSurface surface, EGLint* rects, EGLint n_rects);

static EGLSwapBuffers_t orig_eglSwapBuffers = nullptr;
static EGLSwapBuffersWithDamageKHR_t orig_eglSwapBuffersWithDamageKHR = nullptr;
static std::atomic<bool> g_EglHooked{false};
static bool g_ImGuiInitialized = false;
static std::mutex g_RenderMutex;

// ==================== Teardown / Lobby Transition Guard ====================
// When GameActivity closes, the game destroys the EGL surface and frees UWorld/levels/actors.
// If the EGL surface drops to 0, or IsWorldReady fails repeatedly, we freeze all game memory
// access for 2 seconds to avoid reading deallocated/unmapped objects.
static auto s_MemoryPauseUntil = std::chrono::steady_clock::time_point::min();
static int s_FailedWorldReadyStreak = 0;
constexpr int MAX_FAILED_WORLD_STREAK = 3;
constexpr auto WORLD_PAUSE_DURATION = std::chrono::milliseconds(2000);

static void TriggerGameTeardownCooldown(const char* reason) {
    s_MemoryPauseUntil = std::chrono::steady_clock::now() + WORLD_PAUSE_DURATION;
    s_FailedWorldReadyStreak = 0;
    UE4Helper::ResetWorldState();
    ActorPipeline::Reset();
    ESP::g_Enemies.clear();
    Aimbot::g_TargetPlayer = nullptr;
    LOGW("[TeardownGuard] %s! Freezing game memory reads for 2 seconds.", reason);
}

static void RenderGLESFrame(EGLDisplay dpy, EGLSurface surface) {
    // ImGui/context and frame caches have one owner. Skip concurrent swaps;
    // never stall the game's other EGL threads waiting for an overlay.
    std::unique_lock<std::mutex> renderLock(g_RenderMutex, std::try_to_lock);
    if (!renderLock.owns_lock() || g_ShouldUnload.load()) return;
    const EGLContext context = eglGetCurrentContext();
    if (context == EGL_NO_CONTEXT || eglGetCurrentSurface(EGL_DRAW) != surface) return;
    static EGLContext ownerContext = EGL_NO_CONTEXT;
    if (ownerContext != EGL_NO_CONTEXT && ownerContext != context) return;
    EGLint width = 0, height = 0;
    eglQuerySurface(dpy, surface, EGL_WIDTH, &width);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &height);

    if (width <= 0 || height <= 0) {
        GLint vp[4] = {0, 0, 0, 0};
        glGetIntegerv(GL_VIEWPORT, vp);
        width = vp[2];
        height = vp[3];
    }
    if (width <= 0 || height <= 0) {
        TriggerGameTeardownCooldown("EGL surface resized to 0 or destroyed");
        return;
    }

    // UE4 on tablets shrinks the EGL buffer (MobileContentScaleFactor) while
    // AMotionEvent stays in real screen pixels, so map screen -> buffer space.
    const int dispW = width, dispH = height;
    {
        float sx = 1.0f, sy = 1.0f;
        int rw = g_RealScreenW.load(), rh = g_RealScreenH.load();
        if (rw > 0 && rh > 0) {
            if ((width > height) != (rw > rh)) std::swap(rw, rh);
            sx = (float)width / (float)rw;
            sy = (float)height / (float)rh;
        }
        sx *= g_Config.touch_scale_x;
        sy *= g_Config.touch_scale_y;
        TouchHelper::SetDisplayScale(sx, sy);
        static int s_LoggedW = 0, s_LoggedH = 0;
        if (s_LoggedW != width || s_LoggedH != height) {
            s_LoggedW = width; s_LoggedH = height;
            LOGI("[Touch] EGL %dx%d, real screen %dx%d, touch scale %.3f x %.3f",
                 width, height, rw, rh, sx, sy);
        }
    }

    g_ScreenWidth  = dispW;
    g_ScreenHeight = dispH;

    if (!g_ImGuiInitialized) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.DisplaySize = ImVec2(static_cast<float>(dispW), static_cast<float>(dispH));

        Menu::InitStyle();
        ImGui_ImplOpenGL3_Init("#version 300 es");
        LiquidGlass::Init();
        BgTexture::Init();
        g_ImGuiInitialized = true;
        ownerContext = context;
        LOGI("[GLES] Dear ImGui successfully initialized with OpenGL ES 3.0! Surface: %dx%d", width, height);
    }

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(static_cast<float>(dispW), static_cast<float>(dispH));

    static auto s_LastTime = std::chrono::steady_clock::now();
    auto currentTime = std::chrono::steady_clock::now();
    float deltaTime = std::chrono::duration<float>(currentTime - s_LastTime).count();
    s_LastTime = currentTime;
    io.DeltaTime = (deltaTime > 0.0f) ? std::min(deltaTime, 0.25f) : (1.0f / 60.0f);

    const auto now = std::chrono::steady_clock::now();
    const bool isMemoryPaused = (now < s_MemoryPauseUntil);

    // If input hook is not active and touch function was already found, allow fallback
    if (!g_InputHooked.load() && SDK::g_fnGetInputTouchState && !isMemoryPaused) {
        auto ctrl = UE4Helper::GetPlayerController();
        if (ctrl) {
            Menu::UpdateInput(ctrl);
        }
    }

    // TouchHelper applies input
    TouchHelper::ApplyPendingInput();
    // Begin ImGui Frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();

    uint64_t frame = ++g_RenderFrameCounter;
#ifdef ARENA_DIAG
    {
        const float ms = deltaTime * 1000.0f;
        if (ms > 50.0f) {   // frame hitch: >50ms = lag, >200ms = freeze
            FILE* lf = fopen("/sdcard/Download/arena_esp_diag.txt", "a");
            if (lf) {
                fprintf(lf, "[%s] frame=%llu dt=%.1fms fps=%.1f\n",
                        ms > 200.0f ? "FREEZE" : "LAG",
                        (unsigned long long)frame, ms, io.Framerate);
                fclose(lf);
            }
        }
    }
#endif
    if (frame == 1 || frame == 10 || frame % 300 == 0) {
        LOGI("[GLES] Frame #%" PRIu64 " rendered via OpenGL ES (%dx%d, FPS: %.1f)",
             frame, width, height, io.Framerate);
    }

    // Apply toggles before this frame's work. Screen-only overlays and stub
    // features do not need to discover a world or enumerate actors.
    Menu::Render(width, height);
    // Gate all gameplay work on the sealed auth state, not just the menu UI.
    // Writing the feature toggles directly (without a valid login) buys nothing.
    // System 3: ESP + aim are tied to the VM session key too, not just the auth
    // gate — a login bypass yields no key, so the whole actor pipeline stays dead.
    const bool authed = Login::Authorized() && Login::SessionValid()
                        && !AntiCrack::AntiDebug::I().IsCompromised();
    const bool needActors = authed && (g_Config.esp_enabled || g_Config.aimbot_enabled);
    const bool needWorld = authed && (needActors || g_Config.mem_wide_view || MemoryHacks::HasPendingRestore());

    ESP::g_Enemies.clear();
    Aimbot::g_TargetPlayer = nullptr;
    if (!needActors || isMemoryPaused) ActorPipeline::Reset();
    if (needWorld && !g_ShouldUnload.load() && !isMemoryPaused) {
        // Bind the world/player snapshot before querying the world. This prevents
        // an extra GetWorld/GetLocalPlayer resolution on every render frame.
        const UE4Helper::ScopedFrame frameState;
        auto world = UE4Helper::GetWorld();
        if (world && UE4Helper::IsWorldReady(world)) {
            // World is valid and verified healthy
            s_FailedWorldReadyStreak = 0;

            ImDrawList* bgDrawList = ImGui::GetBackgroundDrawList();

            // 1. Render ESP
            if (g_Config.esp_enabled || g_Config.aimbot_enabled) {
                ESP::RenderImGuiESP(bgDrawList, width, height);
            }

            // 2. Render Overlays (FOV Circle, Crosshair)
            if (g_Config.aimbot_enabled || g_Config.mem_crosshair) {
                Aimbot::DrawOverlay(bgDrawList, width, height);
            }

            // 3. Update Aimbot
            if (g_Config.aimbot_enabled) {
                Aimbot::Update(width, height);
            }

            // 4. Update Memory Hacks
            if (g_Config.mem_no_recoil || g_Config.mem_wide_view || g_Config.mem_fast_shoot) {
                MemoryHacks::Update();
            }
        } else {
            UE4Helper::ResetWorldState();
            s_FailedWorldReadyStreak++;
            if (s_FailedWorldReadyStreak >= MAX_FAILED_WORLD_STREAK) {
                TriggerGameTeardownCooldown("IsWorldReady failed repeatedly (lobby / activity transition)");
            }
        }
    } else if (isMemoryPaused) {
        UE4Helper::ResetWorldState();
    }

    // Finalize ImGui and submit to OpenGL ES
    ImGui::EndFrame();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    TouchHelper::PublishCaptureState();
}

EGLBoolean hk_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    if (!g_ShouldUnload.load()) {
        RenderGLESFrame(dpy, surface);
    }
    return orig_eglSwapBuffers ? orig_eglSwapBuffers(dpy, surface) : EGL_TRUE;
}

EGLBoolean hk_eglSwapBuffersWithDamageKHR(EGLDisplay dpy, EGLSurface surface, EGLint* rects, EGLint n_rects) {
    if (!g_ShouldUnload.load()) {
        RenderGLESFrame(dpy, surface);
    }
    return orig_eglSwapBuffersWithDamageKHR ? orig_eglSwapBuffersWithDamageKHR(dpy, surface, rects, n_rects) : EGL_TRUE;
}

static bool InstallEglHook() {
    if (g_EglHooked.load()) return true;

    void* eglHandle = dlopen("libEGL.so", RTLD_NOW);
    void* swapBuffersAddr = nullptr;
    void* swapDamageAddr = nullptr;

    if (eglHandle) {
        swapBuffersAddr = dlsym(eglHandle, "eglSwapBuffers");
        swapDamageAddr = dlsym(eglHandle, "eglSwapBuffersWithDamageKHR");
        LOGI("[EGL] Resolved from libEGL.so: eglSwapBuffers=%p, eglSwapBuffersWithDamageKHR=%p",
             swapBuffersAddr, swapDamageAddr);
    }

    if (!swapBuffersAddr) {
        swapBuffersAddr = dlsym(RTLD_DEFAULT, "eglSwapBuffers");
        LOGI("[EGL] Resolved from RTLD_DEFAULT: eglSwapBuffers=%p", swapBuffersAddr);
    }

    if (!swapBuffersAddr) {
        swapBuffersAddr = reinterpret_cast<void*>(eglSwapBuffers);
        LOGI("[EGL] Fallback direct link: eglSwapBuffers=%p", swapBuffersAddr);
    }

    bool success = false;
    if (swapBuffersAddr) {
        LOGI("[EGL] Installing inline hook on eglSwapBuffers at %p...", swapBuffersAddr);
        success = Hooks::HookFunction(
            swapBuffersAddr,
            reinterpret_cast<void*>(hk_eglSwapBuffers),
            reinterpret_cast<void**>(&orig_eglSwapBuffers)
        );
        if (success) {
            LOGI("[EGL] [SUCCESS] Inline hook installed on eglSwapBuffers! (trampoline=%p)", orig_eglSwapBuffers);
            g_EglHooked.store(true);
        } else {
            LOGE("[EGL] [ERROR] Failed to hook eglSwapBuffers!");
        }
    }

    // Only hook eglSwapBuffersWithDamageKHR if primary eglSwapBuffers could not be hooked
    if (!success && swapDamageAddr) {
        bool damageHooked = Hooks::HookFunction(
            swapDamageAddr,
            reinterpret_cast<void*>(hk_eglSwapBuffersWithDamageKHR),
            reinterpret_cast<void**>(&orig_eglSwapBuffersWithDamageKHR)
        );
        if (damageHooked) {
            LOGI("[EGL] [SUCCESS] Inline hook installed on eglSwapBuffersWithDamageKHR!");
            g_EglHooked.store(true);
            success = true;
        }
    }

    return success;
}

// ==================== Mod Unload ====================
// Called from UnloadThread — runs dlclose on our own library to fully eject it from the process.
static void* UnloadThread(void* /*arg*/) {
    LOGI("[Unload] UnloadThread started (TID: %d). Beginning safe shutdown sequence.", gettid());

    // 1. Signal all hooked functions to stop rendering / processing input
    g_ShouldUnload.store(true);

    // 2. Give the render thread a few frames to finish its current work
    usleep(300000); // 300ms

    // 3. Remove all inline hooks and vtable hooks
    Hooks::UnhookAll();
    g_EglHooked.store(false);
    g_InputHooked.store(false);
    LOGI("[Unload] All hooks removed.");

    // 4. Shutdown ImGui on the next available moment (safe: hooks are gone, no more RenderGLESFrame)
    if (g_ImGuiInitialized) {
        BgTexture::Shutdown();
        LiquidGlass::Shutdown();
        ImGui_ImplOpenGL3_Shutdown();
        ImGui::DestroyContext();
        g_ImGuiInitialized = false;
        LOGI("[Unload] ImGui context destroyed.");
    }

    // 5. Save config before leaving
    ConfigManager::SaveConfig();
    LOGI("[Unload] Config saved.");

    usleep(100000); // 100ms extra safety margin

    // 6. Find our own library handle and dlclose it — this unloads the .so from the process
    void* self = dlopen(OBFUSCATE("libarena.so"), RTLD_NOLOAD | RTLD_NOW);
    if (!self) {
        // Try alternate common injection names
        self = dlopen(OBFUSCATE("libengine_android.so"), RTLD_NOLOAD | RTLD_NOW);
    }
    if (self) {
        LOGI("[Unload] Found our library handle %p — calling dlclose to eject.", self);
        // dlclose twice: once to drop the RTLD_NOLOAD reference, once to actually unload
        dlclose(self);
        dlclose(self);
    } else {
        LOGW("[Unload] Could not find own library handle via dlopen(RTLD_NOLOAD). Module stays mapped but hooks are removed.");
    }

    LOGI("[Unload] Shutdown complete.");
    return nullptr;
}

void RequestUnload() {
    if (g_ShouldUnload.load()) return; // Already unloading
    LOGI("[Unload] Unload requested by user via menu.");
    pthread_t thread;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&thread, &attr, UnloadThread, nullptr);
    pthread_attr_destroy(&attr);
}

// ==================== Background Logic Thread ====================
void* MainThread(void* arg) {
    BOOT("MainThread:enter");
    LOGI("[MainThread] Arena Android Engine Thread Started (TID: %d)!", gettid());

    // Give process and game threads a moment to stabilize after injection
    sleep(2);
    BOOT("MainThread:preInitUE4");

    int waitCount = 0;
    while (!UE4Helper::InitUE4() && !g_ShouldUnload.load()) {
        usleep(500000); // 500ms
        waitCount++;
        if (waitCount % 10 == 0) {
            LOGI("[MainThread] Still waiting for libUE4.so to be loaded into memory... (waited %d sec)", waitCount / 2);
        }
    }
    if (g_ShouldUnload.load()) return nullptr;
    LOGI("[MainThread] libUE4.so successfully initialized at base: 0x%" PRIXPTR, UE4Helper::g_UE4Base);
    BOOT("MainThread:UE4ready");

    // Initialize config before publishing render/input hooks; the render thread
    // owns config afterwards, avoiding string/bool races during startup.
    // Load initial config (visual preferences, scales, etc.)
    ConfigManager::LoadConfig();
    BOOT("MainThread:configLoaded");

    // No auto-login: every launch (each re-injection after the cheat is unloaded)
    // must show the activation window and have the user paste + activate the key.
    g_Config.is_logged_in = false;

    // Feature toggles persist from the saved config. Safety is enforced elsewhere:
    // nothing runs until Login::Authorized() AND the world is ready (RenderGLESFrame
    // gates on authed + IsWorldReady + the teardown cooldown), so restoring the
    // user's last-enabled features at startup cannot read memory early or crash.
    LOGI("[MainThread] Configuration loaded (feature toggles restored from config).");
    InstallEglHook();
    InstallInputHook();
    BOOT("MainThread:hooksInstalled");

    // Э5.1: baseline our own code pages (clean) for runtime integrity checks.
    AntiCrack::Integrity::I().Init();
    BOOT("MainThread:integrityInit");

    int tickCount = 0;
    while (!g_ShouldUnload.load()) {
        if (!g_EglHooked.load()) {
            InstallEglHook();
        }
        if (!g_InputHooked.load()) {
            InstallInputHook();
        }

        // Э5.1: re-verify our code integrity every ~3s. A memory patch of the
        // protection path changes the hash -> Login::Authorized() then fails.
        if (tickCount % 15 == 0) {
            AntiCrack::Integrity::I().Verify();
        }

        // Killswitch: re-check with the server every ~2 min. A banned/disabled key
        // (or expiry) kills the live session; network blips are tolerated.
        if (tickCount != 0 && tickCount % 600 == 0) {
            Login::Heartbeat();
        }

        // Re-query every ~2s: covers rotation and late Application init.
        if (tickCount % 10 == 0) {
            int rw = 0, rh = 0;
            if (QueryRealScreenSize(rw, rh)) {
                g_RealScreenW.store(rw);
                g_RealScreenH.store(rh);
            }
        }

        tickCount++;
        if (tickCount % 25 == 0) {
            LOGD("[MainThread] Heartbeat: GLES Hooked=%s, Input Hooked=%s, Frames=%" PRIu64,
                 g_EglHooked.load() ? "YES" : "NO", g_InputHooked.load() ? "YES" : "NO", g_RenderFrameCounter.load());
        }

        usleep(200000); // 200ms idle sleep
    }
    LOGI("[MainThread] Exiting main loop due to unload request.");
    return nullptr;
}

// Cross-module duplicate-load guard. Exported by name so a second copy in the
// same process can find it via dlsym; the name is deliberately innocuous (reads
// like benign GL state) rather than advertising the module.
extern "C" __attribute__((visibility("default"))) int g_eglCtxPresentState = 0x1;

static bool IsAlreadyLoadedInProcess() {
    void* existing = dlsym(RTLD_DEFAULT, "g_eglCtxPresentState");
    if (existing && existing != reinterpret_cast<void*>(&g_eglCtxPresentState)) {
        return true;
    }
    return false;
}

static void StartMainThreadIfNeeded() {
    if (IsAlreadyLoadedInProcess()) {
        LOGW("[Init] Arena Android Engine is ALREADY loaded in this process! Aborting duplicate initialization to prevent crash.");
        return;
    }
    bool expected = false;
    if (g_ThreadStarted.compare_exchange_strong(expected, true)) {
        BOOT("StartMainThread:spawning");
        LOGI("[Init] Spawning MainThread...");
        pthread_t thread;
        pthread_create(&thread, nullptr, MainThread, nullptr);
        BOOT("StartMainThread:preWatchdog");
        // NOTE: StartPtraceGuard() (fork-based anti-attach) is disabled — fork() in
        // the game's multithreaded process crashes on inject. Detection via the
        // watchdog's TracerPid check still covers debugger attaches.
        AntiCrack::AntiDebug::StartWatchdog();   // anti-debug/anti-instrumentation watchdog
        BOOT("StartMainThread:postWatchdog");
    }
}

// ==================== JNI & Library Entry Points ====================
extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    BOOT("JNI_OnLoad:enter");
    LOGI("[JNI] JNI_OnLoad called - initializing Arena Android module (OpenGL ES 3.0 mode)");
    g_JavaVM = vm;
    if (IsAlreadyLoadedInProcess()) {
        LOGW("[JNI] Duplicate module load detected! Aborting initialization.");
        return JNI_VERSION_1_6;
    }
    Tools::InstallCrashHandler();
    StartMainThreadIfNeeded();
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT void JNICALL JNI_OnUnload(JavaVM* vm, void* reserved) {
    LOGI("[JNI] JNI_OnUnload called — performing final cleanup.");
    if (!g_ShouldUnload.load()) {
        // Ensure hooks are removed even if unload was triggered externally
        g_ShouldUnload.store(true);
        usleep(200000);
        Hooks::UnhookAll();
        if (g_ImGuiInitialized) {
            BgTexture::Shutdown();
            LiquidGlass::Shutdown();
            ImGui_ImplOpenGL3_Shutdown();
            ImGui::DestroyContext();
            g_ImGuiInitialized = false;
        }
    }
    LOGI("[JNI] JNI_OnUnload complete.");
}

__attribute__((constructor))
void NativeInit() {
    BOOT("NativeInit:enter");
    LOGI("[Native] Native constructor executed! Setting up crash handlers.");
    if (IsAlreadyLoadedInProcess()) {
        LOGW("[Native] Duplicate module load detected! Aborting initialization.");
        return;
    }
    CrashLog::Init();
    Tools::InstallCrashHandler();
    CrashLog::Log("NativeInit: module loaded, pid=%d", getpid());
    StartMainThreadIfNeeded();
}

__attribute__((destructor))
void NativeDestroy() {
    LOGI("[Native] Native destructor — ensuring hooks are cleaned up.");
    if (!g_ShouldUnload.load()) {
        g_ShouldUnload.store(true);
        usleep(150000);
        Hooks::UnhookAll();
        if (g_ImGuiInitialized) {
            ImGui_ImplOpenGL3_Shutdown();
            ImGui::DestroyContext();
            g_ImGuiInitialized = false;
        }
    }
}
