#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/uio.h>
#include <string>
#include <vector>
#include <cmath>

static pid_t g_Pid = -1;
static uintptr_t g_LibBase = 0;
static uintptr_t g_GNames = 0;
static uintptr_t g_GUObjectArray = 0;

static bool ReadMem(uintptr_t addr, void* buf, size_t size) {
    if (addr < 0x10000ULL || addr > 0x00007FFFFFFFFFFFULL) return false;
    struct iovec local = { buf, size };
    struct iovec remote = { (void*)addr, size };
    ssize_t n = process_vm_readv(g_Pid, &local, 1, &remote, 1, 0);
    return (n == (ssize_t)size);
}

template<typename T>
static T ReadVal(uintptr_t addr, T defVal = T()) {
    T val = defVal;
    ReadMem(addr, &val, sizeof(T));
    return val;
}

static uintptr_t ReadPtr(uintptr_t addr) {
    return ReadVal<uintptr_t>(addr, 0);
}

static int32_t ReadI32(uintptr_t addr) {
    return ReadVal<int32_t>(addr, 0);
}

static uint16_t ReadU16(uintptr_t addr) {
    return ReadVal<uint16_t>(addr, 0);
}

static std::string GetName(int32_t id) {
    if (id <= 0 || !g_GNames) return "None";

    uint32_t block = static_cast<uint32_t>(id) >> 16;
    uint32_t offset = (static_cast<uint32_t>(id) & 0xFFFF) * 2;
    if (block >= 8192) return "None";

    uintptr_t blockPtrAddr = g_GNames + 0x48 + block * sizeof(uint8_t*);
    uintptr_t chunk = ReadPtr(blockPtrAddr);
    if (!chunk) return "None";

    uintptr_t entry = chunk + offset;
    uint16_t header = ReadU16(entry);
    size_t len = header >> 6;
    if (len == 0 || len > 512) return "None";

    char buf[512] = {};
    ReadMem(entry + 2, buf, len);
    return std::string(buf, len);
}

static std::string GetObjClass(uintptr_t obj) {
    if (!obj) return "null";
    uintptr_t cls = ReadPtr(obj + 0x10);
    if (!cls) return "null_class";
    return GetName(ReadI32(cls + 0x18));
}

static std::string GetObjName(uintptr_t obj) {
    if (!obj) return "null";
    return GetName(ReadI32(obj + 0x18));
}

struct FVector {
    float X, Y, Z;
    float Size() const { return std::sqrt(X * X + Y * Y + Z * Z); }
};

struct FQuat {
    float X, Y, Z, W;
};

struct FTransform {
    FQuat Rotation;
    FVector Translation;
    FVector Scale3D; // 0x1C, matches CoreUObject.Transform in the SDK dump
    uint8_t Pad_0x28[0x8];

    FVector TransformPosition(const FVector& V) const {
        // Match SDK::FTransform: scale locally, rotate, then translate.
        const FVector scaled = {V.X * Scale3D.X, V.Y * Scale3D.Y, V.Z * Scale3D.Z};
        FVector Qxyz = {Rotation.X, Rotation.Y, Rotation.Z};
        FVector t = {
            2.0f * (Qxyz.Y * scaled.Z - Qxyz.Z * scaled.Y),
            2.0f * (Qxyz.Z * scaled.X - Qxyz.X * scaled.Z),
            2.0f * (Qxyz.X * scaled.Y - Qxyz.Y * scaled.X)
        };
        return {
            Translation.X + scaled.X + Rotation.W * t.X + (Qxyz.Y * t.Z - Qxyz.Z * t.Y),
            Translation.Y + scaled.Y + Rotation.W * t.Y + (Qxyz.Z * t.X - Qxyz.X * t.Z),
            Translation.Z + scaled.Z + Rotation.W * t.Z + (Qxyz.X * t.Y - Qxyz.Y * t.X)
        };
    }
};

static void InspectMesh(const char* prefix, uintptr_t mesh) {
    if (!mesh) return;
    std::string mClass = GetObjClass(mesh);
    std::string mName = GetObjName(mesh);
    printf("%sMesh: 0x%lx (Class: %s, Name: %s)\n", prefix, mesh, mClass.c_str(), mName.c_str());

    FTransform c2w = {};
    ReadMem(mesh + 0x190, &c2w, sizeof(c2w));
    printf("%s  C2W: Trans=(%.1f, %.1f, %.1f) Scale=(%.2f, %.2f, %.2f) Rot=(%.3f, %.3f, %.3f, %.3f)\n",
           prefix, c2w.Translation.X, c2w.Translation.Y, c2w.Translation.Z,
           c2w.Scale3D.X, c2w.Scale3D.Y, c2w.Scale3D.Z,
           c2w.Rotation.X, c2w.Rotation.Y, c2w.Rotation.Z, c2w.Rotation.W);

    uintptr_t cstData = ReadPtr(mesh + 0x9B8);
    int32_t cstNum = ReadI32(mesh + 0x9B8 + 8);
    int32_t cstMax = ReadI32(mesh + 0x9B8 + 12);
    printf("%s  CST (+0x9B8): Data=0x%lx, Num=%d, Max=%d\n", prefix, cstData, cstNum, cstMax);

    uintptr_t bstData = ReadPtr(mesh + 0x9A8);
    int32_t bstNum = ReadI32(mesh + 0x9A8 + 8);
    printf("%s  BST (+0x9A8): Data=0x%lx, Num=%d\n", prefix, bstData, bstNum);

    // Also check other candidate offsets in case Arena Breakout changed CachedComponentSpaceTransforms offset!
    // E.g. 0x998, 0x9A0, 0x9B0, 0x9C0, 0x9C8, 0x9D0, 0x9E0...
    if (cstNum == 0) {
        for (uintptr_t off = 0x960; off <= 0xA40; off += 8) {
            uintptr_t candData = ReadPtr(mesh + off);
            int32_t candNum = ReadI32(mesh + off + 8);
            int32_t candMax = ReadI32(mesh + off + 12);
            if (candNum >= 10 && candNum <= 300 && candMax >= candNum && candData > 0x10000ULL && (candData < 0x7FFFFFFFFFFFULL)) {
                printf("%s  ** FOUND TRANSFORMS CANDIDATE at +0x%lx: Data=0x%lx, Num=%d, Max=%d **\n",
                       prefix, off, candData, candNum, candMax);
                cstData = candData;
                cstNum = candNum;
            }
        }
    }

    uintptr_t skelMesh = ReadPtr(mesh + 0x6D0);
    if (skelMesh) {
        std::string smName = GetObjName(skelMesh);
        printf("%s  SkeletalMesh (+0x6D0): 0x%lx (%s)\n", prefix, skelMesh, smName.c_str());
        
        // Scan for RefSkeleton RawRefBoneInfo / FinalRefBoneInfo
        for (uintptr_t off = 0x1B0; off <= 0x300; off += 8) {
            uintptr_t data = ReadPtr(skelMesh + off);
            int32_t num = ReadI32(skelMesh + off + 8);
            int32_t max = ReadI32(skelMesh + off + 12);
            if (num >= 20 && num <= 300 && max >= num && max < 1000 && data > 0x10000ULL && data < 0x7FFFFFFFFFFFULL) {
                printf("%s    Found Bone TArray candidate at skelMesh + 0x%lx: Data=0x%lx, Num=%d, Max=%d\n",
                       prefix, off, data, num, max);
                // Check if element size is 0xC, 0x10, 0x18, or 0x20
                for (int stride : {0xC, 0x10, 0x14, 0x18, 0x20}) {
                    int validNames = 0;
                    std::string sampleNames[5];
                    for (int b = 0; b < 5 && b < num; b++) {
                        int32_t nameIdx = ReadI32(data + b * stride);
                        std::string nm = GetName(nameIdx);
                        sampleNames[b] = nm;
                        if (nm != "None" && nm.length() > 1 && nm.length() < 30) validNames++;
                    }
                    if (validNames >= 3) {
                        printf("%s      -> Stride 0x%x MATCH! First 5: [%s, %s, %s, %s, %s]\n",
                               prefix, stride, sampleNames[0].c_str(), sampleNames[1].c_str(),
                               sampleNames[2].c_str(), sampleNames[3].c_str(), sampleNames[4].c_str());
                        // Print ALL bones and their index!
                        printf("%s      === EXACT SKELETON BONE MAPPING (%d bones) ===\n", prefix, num);
                        for (int b = 0; b < num; b++) {
                            int32_t nameIdx = ReadI32(data + b * stride);
                            std::string bName = GetName(nameIdx);
                            int32_t parentIdx = ReadI32(data + b * stride + 8);
                            printf("%s        Bone[%2d] = \"%-24s\" (Parent: %d)\n", prefix, b, bName.c_str(), parentIdx);
                        }
                        printf("%s      ==============================================\n", prefix);
                        break;
                    }
                }
            }
        }
    }

    if (cstData && cstNum > 0 && cstNum < 300) {
        printf("%s  Sample Bones World Positions:\n", prefix);
        for (int b = 0; b < (cstNum < 15 ? cstNum : 15); b++) {
            FTransform bTrans = {};
            ReadMem(cstData + b * 0x30, &bTrans, sizeof(bTrans));
            FVector wPos = c2w.TransformPosition(bTrans.Translation);
            printf("%s    Bone #%2d: Comp=(%6.1f, %6.1f, %6.1f) -> World=(%7.1f, %7.1f, %7.1f)\n",
                   prefix, b, bTrans.Translation.X, bTrans.Translation.Y, bTrans.Translation.Z,
                   wPos.X, wPos.Y, wPos.Z);
        }
    }
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printf("Usage: %s <pid>\n", argv[0]);
        return 1;
    }
    g_Pid = atoi(argv[1]);

    char mapsPath[64];
    snprintf(mapsPath, sizeof(mapsPath), "/proc/%d/maps", g_Pid);
    FILE* f = fopen(mapsPath, "r");
    if (!f) return 1;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, "libUE4.so") && strstr(line, "r--p") && !strstr(line, "anon")) {
            sscanf(line, "%lx-", &g_LibBase);
            break;
        }
    }
    fclose(f);
    printf("libUE4.so base: 0x%lx\n", g_LibBase);

    g_GNames = g_LibBase + 0x0F36BEC0;
    g_GUObjectArray = g_LibBase + 0x0F38BDB0;

    printf("=== Inspecting Real C++ USkinnedMeshComponent::GetBoneIndex (RVA: 0xC149A64) ===\n");
    uintptr_t realGetBoneIndex = g_LibBase + 0xC149A64;
    uint32_t realInsns[32] = {};
    ReadMem(realGetBoneIndex, realInsns, sizeof(realInsns));
    for (int i = 0; i < 32; i++) {
        printf("  +0x%02x: %08x\n", i * 4, realInsns[i]);
    }
    printf("==============================================================================\n");

    uintptr_t gEngine = ReadPtr(g_LibBase + 0x0F5D3138);
    uintptr_t vp = ReadPtr(gEngine + 0x788);
    uintptr_t world = ReadPtr(vp + 0x70);
    uintptr_t level = ReadPtr(world + 0x30);
    uintptr_t actorsData = ReadPtr(level + 0x98);
    int32_t actorsCount = ReadI32(level + 0xA0);
    printf("World: 0x%lx, Level: 0x%lx, Total Actors: %d\n\n", world, level, actorsCount);

    int totalChars = 0;
    int activeChars = 0;

    for (int i = 0; i < actorsCount; i++) {
        uintptr_t actor = ReadPtr(actorsData + i * 8);
        if (!actor) continue;

        uintptr_t cls = ReadPtr(actor + 0x10);
        if (!cls) continue;

        std::string clsName = GetName(ReadI32(cls + 0x18));

        // Filter out non-characters
        if (clsName.find("Controller") != std::string::npos ||
            clsName.find("Camera") != std::string::npos ||
            clsName.find("PlayerState") != std::string::npos ||
            clsName.find("Switcher") != std::string::npos ||
            clsName.find("Spawner") != std::string::npos) {
            continue;
        }

        if (clsName.find("Character") == std::string::npos &&
            clsName.find("Pawn") == std::string::npos &&
            clsName.find("Uam") == std::string::npos) {
            continue;
        }

        totalChars++;

        uintptr_t root = ReadPtr(actor + 0x158);
        FVector rootPos = {0,0,0};
        if (root) {
            ReadMem(root + 0x190 + 0x10, &rootPos, sizeof(rootPos));
        }

        bool isActive = (rootPos.Size() > 1.0f);
        if (isActive) activeChars++;

        printf("================================================================\n");
        printf("Actor[%d]: 0x%lx | Class: %s | RootPos: (%.1f, %.1f, %.1f) %s\n",
               i, actor, clsName.c_str(), rootPos.X, rootPos.Y, rootPos.Z,
               isActive ? "[ACTIVE IN MAP]" : "[DORMANT/ORIGIN]");

        // 1. Inspect Main Character Mesh at +0x370
        uintptr_t mesh = ReadPtr(actor + 0x370);
        InspectMesh("  [MainMesh +0x370] ", mesh);

        // 2. Inspect RootComponent->AttachChildren (+0x100)
        if (root) {
            uintptr_t childrenData = ReadPtr(root + 0x100);
            int32_t numChildren = ReadI32(root + 0x100 + 8);
            if (childrenData && numChildren > 0 && numChildren < 50) {
                printf("  [Root AttachChildren]: %d children\n", numChildren);
                for (int c = 0; c < numChildren; c++) {
                    uintptr_t childComp = ReadPtr(childrenData + c * 8);
                    if (!childComp) continue;
                    std::string cCls = GetObjClass(childComp);
                    std::string cName = GetObjName(childComp);
                    printf("    Child[%d]: 0x%lx (Class: %s, Name: %s)\n", c, childComp, cCls.c_str(), cName.c_str());
                    if (cCls.find("Skeletal") != std::string::npos || cCls.find("Mesh") != std::string::npos) {
                        InspectMesh("      ", childComp);
                    }
                }
            }
        }

        // 3. Inspect CmpCacheArray at +0x1838 (0x43 elements)
        printf("  [CmpCacheArray +0x1838]:\n");
        for (int c = 0; c < 0x43; c++) {
            uintptr_t comp = ReadPtr(actor + 0x1838 + c * 8);
            if (!comp) continue;
            std::string cCls = GetObjClass(comp);
            if (cCls.find("Avatar") != std::string::npos ||
                cCls.find("Mesh") != std::string::npos ||
                cCls.find("Weapon") != std::string::npos ||
                cCls.find("Anim") != std::string::npos) {
                printf("    Slot[%d]: 0x%lx (Class: %s)\n", c, comp, cCls.c_str());

                // If this is USGCharacterAvatarComponent, inspect BodyMesh & AvatarMergedMesh
                if (cCls.find("Avatar") != std::string::npos) {
                    uintptr_t bodyMeshComp = ReadPtr(comp + 0x1F0); // BodyMesh
                    uintptr_t mergedMeshComp = ReadPtr(comp + 0x1F8); // AvatarMergedMesh
                    printf("      AvatarComp BodyMesh (+0x1F0): 0x%lx (Class: %s)\n",
                           bodyMeshComp, GetObjClass(bodyMeshComp).c_str());
                    printf("      AvatarComp AvatarMergedMesh (+0x1F8): 0x%lx (Class: %s)\n",
                           mergedMeshComp, GetObjClass(mergedMeshComp).c_str());

                    // If USGInventoryEquipMeshComponent, check WearableMesh.MeshComponent at +0x100 + 0x4F0 = 0x5F0
                    if (bodyMeshComp) {
                        uintptr_t innerMesh = ReadPtr(bodyMeshComp + 0x5F0);
                        printf("        BodyMesh Inner MeshComponent (+0x5F0): 0x%lx\n", innerMesh);
                        InspectMesh("        BodyMeshInner ", innerMesh);
                    }
                    if (mergedMeshComp) {
                        uintptr_t innerMesh = ReadPtr(mergedMeshComp + 0x5F0);
                        printf("        MergedMesh Inner MeshComponent (+0x5F0): 0x%lx\n", innerMesh);
                        InspectMesh("        MergedMeshInner ", innerMesh);
                    }
                }
            }
        }

        // Limit output to first 3 active characters or 10 dormant
        if (isActive && activeChars >= 3) break;
        if (!isActive && totalChars >= 15) break;
    }

    printf("\nDone! Total characters checked: %d (Active: %d)\n", totalChars, activeChars);
    return 0;
}
