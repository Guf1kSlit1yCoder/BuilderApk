#include "VisCheck.h"
#include "ActorPipeline.h"
#include "Memory/Hooks.h"
#include "Memory/Tools.h"
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstring>
#include <mutex>
#include <unistd.h>
#include <unordered_map>

namespace VisCheck {
namespace {
    using PE_t = void (*)(SDK::UObject*, SDK::UFunction*, void*);

    // PlayerController/HUD tables are known to be driven by the game thread and
    // establish its tid; character tables only tick when called on that tid.
    struct HookedTable { void** vtable; PE_t orig; bool trusted; };
    constexpr int kMaxTables = 16;
    HookedTable s_Tables[kMaxTables]{};
    std::atomic<int> s_TableCount{0};
    std::atomic<int> s_GameTid{0};

    struct Result {
        uint16_t visible = 0;
        uint16_t seeded = 0;
        uint8_t  streak[kMaxPoints]{};   // consecutive raw results disagreeing with `visible`
        int64_t  timeMs[kMaxPoints]{};
    };

    std::mutex s_Mutex;
    std::vector<Target> s_Targets;
    SDK::FVector s_Camera{};
    SDK::ASGCharacter* s_Local = nullptr;
    std::unordered_map<SDK::ASGCharacter*, Result> s_Results;

    std::atomic<int64_t> s_LastTickMs{0};
    std::atomic<int> s_TickCount{0};
    thread_local bool t_InTick = false;

    struct TraceFn {
        bool resolved = false, ok = false;
        SDK::UFunction* fn = nullptr;
        SDK::UObject* cdo = nullptr;
        int oCtx = -1, oStart = -1, oEnd = -1, oChannel = -1, oComplex = -1, oIgnore = -1,
            oDebug = -1, oSelf = -1, oDrawTime = -1, oRet = -1;
        // Hit identification (optional): OutHit param, FHitResult.Actor, AActor.Owner.
        int oOutHit = -1, oHitActor = -1, oOwner = -1;
    } s_Trace;

    constexpr size_t kParmsBuffer = 1024;
    constexpr int kFlipStreak = 2;

    int64_t NowMs() {
        return std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
    }

    const HookedTable* TableFor(SDK::UObject* obj) {
        void** vt = *reinterpret_cast<void***>(obj);
        const int n = s_TableCount.load(std::memory_order_acquire);
        for (int i = 0; i < n; ++i)
            if (s_Tables[i].vtable == vt) return &s_Tables[i];
        return nullptr;
    }

    // Full-name formats differ between builds; match by name + outer class instead.
    SDK::UFunction* FindFunction(const char* outerName, const char* funcName) {
        auto objects = SDK::UObject::GObjects;
        if (!objects || !Tools::IsPtrValid(objects)) return nullptr;
        const int32_t count = objects->Num();
        if (count <= 0 || count > 2000000) return nullptr;
        for (int32_t i = 0; i < count; ++i) {
            SDK::UObject* obj = objects->GetByIndex(i);
            if (!obj || !Tools::IsPtrValid(obj)) continue;
            if (obj->GetName() != funcName) continue;
            SDK::UObject* outer = obj->GetOuter();
            if (!outer || outer->GetName() != outerName) continue;
            LOGI("[VisCheck] found %s as '%s'", funcName, obj->GetFullName().c_str());
            return reinterpret_cast<SDK::UFunction*>(obj);
        }
        return nullptr;
    }

    SDK::UStruct* FindScriptStruct(const char* name) {
        auto objects = SDK::UObject::GObjects;
        if (!objects || !Tools::IsPtrValid(objects)) return nullptr;
        const int32_t count = objects->Num();
        if (count <= 0 || count > 2000000) return nullptr;
        for (int32_t i = 0; i < count; ++i) {
            SDK::UObject* obj = objects->GetByIndex(i);
            if (!obj || !Tools::IsPtrValid(obj) || obj->GetName() != name) continue;
            auto* cls = obj->ClassPrivate;
            if (!cls || !Tools::IsPtrValid(cls) || cls->GetName() != "ScriptStruct") continue;
            LOGI("[VisCheck] found %s as '%s'", name, obj->GetFullName().c_str());
            return reinterpret_cast<SDK::UStruct*>(obj);
        }
        return nullptr;
    }

    bool ResolveTrace() {
        if (s_Trace.resolved) return s_Trace.ok;
        const int64_t now = NowMs();
        static int64_t s_NextTry = 0;
        if (now < s_NextTry) return false;
        s_NextTry = now + 2000;

        if (!s_Trace.fn) {
            s_Trace.fn = SDK::UObject::FindObjectFast<SDK::UFunction>("LineTraceSingle");
            if (!s_Trace.fn) s_Trace.fn = FindFunction("KismetSystemLibrary", "LineTraceSingle");
        }
        if (!s_Trace.cdo) {
            s_Trace.cdo = SDK::UObject::FindObjectFast<SDK::UObject>("Default__KismetSystemLibrary");
        }
        if (!s_Trace.fn || !s_Trace.cdo) {
            LOGE("[VisCheck] LineTraceSingle unavailable (fn=%p cdo=%p), retrying", s_Trace.fn, s_Trace.cdo);
            return false;
        }
        s_Trace.resolved = true;
        auto* f = reinterpret_cast<SDK::UStruct*>(s_Trace.fn);
        s_Trace.oCtx      = f->FindPropertyOffset("WorldContextObject");
        s_Trace.oStart    = f->FindPropertyOffset("Start");
        s_Trace.oEnd      = f->FindPropertyOffset("End");
        s_Trace.oChannel  = f->FindPropertyOffset("TraceChannel");
        s_Trace.oComplex  = f->FindPropertyOffset("bTraceComplex");
        s_Trace.oIgnore   = f->FindPropertyOffset("ActorsToIgnore");
        s_Trace.oDebug    = f->FindPropertyOffset("DrawDebugType");
        s_Trace.oSelf     = f->FindPropertyOffset("bIgnoreSelf");
        s_Trace.oDrawTime = f->FindPropertyOffset("DrawTime");
        s_Trace.oRet      = f->FindPropertyOffset("ReturnValue");
        const int offs[] = { s_Trace.oCtx, s_Trace.oStart, s_Trace.oEnd, s_Trace.oChannel, s_Trace.oComplex,
                             s_Trace.oIgnore, s_Trace.oDebug, s_Trace.oSelf, s_Trace.oRet };
        bool ok = true;
        for (int o : offs) ok &= (o >= 0 && o + 16 <= (int)kParmsBuffer);
        s_Trace.ok = ok;

        s_Trace.oOutHit = f->FindPropertyOffset("OutHit");
        if (auto* hr = FindScriptStruct("HitResult"))
            s_Trace.oHitActor = hr->FindPropertyOffset("Actor");
        if (s_Trace.oOutHit >= 0 && s_Trace.oHitActor >= 0 &&
            s_Trace.oOutHit + s_Trace.oHitActor + 8 > (int)kParmsBuffer) s_Trace.oHitActor = -1;

        LOGI("[VisCheck] LineTraceSingle resolved ok=%d ctx=%d start=%d end=%d ch=%d cx=%d ign=%d self=%d ret=%d outHit=%d hitActor=%d",
             (int)ok, s_Trace.oCtx, s_Trace.oStart, s_Trace.oEnd, s_Trace.oChannel, s_Trace.oComplex,
             s_Trace.oIgnore, s_Trace.oSelf, s_Trace.oRet, s_Trace.oOutHit, s_Trace.oHitActor);
        return ok;
    }

    void ResolveOwner(SDK::UObject* anyActor) {
        static bool s_Done = false;
        if (s_Done || !anyActor || !anyActor->ClassPrivate) return;
        s_Done = true;
        s_Trace.oOwner = reinterpret_cast<SDK::UStruct*>(anyActor->ClassPrivate)->FindPropertyOffset("Owner");
        LOGI("[VisCheck] AActor.Owner offset=%d", s_Trace.oOwner);
    }

    // Gear, weapons and backpacks are separate actors owned by or attached to a character.
    bool BelongsTo(SDK::AActor* hit, SDK::ASGCharacter* who) {
        if (!who || !ActorPipeline::IsObjectValid(hit)) return false;
        if (hit == reinterpret_cast<SDK::AActor*>(who)) return true;
        if (s_Trace.oOwner > 0) {
            SDK::AActor* a = hit;
            for (int i = 0; i < 4; ++i) {
                auto* slot = reinterpret_cast<uint8_t*>(a) + s_Trace.oOwner;
                if (!Tools::IsReadable(slot, sizeof(void*))) break;
                a = *reinterpret_cast<SDK::AActor**>(slot);
                if (!a) break;
                if (a == reinterpret_cast<SDK::AActor*>(who)) return true;
                if (!ActorPipeline::IsObjectValid(a)) break;
            }
        }
        SDK::USceneComponent* c = hit->RootComponent;
        const auto* whoRoot = who->RootComponent;
        const auto* whoMesh = who->GetMeshComponent();
        for (int i = 0; i < 8 && c && Tools::IsReadable(c, sizeof(SDK::USceneComponent)); ++i) {
            c = c->AttachParent;
            if (!c) break;
            if (c == whoRoot || c == reinterpret_cast<const SDK::USceneComponent*>(whoMesh)) return true;
        }
        return false;
    }

    // One LineTraceSingle. Returns true on a blocking hit and reports the hit actor.
    bool TraceOnce(SDK::UObject* ctx, const SDK::FVector& start, const SDK::FVector& end,
                   SDK::AActor* const* ignore, int ignoreCount, SDK::AActor** hitActor) {
        alignas(16) uint8_t parms[kParmsBuffer];
        std::memset(parms, 0, sizeof(parms));

        struct { const void* data; int32_t num; int32_t max; } ignoreArr{ ignore, ignoreCount, ignoreCount };

        *reinterpret_cast<SDK::UObject**>(parms + s_Trace.oCtx) = ctx;
        *reinterpret_cast<SDK::FVector*>(parms + s_Trace.oStart) = start;
        *reinterpret_cast<SDK::FVector*>(parms + s_Trace.oEnd) = end;
        parms[s_Trace.oChannel] = 0;   // TraceTypeQuery1 == Visibility
        // Per-triangle geometry: simple collision is missing or coarse on much cover.
        parms[s_Trace.oComplex] = 1;
        std::memcpy(parms + s_Trace.oIgnore, &ignoreArr, sizeof(ignoreArr));
        parms[s_Trace.oDebug] = 0;
        parms[s_Trace.oSelf] = 1;
        if (s_Trace.oDrawTime >= 0) *reinterpret_cast<float*>(parms + s_Trace.oDrawTime) = 0.0f;

        auto pe = reinterpret_cast<PE_t>((*reinterpret_cast<void***>(s_Trace.cdo))[SDK::UObject::ProcessEventIndex]);
        pe(s_Trace.cdo, s_Trace.fn, parms);
        const bool blocked = parms[s_Trace.oRet] != 0;
        *hitActor = nullptr;
        if (blocked && s_Trace.oOutHit >= 0 && s_Trace.oHitActor >= 0) {
            SDK::FWeakObjectPtr weak;
            std::memcpy(&weak, parms + s_Trace.oOutHit + s_Trace.oHitActor, sizeof(weak));
            if (weak.ObjectSerialNumber > 0) *hitActor = reinterpret_cast<SDK::AActor*>(weak.Get());
        }
        return blocked;
    }

    // Bushes/grass/trees are one InstancedFoliageActor per level; treat them as see-through.
    bool IsFoliage(SDK::AActor* hit) {
        static std::unordered_map<SDK::AActor*, bool> s_Cache;
        auto it = s_Cache.find(hit);
        if (it != s_Cache.end()) return it->second;
        if (s_Cache.size() > 512) s_Cache.clear();
        bool foliage = false;
        if (ActorPipeline::IsObjectValid(hit)) {
            const std::string cls = hit->ClassPrivate->GetName();
            foliage = cls.find("Foliage") != std::string::npos;
        }
        s_Cache[hit] = foliage;
        return foliage;
    }

    // Visible when the segment is clear apart from foliage and the target's and our own gear.
    bool SegmentClear(SDK::ASGCharacter* local, SDK::ASGCharacter* target,
                      const SDK::FVector& start, const SDK::FVector& end, int& budget) {
        constexpr int kMaxIgnore = 8;
        SDK::AActor* ignore[kMaxIgnore] = { reinterpret_cast<SDK::AActor*>(target) };
        int ignoreCount = 1;
        while (budget > 0) {
            --budget;
            SDK::AActor* hit = nullptr;
            if (!TraceOnce(local, start, end, ignore, ignoreCount, &hit)) return true;
            if (!hit || ignoreCount >= kMaxIgnore) return false;
            if (!IsFoliage(hit) && !BelongsTo(hit, target) && !BelongsTo(hit, local)) {
                static int64_t s_LastHitLog = 0;
                const int64_t now = NowMs();
                if (now - s_LastHitLog > 2000 && ActorPipeline::IsObjectValid(hit)) {
                    s_LastHitLog = now;
                    LOGI("[VisCheck] blocked by %s", hit->GetName().c_str());
                }
                return false;
            }
            ignore[ignoreCount++] = hit;
        }
        return false;
    }

    void Apply(Result& r, int bone, bool raw, int64_t now) {
        const uint16_t bit = (uint16_t)(1u << bone);
        r.timeMs[bone] = now;
        auto set = [&](bool v) { r.visible = v ? (r.visible | bit) : (r.visible & ~bit); r.streak[bone] = 0; };
        if (!(r.seeded & bit)) { r.seeded |= bit; set(raw); return; }
        const bool cur = (r.visible & bit) != 0;
        if (raw == cur) { r.streak[bone] = 0; return; }
        if (++r.streak[bone] >= kFlipStreak) set(raw);
    }

    uint16_t FreshMask(const Result& r, int64_t now) {
        uint16_t m = 0;
        for (int i = 0; i < kMaxPoints; ++i)
            if ((r.seeded & (1u << i)) && now - r.timeMs[i] <= 1000) m |= (uint16_t)(1u << i);
        return m;
    }

    void GameThreadTick() {
        const int64_t now = NowMs();
        static int64_t s_LastAttempt = 0;
        if (now - s_LastAttempt < 16) return;
        s_LastAttempt = now;
        if (!ResolveTrace()) return;
        // Only a tick that can actually trace marks the check as live.
        s_LastTickMs.store(now, std::memory_order_relaxed);
        s_TickCount.fetch_add(1, std::memory_order_relaxed);

        std::vector<Target> targets;
        SDK::FVector cam;
        SDK::ASGCharacter* local;
        {
            std::lock_guard<std::mutex> lock(s_Mutex);
            targets = s_Targets;
            cam = s_Camera;
            local = s_Local;
        }
        if (targets.empty() || !ActorPipeline::IsObjectValid(local)) return;
        ResolveOwner(local);

        // Round-robin over every (target, bone) pair so each bone gets its own result.
        struct Pair { uint16_t target; uint8_t bone; };
        std::vector<Pair> pairs;
        pairs.reserve(targets.size() * kMaxPoints);
        for (size_t ti = 0; ti < targets.size(); ++ti)
            for (int b = 0; b < kMaxPoints; ++b)
                if (targets[ti].valid & (1u << b)) pairs.push_back({ (uint16_t)ti, (uint8_t)b });
        if (pairs.empty()) return;

        const auto t0 = std::chrono::steady_clock::now();
        static size_t s_Cursor = 0;
        int budget = 40;
        struct Done { SDK::ASGCharacter* actor; uint8_t bone; bool visible; };
        std::vector<Done> done;
        done.reserve(budget);
        const size_t n = pairs.size();
        size_t visited = 0;
        int lastValidated = -1;
        bool lastValid = false;
        for (; visited < n && budget > 0; ++visited) {
            const Pair& p = pairs[(s_Cursor + visited) % n];
            const Target& t = targets[p.target];
            if (lastValidated != p.target) {
                lastValidated = p.target;
                lastValid = ActorPipeline::IsObjectValid(t.actor);
            }
            if (!lastValid) continue;
            SDK::FVector dir = t.points[p.bone] - cam;
            const float len = std::sqrt(dir.SizeSquared());
            if (!std::isfinite(len) || len < 1.0f) continue;
            dir = dir * (1.0f / len);
            // Skip the first 40 cm (own weapon/arms) and stop 5 cm short of the bone.
            const SDK::FVector start = cam + dir * std::min(40.0f, len * 0.5f);
            const SDK::FVector end = t.points[p.bone] - dir * 5.0f;
            done.push_back({ t.actor, p.bone, SegmentClear(local, t.actor, start, end, budget) });
        }
        s_Cursor = (s_Cursor + visited) % n;
        const float tickUs = std::chrono::duration<float, std::micro>(std::chrono::steady_clock::now() - t0).count();

        std::lock_guard<std::mutex> lock(s_Mutex);
        for (const auto& d : done) Apply(s_Results[d.actor], d.bone, d.visible, now);

        static int64_t s_LastLog = 0;
        static float s_MaxUs = 0.0f, s_SumUs = 0.0f;
        static int s_Samples = 0;
        s_MaxUs = std::max(s_MaxUs, tickUs);
        s_SumUs += tickUs;
        ++s_Samples;
        if (now - s_LastLog > 5000) {
            const int ticks = s_TickCount.exchange(0);
            int nVisible = 0;
            for (const auto& t : targets) {
                auto it = s_Results.find(t.actor);
                if (it != s_Results.end() && (it->second.visible & FreshMask(it->second, now))) ++nVisible;
            }
            LOGI("[VisCheck] %.1f ticks/s, targets=%zu bones=%zu traced=%zu visible=%d tick avg=%.0fus max=%.0fus",
                 s_LastLog ? ticks * 1000.0f / (float)(now - s_LastLog) : 0.0f,
                 targets.size(), n, done.size(), nVisible, s_SumUs / s_Samples, s_MaxUs);
            s_LastLog = now;
            s_MaxUs = s_SumUs = 0.0f;
            s_Samples = 0;
        }
    }

    void hk_ProcessEvent(SDK::UObject* obj, SDK::UFunction* fn, void* parms) {
        const HookedTable* table = TableFor(obj);
        if (table && table->orig) table->orig(obj, fn, parms);
        if (t_InTick || !table) return;
        const int tid = gettid();
        if (table->trusted) s_GameTid.store(tid, std::memory_order_relaxed);
        else if (tid != s_GameTid.load(std::memory_order_relaxed)) return;
        t_InTick = true;
        GameThreadTick();
        t_InTick = false;
    }

    void HookObject(SDK::UObject* obj, bool trusted) {
        if (!ActorPipeline::IsObjectValid(obj)) return;
        void** vt = *reinterpret_cast<void***>(obj);
        if (!Tools::IsPtrValid(vt)) return;
        const int n = s_TableCount.load(std::memory_order_acquire);
        for (int i = 0; i < n; ++i) if (s_Tables[i].vtable == vt) return;
        if (n >= kMaxTables) return;
        const int idx = SDK::UObject::ProcessEventIndex;
        if (vt[idx] == reinterpret_cast<void*>(&hk_ProcessEvent)) return;
        s_Tables[n] = { vt, reinterpret_cast<PE_t>(vt[idx]), trusted };
        s_TableCount.store(n + 1, std::memory_order_release);
        void* old = nullptr;
        if (!Hooks::HookVTable(vt, idx, reinterpret_cast<void*>(&hk_ProcessEvent), &old)) {
            LOGE("[VisCheck] vtable hook failed for %s", obj->GetName().c_str());
            return;
        }
        LOGI("[VisCheck] hooked ProcessEvent on %s (vtable=%p trusted=%d)", obj->GetName().c_str(), vt, (int)trusted);
    }
}

void EnsureHooked(SDK::APlayerController* pc, SDK::ASGCharacter* local, const std::vector<Target>& targets) {
    if (!ActorPipeline::IsObjectValid(pc)) return;
    HookObject(pc, true);
    if (Tools::IsReadable(&pc->MyHUD, sizeof(void*))) HookObject(reinterpret_cast<SDK::UObject*>(pc->MyHUD), true);
    // Character blueprints receive per-frame events, so they keep ticks frequent.
    HookObject(local, false);
    for (const auto& t : targets) HookObject(t.actor, false);
}

void Publish(const SDK::FVector& camera, SDK::ASGCharacter* local, std::vector<Target>& targets) {
    std::lock_guard<std::mutex> lock(s_Mutex);
    s_Targets.swap(targets);
    s_Camera = camera;
    s_Local = local;
}

bool QueryBones(SDK::ASGCharacter* actor, uint16_t& visible, uint16_t& known) {
    visible = known = 0;
    const int64_t now = NowMs();
    if (now - s_LastTickMs.load(std::memory_order_relaxed) > 500) return false;
    std::lock_guard<std::mutex> lock(s_Mutex);
    auto it = s_Results.find(actor);
    // Tracing is live: bones without a fresh result count as occluded rather
    // than mixing in the render-time heuristic.
    if (it == s_Results.end()) return true;
    known = FreshMask(it->second, now);
    visible = it->second.visible & known;
    return true;
}

int Query(SDK::ASGCharacter* actor) {
    uint16_t visible, known;
    if (!QueryBones(actor, visible, known)) return -1;
    return visible ? 1 : 0;
}

void Reset() {
    std::lock_guard<std::mutex> lock(s_Mutex);
    s_Targets.clear();
    s_Results.clear();
    s_Local = nullptr;
    s_Trace.resolved = false;
    s_Trace.ok = false;
}

} // namespace VisCheck
