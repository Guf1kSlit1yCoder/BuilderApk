#pragma once
#include <cstdint>
#include <vector>

struct VTableHookEntry {
    void **vtable;
    int index;
    void *original;
};

namespace Hooks {
    bool HookVTable(void **vtable, int index, void *newFunc, void **oldFunc);
    bool HookFunction(void *target, void *replace, void **backup);
    void UnhookAll();
}
