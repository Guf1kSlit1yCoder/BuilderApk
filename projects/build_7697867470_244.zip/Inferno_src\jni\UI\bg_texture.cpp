#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_JPEG
#define STBI_NO_STDIO
#include "stb_image.h"
#include "bg_texture.h"
#include "bg_image_data.h"
#include <GLES3/gl3.h>
#include <android/log.h>

#define TAG "BgTexture"
#if defined(ARENA_LOG_ENABLED) && ARENA_LOG_ENABLED
#define LOGI_BG(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE_BG(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#else
#define LOGI_BG(...) do {} while(0)
#define LOGE_BG(...) do {} while(0)
#endif

namespace BgTexture
{

static GLuint g_Tex   = 0;
static GLuint g_Prog  = 0;
static GLuint g_VAO   = 0;
static GLuint g_VBO   = 0;
static int    g_ImgW  = 0;
static int    g_ImgH  = 0;

static const char* kVS = R"GLSL(#version 300 es
const vec2 kPos[4] = vec2[4](
    vec2(-1.0,-1.0), vec2( 1.0,-1.0),
    vec2(-1.0, 1.0), vec2( 1.0, 1.0)
);
const vec2 kUV[4] = vec2[4](
    vec2(0.0, 1.0), vec2(1.0, 1.0),
    vec2(0.0, 0.0), vec2(1.0, 0.0)
);
out vec2 vUV;
void main() {
    vUV         = kUV[gl_VertexID];
    gl_Position = vec4(kPos[gl_VertexID], 0.0, 1.0);
}
)GLSL";

static const char* kFS = R"GLSL(#version 300 es
precision mediump float;
uniform sampler2D uTex;
in  vec2 vUV;
out vec4 fragColor;
void main() {
    fragColor = texture(uTex, vUV);
}
)GLSL";

static GLuint CompileShader(GLenum type, const char* src)
{
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char b[256]; glGetShaderInfoLog(s, 256, nullptr, b); LOGE_BG("Shader: %s", b); glDeleteShader(s); return 0; }
    return s;
}

bool Init()
{
    // Decode embedded JPEG
    int ch = 0;
    unsigned char* px = stbi_load_from_memory(kBgImageData, kBgImageSize, &g_ImgW, &g_ImgH, &ch, 4);
    if (!px) { LOGE_BG("stbi decode failed"); return false; }

    glGenTextures(1, &g_Tex);
    glBindTexture(GL_TEXTURE_2D, g_Tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, g_ImgW, g_ImgH, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    stbi_image_free(px);
    glBindTexture(GL_TEXTURE_2D, 0);

    GLuint vs = CompileShader(GL_VERTEX_SHADER,   kVS);
    GLuint fs = CompileShader(GL_FRAGMENT_SHADER, kFS);
    if (!vs || !fs) { glDeleteShader(vs); glDeleteShader(fs); return false; }

    g_Prog = glCreateProgram();
    glAttachShader(g_Prog, vs); glAttachShader(g_Prog, fs);
    glLinkProgram(g_Prog);
    glDeleteShader(vs); glDeleteShader(fs);

    GLint ok = 0; glGetProgramiv(g_Prog, GL_LINK_STATUS, &ok);
    if (!ok) { char b[256]; glGetProgramInfoLog(g_Prog, 256, nullptr, b); LOGE_BG("Link: %s", b); glDeleteProgram(g_Prog); g_Prog = 0; return false; }

    // Dummy VAO (vertex positions come from gl_VertexID in the shader)
    glGenVertexArrays(1, &g_VAO);

    LOGI_BG("Init OK (%dx%d)", g_ImgW, g_ImgH);
    return true;
}

unsigned int GetTex() { return g_Tex; }

void Shutdown()
{
    if (g_Tex)  { glDeleteTextures(1, &g_Tex);       g_Tex  = 0; }
    if (g_Prog) { glDeleteProgram(g_Prog);            g_Prog = 0; }
    if (g_VAO)  { glDeleteVertexArrays(1, &g_VAO);   g_VAO  = 0; }
}

void Draw(int /*screenW*/, int /*screenH*/)
{
    if (!g_Prog || !g_Tex) return;

    // Save state
    GLint prevProg = 0, prevVAO = 0;
    GLboolean depthTest = glIsEnabled(GL_DEPTH_TEST);
    GLboolean blendOn   = glIsEnabled(GL_BLEND);
    GLboolean cullFace  = glIsEnabled(GL_CULL_FACE);
    glGetIntegerv(GL_CURRENT_PROGRAM,      &prevProg);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &prevVAO);

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);
    glDisable(GL_CULL_FACE);

    glUseProgram(g_Prog);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, g_Tex);
    glUniform1i(glGetUniformLocation(g_Prog, "uTex"), 0);

    glBindVertexArray(g_VAO);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    glBindVertexArray(0);

    // Restore state
    glUseProgram(prevProg);
    glBindVertexArray(prevVAO);
    if (depthTest) glEnable(GL_DEPTH_TEST);
    if (blendOn)   glEnable(GL_BLEND);
    if (cullFace)  glEnable(GL_CULL_FACE);
}

} // namespace BgTexture
