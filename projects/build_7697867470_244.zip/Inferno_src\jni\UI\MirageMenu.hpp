#pragma once
#define IMGUI_DEFINE_MATH_OPERATORS

#include "imgui.h"
#include "imgui_internal.h"
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>

#include "vandal_widgets.hpp"
#include "vandal_main.h"
#include "Config.h"
#include "Lang.h"
#include "Login.h"
#include "mirage_logo.h"
#include "bg_texture.h"

inline int GetCurrentLang() {
    return g_Config.arabic_language ? 2 : (g_Config.russian_language ? 1 : 0);
}

inline const char* LText(const char* en, const char* ru, const char* ar = nullptr) {
    int lang = GetCurrentLang();
    if (lang == 1) return ru;
    if (lang == 2) {
        if (ar) return Lang::Shape(ar);
        return Lang::T(en, ru);
    }
    return en;
}

// Forward declaration
void RequestUnload();

namespace mirage {

inline bool s_show_unload_modal = false;
inline bool checkboxes[60] = { false };
inline int slider_int[30] = { 90, 10, 50, 400, 100, 80, 0, 0, 50 };
inline float color_edit[10][4] = {
    { 0.20f, 0.78f, 0.96f, 1.0f },
    { 0.68f, 0.35f, 0.98f, 1.0f },
    { 1.00f, 0.20f, 0.20f, 1.0f },
    { 0.20f, 0.90f, 0.40f, 1.0f }
};

inline bool crosshair_enable = false;
inline int crosshair_style = 0;
inline int crosshair_size = 12;
inline int crosshair_thick = 2;
inline int crosshair_gap = 4;
inline bool crosshair_dot = false;
inline bool crosshair_outline = true;
inline bool crosshair_recoil = false;
inline float crosshair_col[4] = { 0.2f, 0.9f, 0.5f, 1.0f };

inline void DrawCountryFlag(ImDrawList* dl, ImVec2 pos, ImVec2 sz, int lang_id) {
    if (!dl) return;
    float rounding = 4.0f;

    // Outer subtle shadow for physical badge elevation
    dl->AddShadowRect(pos, pos + sz, IM_COL32(0, 0, 0, 160), 8.0f, ImVec2(0, 2), ImDrawFlags_RoundCornersAll, rounding);

    if (lang_id == 1) { // 🇷🇺 RUSSIAN FEDERATION (White, Blue, Red tricolor)
        float h3 = sz.y / 3.0f;
        // White top stripe
        dl->AddRectFilled(pos, ImVec2(pos.x + sz.x, pos.y + h3), IM_COL32(255, 255, 255, 255), rounding, ImDrawFlags_RoundCornersTop);
        // Blue middle stripe
        dl->AddRectFilled(ImVec2(pos.x, pos.y + h3), ImVec2(pos.x + sz.x, pos.y + h3 * 2.0f), IM_COL32(0, 57, 166, 255));
        // Red bottom stripe
        dl->AddRectFilled(ImVec2(pos.x, pos.y + h3 * 2.0f), ImVec2(pos.x + sz.x, pos.y + sz.y), IM_COL32(213, 43, 30, 255), rounding, ImDrawFlags_RoundCornersBottom);
    }
    else if (lang_id == 0) { // 🇺🇸 UNITED STATES (Stripes + Blue Canton with Stars)
        // 7 horizontal stripes alternating Red & White
        float stripe_h = sz.y / 7.0f;
        for (int i = 0; i < 7; i++) {
            ImU32 col = (i % 2 == 0) ? IM_COL32(179, 25, 66, 255) : IM_COL32(255, 255, 255, 255);
            ImDrawFlags rflags = (i == 0) ? ImDrawFlags_RoundCornersTop : ((i == 6) ? ImDrawFlags_RoundCornersBottom : 0);
            dl->AddRectFilled(ImVec2(pos.x, pos.y + i * stripe_h), ImVec2(pos.x + sz.x, pos.y + (i + 1) * stripe_h), col, rounding, rflags);
        }
        // Dark blue canton
        float canton_w = sz.x * 0.44f;
        float canton_h = stripe_h * 4.0f;
        dl->AddRectFilled(pos, ImVec2(pos.x + canton_w, pos.y + canton_h), IM_COL32(10, 49, 97, 255), rounding, ImDrawFlags_RoundCornersTopLeft);

        // Micro star dots (grid of 6 stars)
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 3; col++) {
                float sx = pos.x + 3.5f + col * ((canton_w - 7.0f) / 2.0f);
                float sy = pos.y + 3.0f + row * ((canton_h - 6.0f) / 1.0f);
                dl->AddCircleFilled(ImVec2(sx, sy), 0.9f, IM_COL32(255, 255, 255, 240));
            }
        }
    }
    else { // 🇸🇦 ARABIC (Saudi Emerald Green with white saber sword & calligraphy)
        // Green field
        dl->AddRectFilled(pos, pos + sz, IM_COL32(0, 108, 53, 255), rounding, ImDrawFlags_RoundCornersAll);

        // White saber sword
        float my = pos.y + sz.y * 0.68f;
        float bx = pos.x + sz.x * 0.18f;
        float ex = pos.x + sz.x * 0.82f;
        // Blade pointing left (traditional Saudi flag orientation)
        dl->AddLine(ImVec2(bx, my), ImVec2(ex - 6.0f, my), IM_COL32(255, 255, 255, 240), 1.6f);
        // Hilt & guard
        dl->AddLine(ImVec2(ex - 6.0f, my - 3.5f), ImVec2(ex - 6.0f, my + 3.5f), IM_COL32(255, 255, 255, 240), 1.6f);
        dl->AddCircleFilled(ImVec2(ex - 2.0f, my), 1.5f, IM_COL32(255, 255, 255, 240));

        // Calligraphic inscription representation
        float cy1 = pos.y + sz.y * 0.32f;
        float cy2 = pos.y + sz.y * 0.46f;
        dl->AddLine(ImVec2(pos.x + sz.x * 0.22f, cy1), ImVec2(pos.x + sz.x * 0.78f, cy1), IM_COL32(255, 255, 255, 210), 1.2f);
        dl->AddLine(ImVec2(pos.x + sz.x * 0.28f, cy2), ImVec2(pos.x + sz.x * 0.72f, cy2), IM_COL32(255, 255, 255, 210), 1.2f);
        dl->AddLine(ImVec2(pos.x + sz.x * 0.38f, cy1 - 2.5f), ImVec2(pos.x + sz.x * 0.38f, cy1 + 2.5f), IM_COL32(255, 255, 255, 210), 1.0f);
        dl->AddLine(ImVec2(pos.x + sz.x * 0.62f, cy1 - 2.5f), ImVec2(pos.x + sz.x * 0.62f, cy1 + 2.5f), IM_COL32(255, 255, 255, 210), 1.0f);
    }

    // High-precision crisp glass border
    dl->AddRect(pos, pos + sz, IM_COL32(255, 255, 255, 70), rounding, 0, 1.2f);
}

inline void DrawInGameCrosshair(ImDrawList* dl, int screen_w, int screen_h) {
    if (!crosshair_enable || !dl) return;

    ImVec2 center((float)screen_w * 0.5f, (float)screen_h * 0.5f);

    float r_expand = 0.f;
    if (crosshair_recoil) {
        r_expand = fabsf(sinf((float)ImGui::GetTime() * 4.f)) * 8.f;
    }

    ImU32 c_col = ImGui::GetColorU32(ImVec4(crosshair_col[0], crosshair_col[1], crosshair_col[2], crosshair_col[3]));
    ImU32 o_col = IM_COL32(0, 0, 0, 220);
    float total_gap = (float)crosshair_gap + r_expand;
    float sz = (float)crosshair_size;
    float th = (float)crosshair_thick;

    // Center Dot
    if (crosshair_dot || crosshair_style == 1) {
        if (crosshair_outline)
            dl->AddCircleFilled(center, th + 1.f, o_col);
        dl->AddCircleFilled(center, th * 0.75f, c_col);
    }

    if (crosshair_style == 1) return; // Dot-only style

    // Circle style
    if (crosshair_style == 2) {
        if (crosshair_outline)
            dl->AddCircle(center, total_gap + sz, o_col, 32, th + 2.f);
        dl->AddCircle(center, total_gap + sz, c_col, 32, th);
        return;
    }

    // Line 1: Left
    ImVec2 l_start(center.x - total_gap - sz, center.y);
    ImVec2 l_end(center.x - total_gap, center.y);

    // Line 2: Right
    ImVec2 r_start(center.x + total_gap, center.y);
    ImVec2 r_end(center.x + total_gap + sz, center.y);

    // Line 3: Bottom
    ImVec2 b_start(center.x, center.y + total_gap);
    ImVec2 b_end(center.x, center.y + total_gap + sz);

    // Line 4: Top
    ImVec2 t_start(center.x, center.y - total_gap - sz);
    ImVec2 t_end(center.x, center.y - total_gap);

    if (crosshair_outline) {
        dl->AddLine(l_start, l_end, o_col, th + 2.f);
        dl->AddLine(r_start, r_end, o_col, th + 2.f);
        dl->AddLine(b_start, b_end, o_col, th + 2.f);
        if (crosshair_style != 3) dl->AddLine(t_start, t_end, o_col, th + 2.f);
    }

    dl->AddLine(l_start, l_end, c_col, th);
    dl->AddLine(r_start, r_end, c_col, th);
    dl->AddLine(b_start, b_end, c_col, th);
    if (crosshair_style != 3) dl->AddLine(t_start, t_end, c_col, th);
}

inline int combo[30] = { 0 };
inline int keybind[30] = { 0 };
inline int keybind_mode[30] = { 0 };
inline char UserName[64] = "MirageUser";

inline int active_page = 0;
inline int aim_sub = 0;
inline int vis_sub = 0;
inline int ply_sub = 0;
inline int rad_sub = 0;
inline int msc_sub = 0;

inline float card_anim_c1 = 1.0f;
inline float card_anim_c2 = 1.0f;
inline int prev_page = 0;
inline bool page_changed = false;
inline c_white_fire_bg p_animated_bg;

void RenderMirageTabs(int active_page, float col_w, float card_h, float sub_offset, float ease_c1, float ease_c2, float col_gap);

inline ImVec2 float_btn_pos = ImVec2(40.f, 150.f);
inline bool float_btn_init = false;

inline void DrawLetterWaveTitle(ImDrawList* dl, const char* text, ImVec2 pos, float spacing = 4.0f, float alpha = 1.0f) {
    if (!text || !*text || !dl) return;
    PushFont(font::inter_bold);
    DrawLetterWaveText(dl, text, pos, spacing, alpha, true);
    PopFont();
}

inline void RenderFloatingMenuButton(bool* is_open, int screen_w = 0, int screen_h = 0) {
    if (!is_open) return;

    ImVec2 disp_sz = ImGui::GetIO().DisplaySize;
    if (disp_sz.x < 100.f || disp_sz.y < 100.f) {
        disp_sz = ImVec2((float)screen_w, (float)screen_h);
    }
    if (disp_sz.x < 100.f) disp_sz.x = 1920.f;
    if (disp_sz.y < 100.f) disp_sz.y = 1080.f;

    if (!float_btn_init) {
        float_btn_pos = ImVec2(30.f, disp_sz.y * 0.35f);
        float_btn_init = true;
    }

    const float btn_radius = 56.f;
    const float btn_diam = btn_radius * 2.f;

    ImGui::SetNextWindowPos(float_btn_pos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(btn_diam, btn_diam), ImGuiCond_Always);

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | 
                             ImGuiWindowFlags_NoSavedSettings | 
                             ImGuiWindowFlags_NoBackground | 
                             ImGuiWindowFlags_NoMove | 
                             ImGuiWindowFlags_NoScrollbar;

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);

    if (ImGui::Begin("##MIRAGE_FLOAT_BTN", nullptr, flags)) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 win_pos = ImGui::GetWindowPos();
        ImVec2 center = win_pos + ImVec2(btn_radius, btn_radius);
        ImGuiIO& io = ImGui::GetIO();

        static bool is_dragging_btn = false;
        static ImVec2 drag_start_mouse;
        static ImVec2 drag_start_btn_pos;
        static bool was_dragged = false;

        ImRect btn_rect(win_pos, win_pos + ImVec2(btn_diam, btn_diam));
        bool is_hovered = ImGui::IsMouseHoveringRect(btn_rect.Min, btn_rect.Max);

        // Touch / Drag handling
        if (io.MouseDown[0] && !s_show_unload_modal) {
            if (!is_dragging_btn && is_hovered) {
                is_dragging_btn = true;
                drag_start_mouse = io.MousePos;
                drag_start_btn_pos = float_btn_pos;
                was_dragged = false;
            }
            if (is_dragging_btn) {
                ImVec2 delta = io.MousePos - drag_start_mouse;
                if (fabsf(delta.x) > 6.f || fabsf(delta.y) > 6.f) {
                    was_dragged = true;
                }
                float_btn_pos = drag_start_btn_pos + delta;
                float_btn_pos.x = ImClamp(float_btn_pos.x, 10.f, disp_sz.x - btn_diam - 10.f);
                float_btn_pos.y = ImClamp(float_btn_pos.y, 10.f, disp_sz.y - btn_diam - 10.f);
            }
        } else {
            if (is_dragging_btn) {
                if (!was_dragged) {
                    *is_open = !(*is_open);
                }
                is_dragging_btn = false;
            }
        }

        // Render pure emblem image without the circular background underneath
        GLuint logo_tex = GetMirageLogoTexture();
        if (logo_tex) {
            // Soft elevation drop shadow matching squircle shape
            dl->AddShadowRect(win_pos + ImVec2(8.f, 8.f), win_pos + ImVec2(btn_diam - 8.f, btn_diam - 8.f),
                IM_COL32(0, 0, 0, 190), 22.f, ImVec2(0, 4), ImDrawFlags_RoundCornersAll, 24.f);

            // Subtle pulsing active glow when hovered or dragged
            if (is_hovered || is_dragging_btn) {
                float pulse = (sinf((float)ImGui::GetTime() * 3.0f) + 1.f) * 0.5f;
                dl->AddShadowRect(win_pos + ImVec2(6.f, 6.f), win_pos + ImVec2(btn_diam - 6.f, btn_diam - 6.f),
                    ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.40f + pulse * 0.25f)), 
                    26.f, ImVec2(0, 0), ImDrawFlags_RoundCornersAll, 24.f);
            }

            // Draw full-size emblem badge (pure image, no circle underneath)
            dl->AddImage((ImTextureID)(intptr_t)logo_tex, win_pos, win_pos + ImVec2(btn_diam, btn_diam));
        }

        // When menu is open, show an elegant semi-transparent close overlay
        if (*is_open) {
            dl->AddRectFilled(win_pos, win_pos + ImVec2(btn_diam, btn_diam), IM_COL32(10, 12, 18, 190), 24.f);
            PushFont(font::inter_bold);
            const char* btn_icon = ICON_CLOSE_FILL;
            ImVec2 ico_sz = CalcTextSize(btn_icon);
            dl->AddText(center - ico_sz * 0.5f, IM_COL32(255, 120, 120, 245), btn_icon);
            PopFont();
        }
    }
    ImGui::End();
    ImGui::PopStyleVar(2);
}

inline void RenderMirageTabs(int active_page, float col_w, float card_h, float sub_offset, float ease_c1, float ease_c2, float col_gap) {
    ImDrawList* dl = ImGui::GetWindowDrawList();

    // =========================================================================
    // ВКЛАДКА 0: АИМБОТ (AIMBOT)
    // =========================================================================
    if (active_page == 0) {
        if (aim_sub == 0) { // ОСНОВНОЙ АИМ (AIMBOT CORE)
            ImGui::SetCursorPos(ImVec2(2.f, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c1);
            ImGui::BeginGroup();
            {
                custom::Child(LText("Aimbot Core Engine", "Основной Аимбот", "محرك التصويب الأساسي"), ImVec2(col_w, card_h), true, 0, false, ICON_SWORD_FILL); {
                    static const char* bones_ru[] = { "Авто (Auto)", "Голова (Head)", "Шея (Neck)", "Грудь (Chest)", "Таз (Pelvis)" };
                    static const char* bones_en[] = { "Auto", "Head Bone", "Neck Bone", "Chest Bone", "Pelvis Bone" };
                    static const char* bones_ar[] = { "تلقائي (Auto)", "عظمة الرأس", "عظمة الرقبة", "عظمة الصدر", "عظمة الحوض" };
                    static const char* bones_ar_s[5];
                    static bool s_bones_init = false;
                    if (!s_bones_init) {
                        for (int bi = 0; bi < 5; bi++) bones_ar_s[bi] = Lang::Shape(bones_ar[bi]);
                        s_bones_init = true;
                    }
                    int cur_l = GetCurrentLang();
                    const char** cur_bones = (cur_l == 1) ? bones_ru : ((cur_l == 2) ? bones_ar_s : bones_en);

                    custom::Checkbox(LText("Enable Aimbot Target", "Включить Аимбот", "تفعيل التصويب التلقائي"), &g_Config.aimbot_enabled);
                    custom::SliderFloat(LText("Targeting FOV Radius", "Радиус обзора (FOV)", "نصف قطر زاوية الرؤية"), &g_Config.aimbot_fov_radius, 10.0f, 500.0f, "%.0f");
                    custom::Checkbox(LText("Draw FOV Circle", "Отображать круг FOV", "رسم دائرة زاوية الرؤية"), &g_Config.aimbot_fov);
                    custom::ColorEdit4(LText("FOV Circle Color", "Цвет круга FOV", "لون دائرة FOV"), g_Config.col_aimbot_fov, 0);
                    static const char* priority_ru[] = { "По дистанции (Ближний)", "По прицелу (К центру)" };
                    static const char* priority_en[] = { "Closest Distance", "Closest Crosshair" };
                    static const char* priority_ar[] = { "الأقرب مسافة", "الأقرب للمؤشر" };
                    static const char* priority_ar_s[2];
                    static bool s_prio_init = false;
                    if (!s_prio_init) {
                        for (int pi = 0; pi < 2; pi++) priority_ar_s[pi] = Lang::Shape(priority_ar[pi]);
                        s_prio_init = true;
                    }
                    const char** cur_priority = (cur_l == 1) ? priority_ru : ((cur_l == 2) ? priority_ar_s : priority_en);

                    custom::Combo(LText("Target Hitbox Bone", "Точка прицеливания", "نقطة التصويب"), &g_Config.aimbot_bone, cur_bones, 5);
                    custom::Combo(LText("Target Priority", "Приоритет цели", "أولوية الهدف"), &g_Config.aimbot_priority, cur_priority, 2);
                    custom::Checkbox(LText("Vertical Adjust", "Вертикаль", "ضبط عمودي"), &g_Config.aimbot_vertical);
                    if (g_Config.aimbot_vertical) {
                        custom::SliderFloat(LText("Vertical Offset (down/up)", "Смещение вниз/вверх", "الإزاحة العمودية"), &g_Config.aimbot_vertical_offset, -50.0f, 50.0f, "%.0f cm");
                    }
                    custom::Checkbox(LText("Ignore Bots / NPCs", "Игнорировать ботов / NPC", "تجاهل البوتات والشخصيات"), &g_Config.aimbot_ignore_bots);
                    custom::Checkbox(LText("Ignore Knocked Players", "Игнорировать нокнутых", "تجاهل المصابين"), &g_Config.aimbot_ignore_knocked);
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();

            ImGui::SetCursorPos(ImVec2(2.f + col_w + col_gap, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c2);
            ImGui::BeginGroup();
            {
                custom::Child(LText("Trigger & Scope Zone", "Условия и Зона прицела", "الشروط ونطاق التصويب"), ImVec2(col_w, card_h), true, 0, false, ICON_TARGET_FILL); {
                    custom::Checkbox(LText("Visible Check Only", "Только видимые цели", "فحص الأهداف المرئية فقط"), &g_Config.aimbot_visible_only);
                    custom::Checkbox(LText("Aim on Shoot", "Аим при стрельбе", "تصويب عند إطلاق النار"), &g_Config.aimbot_on_fire);
                    custom::Checkbox(LText("Touch Trigger Zone (Scope)", "Сенсорная зона (Прицел)", "منطقة لمس التصويب"), &g_Config.aimbot_touch_zone);
                    if (g_Config.aimbot_touch_zone) {
                        custom::Checkbox(LText("Lock Zone Position", "Зафиксировать зону прицела", "قفل موضع المنطقة"), &g_Config.aimbot_fire_zone_locked);
                        custom::SliderFloat(LText("Scope Zone Radius", "Радиус зоны прицела", "نصف قطر منطقة التصويب"), &g_Config.aimbot_fire_zone_r, 40.0f, 250.0f, "%.0f");
                    }
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();
        }
        else if (aim_sub == 1) { // ОТДАЧА И RCS (ACCURACY & RCS)
            ImGui::SetCursorPos(ImVec2(2.f, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c1);
            ImGui::BeginGroup();
            {
                custom::Child(LText("Recoil Control System", "Контроль отдачи (RCS)", "نظام التحكم في الارتداد"), ImVec2(col_w, card_h), true, 0, false, ICON_TARGET_FILL); {
                    custom::Checkbox(LText("Recoil Compensation", "Антиотдача (No Recoil)", "تعويض الارتداد"), &g_Config.mem_no_recoil);
                    custom::Checkbox(LText("No Camera Shake", "Без тряски камеры", "منع اهتزاز الكاميرا"), &g_Config.mem_no_camera_shake);
                    custom::Checkbox(LText("Instant Hit", "Мгновенное попадание", "إصابة فورية"), &g_Config.mem_instant_hit);
                    custom::Checkbox(LText("Fast Bullet Velocity", "Быстрая скорость пули", "سرعة رصاص فائقة"), &g_Config.mem_fast_bullet);
                    custom::Checkbox(LText("Rapid Fire Rate", "Быстрая стрельба", "إطلاق نار سريع"), &g_Config.mem_fast_shoot);
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();

            ImGui::SetCursorPos(ImVec2(2.f + col_w + col_gap, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c2);
            ImGui::BeginGroup();
            {
                custom::Child(LText("Aim Smoothing Engine", "Сглаживание и Плавность", "سلاسة وانسيابية التصويب"), ImVec2(col_w, card_h), true, 0, false, ICON_SETTINGS_4_FILL); {
                    custom::SliderFloat(LText("Aim Smooth Interpolation", "Плавность доводки", "سلاسة توجيه التصويب"), &g_Config.aimbot_smooth, 1.0f, 50.0f, "%.0f");
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();
        }
    }

    // =========================================================================
    // ВКЛАДКА 1: ВИЗУАЛЫ / ESP (VISUALS) - БЕЗ 3D СКЕЛЕТА
    // =========================================================================
    if (active_page == 1) {
        if (vis_sub == 0) { // НАСТРОЙКИ ВХ (WALLHACK ESP)
            ImGui::SetCursorPos(ImVec2(2.f, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c1);
            ImGui::BeginGroup();
            {
                custom::Child(LText("Wallhack ESP Overlays", "Основные оверлеи ЕСП", "تراكبات الرؤية ESP"), ImVec2(col_w, card_h), true, 0, false, ICON_EYE_2_FILL); {
                    static const char* box_types_ru[] = { "2D Боксы", "3D Боксы" };
                    static const char* box_types_en[] = { "2D Box Projection", "3D Box Projection" };
                    static const char* box_types_ar[] = { "صناديق ثنائية الأبعاد", "صناديق ثلاثية الأبعاد" };
                    static const char* box_types_ar_s[2];
                    static bool s_bt_init = false;
                    if (!s_bt_init) {
                        for (int bi = 0; bi < 2; bi++) box_types_ar_s[bi] = Lang::Shape(box_types_ar[bi]);
                        s_bt_init = true;
                    }

                    static const char* origins_ru[] = { "Сверху экрана", "Из прицела", "Снизу экрана" };
                    static const char* origins_en[] = { "Top of Screen", "Center Crosshair", "Bottom of Screen" };
                    static const char* origins_ar[] = { "أعلى الشاشة", "مركز التصويب", "أسفل الشاشة" };
                    static const char* origins_ar_s[3];
                    static bool s_org_init = false;
                    if (!s_org_init) {
                        for (int bi = 0; bi < 3; bi++) origins_ar_s[bi] = Lang::Shape(origins_ar[bi]);
                        s_org_init = true;
                    }

                    static const char* hp_styles_ru[] = { "Цифры (Текст)", "Полоска (Bar)" };
                    static const char* hp_styles_en[] = { "Numeric Text", "Progress Bar" };
                    static const char* hp_styles_ar[] = { "أرقام (نص)", "شريط تقدم" };
                    static const char* hp_styles_ar_s[2];
                    static bool s_hp_init = false;
                    if (!s_hp_init) {
                        for (int bi = 0; bi < 2; bi++) hp_styles_ar_s[bi] = Lang::Shape(hp_styles_ar[bi]);
                        s_hp_init = true;
                    }

                    int cur_l = GetCurrentLang();
                    const char** cur_box_types = (cur_l == 1) ? box_types_ru : ((cur_l == 2) ? box_types_ar_s : box_types_en);
                    const char** cur_origins = (cur_l == 1) ? origins_ru : ((cur_l == 2) ? origins_ar_s : origins_en);
                    const char** cur_hp_styles = (cur_l == 1) ? hp_styles_ru : ((cur_l == 2) ? hp_styles_ar_s : hp_styles_en);

                    custom::Checkbox(LText("Enable Wallhack ESP", "Включить Wallhack / ESP", "تفعيل الرؤية عبر الجدران"), &g_Config.esp_enabled);
                    custom::Checkbox(LText("Draw Skeleton ESP", "Скелеты врагов (Skeleton)", "رسم هياكل الأعداء"), &g_Config.esp_skeleton);
                    custom::Checkbox(LText("Draw Player Boxes", "Боксы игроков (Box)", "رسم صناديق اللاعبين"), &g_Config.esp_box);
                    custom::Combo(LText("Box Projection", "Тип боксов", "نوع الصناديق"), &g_Config.esp_box_type, cur_box_types, 2);
                    custom::Checkbox(LText("Draw Player Lines", "Линии до игроков (Lines)", "خطوط إلى اللاعبين"), &g_Config.esp_line);
                    custom::Combo(LText("Line Origin", "Начало линий", "نقطة بداية الخطوط"), &g_Config.esp_line_origin, cur_origins, 3);
                    custom::Checkbox(LText("Draw Player Names", "Имена игроков (Name)", "أسماء اللاعبين"), &g_Config.esp_name);
                    custom::Checkbox(LText("Draw Health Bar", "Полоска здоровья (HP)", "شريط الصحة"), &g_Config.esp_health);
                    custom::Combo(LText("HP Display Style", "Вид здоровья", "شكل عرض الصحة"), &g_Config.esp_health_type, cur_hp_styles, 2);
                    custom::Checkbox(LText("Draw Distance (m)", "Дистанция в метрах", "المسافة بالأمتار"), &g_Config.esp_distance);
                    custom::Checkbox(LText("Draw Team ID", "Номер команды (Team ID)", "رقم الفريق"), &g_Config.esp_team_id);
                    custom::Checkbox(LText("Draw Weapon Name", "Оружие в руках (Weapon)", "السلاح في اليد"), &g_Config.esp_weapon);
                    custom::Checkbox(LText("Head Dot Marker", "Точка на голове (Head Dot)", "نقطة على الرأس"), &g_Config.esp_head_dot);
                    custom::Checkbox(LText("Show Bots on ESP", "Отображать ботов", "إظهار البوتات"), &g_Config.esp_bots);
                    custom::Checkbox(LText("Show Teammates", "Отображать союзников", "إظهار الزملاء"), &g_Config.esp_teammates);
                    custom::Checkbox(LText("Calibration (T/S/B letters)", "Калибровка (буквы T/S/B)", "معايرة"), &g_Config.esp_calibrate);
                    custom::Checkbox(LText("ESP Diagnostics Log", "Лог диагностики ESP", "سجل تشخيص ESP"), &g_Config.esp_log);
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();

            // Вторая колонка: Цвета, размеры и параметры отрисовки
            ImGui::SetCursorPos(ImVec2(2.f + col_w + col_gap, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c2);
            ImGui::BeginGroup();
            {
                custom::Child(LText("ESP Styling & Dimensions", "Параметры и толщина линий", "أنماط وأبعاد ESP"), ImVec2(col_w, card_h), true, 0, false, ICON_SETTINGS_4_FILL); {
                    custom::SliderFloat(LText("Skeleton Thickness", "Толщина линий скелета", "سمك الهيكل"), &g_Config.esp_skeleton_thickness, 1.0f, 5.0f, "%.1f");
                    custom::SliderFloat(LText("Box Thickness", "Толщина линий боксов", "سمك الصندوق"), &g_Config.esp_box_thickness, 1.0f, 5.0f, "%.1f");
                    custom::SliderInt(LText("ESP Font Size", "Размер шрифта ESP", "حجم خط ESP"), &g_Config.esp_text_size, 10, 24);
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();
        }
        else if (vis_sub == 1) { // ЧАМСЫ И МИР (CHAMS & WORLD)
            ImGui::SetCursorPos(ImVec2(2.f, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c1);
            ImGui::BeginGroup();
            {
                custom::Child(LText("Items & Containers ESP", "Предметы и контейнеры", "العناصر والحاويات"), ImVec2(col_w, card_h), true, 0, false, ICON_EYE_FILL); {
                    custom::Checkbox(LText("Grenade Warning ESP", "Предупреждение о гранатах", "تحذير القنابل اليدوية"), &g_Config.esp_grenade_warning);
                    custom::Checkbox(LText("Lootbox & Crates ESP", "Ящики и контейнеры", "صناديق الغنائم"), &g_Config.esp_lootbox);
                    custom::Checkbox(LText("Hide Opened Boxes", "Скрывать открытые ящики", "إخفاء الصناديق المفتوحة"), &g_Config.esp_filter_opened_boxes);
                    custom::Checkbox(LText("Draw Items ESP", "Отображать предметы (Items)", "إظهار العناصر"), &g_Config.esp_items);
                    custom::Checkbox(LText("Draw Dead Bodies ESP", "Отображать трупы (Corpse)", "إظهار الجثث"), &g_Config.esp_dead_bodies);
                    custom::SliderInt(LText("Item Max Distance", "Дистанция предметов", "أقصى مسافة للعناصر"), &g_Config.item_esp_max_distance, 20, 300, "%d m");
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();

            ImGui::SetCursorPos(ImVec2(2.f + col_w + col_gap, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c2);
            ImGui::BeginGroup();
            {
                custom::Child(LText("Camera & HUD", "Камера и HUD", "الكاميرا ومجال الرؤية"), ImVec2(col_w, card_h), true, 0, false, ICON_SUN_2_FILL); {
                    custom::Checkbox(LText("Wide Screen (iPad View)", "Широкий обзор (iPad View)", "رؤية واسعة (iPad)"), &g_Config.mem_wide_view);
                    custom::SliderFloat(LText("Camera FOV Angle", "Угол обзора камеры", "زاوية رؤية الكاميرا"), &g_Config.mem_wide_view_fov, 70.0f, 130.0f, "%.0f");
                    custom::Checkbox(LText("Weapon Ammo Counter HUD", "Счетчик патронов в оружии (HUD)", "عداد ذخيرة السلاح HUD"), &g_Config.ammo_hud_enabled);
                    custom::Checkbox(LText("Lock Ammo HUD Position", "Зафиксировать позицию счетчика", "قفل موضع عداد الذخيرة"), &g_Config.ammo_hud_locked);
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();
        }
    }

    // =========================================================================
    if (active_page == 2) {
        ImGui::SetCursorPos(ImVec2(2.f, sub_offset));
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c1);
        ImGui::BeginGroup();
        {
            custom::Child(LText("Player Colors (Open/Covered)", "Цвета Игроков (Открытые/Закрытые)", "ألوان اللاعبين (مفتوح/مغطى)"), ImVec2(col_w, card_h), true, 0, false, ICON_GROUP_3_FILL); {
                custom::ColorEdit4(LText("Player Skeleton (Visible)", "Скелеты игроков (Открытые)", "هياكل اللاعبين (مرئي)"), g_Config.col_player_skel_vis, 0);
                custom::ColorEdit4(LText("Player Skeleton (Hidden)", "Скелеты игроков (Закрытые)", "هياكل اللاعبين (مخفي)"), g_Config.col_player_skel_hid, 0);
                custom::ColorEdit4(LText("Player Snapline (Visible)", "Линии игроков (Открытые)", "خطوط اللاعبين (مرئي)"), g_Config.col_player_line_vis, 0);
                custom::ColorEdit4(LText("Player Snapline (Hidden)", "Линии игроков (Закрытые)", "خطوط اللاعبين (مخفي)"), g_Config.col_player_line_hid, 0);
                custom::ColorEdit4(LText("Enemy Box (Visible)", "Боксы врагов (Открытые)", "صناديق الأعداء (مرئي)"), color_edit[0], 0);
                custom::ColorEdit4(LText("Enemy Box (Hidden)", "Боксы врагов (Закрытые)", "صناديق الأعداء (مخفي)"), color_edit[1], 0);
                custom::ColorEdit4(LText("Teammate Color", "Цвет союзников", "لون الزملاء"), color_edit[3], 0);
            }
            custom::EndChild();
        } ImGui::EndGroup();
        ImGui::PopStyleVar();

        ImGui::SetCursorPos(ImVec2(2.f + col_w + col_gap, sub_offset));
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c2);
        ImGui::BeginGroup();
        {
            custom::Child(LText("Bot Colors (Open/Covered)", "Цвета Ботов (Открытые/Закрытые)", "ألوان البوتات (مفتوح/مغطى)"), ImVec2(col_w, card_h), true, 0, false, ICON_TARGET_FILL); {
                custom::ColorEdit4(LText("Bot Skeleton (Visible)", "Скелеты ботов (Открытые)", "هياكل البوتات (مرئي)"), g_Config.col_bot_skel_vis, 0);
                custom::ColorEdit4(LText("Bot Skeleton (Hidden)", "Скелеты ботов (Закрытые)", "هياكل البوتات (مخفي)"), g_Config.col_bot_skel_hid, 0);
                custom::ColorEdit4(LText("Bot Snapline (Visible)", "Линии ботов (Открытые)", "خطوط البوتات (مرئي)"), g_Config.col_bot_line_vis, 0);
                custom::ColorEdit4(LText("Bot Snapline (Hidden)", "Линии ботов (Закрытые)", "خطوط البوتات (مخفي)"), g_Config.col_bot_line_hid, 0);
            }
            custom::EndChild();
        } ImGui::EndGroup();
        ImGui::PopStyleVar();
    }

    // =========================================================================
    // ВКЛАДКА 3: КАСТОМ (CUSTOM) - СТУДИЯ ПРИЦЕЛА
    // =========================================================================
    if (active_page == 3) {
        ImGui::SetCursorPos(ImVec2(2.f, sub_offset));
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c1);
        ImGui::BeginGroup();
        {
            custom::Child(LText("Custom Crosshair Studio", "Студия кастомного прицела", "استوديو علامة التصويب"), ImVec2(col_w, card_h), true, 0, false, ICON_TARGET_FILL); {
                static const char* c_styles_ru[] = { "Крестик (Classic Cross)", "Точка (Center Dot)", "Круг (Tactical Ring)", "Т-образный (T-Style)" };
                static const char* c_styles_en[] = { "Classic Cross", "Center Dot", "Tactical Ring", "T-Style Cross" };
                static const char* c_styles_ar[] = { "علامة كلاسيكية", "نقطة في المنتصف", "حلقة تكتيكية", "علامة حرف T" };
                static const char* c_styles_ar_s[4];
                static bool s_cs_init = false;
                if (!s_cs_init) {
                    for (int bi = 0; bi < 4; bi++) c_styles_ar_s[bi] = Lang::Shape(c_styles_ar[bi]);
                    s_cs_init = true;
                }

                int cur_l = GetCurrentLang();
                const char** c_styles = (cur_l == 1) ? c_styles_ru : ((cur_l == 2) ? c_styles_ar_s : c_styles_en);

                custom::Checkbox(LText("Enable Custom Crosshair", "Включить кастомный прицел", "تفعيل علامة التصويب"), &crosshair_enable);
                custom::Combo(LText("Crosshair Style", "Стиль прицела", "نمط علامة التصويب"), &crosshair_style, c_styles, 4);
                custom::SliderInt(LText("Line Length", "Длина линий", "طول الخطوط"), &crosshair_size, 2, 30);
                custom::SliderInt(LText("Line Thickness", "Толщина линий", "سمك الخطوط"), &crosshair_thick, 1, 8);
                custom::SliderInt(LText("Center Gap", "Зазор (Gap)", "الفجوة المركزية"), &crosshair_gap, 0, 20);
                custom::Checkbox(LText("Draw Center Dot", "Точка в центре", "نقطة في المنتصف"), &crosshair_dot);
                custom::Checkbox(LText("Draw Black Outline", "Черная обводка", "إطار أسود"), &crosshair_outline);
                custom::ColorEdit4(LText("Crosshair Color", "Цвет прицела", "لون علامة التصويب"), crosshair_col, 0);
            }
            custom::EndChild();
        } ImGui::EndGroup();
        ImGui::PopStyleVar();

        ImGui::SetCursorPos(ImVec2(2.f + col_w + col_gap, sub_offset));
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c2);
        ImGui::BeginGroup();
        {
            custom::Child(LText("Studio Preview", "Студия Прицела", "استوديو التصويب"), ImVec2(col_w, card_h), true, 0, false, ICON_EYE_FILL); {
                ImVec2 preview_center = ImGui::GetCursorScreenPos() + ImVec2(col_w * 0.5f - 12.f, card_h * 0.45f);
                DrawAnimatedCrosshairPreview(dl, preview_center, 1.0f,
                    crosshair_enable, crosshair_style, crosshair_size, crosshair_thick, crosshair_gap,
                    crosshair_dot, crosshair_outline, false, crosshair_col);
            }
            custom::EndChild();
        } ImGui::EndGroup();
        ImGui::PopStyleVar();
    }

    // =========================================================================
    // ВКЛАДКА 4: НАСТРОЙКИ (SETTINGS) & КОНФИГУРАЦИЯ С ШЕРИНГОМ
    // =========================================================================
    if (active_page == 4) {
        if (msc_sub == 0) { // СИСТЕМА (SYSTEM)
            ImGui::SetCursorPos(ImVec2(2.f, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c1);
            ImGui::BeginGroup();
            {
                custom::Child(LText("System & License", "Система и Лицензия", "النظام والترخيص"), ImVec2(col_w, card_h), true, 0, false, ICON_SETTINGS_4_FILL); {
                    // License Status & Key Expiration Card (Compact & Clean)
                    std::string expiry = g_Config.login_expiry;
                    if (expiry.empty() && !Login::g_Expiry.empty()) expiry = Login::g_Expiry;
                    if (expiry.empty()) expiry = LText("Active", "Активен", "نشط");

                    ImVec2 lic_p0 = ImGui::GetCursorScreenPos();
                    float lic_w = ImGui::GetContentRegionAvail().x;
                    float lic_h = 72.f;
                    ImVec2 lic_p1(lic_p0.x + lic_w, lic_p0.y + lic_h);

                    dl->AddRectFilled(lic_p0, lic_p1, IM_COL32(18, 22, 34, 230), 10.f);
                    dl->AddRect(lic_p0, lic_p1, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.45f)), 10.f, 0, 1.2f);

                    // Header inside card: "ПОДПИСКА" + Green Active Pill Badge
                    PushFont(font::inter_bold);
                    dl->AddText(lic_p0 + ImVec2(12.f, 9.f), IM_COL32(230, 235, 245, 240), LText("SUBSCRIPTION", "ПОДПИСКА", "الاشتراك"));

                    const char* badge_text = LText("ACTIVE", "АКТИВЕН", "نشط");
                    ImVec2 badge_sz = CalcTextSize(badge_text);
                    float badge_pad = 6.f;
                    ImVec2 b_min = ImVec2(lic_p1.x - badge_sz.x - badge_pad * 2.f - 12.f, lic_p0.y + 7.f);
                    ImVec2 b_max = ImVec2(lic_p1.x - 12.f, b_min.y + badge_sz.y + 4.f);
                    dl->AddRectFilled(b_min, b_max, IM_COL32(34, 197, 94, 45), 6.f);
                    dl->AddRect(b_min, b_max, IM_COL32(34, 197, 94, 180), 6.f, 0, 1.f);
                    dl->AddText(b_min + ImVec2(badge_pad, 2.f), IM_COL32(74, 222, 128, 255), badge_text);
                    PopFont();

                    dl->AddLine(lic_p0 + ImVec2(10.f, 32.f), lic_p1 - ImVec2(10.f, lic_h - 32.f), IM_COL32(255, 255, 255, 18), 1.0f);

                    // Expiration Date: "Истекает:" + Date
                    PushFont(font::inter_bold);
                    dl->AddText(lic_p0 + ImVec2(12.f, 42.f), IM_COL32(165, 175, 195, 220), LText("Expires:", "Истекает:", "ينتهي:"));
                    ImVec2 exp_sz = CalcTextSize(expiry.c_str());
                    dl->AddText(ImVec2(lic_p1.x - exp_sz.x - 12.f, lic_p0.y + 42.f), ImGui::GetColorU32(c::anim::active), expiry.c_str());
                    PopFont();

                    ImGui::Dummy(ImVec2(0, lic_h + 16.f));

                    if (custom::Button(LText(ICON_POWER_FILL " UNLOAD MODIFICATION", ICON_POWER_FILL " ВЫГРУЗИТЬ МОД (UNLOAD)", ICON_POWER_FILL " تفريغ التعديل"), ImVec2(0, 38))) {
                        s_show_unload_modal = true;
                    }
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();

            ImGui::SetCursorPos(ImVec2(2.f + col_w + col_gap, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c2);
            ImGui::BeginGroup();
            {
                custom::Child(LText("Menu Text Colors", "Цвета текста меню", "ألوان نص القائمة"), ImVec2(col_w, card_h * 0.5f - 5.f), true, 0, false, ICON_SETTINGS_4_FILL); {
                    custom::ColorEdit4(LText("Primary Theme Color", "Основной цвет темы", "لون السمة الأساسي"), (float*)&c::anim::active, 0);
                    custom::ColorEdit4(LText("Secondary Gradient Color", "Второй цвет (Градиент)", "لون التدرج الثانوي"), (float*)&c::anim::secondary, 0);
                }
                custom::EndChild();
                custom::Child(LText("Counter Text Colors", "Цвета текста счётчика", "ألوان نص العداد"), ImVec2(col_w, card_h * 0.5f - 5.f), true, 0, false, ICON_SETTINGS_4_FILL); {
                    custom::ColorEdit4(LText("Counter Color 1", "Счётчик — цвет 1", "عداد - لون 1"), g_Config.col_counter_a, 0);
                    custom::ColorEdit4(LText("Counter Color 2", "Счётчик — цвет 2", "عداد - لون 2"), g_Config.col_counter_b, 0);
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();
        }
        else if (msc_sub == 1) { // КОНФИГУРАЦИЯ (MULTI-CONFIG SYSTEM WITH SHAREABLE FILES & WAVE HEADER)
            float dt = ImGui::GetIO().DeltaTime;
            static std::vector<std::string> configs = ConfigManager::GetConfigList();
            static int selected_cfg_idx = 0;
            static float refresh_timer = 0.f;
            refresh_timer += dt;
            if (refresh_timer > 3.0f) {
                refresh_timer = 0.f;
                configs = ConfigManager::GetConfigList();
            }
            if (selected_cfg_idx >= (int)configs.size()) selected_cfg_idx = 0;

            ImGui::SetCursorPos(ImVec2(2.f, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c1);
            ImGui::BeginGroup();
            {
                custom::Child(LText("Saved Profiles Roster", "Список Конфигов", "قائمة التكوينات"), ImVec2(col_w, card_h), true, 0, false, ICON_SETTINGS_4_FILL); {
                    // Animated Wave Title matching MIRAGE logo
                    ImVec2 title_p = ImGui::GetCursorScreenPos() + ImVec2(4.f, 2.f);
                    DrawLetterWaveTitle(dl, LText("C O N F I G U R A T I O N", "К О Н Ф И Г И   M I R A G E", "M I R A G E   الإعدادات"), title_p, 3.5f, 1.0f);
                    ImGui::Dummy(ImVec2(0, 24.f));

                    PushFont(font::small_font);
                    ImGui::TextColored(ImVec4(0.55f, 0.65f, 0.85f, 0.90f), LText("Folder: %s", "Папка: %s", "المجلد: %s"), ConfigManager::GetConfigDirectory().c_str());
                    PopFont();
                    ImGui::Spacing();

                    float list_h = card_h - 180.f;
                    if (list_h < 120.f) list_h = 120.f;
                    ImGui::BeginChild("CFG_SCROLL_LIST", ImVec2(0, list_h), true, ImGuiWindowFlags_NoScrollbar);
                    {
                        ImDrawList* list_dl = ImGui::GetWindowDrawList();
                        float item_w = ImGui::GetContentRegionAvail().x;

                        for (int i = 0; i < (int)configs.size(); i++) {
                            const std::string& cname = configs[i];
                            bool is_active_cfg = (cname == ConfigManager::g_ActiveConfigName);
                            bool is_selected = (selected_cfg_idx == i);

                            ImVec2 row_p0 = ImGui::GetCursorScreenPos();
                            ImVec2 row_p1 = row_p0 + ImVec2(item_w, 36.f);
                            ImRect row_bb(row_p0, row_p1);

                            PushID(i);
                            ImGuiID row_id = GetID("##cfg_row");
                            ImGui::ItemSize(ImVec2(item_w, 36.f), 0.f);
                            if (!ImGui::ItemAdd(row_bb, row_id)) {
                                PopID();
                                continue;
                            }

                            bool hov = false, held = false;
                            bool pressed = ImGui::ButtonBehavior(row_bb, row_id, &hov, &held);
                            if (pressed || (hov && ImGui::IsMouseClicked(0))) {
                                selected_cfg_idx = i;
                            }

                            if (is_selected) {
                                list_dl->AddRectFilled(row_p0, row_p1, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.18f)), 6.f);
                                list_dl->AddRect(row_p0, row_p1, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.55f)), 6.f, 0, 1.2f);
                            } else if (hov) {
                                list_dl->AddRectFilled(row_p0, row_p1, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.05f)), 6.f);
                            }

                            ImVec2 rad_c(row_p0.x + 16.f, row_p0.y + 18.f);
                            if (is_active_cfg) {
                                list_dl->AddCircleFilled(rad_c, 6.f, ImGui::GetColorU32(c::anim::active), 16);
                                list_dl->AddCircleFilled(rad_c, 2.5f, IM_COL32_WHITE, 12);
                            } else {
                                list_dl->AddCircle(rad_c, 5.5f, ImGui::GetColorU32(ImVec4(0.45f, 0.50f, 0.60f, 0.70f)), 16, 1.2f);
                            }

                            PushFont(font::inter_bold);
                            list_dl->AddText(ImVec2(row_p0.x + 32.f, row_p0.y + 9.f),
                                is_selected ? IM_COL32_WHITE : ImGui::GetColorU32(ImVec4(0.80f, 0.83f, 0.90f, 0.90f)),
                                cname.c_str());

                            if (is_active_cfg) {
                                const char* badge = LText("[ACTIVE]", "[АКТИВЕН]", "[نشط]");
                                ImVec2 b_sz = CalcTextSize(badge);
                                DrawLetterWaveText(list_dl, badge, ImVec2(row_p1.x - b_sz.x - 10.f, row_p0.y + 9.f), 0.0f, 1.0f, true);
                            }
                            PopFont();
                            PopID();
                        }
                    }
                    ImGui::EndChild();

                    ImGui::Spacing();
                    if (custom::Button(LText(ICON_CHECK_FILL " LOAD SELECTED CONFIG", ICON_CHECK_FILL " ЗАГРУЗИТЬ ВЫБРАННЫЙ", ICON_CHECK_FILL " تحميل المختار"), ImVec2(0, 32))) {
                        if (selected_cfg_idx >= 0 && selected_cfg_idx < (int)configs.size()) {
                            ConfigManager::LoadNamedConfig(configs[selected_cfg_idx]);
                        }
                    }
                    ImGui::Spacing();
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.85f, 0.20f, 0.22f, 0.75f));
                    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.95f, 0.25f, 0.28f, 0.90f));
                    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.70f, 0.15f, 0.18f, 1.00f));
                    if (custom::Button(LText(ICON_CLOSE_FILL " DELETE SELECTED CONFIG", ICON_CLOSE_FILL " УДАЛИТЬ ВЫБРАННЫЙ КОНФИГ", ICON_CLOSE_FILL " حذف التكوين المختار"), ImVec2(0, 32))) {
                        if (selected_cfg_idx >= 0 && selected_cfg_idx < (int)configs.size()) {
                            ConfigManager::DeleteNamedConfig(configs[selected_cfg_idx]);
                            configs = ConfigManager::GetConfigList();
                            selected_cfg_idx = 0;
                        }
                    }
                    ImGui::PopStyleColor(3);
                    ImGui::Spacing();
                    if (custom::Button(LText(ICON_REFRESH_1_FILL " REFRESH CONFIG LIST", ICON_REFRESH_1_FILL " ОБНОВИТЬ СПИСОК КОНФИГОВ", ICON_REFRESH_1_FILL " تحديث قائمة التكوينات"), ImVec2(0, 30))) {
                        configs = ConfigManager::GetConfigList();
                    }
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();

            ImGui::SetCursorPos(ImVec2(2.f + col_w + col_gap, sub_offset));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_c2);
            ImGui::BeginGroup();
            {
                custom::Child(LText("Save Mode & Share Engine", "Сохранение и Экспорт", "وضع الحفظ والمشاركة"), ImVec2(col_w, card_h), true, 0, false, ICON_SETTINGS_4_FILL); {
                    // Save mode combo: Auto vs Manual (Default is ALWAYS AUTO)
                    static const char* modes_ru[] = { "Автосохранение (По стандарту)", "Ручное сохранение" };
                    static const char* modes_en[] = { "Auto-Save Mode (Default)", "Manual Save Mode" };
                    static const char* modes_ar[] = { "حفظ تلقائي (افتراضي)", "حفظ يدوي" };
                    static const char* modes_ar_s[2];
                    static bool s_mode_init = false;
                    if (!s_mode_init) {
                        for (int bi = 0; bi < 2; bi++) modes_ar_s[bi] = Lang::Shape(modes_ar[bi]);
                        s_mode_init = true;
                    }
                    int cur_mode_idx = ConfigManager::g_AutoSaveMode ? 0 : 1;
                    int cur_l = GetCurrentLang();
                    const char** cur_modes = (cur_l == 1) ? modes_ru : ((cur_l == 2) ? modes_ar_s : modes_en);
                    if (custom::Combo(LText("Save Mode Engine", "Режим сохранения", "وضع الحفظ"), &cur_mode_idx, cur_modes, 2)) {
                        ConfigManager::g_AutoSaveMode = (cur_mode_idx == 0);
                    }

                    PushFont(font::small_font);
                    if (ConfigManager::g_AutoSaveMode) {
                        ImGui::TextColored(ImVec4(0.35f, 0.95f, 0.45f, 0.95f),
                            LText("Auto: All modifications are saved instantly", "Авто: Все изменения сохраняются мгновенно", "تلقائي: يتم حفظ جميع التعديلات فوراً"));
                    } else {
                        ImGui::TextColored(ImVec4(0.95f, 0.75f, 0.25f, 0.95f),
                            LText("Manual: Click SAVE button to write to file", "Ручной: Нажмите кнопку для сохранения", "يدوي: اضغط على زر الحفظ للكتابة في الملف"));
                    }
                    PopFont();

                    ImGui::Spacing();
                    // Save active config
                    if (custom::Button(LText(ICON_CHECK_FILL " SAVE ACTIVE CONFIG", ICON_CHECK_FILL " СОХРАНИТЬ АКТИВНЫЙ", ICON_CHECK_FILL " حفظ التكوين الحالي"), ImVec2(0, 34))) {
                        ConfigManager::SaveNamedConfig(ConfigManager::g_ActiveConfigName);
                    }

                    ImGui::Spacing();
                    ImGui::Spacing();
                    // Custom config name input and creation
                    static char s_NewConfigName[64] = "MyConfig";
                    PushFont(font::small_font);
                    ImGui::TextColored(ImVec4(0.85f, 0.88f, 0.95f, 0.90f),
                        LText("New Profile Name:", "Имя нового конфига:", "اسم التكوين الجديد:"));
                    PopFont();
                    ImGui::PushItemWidth(-1);
                    ImGui::InputText("##NEW_CFG_NAME_INPUT", s_NewConfigName, sizeof(s_NewConfigName));
                    ImGui::PopItemWidth();
                    ImGui::Spacing();

                    if (custom::Button(LText(ICON_REFRESH_1_FILL " CREATE PROFILE", ICON_REFRESH_1_FILL " СОЗДАТЬ С ИМЕНЕМ", ICON_REFRESH_1_FILL " إنشاء بالاسم"), ImVec2(0, 34))) {
                        if (s_NewConfigName[0] != '\0') {
                            ConfigManager::SaveNamedConfig(s_NewConfigName);
                            configs = ConfigManager::GetConfigList();
                        }
                    }

                    ImGui::Spacing();

                    // Shareable Files Info
                    PushFont(font::small_font);
                    ImGui::TextColored(ImVec4(0.85f, 0.88f, 0.95f, 0.95f),
                        LText("Files (.cfg) ready to share with friends:",
                              "Файлы (.cfg) готовы для отправки друзьям:",
                              "ملفات (.cfg) جاهزة للمشاركة مع الأصدقاء:"));
                    ImGui::TextColored(ImVec4(0.60f, 0.70f, 0.90f, 0.85f),
                        LText("Copy any .cfg from MirageConfigs and send via Telegram, Discord, or WhatsApp!",
                              "Скопируйте .cfg из MirageConfigs и отправьте через Telegram, Discord или WhatsApp!",
                              "انسخ أي ملف .cfg من MirageConfigs وشاركه عبر تيليجرام أو ديسكورد أو واتساب!"));
                    PopFont();

                    ImGui::Spacing();
                    if (custom::Button(LText(ICON_REFRESH_LINE " RESET DEFAULTS", ICON_REFRESH_LINE " СБРОСИТЬ НАСТРОЙКИ (RESET)", ICON_REFRESH_LINE " استعادة الإعدادات الافتراضية"), ImVec2(0, 32))) {
                        ConfigManager::ResetToDefaults();
                    }
                }
                custom::EndChild();
            } ImGui::EndGroup();
            ImGui::PopStyleVar();
        }
    }
}

inline void RenderMirageMenu(bool* is_open, int screen_w = 0, int screen_h = 0) {
    // 1. Always render the floating draggable button so menu can be reopened anytime
    RenderFloatingMenuButton(is_open, screen_w, screen_h);

    if (is_open && !(*is_open)) return;

    ImVec2 disp_sz = ImGui::GetIO().DisplaySize;
    if (disp_sz.x < 100.f || disp_sz.y < 100.f) {
        disp_sz = ImVec2((float)screen_w, (float)screen_h);
    }

    // 25% Expanded Dimensions:
    // Base was 1050x670 -> +25% = 1312x838
    ImVec2 win_sz(ImMin(1312.f, disp_sz.x * 0.98f), ImMin(838.f, disp_sz.y * 0.96f));
    ImVec2 win_pos((disp_sz.x - win_sz.x) * 0.5f, (disp_sz.y - win_sz.y) * 0.5f);

    ImGui::SetNextWindowPos(win_pos, ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(win_sz, ImGuiCond_Always);

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground;
    if (s_show_unload_modal) {
        flags |= ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoInputs;
    }

    if (ImGui::Begin("##MIRAGE_MAIN_WINDOW", nullptr, flags)) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 pos = ImGui::GetWindowPos();
        float dt = ImGui::GetIO().DeltaTime;

        // Auto-save any modified settings
        ConfigManager::UpdateAutoSave(dt);

        // 1. Ambient Background Particles
        p_animated_bg.render(dl, ImRect(pos, pos + win_sz), dt, 1.0f);

        // 2. Detached Dual Floating Card Layout (+25% Expanded)
        float sb_w = 265.f;
        float gap_w = 16.f;
        float main_w = win_sz.x - sb_w - gap_w;
        ImVec2 main_pos = pos + ImVec2(sb_w + gap_w, 0.f);

        // 3. Country Flag Language Selector in Left Sidebar ("слева где табы")
        int cur_l = GetCurrentLang();
        float card_x = pos.x + 14.f;
        float card_w = sb_w - 28.f;
        float card_h = 76.f;
        float card_y = ImMax(pos.y + 330.f, pos.y + win_sz.y - card_h - 18.f);
        ImVec2 card_p0(card_x, card_y);
        ImVec2 card_p1(card_x + card_w, card_y + card_h);

        ImGui::SetCursorScreenPos(card_p0);
        bool lang_clicked = ImGui::InvisibleButton("##SIDEBAR_FLAG_LANG_BTN", ImVec2(card_w, card_h));
        bool lang_hov = ImGui::IsItemHovered();
        if (lang_clicked) {
            cur_l = (cur_l + 1) % 3;
            if (cur_l == 1) { // Russian
                g_Config.russian_language = true;
                g_Config.arabic_language = false;
                c::lang = true;
            } else if (cur_l == 2) { // Arabic
                g_Config.russian_language = false;
                g_Config.arabic_language = true;
                c::lang = false;
            } else { // English
                g_Config.russian_language = false;
                g_Config.arabic_language = false;
                c::lang = false;
            }
            ConfigManager::SaveConfig(); // Instant auto-save language selection
        }

        // 4. Draw Left Detached SideNav Window (Without user profile footer)
        ImGui::SetCursorPos(ImVec2(0, 0));
        static const char* side_labels_en[] = { "AIMBOT", "VISUALS", "PLAYERS", "CUSTOM", "SETTINGS" };
        static const char* side_labels_ru[] = { "АИМБОТ", "ВИЗУАЛЫ", "ИГРОКИ", "КАСТОМ", "НАСТРОЙКИ" };
        static const char* side_labels_ar[] = { "تصويب", "رؤية", "لاعبين", "تخصيص", "إعدادات" };
        static const char* side_labels_ar_s[5];
        static bool s_side_init = false;
        if (!s_side_init) {
            for (int i = 0; i < 5; i++) side_labels_ar_s[i] = Lang::Shape(side_labels_ar[i]);
            s_side_init = true;
        }
        static const char* side_icons[] = { ICON_SWORD_FILL, ICON_EYE_2_FILL, ICON_GROUP_3_FILL, ICON_TARGET_FILL, ICON_SETTINGS_4_FILL };

        const char** cur_side_labels = (cur_l == 1) ? side_labels_ru : ((cur_l == 2) ? side_labels_ar_s : side_labels_en);
        if (custom::SideNav(cur_side_labels, side_icons, 5, &active_page, ImVec2(sb_w, win_sz.y))) {
            aim_sub = 0;
            vis_sub = 0;
            ply_sub = 0;
            rad_sub = 0;
            msc_sub = 0;
        }

        // 5. Render Country Flag Language Card on top of Left SideNav background
        {
            // Drop shadow
            dl->AddShadowRect(card_p0, card_p1, IM_COL32(0, 0, 0, 170), 16.f, ImVec2(0, 4), ImDrawFlags_RoundCornersAll, 10.f);

            // Dark glass card background
            ImU32 card_bg = lang_hov ? IM_COL32(22, 26, 38, 255) : IM_COL32(14, 16, 26, 250);
            dl->AddRectFilled(card_p0, card_p1, card_bg, 10.f);

            // Glowing border (active accent when hovered)
            ImU32 border_col = lang_hov 
                ? ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.75f))
                : IM_COL32(255, 255, 255, 28);
            dl->AddRect(card_p0, card_p1, border_col, 10.f, 0, lang_hov ? 1.5f : 1.0f);

            // Country name text on top ("а сверху надпись страны")
            static const char* c_names_ru = "РОССИЯ";
            static const char* c_names_en = "UNITED STATES";
            static const char* c_names_ar = nullptr;
            if (!c_names_ar) c_names_ar = Lang::Shape("المملكة العربية السعودية");

            const char* cur_c_name = (cur_l == 1) ? c_names_ru : ((cur_l == 2) ? c_names_ar : c_names_en);

            PushFont(font::inter_bold);
            ImVec2 c_name_sz = CalcTextSize(cur_c_name);
            float c_name_x = card_p0.x + (card_w - c_name_sz.x) * 0.5f;
            dl->AddText(ImVec2(c_name_x, card_p0.y + 7.f), IM_COL32(245, 248, 255, 245), cur_c_name);
            PopFont();

            // Subtle divider line
            dl->AddLine(ImVec2(card_p0.x + 10.f, card_p0.y + 29.f), ImVec2(card_p1.x - 10.f, card_p0.y + 29.f), IM_COL32(255, 255, 255, 18), 1.0f);

            // Flag on left
            float flag_x = card_p0.x + 12.f;
            float flag_y = card_p0.y + 36.f;
            ImVec2 flag_sz(46.f, 30.f);
            DrawCountryFlag(dl, ImVec2(flag_x, flag_y), flag_sz, cur_l);

            // Language Subtitle in middle
            static const char* sub_names_ru = "Русский язык";
            static const char* sub_names_en = "English (US)";
            static const char* sub_names_ar = nullptr;
            if (!sub_names_ar) sub_names_ar = Lang::Shape("اللغة العربية");
            const char* cur_sub_name = (cur_l == 1) ? sub_names_ru : ((cur_l == 2) ? sub_names_ar : sub_names_en);

            PushFont(font::small_font);
            dl->AddText(ImVec2(flag_x + flag_sz.x + 12.f, flag_y + 7.f), IM_COL32(175, 185, 210, 220), cur_sub_name);
            PopFont();

            // Interactive Arrow on right ("и страла" / "и стрелка")
            PushFont(font::inter_bold);
            float arrow_x = card_p1.x - 26.f;
            float arrow_y = flag_y + 6.f;
            ImU32 arr_col = lang_hov ? ImGui::GetColorU32(c::anim::active) : IM_COL32(145, 155, 180, 190);
            const char* cur_arr = (cur_l == 2) ? ICON_ARROW_LEFT_FILL : ICON_ARROW_RIGHT_FILL;
            dl->AddText(ImVec2(arrow_x, arrow_y), arr_col, cur_arr);
            PopFont();
        }

        if (active_page != prev_page) {
            card_anim_c1 = 0.f;
            card_anim_c2 = 0.f;
            prev_page = active_page;
            page_changed = true;
        }

        // 4. Draw Right Main Body Solid Black Window
        dl->AddShadowRect(main_pos, main_pos + ImVec2(main_w, win_sz.y),
            ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, 0.85f)), 38.f, ImVec2(0, 8), ImDrawFlags_RoundCornersAll, 14.f);

        dl->AddRectFilled(main_pos, main_pos + ImVec2(main_w, win_sz.y),
            ImGui::GetColorU32(ImVec4(0.010f, 0.012f, 0.018f, 1.0f)), 14.f, ImDrawFlags_RoundCornersAll);

        dl->AddRect(main_pos, main_pos + ImVec2(main_w, win_sz.y),
            ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.12f)), 14.f, 0, 1.0f);

        // Glowing accent top rim line
        dl->AddLine(main_pos + ImVec2(24.f, 0.5f), main_pos + ImVec2(main_w - 24.f, 0.5f),
            ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.50f)), 1.2f);

        // 5. Right Main Header Bar (Search Bar Removed, Category Title + Controls)
        float header_h = 52.f;
        ImVec2 header_min = main_pos;
        ImVec2 header_max = main_pos + ImVec2(main_w, header_h);

        dl->AddRectFilled(header_min, header_max, ImGui::GetColorU32(ImVec4(0.014f, 0.016f, 0.024f, 1.0f)), 14.f, ImDrawFlags_RoundCornersTop);
        dl->AddLine(ImVec2(header_min.x + 16.f, header_max.y), ImVec2(header_max.x - 16.f, header_max.y), ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.08f)), 1.f);

        // Header Category Title on the left
        static const char* cat_titles_ru[] = { "АИМБОТ И ОРУЖИЕ", "ВИЗУАЛЫ И ВХ", "СПИСОК ИГРОКОВ", "КАСТОМ И ПРИЦЕЛ", "СЕТТИНГИ И СИСТЕМА" };
        static const char* cat_titles_en[] = { "AIMBOT & WEAPONS", "VISUALS & ESP", "PLAYER ROSTER", "CUSTOM STUDIO", "SETTINGS & SYSTEM" };
        static const char* cat_titles_ar[] = { "التصويب والأسلحة", "الرؤية و ESP", "قائمة اللاعبين", "التخصيص والتصويب", "الإعدادات والنظام" };
        static const char* cat_titles_ar_s[5];
        static bool s_cat_init = false;
        if (!s_cat_init) {
            for (int i = 0; i < 5; i++) cat_titles_ar_s[i] = Lang::Shape(cat_titles_ar[i]);
            s_cat_init = true;
        }
        const char* cur_title = (cur_l == 1) ? cat_titles_ru[active_page] : ((cur_l == 2) ? cat_titles_ar_s[active_page] : cat_titles_en[active_page]);
        PushFont(font::inter_bold);
        dl->AddText(main_pos + ImVec2(20.f, (header_h - CalcTextSize(cur_title).y) * 0.5f),
            ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.95f)), cur_title);
        PopFont();

        // Top-Right Close Button in Header Bar (Guaranteed visible and rendered on top of header)
        float c_btn_w = 38.f;
        float c_btn_h = 34.f;
        ImVec2 c_btn_pos = ImVec2(main_pos.x + main_w - c_btn_w - 12.f, main_pos.y + (header_h - c_btn_h) * 0.5f);
        ImGui::SetCursorScreenPos(c_btn_pos);
        if (ImGui::InvisibleButton("##MIRAGE_HEADER_CLOSE_BTN", ImVec2(c_btn_w, c_btn_h))) {
            if (is_open) {
                *is_open = false;
                ConfigManager::SaveConfig();
            }
        }
        bool c_hovered = ImGui::IsItemHovered();
        bool c_active = ImGui::IsItemActive();

        ImU32 c_bg = c_active ? IM_COL32(239, 68, 68, 140) : (c_hovered ? IM_COL32(239, 68, 68, 60) : IM_COL32(255, 255, 255, 12));
        ImU32 c_border = c_hovered ? IM_COL32(239, 68, 68, 180) : IM_COL32(255, 255, 255, 24);
        dl->AddRectFilled(c_btn_pos, c_btn_pos + ImVec2(c_btn_w, c_btn_h), c_bg, 8.f);
        dl->AddRect(c_btn_pos, c_btn_pos + ImVec2(c_btn_w, c_btn_h), c_border, 8.f, 0, 1.f);

        PushFont(font::inter_bold);
        ImVec2 c_icon_sz = CalcTextSize(ICON_CLOSE_FILL);
        ImVec2 c_icon_pos = c_btn_pos + (ImVec2(c_btn_w, c_btn_h) - c_icon_sz) * 0.5f;
        dl->AddText(c_icon_pos, c_hovered ? IM_COL32(255, 130, 130, 255) : IM_COL32(220, 225, 235, 230), ICON_CLOSE_FILL);
        PopFont();

        // 6. Dual-Column Content Dashboard Canvas (+25% Expanded & Safe Insets)
        float content_x = sb_w + gap_w + 14.f;
        float content_y = header_h + 10.f;
        float content_w = main_w - 28.f;
        float content_h = win_sz.y - content_y - 14.f;
        float col_gap = 14.f;
        float col_w = (content_w - col_gap - 6.f) * 0.5f;

        ImGui::SetCursorPos(ImVec2(content_x, content_y));
        ImGui::BeginChild("MIRAGE_DASHBOARD_CANVAS", ImVec2(content_w, content_h), false, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground);
        {
            card_anim_c1 = ImLerp(card_anim_c1, 1.f, dt * 8.0f);
            card_anim_c2 = ImLerp(card_anim_c2, 1.f, dt * 6.0f);

            float t1 = 1.0f - card_anim_c1;
            float t2 = 1.0f - card_anim_c2;
            float ease_c1 = 1.0f - (t1 * t1 * t1);
            float ease_c2 = 1.0f - (t2 * t2 * t2);

            static const char* aim_subs_en[] = { "AIMBOT CORE", "RCS" };
            static const char* aim_subs_ru[] = { "ОСНОВНОЙ АИМ", "РКС" };
            static const char* aim_subs_ar[] = { "التصويب الأساسي", "مانع الارتداد" };
            static const char* aim_subs_ar_s[2];
            static bool s_aim_sub_init = false;
            if (!s_aim_sub_init) {
                aim_subs_ar_s[0] = Lang::Shape(aim_subs_ar[0]);
                aim_subs_ar_s[1] = Lang::Shape(aim_subs_ar[1]);
                s_aim_sub_init = true;
            }

            static const char* vis_subs_en[] = { "WALLHACK ESP", "CHAMS & WORLD" };
            static const char* vis_subs_ru[] = { "НАСТРОЙКИ ВХ", "ПРЕДМЕТЫ И МИР" };
            static const char* vis_subs_ar[] = { "إعدادات ESP", "العناصر والعالم" };
            static const char* vis_subs_ar_s[2];
            static bool s_vis_sub_init = false;
            if (!s_vis_sub_init) {
                vis_subs_ar_s[0] = Lang::Shape(vis_subs_ar[0]);
                vis_subs_ar_s[1] = Lang::Shape(vis_subs_ar[1]);
                s_vis_sub_init = true;
            }

            static const char* ply_subs_en[] = { "ROSTER LIST", "TARGET FILTERS" };
            static const char* ply_subs_ru[] = { "СПИСОК ИГРОКОВ", "ФИЛЬТРЫ ЦЕЛЕЙ" };
            static const char* ply_subs_ar[] = { "قائمة اللاعبين", "تصفية الأهداف" };
            static const char* ply_subs_ar_s[2];
            static bool s_ply_sub_init = false;
            if (!s_ply_sub_init) {
                ply_subs_ar_s[0] = Lang::Shape(ply_subs_ar[0]);
                ply_subs_ar_s[1] = Lang::Shape(ply_subs_ar[1]);
                s_ply_sub_init = true;
            }

            static const char* msc_subs_en[] = { "SYSTEM", "CONFIGURATION" };
            static const char* msc_subs_ru[] = { "СИСТЕМА", "КОНФИГУРАЦИЯ" };
            static const char* msc_subs_ar[] = { "النظام", "الإعدادات" };
            static const char* msc_subs_ar_s[2];
            static bool s_msc_sub_init = false;
            if (!s_msc_sub_init) {
                msc_subs_ar_s[0] = Lang::Shape(msc_subs_ar[0]);
                msc_subs_ar_s[1] = Lang::Shape(msc_subs_ar[1]);
                s_msc_sub_init = true;
            }

            const char** cur_aim_subs = (cur_l == 1) ? aim_subs_ru : ((cur_l == 2) ? aim_subs_ar_s : aim_subs_en);
            const char** cur_vis_subs = (cur_l == 1) ? vis_subs_ru : ((cur_l == 2) ? vis_subs_ar_s : vis_subs_en);
            const char** cur_msc_subs = (cur_l == 1) ? msc_subs_ru : ((cur_l == 2) ? msc_subs_ar_s : msc_subs_en);

            ImGui::SetCursorPos(ImVec2(2.f, 0));
            if (active_page == 0) custom::SubTabBar(cur_aim_subs, 2, &aim_sub);
            else if (active_page == 1) custom::SubTabBar(cur_vis_subs, 2, &vis_sub);
            else if (active_page == 4) custom::SubTabBar(cur_msc_subs, 2, &msc_sub);

            float sub_offset = (active_page == 2 || active_page == 3) ? 0.f : 38.f;
            float card_h = content_h - sub_offset;

            // Render active tabs
            RenderMirageTabs(active_page, col_w, card_h, sub_offset, ease_c1, ease_c2, col_gap);

            // Auto-Save Engine (Default is always AUTO)
            static float auto_save_clock = 0.f;
            auto_save_clock += dt;
            if (ConfigManager::g_AutoSaveMode && auto_save_clock > 3.0f) {
                auto_save_clock = 0.f;
                ConfigManager::SaveNamedConfig(ConfigManager::g_ActiveConfigName);
            }
        }
        ImGui::EndChild();
    }
    ImGui::End();

    if (s_show_unload_modal) {
        ImVec2 dsz = ImGui::GetIO().DisplaySize;
        if (dsz.x < 100.f || dsz.y < 100.f) dsz = ImVec2((float)screen_w, (float)screen_h);

        // 1. Semi-transparent backdrop to dim background and capture clicks
        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(dsz);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.0f, 0.0f, 0.0f, 0.78f));
        ImGui::Begin("##UnloadBackdrop", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing);
        ImGui::BringWindowToDisplayFront(ImGui::GetCurrentWindow());
        ImGui::End();
        ImGui::PopStyleColor();
        ImGui::PopStyleVar();

        // 2. Centered Modal Dialog
        float m_w = ImMin(540.f, dsz.x * 0.94f);
        float m_h = 280.f;
        ImVec2 m_pos((dsz.x - m_w) * 0.5f, (dsz.y - m_h) * 0.5f);

        ImGui::SetNextWindowPos(m_pos, ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(m_w, m_h), ImGuiCond_Always);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 14.f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(24.f, 20.f));
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.08f, 0.09f, 0.13f, 0.98f));
        ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.92f, 0.22f, 0.22f, 0.95f)); // Glowing red border

        if (ImGui::Begin("##UnloadConfirmDialog", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings)) {
            ImGui::BringWindowToDisplayFront(ImGui::GetCurrentWindow());
            ImDrawList* wdl = ImGui::GetWindowDrawList();
            ImVec2 win_pos = ImGui::GetWindowPos();

            // Geometric Red Warning Triangle centered at top
            float tri_cx = win_pos.x + m_w * 0.5f;
            float tri_top_y = win_pos.y + 18.f;
            ImVec2 tri_top(tri_cx, tri_top_y);
            ImVec2 tri_left(tri_cx - 22.f, tri_top_y + 36.f);
            ImVec2 tri_right(tri_cx + 22.f, tri_top_y + 36.f);

            wdl->AddTriangleFilled(tri_top, tri_left, tri_right, IM_COL32(230, 45, 45, 245));
            wdl->AddTriangle(tri_top, tri_left, tri_right, IM_COL32(255, 100, 100, 255), 2.0f);

            // Exclamation mark inside triangle
            wdl->AddRectFilled(ImVec2(tri_cx - 2.0f, tri_top_y + 11.f), ImVec2(tri_cx + 2.0f, tri_top_y + 23.f), IM_COL32_WHITE, 1.0f);
            wdl->AddCircleFilled(ImVec2(tri_cx, tri_top_y + 28.5f), 2.2f, IM_COL32_WHITE, 12);

            // Spacing under triangle
            ImGui::Dummy(ImVec2(0, 42.f));

            // Modal Title
            PushFont(font::inter_bold);
            const char* title_text = LText("UNLOAD MODIFICATION", "ПОДТВЕРЖДЕНИЕ ВЫГРУЗКИ", "تأكيد تفريغ التعديل");
            ImVec2 title_sz = CalcTextSize(title_text);
            ImGui::SetCursorPosX((m_w - title_sz.x) * 0.5f);
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "%s", title_text);
            PopFont();

            ImGui::Spacing();

            // Warning Question
            PushFont(font::small_font);
            const char* q_text = LText("Are you sure you want to unload the cheat from memory?",
                                       "Вы точно уверены, что хотите выгрузить чит из памяти?",
                                       "هل أنت متأكد من رغبتك في تفريغ التعديل من الذاكرة؟");
            ImVec2 q_sz = CalcTextSize(q_text);
            ImGui::SetCursorPosX(ImMax(12.f, (m_w - q_sz.x) * 0.5f));
            ImGui::PushTextWrapPos(m_w - 24.f);
            ImGui::TextColored(ImVec4(0.85f, 0.88f, 0.95f, 0.95f), "%s", q_text);
            ImGui::PopTextWrapPos();

            ImGui::Spacing();
            const char* sub_text = LText("All overlays, aimbot, and hooks will be stopped immediately.",
                                         "Все функции ЕСП, аимбот и хуки будут немедленно остановлены.",
                                         "سيتم إيقاف جميع التراكبات والإيمبوت فوراً.");
            ImVec2 sub_sz = CalcTextSize(sub_text);
            ImGui::SetCursorPosX(ImMax(12.f, (m_w - sub_sz.x) * 0.5f));
            ImGui::PushTextWrapPos(m_w - 24.f);
            ImGui::TextColored(ImVec4(0.60f, 0.65f, 0.78f, 0.85f), "%s", sub_text);
            ImGui::PopTextWrapPos();
            PopFont();

            // Buttons at bottom: separate [ ДА ] (Yes) and [ НЕТ ] (No)
            ImGui::SetCursorPosY(m_h - 58.f);
            float btn_w = (m_w - 48.f - 24.f) * 0.5f;
            ImGui::SetCursorPosX(24.f);

            // YES / ДА button (Red)
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.85f, 0.20f, 0.20f, 0.90f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.95f, 0.28f, 0.28f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.70f, 0.15f, 0.15f, 1.0f));
            if (custom::Button(LText(ICON_CHECK_FILL " YES", ICON_CHECK_FILL " ДА", ICON_CHECK_FILL " نعم"), ImVec2(btn_w, 38))) {
                s_show_unload_modal = false;
                RequestUnload();
            }
            ImGui::PopStyleColor(3);

            ImGui::SameLine(0, 24.f);

            // NO / НЕТ button (Neutral dark)
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.25f, 0.28f, 0.36f, 0.90f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.35f, 0.38f, 0.48f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.18f, 0.20f, 0.28f, 1.0f));
            if (custom::Button(LText(ICON_CLOSE_FILL " NO", ICON_CLOSE_FILL " НЕТ", ICON_CLOSE_FILL " لا"), ImVec2(btn_w, 38))) {
                s_show_unload_modal = false;
            }
            ImGui::PopStyleColor(3);
        }
        ImGui::End();
        ImGui::PopStyleColor(2);
        ImGui::PopStyleVar(3);
    }
}

} // namespace mirage
