#pragma once
#include <string>

// UI language: 0 = English, 1 = Russian, 2 = Arabic (Config: russian_language / arabic_language).
namespace Lang {
    int Current();
    // Display-ready text (Arabic is shaped and reordered right-to-left).
    const char* T(const char* en, const char* ru);
    // Logical (unshaped) text, for composing strings that are passed to Display().
    const char* Raw(const char* en, const char* ru);
    // Shapes a composed logical string when the language is Arabic; otherwise returns it unchanged.
    std::string Display(const std::string& logical);
    // Shapes an Arabic logical UTF-8 string and caches it for Dear ImGui rendering.
    const char* Shape(const char* ar_text);
}
