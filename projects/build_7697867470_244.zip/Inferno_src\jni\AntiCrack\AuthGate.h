#pragma once
// ──────────────────────────────────────────────────────────────────────────────
//  Authorization state — the gate that decides whether the cheat is unlocked.
//
//  The old gate was a single bool (g_Config.is_logged_in). One memory write or
//  one patched branch and the whole product was open. This replaces it with a
//  sealed, salted, self-checked record:
//
//    * There is no "is_logged_in = true" to locate and flip.
//    * The authorization value is derived from the RSA-recovered hash of the
//      server's signed payload — it cannot be reconstructed without a genuine
//      signature (which needs the server's private key).
//    * It is stored twice under a per-process random salt and cross-checked, so
//      a blind memory write to one copy desyncs and reads as unauthorized.
//    * If a tracer / Frida is live at seal time, the record is poisoned.
//
//  NOTE (honest scope): the final Authorized() still returns a bool a caller
//  branches on. Making that branch itself unpatchable is the job of Э3 (OLLVM on
//  these functions) + Э5.1 (code integrity). The fully data-driven kill — auth
//  material decrypting real offsets so a bypass yields a dead cheat, not an open
//  one — needs the rotating server secret from Э4. This header is built so that
//  step drops in at Seal()/SessionKey() without touching call sites.
// ──────────────────────────────────────────────────────────────────────────────
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <atomic>
#include <ctime>
#include <cstdio>
#include <unistd.h>

namespace AntiCrack {

// ── Native base64 decode (no android.util.Base64 / JNI in the trust path) ──────
inline bool Base64Decode(const char* in, size_t inlen, uint8_t* out, size_t* outlen) {
    auto val = [](char c) -> int {
        if (c >= 'A' && c <= 'Z') return c - 'A';
        if (c >= 'a' && c <= 'z') return c - 'a' + 26;
        if (c >= '0' && c <= '9') return c - '0' + 52;
        if (c == '+' || c == '-') return 62;
        if (c == '/' || c == '_') return 63;
        return -1;
    };
    size_t o = 0; int acc = 0, bits = 0;
    for (size_t i = 0; i < inlen; ++i) {
        char c = in[i];
        // skip padding, whitespace, and JSON backslash-escapes (PHP json_encode
        // emits "\/" for '/', so the raw sig string contains stray backslashes).
        if (c == '=' || c == '\n' || c == '\r' || c == ' ' || c == '\\') continue;
        int v = val(c);
        if (v < 0) return false;
        acc = (acc << 6) | v; bits += 6;
        if (bits >= 8) { bits -= 8; out[o++] = (uint8_t)((acc >> bits) & 0xFF); }
    }
    *outlen = o;
    return true;
}

// ── mixing ─────────────────────────────────────────────────────────────────────
inline uint64_t SplitMix64(uint64_t x) {
    x += 0x9E3779B97F4A7C15ULL;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL;
    return x ^ (x >> 31);
}

// Fold a 32-byte hash into a 64-bit cookie, keyed by salt.
inline uint64_t FoldHash(const uint8_t h[32], uint64_t salt) {
    uint64_t acc = salt ^ 0xA5A5F00DD00DBEEFULL;
    for (int i = 0; i < 4; ++i) {
        uint64_t limb = 0;
        for (int b = 0; b < 8; ++b) limb = (limb << 8) | h[i * 8 + b];
        acc = SplitMix64(acc ^ limb);
    }
    // never let a genuine cookie collapse to 0 (0 == "never sealed")
    return acc ? acc : 0x1ULL;
}

class AuthGate {
public:
    static AuthGate& I() { static AuthGate g; return g; }

    // Seal the session using the RSA-recovered hash. `secBad` = a tracer/Frida was
    // detected; when true we poison the record so authorization can never hold.
        void Seal(const uint8_t recovered[32], bool secBad) {
        EnsureSalt();
        uint64_t c = FoldHash(recovered, m_salt.load());
        if (secBad) c ^= 0xDEADDEAD13371337ULL;   // poison: Authorized() will reject
        uint64_t salt = m_salt.load();
        m_a.store(c ^ salt);
        m_b.store(c ^ ~salt);
        m_chk.store(SplitMix64(c) ^ salt);
        m_sealed.store(true);
    }

    void Clear() {
        m_a.store(0); m_b.store(0); m_chk.store(0); m_sealed.store(false);
    }

    // Recomputed each call from two salted copies; no stored boolean truth.
        bool Authorized() const {
        if (!m_sealed.load()) return false;
        uint64_t salt = m_salt.load();
        uint64_t cA = m_a.load() ^ salt;
        uint64_t cB = m_b.load() ^ ~salt;
        uint64_t chk = m_chk.load() ^ salt;
        // all three must agree on the same non-zero cookie
        uint64_t diff = (cA ^ cB) | (chk ^ SplitMix64(cA)) | ((cA == 0) ? 1ULL : 0ULL);
        return diff == 0;
    }

    // Derived session key for future data-driven coupling (Э4). Garbage unless sealed.
    uint64_t SessionKey() const {
        uint64_t salt = m_salt.load();
        return SplitMix64((m_a.load() ^ salt) ^ 0x51ED270FULL);
    }

private:
    AuthGate() : m_a(0), m_b(0), m_chk(0), m_salt(0), m_sealed(false) {}

    void EnsureSalt() {
        if (m_salt.load() != 0) return;
        uint64_t s = 0;
        FILE* f = fopen("/dev/urandom", "rb");
        if (f) { if (fread(&s, 1, sizeof(s), f) != sizeof(s)) s = 0; fclose(f); }
        if (s == 0) {
            // ASLR address + time + pid as fallback entropy
            s = (uint64_t)(uintptr_t)this
              ^ ((uint64_t)time(nullptr) << 20)
              ^ ((uint64_t)getpid() << 3)
              ^ 0x243F6A8885A308D3ULL;
            s = SplitMix64(s);
        }
        if (s == 0) s = 0x9E3779B97F4A7C15ULL;
        m_salt.store(s);
    }

    std::atomic<uint64_t> m_a, m_b, m_chk, m_salt;
    std::atomic<bool>     m_sealed;
};

} // namespace AntiCrack
