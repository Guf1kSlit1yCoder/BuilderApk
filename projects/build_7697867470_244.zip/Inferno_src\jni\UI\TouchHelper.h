#pragma once
#include <android/input.h>

namespace TouchHelper {
    bool HandleInputEvent(const AInputEvent* event);
    void UpdateTouchState(float x, float y, bool isDown);
    // Called only by the render thread, before NewFrame / after Render respectively.
    void ApplyPendingInput();
    void PublishCaptureState();
    // Scale applied to raw AMotionEvent coordinates before passing to ImGui.
    // Call each frame from the render thread with (viewport_w / egl_w, viewport_h / egl_h).
    void SetDisplayScale(float sx, float sy);
    // True if any finger is currently held within radius r of (cx, cy), in display
    // (viewport) pixel space. Used by the aimbot to fire only while the fire button
    // (a user-placed zone) is pressed. Tracks ALL touches, UI-owned or not.
    bool IsPointerDownInCircle(float cx, float cy, float r);
}
