LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := arena_esp
LOCAL_SHORT_COMMANDS := true

LOCAL_C_INCLUDES := $(LOCAL_PATH) \
                    $(LOCAL_PATH)/Memory \
                    $(LOCAL_PATH)/Core \
                    $(LOCAL_PATH)/UI \
                    $(LOCAL_PATH)/ImGui \
                    $(LOCAL_PATH)/SDK

LOCAL_SRC_FILES := Main.cpp \
                   Config.cpp \
                   Memory/Tools.cpp \
                   Memory/Hooks.cpp \
                   Core/UE4Helper.cpp \
                   Core/ActorPipeline.cpp \
                   Core/ESP.cpp \
                   Core/Aimbot.cpp \
                   Core/MemoryHacks.cpp \
                   Core/VisCheck.cpp \
                   Core/CrashLog.cpp \
                   UI/VandalAuth.cpp \
                   UI/vandal_widgets.cpp \
                   UI/Menu.cpp \
                   UI/TouchHelper.cpp \
                   UI/liquid_glass_gl.cpp \
                   UI/bg_texture.cpp \
                   UI/mirage_logo.cpp \
                   ImGui/imgui.cpp \
                   ImGui/imgui_draw.cpp \
                   ImGui/imgui_tables.cpp \
                   ImGui/imgui_widgets.cpp \
                   ImGui/imgui_impl_opengl3.cpp \
                   SDK/Basic.cpp \
                   SDK/SDK.cpp

LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv3 -lz -Wl,--gc-sections

LOCAL_CPPFLAGS := -std=c++17 -O2 -ffunction-sections -fdata-sections -fexceptions -frtti -Wall -Wno-error -fvisibility=hidden -w
LOCAL_ARM_MODE := arm

include $(BUILD_SHARED_LIBRARY)
