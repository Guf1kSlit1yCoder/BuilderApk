#pragma once
#include "UE4Helper.h"
#include "Config.h"
#include "ImGui/imgui.h"

namespace Aimbot {
    extern SDK::ASGCharacter* g_TargetPlayer;
    extern SDK::FVector g_LastTargetLoc;
    extern int g_LastTargetBone;

    void Update(int screenWidth, int screenHeight);
    bool IsTriggerActive(int screenWidth, int screenHeight);
    SDK::ASGCharacter* FindBestTarget(int screenWidth, int screenHeight);
    SDK::FVector GetTargetAimLocation(SDK::ASGCharacter* target);
    SDK::FRotator CalculateAimRotation(const SDK::FVector& start, const SDK::FVector& target);
    void ApplyAim(const SDK::FRotator& targetRot);
    void DrawOverlay(ImDrawList* drawList, int screenWidth, int screenHeight);
}
