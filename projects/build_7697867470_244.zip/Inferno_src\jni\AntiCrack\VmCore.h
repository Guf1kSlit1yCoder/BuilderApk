#pragma once
// ──────────────────────────────────────────────────────────────────────────────
//  LicenseVM — stack-based bytecode interpreter with a HIDDEN dispatcher.
//
//  The decision "what makes a login valid" lives in bytecode (license_bytecode.h),
//  not in readable C++ branches. On top of that, the dispatcher is NOT a switch:
//  each stored opcode byte is masked by its position, demasked at runtime, and the
//  handler is reached through a function-pointer table — in a disassembler the
//  interpreter loop is just an indirect `BLR`, not a jump table, so the VM's
//  architecture does not fall out for free.
//
//    stored_byte = ((opcode + (pc % 3)) & 0xFF) ^ 0x5A      (emitted by vm_compiler.py)
//    opcode      = ((stored ^ 0x5A) - (pc % 3)) & 0xFF      (recovered here)
//
//  pc is the position of the opcode byte; operands follow unmasked. The compiler
//  advances position identically, so the mask sequence matches.
// ──────────────────────────────────────────────────────────────────────────────
#include <cstdint>
#include <cstddef>

namespace AntiCrack {

namespace vmop {
    enum : uint8_t {
        PUSH8  = 0x01, PUSH64 = 0x02, PUSHIN = 0x03,
        ADD = 0x10, SUB = 0x11, MUL = 0x12, XOR = 0x13, AND = 0x14, OR = 0x15, NOT = 0x16,
        EQ = 0x20, NE = 0x21,
        DUP = 0x30, DROP = 0x31, SWAP = 0x32,
        STORE = 0x40, LOAD = 0x41,
        MIX = 0x60, RET = 0xFF
    };
}

class VmCore {
public:
    // State (public so the free-standing handlers can manipulate it).
    const uint8_t* code = nullptr;
    size_t size = 0;
    size_t pc = 0;
    uint64_t st[64];
    int sp = 0;
    uint64_t reg[16];
    const uint64_t* inputs = nullptr;
    size_t numInputs = 0;
    bool done = false;
    uint64_t result = 0;

    void push(uint64_t v) { if (sp < 64) st[sp++] = v; }
    uint64_t pop()        { return sp > 0 ? st[--sp] : 0; }
    void fault()          { result = 0; done = true; }

    uint64_t Execute(const uint8_t* bc, size_t n, const uint64_t* in, size_t nin) {
        code = bc; size = n; inputs = in; numInputs = nin;
        pc = 0; sp = 0; done = false; result = 0;
        for (int i = 0; i < 16; ++i) reg[i] = 0;
        const OpcodeHandler* tbl = Table();
        int guard = 0;
        while (pc < size && !done) {
            if (++guard > 100000) { result = 0; break; }
            const uint8_t stored = code[pc];
            const uint8_t op = (uint8_t)(((stored ^ 0x5A) - (pc % 3)) & 0xFF);
            ++pc;                                   // consume the opcode byte
            tbl[op](this);                          // indirect call — no switch
        }
        return result;
    }

private:
    typedef void (*OpcodeHandler)(VmCore*);

    // ── handlers (logic moved out of the old switch cases) ──────────────────────
    static void h_invalid(VmCore* v) { v->fault(); }
    static void h_push8 (VmCore* v) { if (v->pc < v->size) v->push(v->code[v->pc++]); else v->fault(); }
    static void h_push64(VmCore* v) { if (v->pc + 8 > v->size) { v->fault(); return; }
                                      uint64_t x = 0; for (int i = 0; i < 8; ++i) x |= (uint64_t)v->code[v->pc++] << (i * 8); v->push(x); }
    static void h_pushin(VmCore* v) { if (v->pc >= v->size) { v->fault(); return; }
                                      uint8_t idx = v->code[v->pc++]; v->push(idx < v->numInputs ? v->inputs[idx] : 0); }
    static void h_add(VmCore* v){ uint64_t b=v->pop(),a=v->pop(); v->push(a+b); }
    static void h_sub(VmCore* v){ uint64_t b=v->pop(),a=v->pop(); v->push(a-b); }
    static void h_mul(VmCore* v){ uint64_t b=v->pop(),a=v->pop(); v->push(a*b); }
    static void h_xor(VmCore* v){ uint64_t b=v->pop(),a=v->pop(); v->push(a^b); }
    static void h_and(VmCore* v){ uint64_t b=v->pop(),a=v->pop(); v->push(a&b); }
    static void h_or (VmCore* v){ uint64_t b=v->pop(),a=v->pop(); v->push(a|b); }
    static void h_not(VmCore* v){ v->push(~v->pop()); }
    static void h_eq (VmCore* v){ uint64_t b=v->pop(),a=v->pop(); v->push(a==b?1:0); }
    static void h_ne (VmCore* v){ uint64_t b=v->pop(),a=v->pop(); v->push(a!=b?1:0); }
    static void h_dup(VmCore* v){ uint64_t a=v->pop(); v->push(a); v->push(a); }
    static void h_drop(VmCore* v){ v->pop(); }
    static void h_swap(VmCore* v){ uint64_t b=v->pop(),a=v->pop(); v->push(b); v->push(a); }
    static void h_store(VmCore* v){ if (v->pc>=v->size){v->fault();return;} uint8_t r=v->code[v->pc++]; if(r<16) v->reg[r]=v->pop(); }
    static void h_load (VmCore* v){ if (v->pc>=v->size){v->fault();return;} uint8_t r=v->code[v->pc++]; v->push(r<16?v->reg[r]:0); }
    static void h_mix(VmCore* v){ uint64_t x=v->pop();
        x += 0x9E3779B97F4A7C15ULL;
        x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL;
        x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL;
        v->push(x ^ (x >> 31)); }
    static void h_ret(VmCore* v){ v->result = v->pop(); v->done = true; }

    // 256-entry table (sparse); built once. Unknown opcodes -> h_invalid (reject).
    static const OpcodeHandler* Table() {
        static OpcodeHandler tbl[256];
        static bool built = false;
        if (!built) {
            for (int i = 0; i < 256; ++i) tbl[i] = &VmCore::h_invalid;
            tbl[vmop::PUSH8]=&h_push8; tbl[vmop::PUSH64]=&h_push64; tbl[vmop::PUSHIN]=&h_pushin;
            tbl[vmop::ADD]=&h_add; tbl[vmop::SUB]=&h_sub; tbl[vmop::MUL]=&h_mul; tbl[vmop::XOR]=&h_xor;
            tbl[vmop::AND]=&h_and; tbl[vmop::OR]=&h_or; tbl[vmop::NOT]=&h_not;
            tbl[vmop::EQ]=&h_eq; tbl[vmop::NE]=&h_ne;
            tbl[vmop::DUP]=&h_dup; tbl[vmop::DROP]=&h_drop; tbl[vmop::SWAP]=&h_swap;
            tbl[vmop::STORE]=&h_store; tbl[vmop::LOAD]=&h_load;
            tbl[vmop::MIX]=&h_mix; tbl[vmop::RET]=&h_ret;
            built = true;
        }
        return tbl;
    }
};

// Back-compat shim: existing callers use LicenseVM::Run(code,len,inputs,n).
class LicenseVM {
public:
    static uint64_t Run(const uint8_t* code, size_t len,
                        const uint64_t* inputs, size_t numInputs) {
        VmCore vm;
        return vm.Execute(code, len, inputs, numInputs);
    }
};

} // namespace AntiCrack
