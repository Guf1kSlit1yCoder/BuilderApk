#include "TouchHelper.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_internal.h"
#include <atomic>
#include <mutex>
#include <cmath>

namespace TouchHelper {
    namespace {
        struct TouchState {
            float x = 0.0f, y = 0.0f;
            bool down = false;
        };
        // Bounded queue: coalesce motion, retain button edges, never allocate
        // or access ImGui from the Android input thread.
        constexpr size_t Capacity = 64;
        TouchState pending[Capacity];
        size_t pendingCount = 0;
        int32_t primaryPointer = -1;
        std::mutex inputMutex;
        struct CaptureRect { float left, top, right, bottom; };
        constexpr size_t MaxCaptureRects = 16;
        CaptureRect captureRects[MaxCaptureRects];
        size_t captureRectCount = 0;
        bool gestureOwned = false;
        // Scale from raw AMotionEvent pixel space to ImGui display space.
        // Updated each frame by Main.cpp based on GL viewport vs EGL surface size.
        float s_ScaleX = 1.0f, s_ScaleY = 1.0f;

        // All currently-held fingers (display space), for fire-zone detection.
        struct GamePtr { int32_t id = -1; float x = 0.0f, y = 0.0f; };
        constexpr size_t MaxPtrs = 12;
        GamePtr g_ptrs[MaxPtrs];

        void PtrUpsert(int32_t id, float x, float y) {
            int freeSlot = -1;
            for (size_t i = 0; i < MaxPtrs; ++i) {
                if (g_ptrs[i].id == id) { g_ptrs[i].x = x; g_ptrs[i].y = y; return; }
                if (freeSlot < 0 && g_ptrs[i].id < 0) freeSlot = (int)i;
            }
            if (freeSlot >= 0) g_ptrs[freeSlot] = {id, x, y};
        }
        void PtrRemove(int32_t id) {
            for (size_t i = 0; i < MaxPtrs; ++i) if (g_ptrs[i].id == id) g_ptrs[i].id = -1;
        }
        void PtrClear() { for (size_t i = 0; i < MaxPtrs; ++i) g_ptrs[i].id = -1; }

        bool HitUI(float x, float y) {
            for (size_t i = 0; i < captureRectCount; ++i) {
                const auto& r = captureRects[i];
                if (x >= r.left && x < r.right && y >= r.top && y < r.bottom) return true;
            }
            return false;
        }

        void QueueTouch(float x, float y, bool down) {
            if (!std::isfinite(x) || !std::isfinite(y)) return;
            if (pendingCount && pending[pendingCount - 1].down == down) {
                pending[pendingCount - 1] = {x, y, down};
            } else if (pendingCount < Capacity) {
                pending[pendingCount++] = {x, y, down};
            } else {
                // Preserve the latest state even after a long paused frame.
                pending[Capacity - 1] = {x, y, down};
            }
        }
    }

    bool HandleInputEvent(const AInputEvent* event) {
        if (!event || AInputEvent_getType(event) != AINPUT_EVENT_TYPE_MOTION) return false;
        const int32_t action = AMotionEvent_getAction(event);
        const int32_t masked = action & AMOTION_EVENT_ACTION_MASK;
        const size_t count = AMotionEvent_getPointerCount(event);
        const size_t changed = (action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
        std::lock_guard<std::mutex> lock(inputMutex);

        // Track every finger (UI-owned or gameplay) so the aimbot can tell whether
        // the fire button is currently held. Independent of UI gesture ownership.
        if (masked == AMOTION_EVENT_ACTION_CANCEL) {
            PtrClear();
        } else {
            for (size_t i = 0; i < count; ++i) {
                PtrUpsert(AMotionEvent_getPointerId(event, i),
                          AMotionEvent_getX(event, i) * s_ScaleX,
                          AMotionEvent_getY(event, i) * s_ScaleY);
            }
            if ((masked == AMOTION_EVENT_ACTION_UP || masked == AMOTION_EVENT_ACTION_POINTER_UP) && changed < count) {
                PtrRemove(AMotionEvent_getPointerId(event, changed));
            }
        }

        if (masked == AMOTION_EVENT_ACTION_DOWN && count && changed < count) {
            const float x = AMotionEvent_getX(event, changed) * s_ScaleX;
            const float y = AMotionEvent_getY(event, changed) * s_ScaleY;
            // Latch ownership on DOWN, not WantCaptureMouse from the previous
            // frame. A game gesture must receive its UP even if it crosses UI.
            gestureOwned = HitUI(x, y);
            primaryPointer = gestureOwned ? AMotionEvent_getPointerId(event, changed) : -1;
        }
        const bool consumed = gestureOwned;
        if (masked == AMOTION_EVENT_ACTION_CANCEL) {
            if (gestureOwned) QueueTouch(0.0f, 0.0f, false);
            primaryPointer = -1;
            gestureOwned = false;
        } else if (gestureOwned && count && changed < count) {
            for (size_t i = 0; i < count; ++i) {
                if (AMotionEvent_getPointerId(event, i) != primaryPointer) continue;
                const bool released = masked == AMOTION_EVENT_ACTION_UP ||
                    (masked == AMOTION_EVENT_ACTION_POINTER_UP && changed == i);
                QueueTouch(AMotionEvent_getX(event, i) * s_ScaleX,
                           AMotionEvent_getY(event, i) * s_ScaleY, !released);
                if (released) primaryPointer = -1;
                break;
            }
            if (masked == AMOTION_EVENT_ACTION_UP) gestureOwned = false;
        }
        // Additional pointers in a UI-owned gesture stay consumed until final UP.
        // A gesture that began in gameplay is never partially stolen from it.
        return consumed;
    }

    void UpdateTouchState(float x, float y, bool isDown) {
        std::lock_guard<std::mutex> lock(inputMutex);
        QueueTouch(x, y, isDown);
    }

    void ApplyPendingInput() {
        if (!ImGui::GetCurrentContext()) return;
        TouchState batch[Capacity];
        size_t count;
        {
            std::lock_guard<std::mutex> lock(inputMutex);
            count = pendingCount;
            for (size_t i = 0; i < count; ++i) batch[i] = pending[i];
            pendingCount = 0;
        }
        auto& io = ImGui::GetIO();
        for (size_t i = 0; i < count; ++i) {
            io.AddMousePosEvent(batch[i].x, batch[i].y);
            io.AddMouseButtonEvent(0, batch[i].down);
        }
    }

    void SetDisplayScale(float sx, float sy) {
        std::lock_guard<std::mutex> lock(inputMutex);
        s_ScaleX = (sx > 0.05f && sx <= 4.0f) ? sx : 1.0f;
        s_ScaleY = (sy > 0.05f && sy <= 4.0f) ? sy : 1.0f;
    }

    bool IsPointerDownInCircle(float cx, float cy, float r) {
        if (r <= 0.0f) return false;
        const float r2 = r * r;
        std::lock_guard<std::mutex> lock(inputMutex);
        for (size_t i = 0; i < MaxPtrs; ++i) {
            if (g_ptrs[i].id < 0) continue;
            const float dx = g_ptrs[i].x - cx, dy = g_ptrs[i].y - cy;
            if (dx * dx + dy * dy <= r2) return true;
        }
        return false;
    }

    void PublishCaptureState() {
        CaptureRect rects[MaxCaptureRects];
        size_t count = 0;
        if (auto context = ImGui::GetCurrentContext()) {
            for (auto window : context->Windows) {
                if (!window->Active || window->Hidden ||
                    (window->Flags & ImGuiWindowFlags_NoMouseInputs)) continue;
                if (count == MaxCaptureRects) break;
                rects[count++] = {window->Pos.x, window->Pos.y,
                                 window->Pos.x + window->Size.x, window->Pos.y + window->Size.y};
            }
        }
        std::lock_guard<std::mutex> lock(inputMutex);
        captureRectCount = count;
        for (size_t i = 0; i < count; ++i) captureRects[i] = rects[i];
    }
}
