#pragma once
// ──────────────────────────────────────────────────────────────────────────────
//  Syscalls.h — direct ARM64 kernel syscalls (svc #0), bypassing libc.
//
//  Crackers hook libc (openat/read/close/mprotect) via PLT/GOT patching, inline
//  hooks or a shimmed library to feed the anti-tamper code fake /proc data or to
//  silently drop our mprotect. Issuing the trap instruction ourselves means there
//  is no libc symbol in the path to intercept — the only way to tamper is to hook
//  the kernel entry or single-step, which is far louder.
//
//  Used by AntiDebug.h and Integrity.h. On non-arm64 targets (host syntax checks)
//  it falls back to libc so the code still compiles everywhere.
// ──────────────────────────────────────────────────────────────────────────────
#include <sys/types.h>
#include <fcntl.h>

namespace AntiCrack {
namespace sc {

#ifndef AT_FDCWD
#define AT_FDCWD (-100)
#endif

#if defined(__aarch64__)

// ARM64 syscall numbers.
enum { NR_openat = 56, NR_read = 63, NR_close = 57, NR_mprotect = 226 };

static inline long raw_syscall(long nr, long a0, long a1, long a2, long a3) {
    register long x0 asm("x0") = a0;
    register long x1 asm("x1") = a1;
    register long x2 asm("x2") = a2;
    register long x3 asm("x3") = a3;
    register long x8 asm("x8") = nr;
    asm volatile("svc #0\n"
                 : "+r"(x0)
                 : "r"(x1), "r"(x2), "r"(x3), "r"(x8)
                 : "memory", "cc");
    return x0;
}

static inline int  sys_openat(int dfd, const char* path, int flags, int mode) {
    return (int)raw_syscall(NR_openat, dfd, (long)path, flags, mode);
}
static inline ssize_t sys_read(int fd, void* buf, size_t count) {
    return (ssize_t)raw_syscall(NR_read, fd, (long)buf, (long)count, 0);
}
static inline int  sys_close(int fd) {
    return (int)raw_syscall(NR_close, fd, 0, 0, 0);
}
static inline int  sys_mprotect(void* addr, size_t len, int prot) {
    return (int)raw_syscall(NR_mprotect, (long)addr, (long)len, prot, 0);
}

#else  // non-arm64 fallback (host builds / syntax checks)

#include <unistd.h>
#include <sys/mman.h>
static inline int  sys_openat(int dfd, const char* path, int flags, int mode) { return ::openat(dfd, path, flags, mode); }
static inline ssize_t sys_read(int fd, void* buf, size_t count) { return ::read(fd, buf, count); }
static inline int  sys_close(int fd) { return ::close(fd); }
static inline int  sys_mprotect(void* addr, size_t len, int prot) { return ::mprotect(addr, len, prot); }

#endif

// Convenience: open(path, flags) == openat(AT_FDCWD, path, flags, 0).
static inline int sys_open(const char* path, int flags) {
    return sys_openat(AT_FDCWD, path, flags, 0);
}

} // namespace sc
} // namespace AntiCrack
