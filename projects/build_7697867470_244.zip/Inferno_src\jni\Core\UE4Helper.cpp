#include "UE4Helper.h"
#include "AntiCrack/ObfStr.h"
#include <cmath>
#include <chrono>
#include <string>

namespace UE4Helper {
    uintptr_t g_UE4Base = 0;
    SDK::UWorld* g_World = nullptr;
    SDK::ASGCharacter* g_LocalPlayer = nullptr;
    SDK::ASGPlayerController* g_PlayerController = nullptr;
    SDK::UCanvas* g_Canvas = nullptr;
    SDK::UObject* g_Font = nullptr;
    SDK::UObject* g_WhiteTexture = nullptr;

    static bool s_LoggedBase = false;
    static SDK::ASGCharacter* s_LastLoggedPlayer = nullptr;
    static thread_local bool s_FrameActive = false;

    ScopedFrame::ScopedFrame() {
        if (!s_FrameActive) {
            GetLocalPlayer();
            s_FrameActive = true;
            ownsSnapshot = true;
        }
    }

    ScopedFrame::~ScopedFrame() {
        if (ownsSnapshot) s_FrameActive = false;
    }

    static bool IsLiveObject(const SDK::UObject* object) {
        if (!object || !Tools::IsPtrValid(object) ||
            !Tools::IsReadable(object, sizeof(SDK::UObject))) return false;
        auto objects = SDK::UObject::GObjects;
        if (!objects || !Tools::IsPtrValid(objects)) return false;
        auto item = objects->GetItemByIndex(object->InternalIndex);
        return item && item->Object == object && !item->IsUnreachable() && !item->IsPendingKill();
    }

    // Bounded ancestry check: no global object scan and no partial name matches.
    static bool HasBaseClass(const SDK::UObject* object, const char* name) {
        if (!IsLiveObject(object)) return false;
        auto cls = static_cast<SDK::UStruct*>(object->ClassPrivate);
        for (int depth = 0; cls && depth < 32; ++depth) {
            if (!IsLiveObject(cls) || !Tools::IsReadable(cls, sizeof(SDK::UStruct))) return false;
            if (cls->GetName() == name) return true;
            cls = cls->SuperStruct;
        }
        return false;
    }

    static SDK::ASGCharacter* OwnedCharacter(SDK::APawn* pawn, SDK::ASGPlayerController* pc) {
        if (!pawn || !HasBaseClass(pawn, "SGCharacter") ||
            !Tools::IsReadable(pawn, sizeof(SDK::ASGCharacter))) return nullptr;
        if (!IsLiveObject(pawn->RootComponent)) return nullptr;
        // On client side, pawn->Controller can be null or equal to pc
        if (pawn->Controller && pawn->Controller != pc) return nullptr;
        return static_cast<SDK::ASGCharacter*>(pawn);
    }

    bool InitUE4() {
        if (g_UE4Base == 0) {
            g_UE4Base = Tools::GetBaseAddress((const char*)OBFSTR("libUE4.so"));
            if (g_UE4Base == 0) {
                g_UE4Base = Tools::GetBaseAddress((const char*)OBFSTR("libshadowtracker.so"));
            }
            if (g_UE4Base != 0) {
                if (!s_LoggedBase) {
                    LOGI("[UE4Helper] Found game library at base: 0x%" PRIXPTR, g_UE4Base);
                    s_LoggedBase = true;
                }
                SDK::UObject::Init(g_UE4Base);
            }
        }
        return g_UE4Base != 0;
    }

    void ApplyOffsetUnlock(uint32_t key) {
        SDK::UObject::SetOffsetKey(key);
        if (g_UE4Base != 0) {
            SDK::UObject::Init(g_UE4Base);   // recompute GNames/GObjects with real offsets
        }
    }

    bool IsWorldReady(SDK::UWorld* world) {
        if (!world || !Tools::IsPtrValid(world)) return false;
        if (!Tools::IsReadable(world, sizeof(SDK::UWorld))) return false;
        if (!world->PersistentLevel || !Tools::IsPtrValid(world->PersistentLevel)) return false;
        if (!Tools::IsReadable(world->PersistentLevel, sizeof(SDK::ULevel))) return false;
        auto& actors = world->PersistentLevel->Actors;
        if (actors.Num() < 0 || actors.Num() > 50000) return false;
        if (actors.Num() > 0) {
            if (!actors.GetData() || !Tools::IsPtrValid(actors.GetData())) return false;
            if (!Tools::IsReadable(actors.GetData(), sizeof(void*) * std::min(actors.Num(), 5))) return false;
        }
        // Must have a valid OwningGameInstance (confirms we're in a game session)
        if (!world->OwningGameInstance || !Tools::IsPtrValid(world->OwningGameInstance)) return false;
        if (!Tools::IsReadable(world->OwningGameInstance, sizeof(SDK::UGameInstance))) return false;
        return true;
    }

    void ResetWorldState() {
        g_World = nullptr;
        g_LocalPlayer = nullptr;
        g_PlayerController = nullptr;
        g_Canvas = nullptr;
        s_LastLoggedPlayer = nullptr;
    }

    SDK::UWorld* GetWorld() {
        if (s_FrameActive) return g_World;
        if (g_UE4Base == 0) return nullptr;

        // Method 1: Direct GWorld pointer (fastest, if available)
        if (UEPointers::World != 0) {
            uintptr_t worldGlobalAddr = g_UE4Base + UEPointers::World;
            if (Tools::IsPtrValid(reinterpret_cast<void*>(worldGlobalAddr)) &&
                Tools::IsReadable(reinterpret_cast<void*>(worldGlobalAddr), sizeof(uintptr_t))) {
                uintptr_t worldPtr = *reinterpret_cast<uintptr_t*>(worldGlobalAddr);
                if (worldPtr && Tools::IsPtrValid(reinterpret_cast<void*>(worldPtr))) {
                    auto newWorld = reinterpret_cast<SDK::UWorld*>(worldPtr);
                    if (IsWorldReady(newWorld)) {
                        if (newWorld != g_World) {
                            LOGI("[UE4Helper] World (direct ptr) updated: %p", newWorld);
                            g_World = newWorld;
                            g_LocalPlayer = nullptr;
                            g_PlayerController = nullptr;
                            s_LastLoggedPlayer = nullptr;
                        }
                        return g_World;
                    }
                }
            }
        }

        // Prefer the known GEngine pointer. Never perform five whole-GObjects
        // string scans on the EGL thread before trying this constant-time path.
        auto worldFromEngine = [](SDK::UEngine* engine) -> SDK::UWorld* {
            if (!IsLiveObject(engine) || !Tools::IsReadable(engine, sizeof(SDK::UEngine))) return nullptr;
            auto viewport = engine->GameViewport;
            if (!IsLiveObject(viewport) || !Tools::IsReadable(viewport, sizeof(SDK::UGameViewportClient))) return nullptr;
            auto world = viewport->World;
            return IsLiveObject(world) && IsWorldReady(world) ? world : nullptr;
        };
        auto publishWorld = [](SDK::UWorld* world) {
            if (world != g_World) {
                ResetWorldState();
                g_World = world;
                LOGI("[UE4Helper] World via validated engine: %p", world);
            }
            return world;
        };
        if (UEPointers::Engine != 0) {
            auto address = reinterpret_cast<SDK::UEngine**>(g_UE4Base + SDK::UObject::UnmaskPtr(UEPointers::Engine));
            if (Tools::IsReadable(address, sizeof(*address))) {
                if (auto world = worldFromEngine(*address)) return publishWorld(world);
            }
        }

        // Fallback discovery has a per-frame budget and a cooldown after a full
        // miss. A weak identity avoids retaining a deleted/reused engine address.
        static SDK::FWeakObjectPtr cachedEngine{-1, 0};
        if (auto engine = static_cast<SDK::UEngine*>(cachedEngine.Get())) {
            if (auto world = worldFromEngine(engine)) return publishWorld(world);
        }
        static int32_t cursor = 0;
        static auto nextSearch = std::chrono::steady_clock::time_point::min();
        const auto now = std::chrono::steady_clock::now();
        auto objects = SDK::UObject::GObjects;
        if (now >= nextSearch && objects && Tools::IsPtrValid(objects)) {
            const int32_t count = objects->Num();
            if (count > 0 && count <= 2000000) {
                if (cursor >= count) cursor = 0;
                const int32_t end = std::min(count, cursor + 256);
                for (; cursor < end; ++cursor) {
                    auto object = objects->GetByIndex(cursor);
                    if (!IsLiveObject(object) || !IsLiveObject(object->ClassPrivate)) continue;
                    const auto name = object->ClassPrivate->GetName();
                    if (name != "SGGameEngine" && name != "GameEngine") continue;
                    auto engine = static_cast<SDK::UEngine*>(object);
                    if (auto world = worldFromEngine(engine)) {
                        auto item = objects->GetItemByIndex(object->InternalIndex);
                        cachedEngine = {object->InternalIndex, item->SerialNumber};
                        cursor = 0;
                        return publishWorld(world);
                    }
                }
                if (cursor >= count) {
                    cursor = 0;
                    nextSearch = now + std::chrono::seconds(1);
                }
            }
        }

        if (g_World != nullptr) {
            LOGI("[UE4Helper] World became invalid. Resetting state.");
            ResetWorldState();
        }
        return nullptr;
    }


    SDK::UObject* GetDefaultFont() {
        if (g_Font && Tools::IsPtrValid(g_Font)) {
            return g_Font;
        }

        if (!SDK::UObject::GObjects || !Tools::IsPtrValid(SDK::UObject::GObjects)) return nullptr;
        int32_t count = SDK::UObject::GObjects->Num();
        if (count <= 0) return nullptr;

        SDK::UObject* fallbackFont = nullptr;

        for (int32_t i = 0; i < count; i++) {
            SDK::UObject* obj = SDK::UObject::GObjects->GetByIndex(i);
            if (!obj || !obj->ClassPrivate) continue;

            std::string clsName = obj->ClassPrivate->GetName();
            if (clsName != "Font") continue;

            std::string objName = obj->GetName();
            if (objName == "RobotoDistanceField" || objName == "DefaultRegularFont" ||
                objName == "SmallFont" || objName == "Multilingual_Font" ||
                objName == "ChinaEnglishFont_Font" || objName == "Default__Font") {
                g_Font = obj;
                LOGI("[UE4Helper] Bound Primary Font: %s (%p)", objName.c_str(), obj);
                return g_Font;
            }

            if (!fallbackFont) {
                fallbackFont = obj;
            }
        }

        if (fallbackFont) {
            g_Font = fallbackFont;
            LOGI("[UE4Helper] Bound Fallback Font: %s (%p)", fallbackFont->GetName().c_str(), fallbackFont);
            return g_Font;
        }

        return nullptr;
    }

    SDK::UObject* GetWhiteTexture() {
        if (g_WhiteTexture && Tools::IsPtrValid(g_WhiteTexture)) {
            return g_WhiteTexture;
        }

        if (!SDK::UObject::GObjects || !Tools::IsPtrValid(SDK::UObject::GObjects)) return nullptr;
        int32_t count = SDK::UObject::GObjects->Num();
        if (count <= 0) return nullptr;

        SDK::UObject* fallbackTexture = nullptr;

        for (int32_t i = 0; i < count; i++) {
            SDK::UObject* obj = SDK::UObject::GObjects->GetByIndex(i);
            if (!obj || !obj->ClassPrivate) continue;

            std::string clsName = obj->ClassPrivate->GetName();
            if (clsName != "Texture2D") continue;

            std::string objName = obj->GetName();
            if (objName == "WhiteSquareTexture" || objName == "G_Common_White_Tex" ||
                objName == "T_White_1x1_Default_Linear" || objName == "DefaultTexture") {
                g_WhiteTexture = obj;
                LOGI("[UE4Helper] Bound White Texture: %s (%p)", objName.c_str(), obj);
                return g_WhiteTexture;
            }

            if (!fallbackTexture) {
                fallbackTexture = obj;
            }
        }

        if (fallbackTexture) {
            g_WhiteTexture = fallbackTexture;
            LOGI("[UE4Helper] Bound Fallback Texture: %s (%p)", fallbackTexture->GetName().c_str(), fallbackTexture);
            return g_WhiteTexture;
        }

        return nullptr;
    }

    SDK::ASGCharacter* GetLocalPlayer() {
        if (s_FrameActive) return g_LocalPlayer;
        auto world = GetWorld();
        // Never carry a raw pawn/controller into a new possession or failed read.
        // Stability means a verified owner, not retaining a possibly freed pointer.
        g_LocalPlayer = nullptr;
        g_PlayerController = nullptr;
        if (!world || !IsWorldReady(world)) return nullptr;

        auto gameInstance = world->OwningGameInstance;
        if (!IsLiveObject(gameInstance) ||
            !Tools::IsReadable(gameInstance, sizeof(SDK::UGameInstance))) return nullptr;
        const auto players = gameInstance->LocalPlayers;
        if (players.Num() <= 0 || players.Num() > 4 || players.Max() < players.Num() ||
            !Tools::IsPtrValid(players.GetData()) ||
            !Tools::IsReadable(players.GetData(), sizeof(void*))) return nullptr;
        auto player = players[0];
        if (!IsLiveObject(player) || !Tools::IsReadable(player, sizeof(SDK::ULocalPlayer))) return nullptr;
        auto pc = player->PlayerController;
        if (!HasBaseClass(pc, "SGPlayerController") ||
            !Tools::IsReadable(pc, sizeof(SDK::ASGPlayerController)) ||
            !pc->bIsLocalPlayerController || pc->Player != player) return nullptr;

        auto sgpc = static_cast<SDK::ASGPlayerController*>(pc);
        g_PlayerController = sgpc;
        // Prefer the game's explicit binding; fallbacks must also point back to pc.
        g_LocalPlayer = OwnedCharacter(sgpc->ControlledCharacter, sgpc);
        if (!g_LocalPlayer) g_LocalPlayer = OwnedCharacter(pc->Pawn, sgpc);
        if (!g_LocalPlayer) g_LocalPlayer = OwnedCharacter(pc->Character, sgpc);
        if (!g_LocalPlayer) g_LocalPlayer = OwnedCharacter(pc->AcknowledgedPawn, sgpc);

        if (g_LocalPlayer != s_LastLoggedPlayer) {
            LOGI("[UE4Helper] Local possession changed: controller=%p character=%p", sgpc, g_LocalPlayer);
            s_LastLoggedPlayer = g_LocalPlayer;
        }
        return g_LocalPlayer;
    }

    SDK::ASGPlayerController* GetPlayerController() {
        GetLocalPlayer();
        return g_PlayerController;
    }

    float GetDistance(const SDK::FVector& a, const SDK::FVector& b) {
        return a.Distance(b) / 100.0f; // in meters
    }

    bool IsPlayerAlive(SDK::ASGCharacter* actor) {
        if (!actor || !Tools::IsPtrValid(actor)) return false;
        return !actor->IsDead();
    }

    bool IsPlayerVisible(SDK::ASGPlayerController* controller, SDK::ASGCharacter* actor) {
        if (!controller || !actor || !Tools::IsPtrValid(controller) || !Tools::IsPtrValid(actor)) return false;
        return controller->LineOfSightTo(reinterpret_cast<SDK::AActor*>(actor), {0,0,0}, true);
    }

    SDK::FVector GetBoneLocation(SDK::ASGCharacter* actor, int boneId) {
        if (!actor || !Tools::IsPtrValid(actor)) return {0,0,0};
        return actor->GetBoneLocation(boneId);
    }

    SDK::FVector GetBoneLocationByName(SDK::ASGCharacter* actor, const char* boneName) {
        if (!actor || !Tools::IsPtrValid(actor) || !boneName) return {0,0,0};
        return actor->GetBonePos(boneName, {0,0,0});
    }

    bool ProjectWorldToScreen(SDK::UCanvas* canvas, const SDK::FVector& worldPos, SDK::FVector2D& screenPos) {
        if (!canvas || !Tools::IsPtrValid(canvas)) return false;
        SDK::FVector proj = canvas->K2_Project(worldPos);
        screenPos.X = proj.X;
        screenPos.Y = proj.Y;
        return proj.Z > 0.0f && screenPos.X >= 0.0f && screenPos.Y >= 0.0f && screenPos.X <= canvas->ClipX && screenPos.Y <= canvas->ClipY;
    }

    bool BuildProjection(const SDK::FCameraView& view, int screenWidth, int screenHeight, ScreenProjection& out) {
        out = {};
        if (screenWidth <= 0 || screenHeight <= 0 || view.ProjectionMode != 0 || view.FOVMode > 2 ||
            !std::isfinite(view.FOV) || view.FOV <= 0.0f || view.FOV >= 180.0f ||
            !std::isfinite(view.Location.SizeSquared()) ||
            !std::isfinite(view.Rotation.Pitch) || !std::isfinite(view.Rotation.Yaw) || !std::isfinite(view.Rotation.Roll) ||
            !std::isfinite(view.OffCenterProjectionOffset.X) || !std::isfinite(view.OffCenterProjectionOffset.Y)) return false;

        float width = static_cast<float>(screenWidth), height = static_cast<float>(screenHeight);
        const bool constrained = (view.ProjectionFlags & 0x01) != 0;
        if (constrained || view.FOVMode == 2) {
            if (!std::isfinite(view.AspectRatio) || view.AspectRatio <= 0.0f) return false;
        }
        if (constrained) {
            // Constrained view is centered inside the EGL surface (letter/pillarbox).
            if (width / height > view.AspectRatio) width = height * view.AspectRatio;
            else height = width / view.AspectRatio;
        }
        const float tangent = std::tan(DEG2RAD(view.FOV * 0.5f));
        if (!std::isfinite(tangent) || tangent <= 0.0f) return false;
        // ECameraFOVMode from the supplied SDK. FixedAspectVertical preserves the
        // vertical angle derived from the horizontal FOV at the camera's aspect.
        float focal = width * 0.5f / tangent;
        if (view.FOVMode == 1) focal = height * 0.5f / tangent;
        else if (view.FOVMode == 2) focal = height * 0.5f * view.AspectRatio / tangent;
        if (!std::isfinite(focal) || focal <= 0.0f) return false;

        // The ImGui surface stays upright even when the camera rolls. Keep the
        // projection basis unrolled so world-to-screen coordinates match it.
        const float sp = std::sin(DEG2RAD(view.Rotation.Pitch)), cp = std::cos(DEG2RAD(view.Rotation.Pitch));
        const float sy = std::sin(DEG2RAD(view.Rotation.Yaw)), cy = std::cos(DEG2RAD(view.Rotation.Yaw));
        const float sr = 0.0f;
        const float cr = 1.0f;
        out.Location = view.Location;
        out.Forward = {cp * cy, cp * sy, sp};
        out.Right = {sr * sp * cy - cr * sy, sr * sp * sy + cr * cy, -sr * cp};
        out.Up = {-(cr * sp * cy + sr * sy), sr * cy - cr * sp * sy, cr * cp};
        out.CenterX = screenWidth * 0.5f - width * 0.5f * view.OffCenterProjectionOffset.X;
        out.CenterY = screenHeight * 0.5f + height * 0.5f * view.OffCenterProjectionOffset.Y;
        if (!std::isfinite(out.CenterX) || !std::isfinite(out.CenterY)) return false;
        out.FocalX = out.FocalY = focal;
        out.Width = screenWidth;
        out.Height = screenHeight;
        out.Valid = true;
        return true;
    }

    bool WorldToScreen(const SDK::FVector& worldPos, SDK::FVector2D& screenPos, const ScreenProjection& projection) {
        screenPos = {};
        if (!projection.Valid || !std::isfinite(worldPos.SizeSquared())) return false;
        const SDK::FVector delta = worldPos - projection.Location;
        const float depth = delta.Dot(projection.Forward);
        if (!std::isfinite(depth) || depth < 1.0f) return false;
        const float x = projection.CenterX + delta.Dot(projection.Right) * projection.FocalX / depth;
        const float y = projection.CenterY - delta.Dot(projection.Up) * projection.FocalY / depth;
        if (!std::isfinite(x) || !std::isfinite(y)) return false;
        screenPos = {x, y};
        return true;
    }

    bool WorldBoundsToScreen(const SDK::FVector& origin, const SDK::FVector& extent,
                             SDK::FVector2D& minimum, SDK::FVector2D& maximum, const ScreenProjection& projection) {
        minimum = maximum = {};
        if (!projection.Valid || !std::isfinite(origin.SizeSquared()) || !std::isfinite(extent.SizeSquared()) ||
            extent.X <= 0 || extent.Y <= 0 || extent.Z <= 0) return false;
        SDK::FVector corners[8];
        float depths[8];
        bool any = false;
        auto include = [&](const SDK::FVector& point) {
            SDK::FVector2D screen;
            if (!WorldToScreen(point, screen, projection)) return;
            if (!any) { minimum = maximum = screen; any = true; }
            else {
                minimum.X = std::min(minimum.X, screen.X); minimum.Y = std::min(minimum.Y, screen.Y);
                maximum.X = std::max(maximum.X, screen.X); maximum.Y = std::max(maximum.Y, screen.Y);
            }
        };
        for (int i = 0; i < 8; ++i) {
            corners[i] = origin + SDK::FVector{(i & 1) ? extent.X : -extent.X,
                                              (i & 2) ? extent.Y : -extent.Y,
                                              (i & 4) ? extent.Z : -extent.Z};
            depths[i] = (corners[i] - projection.Location).Dot(projection.Forward);
            include(corners[i]);
        }
        // Clip crossing edges, rather than inventing a screen-aligned box when
        // the capsule straddles the camera plane. Epsilon avoids float rejection.
        constexpr float clipDepth = 1.01f;
        for (int i = 0; i < 8; ++i) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                const int j = i ^ bit;
                if (i >= j || (depths[i] < clipDepth) == (depths[j] < clipDepth)) continue;
                const float t = (clipDepth - depths[i]) / (depths[j] - depths[i]);
                include(corners[i] + (corners[j] - corners[i]) * t);
            }
        }
        return any;
    }

    bool IsLocalPlayerInScope() {
        auto controller = GetPlayerController();
        if (!controller || !Tools::IsPtrValid(controller)) return false;
        auto camera = controller->PlayerCameraManager;
        if (!camera || !Tools::IsPtrValid(camera)) return false;

        SDK::FCameraView view;
        if (camera->GetCameraView(view)) {
            const float curFov = view.FOV;
            const float defFov = camera->DefaultFOV;

            // Only consider in scope when optical zoom drops FOV at least 6 degrees below default FOV
            if (std::isfinite(curFov) && std::isfinite(defFov) && defFov > 40.0f && curFov > 5.0f) {
                if (curFov < (defFov - 6.0f)) {
                    return true;
                }
            }
        }
        return false;
    }

    bool IsLocalPlayerFiring() {
        auto controller = GetPlayerController();
        if (!controller || !Tools::IsPtrValid(controller)) return false;

        auto sgCtrl = static_cast<SDK::ASGPlayerController*>(controller);
        if (!Tools::IsReadable(&sgCtrl->SGPlayerInput, sizeof(void*)) || !Tools::IsPtrValid(sgCtrl->SGPlayerInput)) return false;
        auto input = sgCtrl->SGPlayerInput;
        if (!input || !Tools::IsReadable(input, sizeof(SDK::USGPlayerInput))) return false;
        if (!Tools::IsPtrValid(input->ClassPrivate)) return false;

        const uint64_t nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        static uint64_t s_LastFireMs = 0;

        const uint8_t left = *reinterpret_cast<const uint8_t*>(&input->LeftFireBtnPressed);
        const uint8_t right = *reinterpret_cast<const uint8_t*>(&input->RightFireBtnPressed);
        const uint8_t melee = *reinterpret_cast<const uint8_t*>(&input->bQuickMeleeFireBtnPressed);

        const bool btnDown = (left == 1 || left == 0xFF || right == 1 || right == 0xFF || melee == 1 || melee == 0xFF);
        if (btnDown) {
            s_LastFireMs = nowMs;
            return true;
        }

        // Short 70ms latch for semi-auto single tap release
        if (s_LastFireMs > 0 && (nowMs - s_LastFireMs) <= 70) {
            return true;
        }

        return false;
    }
}
