#include "Hooks.h"
#include "Tools.h"
#include <sys/mman.h>
#include <unistd.h>
#include <cstring>
#include <vector>

struct InlineHookEntry {
    void *target;
    uint8_t origBytes[32];
    size_t hookSize;
    void *trampoline;
};

static std::vector<VTableHookEntry> g_VTableHooks;
static std::vector<InlineHookEntry> g_InlineHooks;

static size_t GetPageSize() {
    static size_t s_PageSize = 0;
    if (s_PageSize == 0) {
        long sz = sysconf(_SC_PAGESIZE);
        s_PageSize = (sz > 0) ? static_cast<size_t>(sz) : 4096;
    }
    return s_PageSize;
}

static bool SetMemProtect(void* addr, size_t size, int prot) {
    size_t pageSize = GetPageSize();
    uintptr_t start = reinterpret_cast<uintptr_t>(addr) & ~(pageSize - 1);
    uintptr_t end = (reinterpret_cast<uintptr_t>(addr) + size + pageSize - 1) & ~(pageSize - 1);
    return mprotect(reinterpret_cast<void*>(start), end - start, prot) == 0;
}

bool Hooks::HookVTable(void **vtable, int index, void *newFunc, void **oldFunc) {
    if (!vtable || !newFunc || index < 0) return false;
    if (!Tools::IsPtrValid(&vtable[index])) return false;

    void* original = vtable[index];
    if (original == newFunc) return true; // Already hooked

    if (!SetMemProtect(&vtable[index], sizeof(void*), PROT_READ | PROT_WRITE)) {
        LOGE("[Hooks] HookVTable: mprotect failed on vtable=%p idx=%d", vtable, index);
        return false;
    }

    if (oldFunc) {
        *oldFunc = original;
    }

    g_VTableHooks.push_back({vtable, index, original});
    vtable[index] = newFunc;

    // Keep page writable so subsequent hooks on the same page do not fail
    // SetMemProtect(&vtable[index], sizeof(void*), PROT_READ);
    LOGI("[Hooks] HookVTable: Successfully hooked vtable[%d] %p -> %p (old: %p)", index, vtable, newFunc, original);
    return true;
}

bool Hooks::HookFunction(void *target, void *replace, void **backup) {
    if (!target || !replace) return false;
    if (!Tools::IsPtrValid(target)) return false;

    size_t pageSize = GetPageSize();

#if defined(__aarch64__)
    // Check if target is already hooked (LDR X16, #8; BR X16)
    uint32_t* code = reinterpret_cast<uint32_t*>(target);
    if (code[0] == 0x58000050 && code[1] == 0xd61f0200) {
        LOGW("[Hooks] Target function %p is ALREADY hooked! Skipping duplicate inline hook.", target);
        return true;
    }

    // 16-byte hook: LDR X16, #8; BR X16; <64-bit address>
    constexpr size_t hookSize = 16;
    uint32_t jumpCode[4] = {
        0x58000050, // ldr x16, #8
        0xd61f0200, // br x16
        0x00000000, // addr low
        0x00000000  // addr high
    };
    *reinterpret_cast<uint64_t*>(&jumpCode[2]) = reinterpret_cast<uint64_t>(replace);

    // Allocate executable trampoline
    void* tramp = mmap(nullptr, pageSize, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
    if (tramp == MAP_FAILED || !tramp) {
        LOGE("[Hooks] HookFunction: mmap failed for trampoline");
        return false;
    }

    InlineHookEntry entry;
    entry.target = target;
    entry.hookSize = hookSize;
    entry.trampoline = tramp;
    memcpy(entry.origBytes, target, hookSize);

    // Write original instructions into trampoline
    uint8_t* tPtr = reinterpret_cast<uint8_t*>(tramp);
    memcpy(tPtr, target, hookSize);

    // Append jump back to target + hookSize
    uint32_t trampJump[4] = {
        0x58000050, // ldr x16, #8
        0xd61f0200, // br x16
        0x00000000,
        0x00000000
    };
    *reinterpret_cast<uint64_t*>(&trampJump[2]) = reinterpret_cast<uint64_t>(target) + hookSize;
    memcpy(tPtr + hookSize, trampJump, hookSize);

    // Flush trampoline cache
    __builtin___clear_cache(reinterpret_cast<char*>(tPtr), reinterpret_cast<char*>(tPtr + hookSize * 2));

    // Overwrite target with jump to replace
    if (!SetMemProtect(target, hookSize, PROT_READ | PROT_WRITE | PROT_EXEC)) {
        LOGE("[Hooks] HookFunction: mprotect RWX failed on target=%p", target);
        munmap(tramp, pageSize);
        return false;
    }

    memcpy(target, jumpCode, hookSize);
    __builtin___clear_cache(reinterpret_cast<char*>(target), reinterpret_cast<char*>(target) + hookSize);
    SetMemProtect(target, hookSize, PROT_READ | PROT_EXEC);

    if (backup) {
        *backup = tramp;
    }
    g_InlineHooks.push_back(entry);
    LOGI("[Hooks] HookFunction: ARM64 Hook installed at %p -> %p (trampoline: %p)", target, replace, tramp);
    return true;

#elif defined(__arm__)
    // 8-byte hook for ARM32: LDR PC, [PC, #-4]; <addr>
    constexpr size_t hookSize = 8;
    uint32_t jumpCode[2] = {
        0xe51ff004, // ldr pc, [pc, #-4]
        reinterpret_cast<uint32_t>(replace)
    };

    void* tramp = mmap(nullptr, pageSize, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
    if (tramp == MAP_FAILED || !tramp) return false;

    InlineHookEntry entry;
    entry.target = target;
    entry.hookSize = hookSize;
    entry.trampoline = tramp;
    memcpy(entry.origBytes, target, hookSize);

    uint8_t* tPtr = reinterpret_cast<uint8_t*>(tramp);
    memcpy(tPtr, target, hookSize);

    uint32_t trampJump[2] = {
        0xe51ff004,
        reinterpret_cast<uint32_t>(target) + hookSize
    };
    memcpy(tPtr + hookSize, trampJump, hookSize);
    __builtin___clear_cache(reinterpret_cast<char*>(tPtr), reinterpret_cast<char*>(tPtr + hookSize * 2));

    if (!SetMemProtect(target, hookSize, PROT_READ | PROT_WRITE | PROT_EXEC)) {
        munmap(tramp, pageSize);
        return false;
    }

    memcpy(target, jumpCode, hookSize);
    __builtin___clear_cache(reinterpret_cast<char*>(target), reinterpret_cast<char*>(target) + hookSize);
    SetMemProtect(target, hookSize, PROT_READ | PROT_EXEC);

    if (backup) {
        *backup = tramp;
    }
    g_InlineHooks.push_back(entry);
    LOGI("[Hooks] HookFunction: ARM32 Hook installed at %p -> %p", target, replace);
    return true;
#else
    return false;
#endif
}

void Hooks::UnhookAll() {
    // Restore VTables
    for (auto &h : g_VTableHooks) {
        if (h.vtable && Tools::IsPtrValid(&h.vtable[h.index])) {
            SetMemProtect(&h.vtable[h.index], sizeof(void*), PROT_READ | PROT_WRITE);
            h.vtable[h.index] = h.original;
            SetMemProtect(&h.vtable[h.index], sizeof(void*), PROT_READ);
        }
    }
    g_VTableHooks.clear();

    // Restore Inline Hooks
    size_t pageSize = GetPageSize();
    for (auto &h : g_InlineHooks) {
        if (h.target && Tools::IsPtrValid(h.target)) {
            SetMemProtect(h.target, h.hookSize, PROT_READ | PROT_WRITE | PROT_EXEC);
            memcpy(h.target, h.origBytes, h.hookSize);
            __builtin___clear_cache(reinterpret_cast<char*>(h.target), reinterpret_cast<char*>(h.target) + h.hookSize);
            SetMemProtect(h.target, h.hookSize, PROT_READ | PROT_EXEC);
        }
        if (h.trampoline) {
            munmap(h.trampoline, pageSize);
        }
    }
    g_InlineHooks.clear();
    LOGI("[Hooks] All hooks successfully uninstalled.");
}
