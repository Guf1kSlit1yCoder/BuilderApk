#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_settings.h"
#include "vandal_widgets.hpp"
#include "vandal_main.h"
#include "mirage_logo.h"
#include <cmath>
#include <cstdint>
#include "font_defines.h"

// #ifdef __ANDROID__
// #include "texture_loader_gl.h"
// #endif


namespace custom
{
	float GetAnimOffset()
	{
		if (c::anim_offset_side == 0)
			return -ImGui::GetWindowSize().x;
		else
			return ImGui::GetWindowSize().x;
	}

	int rotation_start_index;
	void ImRotateStart()
	{
		rotation_start_index = ImGui::GetWindowDrawList()->VtxBuffer.Size;
	}

	ImVec2 ImRotationCenter()
	{
		ImVec2 l(FLT_MAX, FLT_MAX), u(-FLT_MAX, -FLT_MAX);

		const auto& buf = ImGui::GetWindowDrawList()->VtxBuffer;
		for (int i = rotation_start_index; i < buf.Size; i++)
			l = ImMin(l, buf[i].pos), u = ImMax(u, buf[i].pos);

		return ImVec2((l.x + u.x) / 2, (l.y + u.y) / 2);
	}

	void ImRotateEnd(float rad, ImVec2 center = ImRotationCenter())
	{
		float s = sin(rad), c = cos(rad);
		center = ImRotate(center, s, c) - center;

		auto& buf = ImGui::GetWindowDrawList()->VtxBuffer;
		for (int i = rotation_start_index; i < buf.Size; i++)
			buf[i].pos = ImRotate(buf[i].pos, s, c) - center;
	}



	const char* keys[] =
	{
		"-",
		"Mouse 1",
		"Mouse 2",
		"CN",
		"Mouse 3",
		"Mouse 4",
		"Mouse 5",
		"-",
		"Back",
		"Tab",
		"-",
		"-",
		"CLR",
		"Enter",
		"-",
		"-",
		"Shift",
		"CTL",
		"Menu",
		"Pause",
		"Caps Lock",
		"KAN",
		"-",
		"JUN",
		"FIN",
		"KAN",
		"-",
		"Escape",
		"CON",
		"NCO",
		"ACC",
		"MAD",
		"Space",
		"PGU",
		"PGD",
		"End",
		"Home",
		"Left",
		"Up",
		"Right",
		"Down",
		"SEL",
		"PRI",
		"EXE",
		"PRI",
		"INS",
		"Delete",
		"HEL",
		"0",
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8",
		"9",
		"-",
		"-",
		"-",
		"-",
		"-",
		"-",
		"-",
		"A",
		"B",
		"C",
		"D",
		"E",
		"F",
		"G",
		"H",
		"I",
		"J",
		"K",
		"L",
		"M",
		"N",
		"O",
		"P",
		"Q",
		"R",
		"S",
		"T",
		"U",
		"V",
		"W",
		"X",
		"Y",
		"Z",
		"WIN",
		"WIN",
		"APP",
		"-",
		"SLE",
		"Numpad 0",
		"Numpad 1",
		"Numpad 2",
		"Numpad 3",
		"Numpad 4",
		"Numpad 5",
		"Numpad 6",
		"Numpad 7",
		"Numpad 8",
		"Numpad 9",
		"MUL",
		"ADD",
		"SEP",
		"MIN",
		"Delete",
		"DIV",
		"F1",
		"F2",
		"F3",
		"F4",
		"F5",
		"F6",
		"F7",
		"F8",
		"F9",
		"F10",
		"F11",
		"F12",
		"F13",
		"F14",
		"F15",
		"F16",
		"F17",
		"F18",
		"F19",
		"F20",
		"F21",
		"F22",
		"F23",
		"F24",
		"-",
		"-",
		"-",
		"-",
		"-",
		"-",
		"-",
		"-",
		"NUM",
		"SCR",
		"EQU",
		"MAS",
		"TOY",
		"OYA",
		"OYA",
		"-",
		"-",
		"-",
		"-",
		"-",
		"-",
		"-",
		"-",
		"-",
		"Shift",
		"Shift",
		"Ctrl",
		"Ctrl",
		"Alt",
		"Alt"
	};

#include <string>

	struct item_bg_state
	{
		ImVec4 background, stroke;
	};

	struct description_state
	{
		ImVec4 hint_rect_col, hint_text_col;
		bool is_hinted;
	};
	void ItemGrab(ImGuiID id, ImRect bb, bool hovered)
	{
		static std::map<ImGuiID, item_bg_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end())
		{
			anim.insert({ id, item_bg_state() });
			it_anim = anim.find(id);
		}

		it_anim->second.background = ImLerp(it_anim->second.background,
			hovered ? ImColor(1.f, 1.f, 1.f, 1.f) : ImColor(0.75f, 0.75f, 0.75f, 1.f),
			c::anim::speed);

		it_anim->second.stroke = ImLerp(it_anim->second.stroke,
			hovered ? ImColor(0.f, 0.f, 0.f, 0.25f) : ImColor(0.f, 0.f, 0.f, 0.15f),
			c::anim::speed);

		ImDrawList* draw = ImGui::GetWindowDrawList();

		// Отрисовка фона и рамки

		draw->AddRectFilled(bb.Min, bb.Max, GetColorU32(it_anim->second.background), c::elements::rounding);

		// === РЁБРА (3 вертикальные полоски) ===
		const float padding_x = 3.0f;
		const float padding_y = 2.0f;
		const float line_width = 2.0f;
		const float spacing = 3.0f;

		const float total_width = (3 * line_width) + (2 * spacing); // 3 линии + 2 пробела
		const float start_x = bb.Min.x + (bb.GetWidth() - total_width) / 2.0f;
		const float top = bb.Min.y + padding_y;
		const float bottom = bb.Max.y - padding_y;
		const ImU32 line_color = ImColor(0.f, 0.f, 0.f, 0.35f);

		for (int i = 0; i < 3; ++i)
		{
			float x = start_x + i * (line_width + spacing);
			draw->AddRectFilled(
				ImVec2(x, top),
				ImVec2(x + line_width, bottom),
				line_color,
				1.0f
			);
		}
	}



	void ItemDescription(const char* text, ImGuiID id, ImRect bb, bool hovered, ImVec2 pos, ImVec4 description_col)
	{
		static std::map<ImGuiID, description_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end())
		{
			anim.insert({ id, description_state() });
			it_anim = anim.find(id);
		}


		if (hovered) {
			if (!it_anim->second.is_hinted)
			{
				static uint32_t dwTickStart = (uint32_t)(ImGui::GetTime() * 1000.0);
				if ((uint32_t)(ImGui::GetTime() * 1000.0) - dwTickStart > 800)
				{
					it_anim->second.is_hinted = true;
					dwTickStart = (uint32_t)(ImGui::GetTime() * 1000.0);
				}
			}
		}
		else
			it_anim->second.is_hinted = false;


		it_anim->second.hint_rect_col = ImLerp(it_anim->second.hint_rect_col, it_anim->second.is_hinted ? utils::GetColorWithAlpha(window_bg_color, ImGui::GetStyle().Alpha) : utils::GetColorWithAlpha(window_bg_color, 0.f), GetAnimSpeed() / 3);
		it_anim->second.hint_text_col = ImLerp(it_anim->second.hint_text_col, it_anim->second.is_hinted ? utils::GetColorWithAlpha(label::default_col, ImGui::GetStyle().Alpha) : utils::GetColorWithAlpha(label::default_col, 0.f), GetAnimSpeed() / 3);

		ImGui::PushClipRect(pos, bb.Max, true);


		PushFont(font::description_font);
		ImRect descrtiption_bb(pos, pos + CalcTextSize(text));

		// Render SV Square
		const int vtx_idx_0 = GetWindowDrawList()->VtxBuffer.Size;
		GetWindowDrawList()->AddText(descrtiption_bb.Min, GetColorU32(description_col), text);
		const int vtx_idx_1 = GetWindowDrawList()->VtxBuffer.Size;
		ShadeVertsLinearColorGradientSetAlpha(GetWindowDrawList(), vtx_idx_0, vtx_idx_1, bb.Min, bb.Max, GetColorU32(description_col), GetColorU32(utils::GetColorWithAlpha(description_col, 0.f)));

		if (hovered) {
			if (!it_anim->second.is_hinted)
			{
				static uint32_t dwTickStart = (uint32_t)(ImGui::GetTime() * 1000.0);
				if ((uint32_t)(ImGui::GetTime() * 1000.0) - dwTickStart > 800)
				{
					it_anim->second.is_hinted = true;
					dwTickStart = (uint32_t)(ImGui::GetTime() * 1000.0);
				}
			}
		}
		else
			it_anim->second.is_hinted = false;


		it_anim->second.hint_rect_col = ImLerp(it_anim->second.hint_rect_col, it_anim->second.is_hinted ? utils::GetColorWithAlpha(window_bg_color, ImGui::GetStyle().Alpha) : utils::GetColorWithAlpha(window_bg_color, 0.f), GetAnimSpeed());
		it_anim->second.hint_text_col = ImLerp(it_anim->second.hint_text_col, it_anim->second.is_hinted ? utils::GetColorWithAlpha(label::default_col, ImGui::GetStyle().Alpha) : utils::GetColorWithAlpha(label::default_col, 0.f), GetAnimSpeed());


		ImGui::PopClipRect();

		for (int i = 0; i < 3; i++)
			GetForegroundDrawList()->AddShadowRect(descrtiption_bb.Min - ImVec2(4, 4), descrtiption_bb.Max + ImVec2(4, 4), GetColorU32(it_anim->second.hint_rect_col), 35.f, ImVec2(0, 0), 0, 2.f);

		GetForegroundDrawList()->AddRectFilled(descrtiption_bb.Min - ImVec2(4, 4), descrtiption_bb.Max + ImVec2(4, 4), GetColorU32(it_anim->second.hint_rect_col), 2.f);
		GetForegroundDrawList()->AddText(descrtiption_bb.Min, GetColorU32(it_anim->second.hint_text_col), text);

		PopFont();


	}


	enum KeybindStatus {
		KEYBIND_NONE = 0,
		KEYBIND_WAITING,
		KEYBIND_ASSIGNED
	};

	struct key_state {
		ImVec4 background, text, icon_col;
		ImVec4 text_color, description_col;
		float alpha = 0.f;
		float size_x = 0.f;
		int status = KEYBIND_NONE;
		const char* key_name;
		bool clicked_to_waiting = false; // Флаг для предотвращения моментального захвата Mouse1


		float total_offset = -400.f;
		float total_alpha = 0.f;
		float timer;
		bool is_visible, can_view;
	};

	struct child_state
	{
		bool active = true;
		std::string name2;

		ImVec2 label_size;
		ImVec2 desc_size;
		ImVec2 total_text_size;

		float check_delta;
		float size_y;
		float bg_alpha;

		// 3D Card state
		float hover_factor = 0.f;
		float tilt_x = 0.f;
		float tilt_y = 0.f;
		float elevation = 0.f;
	};

	bool ChildEx(const char* name, ImGuiID id, const ImVec2& size_arg, bool cap, ImGuiWindowFlags flags, const char* icon)
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* parent_window = g.CurrentWindow;
		flags |= ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_ChildWindow;
		flags |= (parent_window->Flags & ImGuiWindowFlags_NoMove);

		static std::map<ImGuiID, child_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end())
		{
			anim.insert({ id, child_state() });
			it_anim = anim.find(id);
		}


		ImVec2 content_avail = GetContentRegionAvail();
		ImVec2 size = ImFloor(ImVec2(size_arg.x, size_arg.y));

		int auto_fit_axises = ((size.x == 0.0f) ? (1 << ImGuiAxis_X) : 0) | ((size.y == 0.0f) ? (1 << ImGuiAxis_Y) : 0);

		if (size.x <= 0.0f)
			size.x = ImMax(content_avail.x + size.x, 4.0f);
		if (size.y <= 0.0f)
			size.y = ImMax((content_avail.y) + size_arg.y, 4.0f);

		it_anim->second.size_y = size.y;

		ImVec2 base_pos = parent_window->DC.CursorPos;
		ImVec2 panel_min = base_pos;
		ImVec2 panel_max = base_pos + size;
		ImVec2 header_max = base_pos + ImVec2(size.x, 48.f);

		// ---------------------------------------------------------
		// 3D CARD INTERACTIVE TILT & ELEVATION CALCULATIONS
		// ---------------------------------------------------------
		bool hov_card = ImRect(panel_min, panel_max).Contains(ImGui::GetMousePos());
		it_anim->second.hover_factor = ImLerp(it_anim->second.hover_factor, hov_card ? 1.f : 0.f, GetAnimSpeed() * 1.2f);
		it_anim->second.elevation = ImLerp(it_anim->second.elevation, hov_card ? -3.5f : 0.f, GetAnimSpeed() * 1.5f);

		ImVec2 c_center = (panel_min + panel_max) * 0.5f;
		ImVec2 c_half_sz = (panel_max - panel_min) * 0.5f;
		float target_tx = hov_card ? ImClamp((ImGui::GetMousePos().x - c_center.x) / c_half_sz.x, -1.f, 1.f) : 0.f;
		float target_ty = hov_card ? ImClamp((ImGui::GetMousePos().y - c_center.y) / c_half_sz.y, -1.f, 1.f) : 0.f;
		it_anim->second.tilt_x = ImLerp(it_anim->second.tilt_x, target_tx, GetAnimSpeed() * 1.5f);
		it_anim->second.tilt_y = ImLerp(it_anim->second.tilt_y, target_ty, GetAnimSpeed() * 1.5f);

		ImVec2 elev_min = panel_min + ImVec2(0, it_anim->second.elevation);
		ImVec2 elev_max = panel_max + ImVec2(0, it_anim->second.elevation);
		ImVec2 elev_header_max = header_max + ImVec2(0, it_anim->second.elevation);

		SetNextWindowPos(base_pos + ImVec2(0, (cap ? 48.f : 0) + it_anim->second.elevation));
		SetNextWindowSize(size - ImVec2(0, cap ? 48.f : 0));

		float alpha = ImGui::GetStyle().Alpha;
		float rounding = 12.f;

		// 1. Solid Non-Transparent Black Card Fill
		GetWindowDrawList()->AddRectFilled(elev_min, elev_max,
			ImGui::GetColorU32(ImVec4(0.010f, 0.012f, 0.018f, 1.0f)), rounding);

		// 2. iOS Glass Specular Top Highlight Line
		GetWindowDrawList()->AddLine(elev_min + ImVec2(12.f, 1.0f), ImVec2(elev_max.x - 12.f, elev_min.y + 1.0f),
			ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.12f * alpha)), 1.0f);

		// 3. Delicate Glass Rim Edge
		GetWindowDrawList()->AddRect(elev_min, elev_max,
			ImGui::GetColorU32(ImLerp(ImVec4(1.0f, 1.0f, 1.0f, 0.08f * alpha), utils::GetColorWithAlpha(c::anim::active, 0.35f * alpha), it_anim->second.hover_factor)), rounding, 0, 1.0f);

		// Header Separator Line with delicate subtle glass divider
		if (cap) {
			GetWindowDrawList()->AddLine(
				ImVec2(elev_min.x + 14.f, elev_header_max.y),
				ImVec2(elev_max.x - 14.f, elev_header_max.y),
				ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.08f * alpha)), 1.0f);
		}

		std::string s = name;
		std::string label, description;
		size_t p = s.find(':');
		if (p != std::string::npos)
		{
			label = s.substr(0, p);
			description = s.substr(p + 1);
		}
		else
		{
			label = s;
		}
		auto trim = [](std::string& str) {
			size_t b = str.find_first_not_of(' '), e = str.find_last_not_of(' ');
			if (b == std::string::npos) str.clear();
			else str = str.substr(b, e - b + 1);
			};
		trim(label);
		trim(description);

		if (icon && (strcmp(icon, ICON_SWORD_FILL) == 0 || strcmp(icon, "__AIMBOT_LOGO__") == 0)) {
			TextureHandle aimbot_tex = texture::aimbot_logo;
			if (aimbot_tex) {
				float ic_dim = 24.f;
				ImVec2 ic_min = elev_min + ImVec2(14.f, (48.f - ic_dim) * 0.5f);
				GetWindowDrawList()->AddImage(TO_IMGUI_TEX(aimbot_tex), ic_min, ic_min + ImVec2(ic_dim, ic_dim), ImVec2(0,0), ImVec2(1,1), ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, ImGui::GetStyle().Alpha)));
			} else {
				PushFont(font::inter_semibold);
				fade_text_smooth(GetWindowDrawList(), icon,
					utils::center_text(elev_min + ImVec2(0, 0), elev_min + ImVec2(56, 48), icon),
					c::anim::active, c::anim::secondary);
				PopFont();
			}
		} else if (icon && icon[0] != '\0') {
			PushFont(font::inter_semibold);
			fade_text_smooth(GetWindowDrawList(), icon,
				utils::center_text(elev_min + ImVec2(0, 0), elev_min + ImVec2(56, 48), icon),
				c::anim::active, c::anim::secondary);
			PopFont();
		}

		// Header Title & Description
		float txt_x = elev_min.x + 46.f;
		if (description.empty()) {
			PushFont(font::inter_bold);
			ImVec2 l_sz = CalcTextSize(label.c_str());
			GetWindowDrawList()->AddText(ImVec2(txt_x, elev_min.y + (48.f - l_sz.y) * 0.5f), ImGui::GetColorU32(utils::GetColorWithAlpha(c::label::active, ImGui::GetStyle().Alpha)), label.c_str());
			PopFont();
		} else {
			PushFont(font::inter_bold);
			GetWindowDrawList()->AddText(ImVec2(txt_x, elev_min.y + 7.f), ImGui::GetColorU32(utils::GetColorWithAlpha(c::label::active, ImGui::GetStyle().Alpha)), label.c_str());
			PopFont();

			PushFont(font::small_font);
			GetWindowDrawList()->AddText(ImVec2(txt_x, elev_min.y + 27.f), ImGui::GetColorU32(utils::GetColorWithAlpha(c::text::description::default_col, ImGui::GetStyle().Alpha * 0.75f)), description.c_str());
			PopFont();
		}



		const char* temp_window_name;

		if (name)
			ImFormatStringToTempBuffer(&temp_window_name, NULL, "%s/%s_%08X", parent_window->Name, name, id);
		else
			ImFormatStringToTempBuffer(&temp_window_name, NULL, "%s/%08X", parent_window->Name, id);
		bool ret = Begin(temp_window_name, NULL, flags | ImGuiWindowFlags_NoBackground);
		ImGuiWindow* child_window = g.CurrentWindow;
		child_window->ChildId = id;
		child_window->AutoFitChildAxises = (ImS8)auto_fit_axises;
		if (child_window->BeginCount == 1)
			parent_window->DC.CursorPos = child_window->Pos;
		ImGuiID temp_id_for_activation = ImHashStr("##Child", 0, id);
		if (g.ActiveId == temp_id_for_activation)
			ClearActiveID();

		if (g.NavActivateId == id && !(flags & ImGuiWindowFlags_NavFlattened) && (child_window->DC.NavLayersActiveMask != 0 || child_window->DC.NavWindowHasScrollY))
		{
			FocusWindow(child_window);
			NavInitWindow(child_window, false);
			SetActiveID(temp_id_for_activation, child_window);
			g.ActiveIdSource = g.NavInputSource;
		}
		return ret;
	}

	bool Child(const char* str_id, const ImVec2& size_arg, bool cap, ImGuiWindowFlags extra_flags, bool space, const char* icon)
	{
		ImGuiWindow* window = GetCurrentWindow();

		if (cap) {
			PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12, 10));
			PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(10, 6));
		}

		return ChildEx(str_id, window->GetID(str_id), size_arg, cap, extra_flags | ImGuiWindowFlags_AlwaysUseWindowPadding, icon);
	}

	bool ChildID(ImGuiID id, const ImVec2& size_arg, bool cap, ImGuiWindowFlags extra_flags)
	{
		IM_ASSERT(id != 0);
		return ChildEx(NULL, id, size_arg, cap, extra_flags);
	}

	void EndChild()
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;
		PopStyleVar(2);

		IM_ASSERT(g.WithinEndChild == false);
		IM_ASSERT(window->Flags & ImGuiWindowFlags_ChildWindow);

		g.WithinEndChild = true;
		if (window->BeginCount > 1)
		{
			End();
		}
		else
		{
			ImVec2 sz = window->Size;

			if (window->AutoFitChildAxises & (1 << ImGuiAxis_X)) sz.x = ImMax(4.0f, sz.x);
			if (window->AutoFitChildAxises & (1 << ImGuiAxis_Y)) sz.y = ImMax(4.0f, sz.y);

			End();

			ImGuiWindow* parent_window = g.CurrentWindow;
			ImRect bb(parent_window->DC.CursorPos, parent_window->DC.CursorPos + sz);
			ItemSize(sz);
			if ((window->DC.NavLayersActiveMask != 0 || window->DC.NavWindowHasScrollY) && !(window->Flags & ImGuiWindowFlags_NavFlattened))
			{
				ItemAdd(bb, window->ChildId);
			}
			else
			{
				ItemAdd(bb, 0);

				if (window->Flags & ImGuiWindowFlags_NavFlattened) parent_window->DC.NavLayersActiveMaskNext |= window->DC.NavLayersActiveMaskNext;
			}
			if (g.HoveredWindow == window) g.LastItemData.StatusFlags |= ImGuiItemStatusFlags_HoveredWindow;

			// -----------------------------------------------------------------
			// SLEEK TOUCH SCROLLER & VERTICAL SWIPE ENGINE
			// -----------------------------------------------------------------
			if (window->ScrollMax.y > 1.0f)
			{
				ImGuiID scroll_id = window->GetID("#CUSTOM_TOUCH_SCROLLER");
				ImVec2 wpos = window->Pos;
				ImVec2 wsz = window->Size;

				float track_margin = 4.0f;
				float track_w = 6.0f;
				float track_x = wpos.x + wsz.x - track_w - track_margin;
				float track_y = wpos.y + 6.0f;
				float track_h = wsz.y - 12.0f;

				if (track_h > 24.0f)
				{
					float visible_ratio = wsz.y / (wsz.y + window->ScrollMax.y);
					float thumb_h = ImClamp(track_h * visible_ratio, 32.0f, track_h - 8.0f);
					float max_thumb_travel = track_h - thumb_h;
					if (max_thumb_travel < 1.0f) max_thumb_travel = 1.0f;

					// Touch hitbox along right edge: 36px wide for comfortable finger grab
					ImRect hit_bb(ImVec2(track_x - 18.0f, track_y), ImVec2(track_x + track_w + 16.0f, track_y + track_h));
					bool is_scrollbar_hovered = hit_bb.Contains(g.IO.MousePos);

					struct ChildScrollState {
						bool is_dragging_scrollbar = false;
						bool is_swiping_card = false;
						float scroll_vel = 0.0f;
						float touch_start_y = 0.0f;
						float touch_start_x = 0.0f;
						float thumb_anim = 0.0f;
					};
					static std::map<ImGuiID, ChildScrollState> s_scroll_states;
					auto& s_st = s_scroll_states[scroll_id];

					// 1. Direct Touch on Scrollbar Thumb / Track
					if (g.IO.MouseClicked[0] && is_scrollbar_hovered) {
						s_st.is_dragging_scrollbar = true;
						s_st.scroll_vel = 0.0f;
					}

					if (s_st.is_dragging_scrollbar) {
						if (g.IO.MouseDown[0]) {
							float touch_rel_y = g.IO.MousePos.y - (track_y + thumb_h * 0.5f);
							float new_ratio = ImClamp(touch_rel_y / max_thumb_travel, 0.0f, 1.0f);
							window->Scroll.y = new_ratio * window->ScrollMax.y;
							if (g.ActiveId != 0 && g.ActiveId != scroll_id) ImGui::ClearActiveID();
						} else {
							s_st.is_dragging_scrollbar = false;
						}
					}

					// 2. Direct Finger Swipe / Scroll anywhere on Child Window content
					ImRect child_rect(wpos, wpos + wsz);
					bool mouse_in_child = child_rect.Contains(g.IO.MousePos);

					if (g.IO.MouseClicked[0] && mouse_in_child && !is_scrollbar_hovered) {
						s_st.touch_start_y = g.IO.MousePos.y;
						s_st.touch_start_x = g.IO.MousePos.x;
						s_st.is_swiping_card = false;
					}

					if (g.IO.MouseDown[0] && mouse_in_child && !s_st.is_dragging_scrollbar) {
						float drag_dy = g.IO.MousePos.y - s_st.touch_start_y;
						float drag_dx = g.IO.MousePos.x - s_st.touch_start_x;

						// Check if vertical drag dominates and exceeds threshold
						if (!s_st.is_swiping_card && fabsf(drag_dy) > 7.0f && fabsf(drag_dy) > fabsf(drag_dx) * 1.2f) {
							s_st.is_swiping_card = true;
							if (g.ActiveId != 0 && g.ActiveId != scroll_id) ImGui::ClearActiveID();
						}

						if (s_st.is_swiping_card) {
							float delta_y = g.IO.MouseDelta.y;
							window->Scroll.y = ImClamp(window->Scroll.y - delta_y, 0.0f, window->ScrollMax.y);
							s_st.scroll_vel = -delta_y / ImMax(g.IO.DeltaTime, 0.001f);
							s_st.scroll_vel = ImClamp(s_st.scroll_vel, -2500.0f, 2500.0f);
							if (g.ActiveId != 0 && g.ActiveId != scroll_id) ImGui::ClearActiveID();
						}
					} else if (!g.IO.MouseDown[0]) {
						s_st.is_swiping_card = false;
					}

					// 3. Kinetic scroll momentum & decay
					if (!g.IO.MouseDown[0] && fabsf(s_st.scroll_vel) > 10.0f) {
						window->Scroll.y = ImClamp(window->Scroll.y + s_st.scroll_vel * g.IO.DeltaTime, 0.0f, window->ScrollMax.y);
						s_st.scroll_vel = ImLerp(s_st.scroll_vel, 0.0f, ImMin(g.IO.DeltaTime * 9.0f, 1.0f));
						if (window->Scroll.y <= 0.0f || window->Scroll.y >= window->ScrollMax.y) s_st.scroll_vel = 0.0f;
					}

					// Calculate current thumb Y
					float scroll_ratio = ImClamp(window->Scroll.y / window->ScrollMax.y, 0.0f, 1.0f);
					float thumb_y = track_y + scroll_ratio * max_thumb_travel;

					// Animate thumb expand & glow when active/touched
					bool is_active_scroll = s_st.is_dragging_scrollbar || s_st.is_swiping_card || is_scrollbar_hovered;
					s_st.thumb_anim = ImLerp(s_st.thumb_anim, is_active_scroll ? 1.0f : 0.0f, g.IO.DeltaTime * 12.0f);

					float cur_thumb_w = ImLerp(track_w, track_w + 3.0f, s_st.thumb_anim);
					float cur_thumb_x = wpos.x + wsz.x - cur_thumb_w - track_margin;

					// 4. Draw stylish scrollbar directly on parent draw list (crisp overlay)
					ImDrawList* dl = parent_window->DrawList;

					// Subtle track channel
					dl->AddRectFilled(
						ImVec2(track_x - 1.0f, track_y),
						ImVec2(track_x + track_w + 1.0f, track_y + track_h),
						IM_COL32(14, 17, 24, 150),
						track_w * 0.5f
					);
					dl->AddRect(
						ImVec2(track_x - 1.0f, track_y),
						ImVec2(track_x + track_w + 1.0f, track_y + track_h),
						IM_COL32(255, 255, 255, 14),
						track_w * 0.5f,
						0,
						1.0f
					);

					// Neon glow behind thumb on touch
					if (s_st.thumb_anim > 0.02f) {
						dl->AddShadowRect(
							ImVec2(cur_thumb_x - 2.0f, thumb_y - 2.0f),
							ImVec2(cur_thumb_x + cur_thumb_w + 2.0f, thumb_y + thumb_h + 2.0f),
							ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.40f * s_st.thumb_anim)),
							8.0f, ImVec2(0, 0),
							ImDrawFlags_RoundCornersAll,
							cur_thumb_w * 0.5f
						);
					}

					// Gradient Pill Thumb
					int vs = dl->VtxBuffer.Size;
					dl->AddRectFilled(
						ImVec2(cur_thumb_x, thumb_y),
						ImVec2(cur_thumb_x + cur_thumb_w, thumb_y + thumb_h),
						IM_COL32(255, 255, 255, 255),
						cur_thumb_w * 0.5f
					);
					int ve = dl->VtxBuffer.Size;

					ImColor col_top = ImLerpColor(ImColor(135, 145, 170, 180), c::anim::active, 0.65f + 0.35f * s_st.thumb_anim);
					ImColor col_bot = ImLerpColor(ImColor(85, 95, 120, 180), c::anim::secondary, 0.65f + 0.35f * s_st.thumb_anim);
					set_linear_color(dl, vs, ve,
						ImVec2(cur_thumb_x, thumb_y),
						ImVec2(cur_thumb_x, thumb_y + thumb_h),
						col_top, col_bot, 0.0f);

					// Delicate top specular highlight
					dl->AddRect(
						ImVec2(cur_thumb_x, thumb_y),
						ImVec2(cur_thumb_x + cur_thumb_w, thumb_y + thumb_h),
						IM_COL32(255, 255, 255, (int)(60 + 90 * s_st.thumb_anim)),
						cur_thumb_w * 0.5f,
						0,
						1.0f
					);
				}
			}
		}
		g.WithinEndChild = false;
		g.LogLinePosY = -FLT_MAX;
	}


	void BeginGroup()
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;

		g.GroupStack.resize(g.GroupStack.Size + 1);
		ImGuiGroupData& group_data = g.GroupStack.back();
		group_data.WindowID = window->ID;
		group_data.BackupCursorPos = window->DC.CursorPos;
		group_data.BackupCursorMaxPos = window->DC.CursorMaxPos;
		group_data.BackupIndent = window->DC.Indent;
		group_data.BackupGroupOffset = window->DC.GroupOffset;
		group_data.BackupCurrLineSize = window->DC.CurrLineSize;
		group_data.BackupCurrLineTextBaseOffset = window->DC.CurrLineTextBaseOffset;
		group_data.BackupActiveIdIsAlive = g.ActiveIdIsAlive;
		group_data.BackupHoveredIdIsAlive = g.HoveredId != 0;
		group_data.BackupActiveIdPreviousFrameIsAlive = g.ActiveIdPreviousFrameIsAlive;
		group_data.EmitItem = true;

		window->DC.GroupOffset.x = window->DC.CursorPos.x - window->Pos.x - window->DC.ColumnsOffset.x;
		window->DC.Indent = window->DC.GroupOffset;
		window->DC.CursorMaxPos = window->DC.CursorPos;
		window->DC.CurrLineSize = ImVec2(0.0f, 0.0f);
		if (g.LogEnabled) g.LogLinePosY = -FLT_MAX;
	}

	void EndGroup()
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;
		IM_ASSERT(g.GroupStack.Size > 0);

		ImGuiGroupData& group_data = g.GroupStack.back();
		IM_ASSERT(group_data.WindowID == window->ID);

		if (window->DC.IsSetPos) ErrorCheckUsingSetCursorPosToExtendParentBoundaries();

		ImRect group_bb(group_data.BackupCursorPos, ImMax(window->DC.CursorMaxPos, group_data.BackupCursorPos));

		window->DC.CursorPos = group_data.BackupCursorPos;
		window->DC.CursorMaxPos = ImMax(group_data.BackupCursorMaxPos, window->DC.CursorMaxPos);
		window->DC.Indent = group_data.BackupIndent;
		window->DC.GroupOffset = group_data.BackupGroupOffset;
		window->DC.CurrLineSize = group_data.BackupCurrLineSize;
		window->DC.CurrLineTextBaseOffset = group_data.BackupCurrLineTextBaseOffset;
		if (g.LogEnabled) g.LogLinePosY = -FLT_MAX;

		if (!group_data.EmitItem)
		{
			g.GroupStack.pop_back();
			return;
		}

		window->DC.CurrLineTextBaseOffset = ImMax(window->DC.PrevLineTextBaseOffset, group_data.BackupCurrLineTextBaseOffset);
		ItemSize(group_bb.GetSize());
		ItemAdd(group_bb, 0, NULL, ImGuiItemFlags_NoTabStop);

		const bool group_contains_curr_active_id = (group_data.BackupActiveIdIsAlive != g.ActiveId) && (g.ActiveIdIsAlive == g.ActiveId) && g.ActiveId;
		const bool group_contains_prev_active_id = (group_data.BackupActiveIdPreviousFrameIsAlive == false) && (g.ActiveIdPreviousFrameIsAlive == true);
		if (group_contains_curr_active_id) g.LastItemData.ID = g.ActiveId;
		else if (group_contains_prev_active_id) g.LastItemData.ID = g.ActiveIdPreviousFrame;
		g.LastItemData.Rect = group_bb;

		const bool group_contains_curr_hovered_id = (group_data.BackupHoveredIdIsAlive == false) && g.HoveredId != 0;
		if (group_contains_curr_hovered_id) g.LastItemData.StatusFlags |= ImGuiItemStatusFlags_HoveredWindow;

		if (group_contains_curr_active_id && g.ActiveIdHasBeenEditedThisFrame) g.LastItemData.StatusFlags |= ImGuiItemStatusFlags_Edited;

		g.LastItemData.StatusFlags |= ImGuiItemStatusFlags_HasDeactivated;
		if (group_contains_prev_active_id && g.ActiveId != g.ActiveIdPreviousFrame) g.LastItemData.StatusFlags |= ImGuiItemStatusFlags_Deactivated;

		g.GroupStack.pop_back();
	}




	void Separator_line()
	{
		GetWindowDrawList()->AddRectFilled(GetCursorScreenPos(), GetCursorScreenPos() + ImVec2(GetContentRegionMax().x - GetStyle().WindowPadding.x, 1), GetColorU32(c::separator));
		Spacing();
	}

	void SeparatorEx(ImGuiSeparatorFlags flags, float thickness)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems) return;

		ImGuiContext& g = *GImGui;
		IM_ASSERT(ImIsPowerOfTwo(flags & (ImGuiSeparatorFlags_Horizontal | ImGuiSeparatorFlags_Vertical)));
		IM_ASSERT(thickness > 0.0f);

		if (flags & ImGuiSeparatorFlags_Vertical)
		{
			float y1 = window->DC.CursorPos.y;
			float y2 = window->DC.CursorPos.y + window->DC.CurrLineSize.y;
			const ImRect bb(ImVec2(window->DC.CursorPos.x, y1 + (GetStyle().ItemSpacing.y / 2)), ImVec2(window->DC.CursorPos.x + thickness, y2 - (GetStyle().ItemSpacing.y / 2)));


			ItemSize(ImVec2(thickness, 0.0f));
			if (!ItemAdd(bb, 0)) return;

			window->DrawList->AddRectFilled(bb.Min, bb.Max, GetColorU32(c::child::background));

			ImGui::SameLine();
		}
		else if (flags & ImGuiSeparatorFlags_Horizontal)
		{
			float x1 = window->Pos.x;
			float x2 = window->Pos.x + window->Size.x;

			if (g.GroupStack.Size > 0 && g.GroupStack.back().WindowID == window->ID) x1 += window->DC.Indent.x;

			if (ImGuiTable* table = g.CurrentTable)
			{
				x1 = table->Columns[table->CurrentColumn].MinX;
				x2 = table->Columns[table->CurrentColumn].MaxX;
			}

			ImGuiOldColumns* columns = (flags & ImGuiSeparatorFlags_SpanAllColumns) ? window->DC.CurrentColumns : NULL;
			if (columns) PushColumnsBackground();

			const float thickness_for_layout = (thickness == 1.0f) ? 0.0f : thickness;
			const ImRect bb(ImVec2(x1 + GetStyle().WindowPadding.x, window->DC.CursorPos.y), ImVec2(x2 - GetStyle().WindowPadding.x, window->DC.CursorPos.y + thickness));

			ItemSize(ImVec2(0.0f, thickness_for_layout));

			if (ItemAdd(bb, 0))
			{
				window->DrawList->AddRectFilled(bb.Min, bb.Max, GetColorU32(c::separator));
			}
			if (columns)
			{
				PopColumnsBackground();
				columns->LineMinY = window->DC.CursorPos.y;
			}
		}
	}

	void Separator()
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;
		if (window->SkipItems) return;

		ImGuiSeparatorFlags flags = (window->DC.LayoutType == ImGuiLayoutType_Horizontal) ? ImGuiSeparatorFlags_Vertical : ImGuiSeparatorFlags_Horizontal;
		flags |= ImGuiSeparatorFlags_SpanAllColumns;
		SeparatorEx(flags, 1.0f);
	}

	struct theme_state
	{
		ImVec4 background;
		float smooth_swap, alpha_line, line_size;
	};

	bool ThemeButton(const char* id_theme, bool dark, const ImVec2& size_arg)
	{
		ImGuiWindow* window = GetCurrentWindow();

		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		const ImGuiID id = window->GetID(id_theme);
		const ImVec2 label_size = CalcTextSize(id_theme, NULL, true), pos = window->DC.CursorPos;

		ImVec2 size = CalcItemSize(size_arg, label_size.x, label_size.y);

		const ImRect bb(pos, pos + size);

		ItemSize(size, 0.f);
		if (!ItemAdd(bb, id)) return false;

		bool hovered, held, pressed = ButtonBehavior(bb, id, &hovered, &held, NULL);

		static std::map<ImGuiID, theme_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end())
		{
			anim.insert({ id, theme_state() });
			it_anim = anim.find(id);
		}

		it_anim->second.background = ImLerp(it_anim->second.background, dark || hovered ? c::page::background_active : c::page::background, g.IO.DeltaTime * 6.f);

		it_anim->second.alpha_line = ImLerp(it_anim->second.alpha_line, dark ? 1.f : 0.f, g.IO.DeltaTime * 6.f);
		it_anim->second.line_size = ImLerp(it_anim->second.line_size, dark ? (size_arg.x / 4) : (size_arg.x / 2), g.IO.DeltaTime * 6.f);

		it_anim->second.smooth_swap = ImLerp(it_anim->second.smooth_swap, dark ? 26.f : 0, g.IO.DeltaTime * 12.f);

		GetWindowDrawList()->AddRectFilled(bb.Min, bb.Max, GetColorU32(it_anim->second.background), c::page::rounding);

		PushClipRect(bb.Min, bb.Max, true);

		PushFont(font::icomoon_page);
		GetWindowDrawList()->AddText(ImVec2(bb.Min.x + (size_arg.x - CalcTextSize("k").x) / 2, bb.Max.y - CalcTextSize("k").y - (size.y - CalcTextSize("k").y) / 2 + it_anim->second.smooth_swap), GetColorU32(c::anim::active.Value), "k");
		GetWindowDrawList()->AddText(ImVec2(bb.Min.x + (size_arg.x - CalcTextSize("a").x) / 2, bb.Max.y - CalcTextSize("a").y - (size.y - CalcTextSize("a").y) / 2 - 25 + it_anim->second.smooth_swap), GetColorU32(c::anim::active.Value), "a");
		PopFont();

		PopClipRect();

		return pressed;
	}

	struct rotated_text_state
	{
		float hover_anim, scale_offset;
		ImVec4 text;


		float total_offset = -400.f;
		float total_alpha = 0.f;
		float timer;
		bool is_visible, can_view;
	};

	bool rotated_text(const char* label, bool active)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		const ImGuiID id = window->GetID(label);

		static std::map<ImGuiID, rotated_text_state> anim;
		auto& state = anim[id];

		const ImVec2 pos = window->DC.CursorPos + ImVec2(state.total_offset, 0);
		ImVec2 size = ImVec2(20, 20);



		const ImRect bb(pos, pos + size);
		ItemSize(size, 0.f);
		ItemAdd(bb, id);

		bool hovered, held, pressed = ButtonBehavior(bb, id, &hovered, &held);

		float dt = g.IO.DeltaTime;


		state.is_visible = !tab_want_to_change;
		if (tab_want_to_change || ImGui::GetWindowSize().y < 35) {

			state.total_offset = GetAnimOffset();
			state.total_alpha = 0.f;
			state.timer = 0.f;
		}
		state.timer += ImGui::GetIO().DeltaTime;
		float relative = (bb.GetCenter().y - ImGui::GetWindowPos().y) / ImGui::GetWindowSize().y;
		float delay = 0.1f + relative * 0.9f;
		float t = ImClamp((state.timer - delay) / 0.3f, 0.f, 1.f);
		state.total_offset = ImLerp(state.total_offset, 0.f, ImGui::GetIO().DeltaTime * t * 4);
		state.total_alpha = ImLerp(state.total_alpha, ImGui::GetStyle().Alpha, ImGui::GetIO().DeltaTime * t * 3);


		state.text = easing->easing_in_out<ImVec4>(id * 1, active, c::label::default_col, c::label::active, dt * 20.f, interpolation_type::back);

		state.scale_offset = easing->easing_in_out<float>(id * 2, active || hovered, 0.8f, 1.f, dt * 20.f, interpolation_type::back);

		state.hover_anim = ImLerp(state.hover_anim, hovered || active ? IM_PI : IM_PI / 2, dt * 9.f);

		ImRotateStart();
		ImGui::GetWindowDrawList()->AddText(ImGui::GetDefaultFont(), ImGui::GetDefaultFont()->FontSize * state.scale_offset, bb.GetCenter() - (CalcTextSize(label) * state.scale_offset) / 2 + ImVec2(0, 1), ImGui::GetColorU32(utils::GetColorWithAlpha(state.text, state.total_alpha)), label);
		ImRotateEnd(state.hover_anim);

		return pressed;
	}


	struct button_state
	{
		float t;
		float press_anim;
		float hover_anim;
		float gradient_alpha;
		ImVec4 background, text;

		float total_offset = 0.f;
		float total_alpha = 1.f;
		float timer;
		bool is_visible, can_view;
	};

	bool Button(const char* label, const ImVec2& size_arg)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		const ImGuiID id = window->GetID(label);

		static std::map<ImGuiID, button_state> anim;
		auto& state = anim[id];

		const ImVec2 pos = window->DC.CursorPos;
		ImVec2 size = size_arg;
		if (size.x <= 0.0f)
			size.x = GetContentRegionAvail().x;
		if (size.y <= 0.0f)
			size.y = 36.0f;

		const ImRect bb(pos, pos + size);
		ItemSize(size, 0.f);
		if (!ItemAdd(bb, id)) return false;

		bool hovered, held, pressed = ButtonBehavior(bb, id, &hovered, &held);

		float dt = g.IO.DeltaTime;
		float alpha = ImGui::GetStyle().Alpha;

		state.text = easing->easing_in_out<ImVec4>(id * 2, hovered || held, c::label::default_col, c::label::active, dt * 16.f, interpolation_type::back);
		state.press_anim = easing->easing_out<float>(id * 3, 0.f, pressed ? 1.f : 0.f, dt * 30.f, interpolation_type::expo);
		state.hover_anim = easing->easing_in_out<float>(id * 4, pressed ? 1.2f : hovered ? 1.f : 0.f, 0.45f, 1.f, dt * 18.f, interpolation_type::back);
		state.gradient_alpha = ImLerp(state.gradient_alpha, hovered ? 1.f : 0.f, dt * 10.f);

		ImDrawList* draw = GetWindowDrawList();
		ImVec2 center = bb.GetCenter();

		float scale = 1.f - state.press_anim * 0.04f;
		ImVec2 anim_size = size * scale;
		ImVec2 box_min = center - anim_size * 0.5f;
		ImVec2 box_max = center + anim_size * 0.5f;

		// Button background
		draw->AddRectFilled(box_min, box_max, ImGui::GetColorU32(ImVec4(0.05f, 0.06f, 0.10f, 0.85f * alpha)), 8.f);
		ImU32 btn_border = hovered 
			? ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.70f * alpha).Value) 
			: ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.10f * alpha));
		draw->AddRect(box_min, box_max, btn_border, 8.f, 0, 1.f);

		if (state.gradient_alpha > 0.01f) {
			int vtx_start = draw->VtxBuffer.Size;
			draw->AddRectFilled(box_min, box_max, ImColor(1.f, 1.f, 1.f, 1.f), 8.f);
			int vtx_end = draw->VtxBuffer.Size;

			float time = ImGui::GetTime();
			float phase = time * 0.4f;
			float angle = ImDegToRad(phase * 360.f);
			set_linear_color(draw, vtx_start, vtx_end, box_min, box_max,
				ImGui::GetColorU32(c::anim::active.Value),
				ImGui::GetColorU32(c::anim::secondary.Value), angle);

			for (int v = vtx_start; v < vtx_end; v++) {
				ImU32& col = draw->VtxBuffer[v].col;
				int a = (col >> 24) & 0xFF;
				a = (int)(a * state.gradient_alpha * 0.4f * alpha);
				col = (col & 0x00FFFFFF) | (a << 24);
			}
		}

		PushClipRect(bb.Min, bb.Max, true);
		ImVec2 text_size = CalcTextSize(label);
		ImVec2 text_pos = center - text_size * 0.5f;
		draw->AddText(text_pos, ImGui::GetColorU32(state.text), label);
		PopClipRect();

		if (pressed) {
			for (int i = 0; i < particle::PARTICLE_COUT; ++i)
				particle::AddParticle(center, ImVec2(3, 3) / 10, 0);
		}

		return pressed;
	}

	bool InActiveButton(const char* label, const ImVec2& size_arg)
	{
		return Button(label, size_arg);
	}


	struct tab_state {
		ImVec4 text_col, icon_col, dark_col;
		ImVec4 frame_col;
		ImVec4 line_col;
		bool is_want = true;
		float icon_size;
		ImFont* icon_font;
		float text_offset;

		float hover_glow = 0.f;
		float hover_pulse = 0.f;
		float active_bounce = 0.f;
		float indicator_width = 0.f;
		float icon_scale = 1.f;
		float press_scale = 1.f;
		float glow_intensity = 0.f;
	};

	bool Tab(const char* label, const char* icon, int* v, int number) {
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems)
			return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		const ImGuiID id = window->GetID(label);

		const float square_sz = GetFrameHeight();
		const ImVec2 pos = window->DC.CursorPos;
		const ImRect total_bb(pos, pos + ImVec2(ImGui::GetContentRegionAvail().x, 45));

		ItemSize(total_bb, style.FramePadding.y);
		ItemAdd(total_bb, id);

		static std::map<ImGuiID, tab_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end()) {
			anim.insert({ id, tab_state() });
			it_anim = anim.find(id);
		}

		bool hovered, held;
		bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);
		if (pressed) {
			it_anim->second.is_want = true;
		}

		if (it_anim->second.is_want) {
			it_anim->second.is_want = false;
		}
		RenderNavHighlight(total_bb, id);

		float dt = g.IO.DeltaTime;
		bool is_active = (*v == number);

		it_anim->second.hover_glow = easing->easing_in_out<float>(
			id * 10, hovered, 0.f, 1.f, dt * 18.f, interpolation_type::back);
		it_anim->second.hover_pulse = sinf(ImGui::GetTime() * 4.0f) * 0.15f * it_anim->second.hover_glow;

		it_anim->second.active_bounce = easing->easing_in_out<float>(
			id * 11, is_active, 0.f, 1.f, dt * 12.f, interpolation_type::back);

		it_anim->second.glow_intensity = ImLerp(it_anim->second.glow_intensity,
			is_active ? 1.f : (hovered ? 0.4f : 0.f), dt * 8.f);

		it_anim->second.press_scale = easing->easing_in_out<float>(
			id * 12, held, 1.f, 0.92f, dt * 30.f, interpolation_type::back);

		it_anim->second.icon_scale = easing->easing_in_out<float>(
			id * 13, is_active, 0.85f, 1.0f, dt * 10.f, interpolation_type::back);

		float indicator_speed = dt * 14.f;
		it_anim->second.indicator_width = ImLerp(it_anim->second.indicator_width,
			is_active ? 3.f : (hovered ? 1.5f : 0.f), indicator_speed);

		it_anim->second.frame_col = ImLerp(it_anim->second.frame_col,
			is_active ? ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.25f + it_anim->second.hover_pulse).Value) :
			hovered ? ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.1f + it_anim->second.hover_pulse * 0.5f).Value) :
			ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.f).Value), dt * 8.f);

		it_anim->second.dark_col = ImLerp(it_anim->second.dark_col,
			is_active ? ImVec4(utils::GetColorWithAlpha(c::dark_color, 0.08f).Value) :
			ImVec4(utils::GetColorWithAlpha(c::dark_color, 0.f).Value), dt * 8.f);

		it_anim->second.text_col = ImLerp(it_anim->second.text_col,
			is_active ? ImVec4(c::text::label::active.Value) :
			hovered ? ImVec4(c::text::label::hovered.Value) :
			ImVec4(c::label::default_col.Value), dt * 8.f);

		it_anim->second.text_offset = ImLerp(it_anim->second.text_offset,
			is_active ? -7.f : 5.f, dt * 8.f);

		it_anim->second.icon_col = ImLerp(it_anim->second.icon_col,
			is_active ? ImVec4(c::anim::active.Value) :
			hovered ? ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.85f).Value) :
			ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.5f).Value), dt * 8.f);

		float target_size = is_active ? font::regular_l->FontSize : font::regular_l->FontSize - 10.f;
		it_anim->second.icon_size = ImLerp(it_anim->second.icon_size, target_size, dt * 4.f);

		ImVec2 center = total_bb.GetCenter();
		float centering_scale = it_anim->second.press_scale;

		ImVec2 draw_min = center - (total_bb.GetSize() * 0.5f * centering_scale);
		ImVec2 draw_max = center + (total_bb.GetSize() * 0.5f * centering_scale);
		ImRect scaled_bb(draw_min, draw_max);

		if (it_anim->second.glow_intensity > 0.01f) {
			float glow_expand = 3.f * it_anim->second.glow_intensity;
			ImVec2 glow_min = scaled_bb.Min - ImVec2(glow_expand, glow_expand);
			ImVec2 glow_max = scaled_bb.Max + ImVec2(glow_expand, glow_expand);

			for (int i = 0; i < 2; i++) {
				float alpha = it_anim->second.glow_intensity * (0.15f - i * 0.07f);
				float expand = glow_expand * (1.0f + i * 0.5f);
				ImVec2 g_min = scaled_bb.Min - ImVec2(expand, expand);
				ImVec2 g_max = scaled_bb.Max + ImVec2(expand, expand);
				window->DrawList->AddShadowRect(g_min, g_max,
					ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, alpha)),
					20.f - i * 5.f, ImVec2(0, 0),
					ImDrawFlags_RoundCornersAll | ImDrawFlags_ShadowCutOutShapeBackground, 4.f);
			}
		}

		window->DrawList->AddRectFilledMultiColor(scaled_bb.Min, scaled_bb.Max,
			GetColorU32(it_anim->second.frame_col),
			ImGui::GetColorU32(utils::GetColorWithAlpha(c::dark_color, 0.f)),
			ImGui::GetColorU32(utils::GetColorWithAlpha(c::dark_color, 0.f)),
			GetColorU32(it_anim->second.frame_col), 4.f);

		if (it_anim->second.indicator_width > 0.3f) {
			float iw = it_anim->second.indicator_width;
			ImVec2 ind_min(scaled_bb.Max.x - iw - 1, scaled_bb.Min.y + 8);
			ImVec2 ind_max(scaled_bb.Max.x - 1, scaled_bb.Max.y - 8);

			window->DrawList->AddShadowRect(ind_min - ImVec2(1, 2), ind_max + ImVec2(1, 2),
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, it_anim->second.indicator_width / 3.f * 0.6f)),
				8.f, ImVec2(0, 0), 0, 2.f);
			fade_rect_filled(window->DrawList, ind_min, ind_max,
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, it_anim->second.glow_intensity)),
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::dark_color, it_anim->second.glow_intensity)),
				fade_direction::vertically, 2.f, 0, true);
		}

		float icon_sz = it_anim->second.icon_size * it_anim->second.icon_scale;
		ImVec2 icon_pos(scaled_bb.Min.x + 10,
			utils::center_text(scaled_bb.Min, scaled_bb.Max, icon).y);

		PushFont(font::regular_m);
		fade_text_smooth_id(window->DrawList, icon, icon_pos,
			ImGui::GetColorU32(it_anim->second.icon_col),
			ImGui::GetColorU32(it_anim->second.dark_col),
			id);
		PopFont();

		window->DrawList->AddText(
			ImVec2(scaled_bb.Min.x + 40.f,
				utils::center_text(scaled_bb.Min, scaled_bb.Max, label).y),
			GetColorU32(it_anim->second.text_col), label);

		static std::map<ImGuiID, bool> hover_particle_trigger;
		auto& hover_trigger = hover_particle_trigger[id];

		if (hovered && !hover_trigger) {
			for (int i = 0; i < particle::PARTICLE_COUT / 5; ++i)
				particle::AddParticle(center, ImVec2(2, 2), 0);
			hover_trigger = true;
		} else if (!hovered) {
			hover_trigger = false;
		}

		if (pressed) {
			for (int i = 0; i < particle::PARTICLE_COUT; ++i)
				particle::AddParticle(center, ImVec2(3, 3) / 10, 0);
		}

		return pressed;
	}


	bool SquareTab(const char* label, const char* icon, int* v, int number) {
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems)
			return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		const ImGuiID id = window->GetID(label);

		const float square_sz = GetFrameHeight();
		const ImVec2 pos = window->DC.CursorPos;
		const ImRect total_bb(pos, pos + ImVec2(82, ImGui::GetContentRegionAvail().y - 8));

		ItemSize(total_bb, style.FramePadding.y);
		ItemAdd(total_bb, id);

		static std::map<ImGuiID, tab_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end()) {
			anim.insert({ id, tab_state() });
			it_anim = anim.find(id);
		}

		bool hovered, held;
		bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);
		if (pressed) {
			it_anim->second.is_want = true;
		}

		if (it_anim->second.is_want) {
			it_anim->second.is_want = false;
		}
		RenderNavHighlight(total_bb, id);

		float dt = g.IO.DeltaTime;
		bool is_active = (*v == number);

		it_anim->second.hover_glow = easing->easing_in_out<float>(
			id * 20, hovered, 0.f, 1.f, dt * 18.f, interpolation_type::back);
		it_anim->second.hover_pulse = sinf(ImGui::GetTime() * 4.0f) * 0.15f * it_anim->second.hover_glow;

		it_anim->second.active_bounce = easing->easing_in_out<float>(
			id * 21, is_active, 0.f, 1.f, dt * 12.f, interpolation_type::back);

		it_anim->second.glow_intensity = ImLerp(it_anim->second.glow_intensity,
			is_active ? 1.f : (hovered ? 0.5f : 0.f), dt * 8.f);

		it_anim->second.press_scale = easing->easing_in_out<float>(
			id * 22, held, 1.f, 0.93f, dt * 30.f, interpolation_type::back);

		it_anim->second.icon_scale = easing->easing_in_out<float>(
			id * 23, is_active || hovered, 0.9f, 1.05f, dt * 10.f, interpolation_type::back);

		it_anim->second.indicator_width = ImLerp(it_anim->second.indicator_width,
			is_active ? 3.f : (hovered ? 1.f : 0.f), dt * 14.f);

		it_anim->second.frame_col = ImLerp(it_anim->second.frame_col,
			is_active ? ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.25f + it_anim->second.hover_pulse).Value) :
			hovered ? ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.12f + it_anim->second.hover_pulse * 0.5f).Value) :
			ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.f).Value), dt * 8.f);

		it_anim->second.dark_col = ImLerp(it_anim->second.dark_col,
			is_active ? ImVec4(utils::GetColorWithAlpha(c::dark_color, 0.08f).Value) :
			ImVec4(utils::GetColorWithAlpha(c::dark_color, 0.f).Value), dt * 8.f);

		it_anim->second.text_col = ImLerp(it_anim->second.text_col,
			is_active ? ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.f).Value) :
			hovered ? ImVec4(c::text::label::hovered.Value) :
			ImVec4(c::label::default_col.Value), dt * 8.f);

		it_anim->second.icon_col = ImLerp(it_anim->second.icon_col,
			is_active ? ImVec4(c::anim::active.Value) :
			hovered ? ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.85f).Value) :
			ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.5f).Value), dt * 8.f);

		float target_size = is_active ? font::regular_l->FontSize : font::regular_l->FontSize - 10.f;
		it_anim->second.icon_size = ImLerp(it_anim->second.icon_size, target_size, dt * 4.f);

		ImVec2 center = total_bb.GetCenter();
		float centering_scale = it_anim->second.press_scale;
		ImVec2 draw_min = center - (total_bb.GetSize() * 0.5f * centering_scale);
		ImVec2 draw_max = center + (total_bb.GetSize() * 0.5f * centering_scale);
		ImRect scaled_bb(draw_min, draw_max);

		if (it_anim->second.glow_intensity > 0.01f) {
			for (int i = 0; i < 2; i++) {
				float expand = (2.f + i * 2.f) * it_anim->second.glow_intensity;
				ImVec2 g_min = scaled_bb.Min - ImVec2(expand, expand);
				ImVec2 g_max = scaled_bb.Max + ImVec2(expand, expand);
				window->DrawList->AddShadowRect(g_min, g_max,
					ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active,
						it_anim->second.glow_intensity * (0.2f - i * 0.08f))),
					15.f, ImVec2(0, 0),
					ImDrawFlags_RoundCornersAll | ImDrawFlags_ShadowCutOutShapeBackground, 5.f);
			}
		}

		window->DrawList->AddRectFilledMultiColor(scaled_bb.Min, scaled_bb.Max,
			ImGui::GetColorU32(utils::GetColorWithAlpha(it_anim->second.frame_col, 0.f)),
			ImGui::GetColorU32(utils::GetColorWithAlpha(it_anim->second.frame_col, 0.f)),
			GetColorU32(it_anim->second.frame_col),
			GetColorU32(it_anim->second.frame_col), 5);

		float icon_sz = it_anim->second.icon_size * it_anim->second.icon_scale;
		ImVec2 font_sz_offset(icon_sz - font::regular_l->FontSize, icon_sz - font::regular_l->FontSize);

		PushFont(font::regular_l);
		fade_text_smooth_id(
			window->DrawList,
			icon,
			utils::center_text(scaled_bb.Min, scaled_bb.Max, icon) - ImVec2(0, it_anim->second.text_offset) - font_sz_offset / 2,
			ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, it_anim->second.icon_col.w)),
			ImGui::GetColorU32(utils::GetColorWithAlpha(c::dark_color, it_anim->second.icon_col.w)),
			id,
			font::regular_l,
			icon_sz);
		PopFont();

		if (it_anim->second.indicator_width > 0.3f) {
			float iw = it_anim->second.indicator_width;
			ImVec2 ind_min(scaled_bb.GetCenter().x - iw * 4, scaled_bb.Max.y - 4);
			ImVec2 ind_max(scaled_bb.GetCenter().x + iw * 4, scaled_bb.Max.y - 1);

			window->DrawList->AddShadowRect(ind_min - ImVec2(1, 1), ind_max + ImVec2(1, 1),
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, it_anim->second.indicator_width / 3.f * 0.6f)),
				6.f, ImVec2(0, 0), 0, 1.5f);
			fade_rect_filled(window->DrawList, ind_min, ind_max,
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, it_anim->second.glow_intensity)),
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::dark_color, it_anim->second.glow_intensity)),
				fade_direction::horizontally, 1.5f, 0, true);
		}

		window->DrawList->AddText(
			utils::center_text(scaled_bb.Min, scaled_bb.Max, label) + ImVec2(0, 20),
			GetColorU32(it_anim->second.text_col),
			label);

		static std::map<ImGuiID, bool> hover_particle_trigger;
		auto& hover_trigger = hover_particle_trigger[id];

		if (hovered && !hover_trigger) {
			for (int i = 0; i < particle::PARTICLE_COUT / 4; ++i)
				particle::AddParticle(center, ImVec2(2, 2), 0);
			hover_trigger = true;
		} else if (!hovered) {
			hover_trigger = false;
		}

		if (pressed) {
			for (int i = 0; i < particle::PARTICLE_COUT; ++i)
				particle::AddParticle(center, ImVec2(3, 3) / 10, 0);
		}

		return pressed;
	}

	struct subtab_state {
		ImVec4 text_col;
		ImVec4 frame_col;
		ImVec4 line_col;
	};

	bool SubTab(const char* label, int* v, int number, ImColor color)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems)
			return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		const ImGuiID id = window->GetID(label);

		const float square_sz = GetFrameHeight();
		const ImVec2 pos = window->DC.CursorPos;
		const ImRect total_bb(pos, pos + ImVec2(20 + CalcTextSize(label).x, 25));


		ItemSize(total_bb, style.FramePadding.y);
		ItemAdd(total_bb, id);

		static std::map<ImGuiID, subtab_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end())
		{
			anim.insert({ id, subtab_state() });
			it_anim = anim.find(id);
		}

		bool hovered, held;
		bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);
		if (pressed)
		{
			*v = number;
		}

		RenderNavHighlight(total_bb, id);

		it_anim->second.frame_col = ImLerp(it_anim->second.frame_col, *v == number ? color : utils::GetColorWithAlpha(color, 0.f), GetAnimSpeed());
		it_anim->second.text_col = ImLerp(it_anim->second.text_col, *v == number ? color : c::label::active, GetAnimSpeed());

		window->DrawList->AddRectFilled(total_bb.Min, total_bb.Max, GetColorU32(it_anim->second.frame_col), style.FrameRounding);

		window->DrawList->AddText(utils::center_text(total_bb.Min, total_bb.Max, label), ImGui::GetColorU32(c::label::active.Value), label);

		return pressed;
	}

	struct arrow_state {
		ImVec4 arrow_col;
		ImVec4 frame_col;
	};

	bool ArrowButton(const char* label, ImGuiDir dir)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems)
			return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		const ImGuiID id = window->GetID(label);

		const float square_sz = GetFrameHeight();
		const ImVec2 pos = window->DC.CursorPos;
		const ImRect total_bb(pos, pos + ImVec2(20, 20));

		ItemSize(total_bb, style.FramePadding.y);
		ItemAdd(total_bb, id);

		static std::map<ImGuiID, arrow_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end())
		{
			anim.insert({ id, arrow_state() });
			it_anim = anim.find(id);
		}

		bool hovered, held;
		bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);

		RenderNavHighlight(total_bb, id);

		it_anim->second.frame_col = ImLerp(it_anim->second.frame_col, hovered ? ImVec4(c::anim::active.Value) : ImVec4(utils::GetColorWithAlpha(c::anim::active, 0.f).Value), GetAnimSpeed());
		it_anim->second.arrow_col = ImLerp(it_anim->second.arrow_col, hovered ? ImVec4(utils::GetDarkColor(c::anim::active).Value) : ImVec4(c::anim::active.Value), GetAnimSpeed());

		window->DrawList->AddRectFilled(total_bb.Min, total_bb.Max, GetColorU32(it_anim->second.frame_col), c::elements::rounding);

		PushFont(font::icomoon_page);
		window->DrawList->AddText(utils::center_text(total_bb.Min, total_bb.Max, dir == ImGuiDir_Right ? "r" : dir == ImGuiDir_Left ? "l" : dir == ImGuiDir_Up ? "u" : "d"), GetColorU32(it_anim->second.arrow_col), dir == ImGuiDir_Right ? "r" : dir == ImGuiDir_Left ? "l" : dir == ImGuiDir_Up ? "u" : "d");
		PopFont();

		return IsItemClicked();
	}
	
	struct check_state
	{
		float t;
		float check_t;
		float bg_anim;
		float gradient_anim;
		float hover_anim;
		ImVec4 bg_color;
		ImVec4 text_color;
		ImVec4 check_color;
		ImRect check_bb;
		bool hover_flags = false;

		float total_offset = -400.f;
		float total_alpha = 0.f;
		float timer;
		bool is_visible, can_view;
	};


	bool Checkbox(const char* label, bool* v)
	{
		ImGuiWindow* window = ImGui::GetCurrentWindow();
		if(window->SkipItems && tab_want_to_change) return false;

		ImGuiContext& g = *GImGui;
		const ImGuiID id = window->GetID(label);

		const float box = 22.0f;
		const float gap = 14.0f;
		const ImVec2 label_size = ImGui::CalcTextSize(label);
		const ImVec2 pos = window->DC.CursorPos;

		static std::map<ImGuiID, check_state> anim;
		auto& state = anim[id];

		const ImVec2 total_size(box + gap + label_size.x, box + 8);
		const ImRect total_bb(pos, pos + total_size);
		ItemSize(total_bb, 0.0f);
		ItemAdd(total_bb, id);

		bool hovered, held;
		bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);

		float dt = ImGui::GetIO().DeltaTime;
		float time = ImGui::GetTime();
		{
			ImDrawList* draw = ImGui::GetWindowDrawList();

			ImVec2 center(total_bb.Min.x + box / 2 + 2, total_bb.Min.y + total_size.y / 2);
			float r = box / 2.f;
			float rounding = 5.f;

			float check_t = ImClamp(state.t + ((*v ? 1.f : 0.f) - state.t) * dt * 8.f, 0.f, 1.f);
			state.t = check_t;
			float hover_t = easing->easing_in_out<float>(id * 31, hovered, 0.f, 1.f, dt * 14.f, interpolation_type::back);

			float scale = 1.f + hover_t * 0.05f;
			float sr = r * scale;

			ImVec2 box_min(center.x - sr, center.y - sr);
			ImVec2 box_max(center.x + sr, center.y + sr);

			if (hover_t > 0.01f && !*v) {
				draw->AddShadowRect(box_min - ImVec2(3, 3), box_max + ImVec2(3, 3),
					ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, hover_t * 0.15f)), 8.f, ImVec2(0, 0),
					ImDrawFlags_RoundCornersAll | ImDrawFlags_ShadowCutOutShapeBackground, rounding);
			}

			draw->AddRectFilled(box_min, box_max, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::default_col, 0.8f)), rounding);

			if (check_t > 0.01f) {
				int vtx_start = draw->VtxBuffer.Size;
				draw->AddRectFilled(box_min, box_max, ImColor(1.f, 1.f, 1.f, 1.f), rounding);
				int vtx_end = draw->VtxBuffer.Size;

				float phase = time * 0.4f;
				float angle = ImDegToRad(phase * 360.f);
				set_linear_color(draw, vtx_start, vtx_end, box_min, box_max,
					ImGui::GetColorU32(c::anim::active.Value),
					ImGui::GetColorU32(c::dark_color.Value), angle);

				for (int v = vtx_start; v < vtx_end; v++) {
					ImU32& col = draw->VtxBuffer[v].col;
					int a = (col >> 24) & 0xFF;
					a = (int)(a * check_t);
					col = (col & 0x00FFFFFF) | (a << 24);
				}

				float glow = sinf(time * 2.5f) * 0.05f + 0.12f;
				draw->AddShadowRect(box_min - ImVec2(2, 2), box_max + ImVec2(2, 2),
					ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, glow * check_t)), 8.f, ImVec2(0, 0),
					ImDrawFlags_RoundCornersAll | ImDrawFlags_ShadowCutOutShapeBackground, rounding);
			}

			if (check_t > 0.01f) {
				float p = ImClamp(check_t, 0.f, 1.f);
				float cr = sr * 0.4f;

				float cx1 = center.x - cr * 0.55f;
				float cy1 = center.y + cr * 0.05f;
				float cx2 = center.x - cr * 0.05f;
				float cy2 = center.y + cr * 0.5f;
				float cx3 = center.x + cr * 0.65f;
				float cy3 = center.y - cr * 0.4f;

				float dx1 = cx1 + (center.x - cx1) * (1.f - p);
				float dy1 = cy1 + (center.y - cy1) * (1.f - p);

				ImVec2 da(dx1, dy1);
				ImVec2 db(cx2, cy2);
				ImVec2 dc(cx2 + (cx3 - cx2) * p, cy2 + (cy3 - cy2) * p);

				float ca = ImClamp(p, 0.f, 1.f);
				float blend = sinf(time * 0.4f) * 0.5f + 0.5f;
				ImU32 c1 = ImGui::GetColorU32(c::anim::active.Value);
				ImU32 c2 = ImGui::GetColorU32(c::dark_color.Value);
				ImU32 cc = ImLerpColor(c1, c2, blend);
				int a = (int)(ca * 255.f);
				cc = (cc & 0x00FFFFFF) | (a << 24);

				draw->AddLine(da, db, cc, 2.5f);
				draw->AddLine(db, dc, cc, 2.5f);
			}

			float text_x = total_bb.Min.x + box + gap;
			float text_y = center.y - label_size.y * 0.5f;
			state.text_color = ImLerp(state.text_color,
				held ? c::text::label::active : hovered ? c::text::label::hovered : c::text::label::default_col, dt * 10.f);
			draw->AddText(ImVec2(text_x, text_y), ImGui::GetColorU32(state.text_color), label);

			if (IsItemClicked())
			{
				*v = !(*v);
				MarkItemEdited(id);
			}
		}
		return pressed;
	}


	struct checkboxclicked_state
	{
		ImVec4 text_color_offset;
		ImVec4 rect_color;
		ImVec4 circle_color;
		float circle_offset;
	};

	bool CheckboxClicked(const char* label, bool* v)
	{
		ImGuiWindow* window = GetCurrentWindow();
		std::string name = label;

		if (window->SkipItems)
			return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		const ImGuiID id = window->GetID(label);

		static std::map<ImGuiID, checkboxclicked_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end())
		{
			anim.insert({ id, checkboxclicked_state() });
			it_anim = anim.find(id);
		}

		const float square_sz = GetFrameHeight();
		const ImVec2 pos = window->DC.CursorPos;
		ImRect total_bb(pos, pos + ImVec2(75 + CalcTextSize(label).x, 50));

		ItemSize(total_bb, style.FramePadding.y);
		ItemAdd(total_bb, id);


		bool hovered, held;
		bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);
		if (pressed) *v = !(*v);

		it_anim->second.circle_offset = ImLerp(it_anim->second.circle_offset, *v ? 20.f : 0.f, GetAnimSpeed());
		it_anim->second.rect_color = ImLerp(it_anim->second.rect_color, *v ? ImVec4(c::anim::active.Value) : ImVec4(0.1f, 0.1f, 0.1f, 0.5f), GetAnimSpeed());
		it_anim->second.circle_color = ImLerp(it_anim->second.circle_color, *v ? ImVec4(1.f, 1.f, 1.f, 1.f) : ImVec4(0.6f, 0.6f, 0.6f, 1.f), GetAnimSpeed());
		it_anim->second.text_color_offset = ImLerp(it_anim->second.text_color_offset, *v ? ImVec4(0.f, 0.f, 0.f, 0.0f) : ImVec4(0.f, 0.f, 0.f, 0.5f), GetAnimSpeed());

		window->DrawList->AddRectFilled(total_bb.Max - ImVec2(60, 35), total_bb.Max - ImVec2(20, 15), GetColorU32(it_anim->second.rect_color), 25);
		window->DrawList->AddCircleFilled(total_bb.Max - ImVec2(50 - it_anim->second.circle_offset, 25), 7.f, GetColorU32(it_anim->second.circle_color), 60);

		window->DrawList->AddText(ImVec2(total_bb.Min.x + 5.f, utils::center_text(total_bb.Min, total_bb.Max, label).y), ImGui::GetColorU32(c::label::active.Value), label);
		return pressed;
	}

	static float CalcMaxPopupHeightFromItemCount(int items_count)
	{
		ImGuiContext& g = *GImGui;
		if (items_count <= 0)
			return FLT_MAX;
		return (g.FontSize + g.Style.ItemSpacing.y) * items_count - g.Style.ItemSpacing.y + (g.Style.WindowPadding.y * 2);
	}

	struct begin_state
	{
		ImVec4 background, text, icon_col;
		float open, alpha, combo_size = 0.f, shadow_opticaly;
		bool opened_combo = false, hovered = false;
		float arrow_roll;
		
		float total_offset = -400.f;
		float total_alpha = 0.f;
		float timer;
		bool is_visible, can_view;
	};

	bool BeginCombo(const char* label, const char* preview_value, int val, bool multi, ImGuiComboFlags flags)
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = GetCurrentWindow();

		g.NextWindowData.ClearFlags();
		if (window->SkipItems) return false;

		const ImGuiStyle& style = g.Style;
		const ImGuiID id = window->GetID(label);

		static std::map<ImGuiID, begin_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end())
		{
			anim.insert({ id, begin_state() });
			it_anim = anim.find(id);
		}

		const ImVec2 pos = window->DC.CursorPos + ImVec2(it_anim->second.total_offset, 0);

		const ImVec2 label_size = CalcTextSize(label, NULL, true);
		const float w = GetContentRegionAvail().x;

		const ImRect total_bb(pos, pos + ImVec2(w, 28));

		float preview_value_size = CalcTextSize(preview_value).x;

		const ImRect bb_box(total_bb.Max - ImVec2(preview_value_size + 55, total_bb.GetHeight()), total_bb.Max);

		float box_offset = bb_box.Max.x - ImGui::GetCurrentWindow()->Size.x / 2 - 10;

		const ImRect bb(ImVec2(total_bb.Min.x + CalcTextSize(label).x + 10 < box_offset ? box_offset : total_bb.Min.x + CalcTextSize(label).x + 10, bb_box.Min.y), bb_box.Max);

		ItemSize(total_bb, 0.f);

		ItemAdd(total_bb, id, &bb);

		bool hovered, held, pressed = ButtonBehavior(total_bb, id, &hovered, &held);


		static ImDrawList* child_dl;
		static ImVec2 tooltip_pos;

		it_anim->second.is_visible = !tab_want_to_change;
		if (tab_want_to_change || ImGui::GetWindowSize().y < 35) {
			it_anim->second.total_offset = GetAnimOffset();
			it_anim->second.total_alpha = 0.f;
			it_anim->second.timer = 0.f;
		}
		it_anim->second.timer += ImGui::GetIO().DeltaTime;
		float relative = (total_bb.GetCenter().y - ImGui::GetWindowPos().y) / ImGui::GetWindowSize().y;
		float delay = 0.1f + relative * 0.9f;
		float t = ImClamp((it_anim->second.timer - delay) / 0.3f, 0.f, 1.f);
		it_anim->second.total_offset = ImLerp(it_anim->second.total_offset, 0.f, ImGui::GetIO().DeltaTime * t * 4);
		it_anim->second.total_alpha = ImLerp(it_anim->second.total_alpha, ImGui::GetStyle().Alpha, ImGui::GetIO().DeltaTime * t * 3);


		if (hovered && g.IO.MouseClicked[0] || it_anim->second.opened_combo && g.IO.MouseClicked[0] && !it_anim->second.hovered)
		{
			it_anim->second.opened_combo = !it_anim->second.opened_combo;

			if (it_anim->second.opened_combo) {
				tooltip_pos = g.IO.MousePos;
			}
		}
		it_anim->second.arrow_roll = ImLerp(it_anim->second.arrow_roll, it_anim->second.opened_combo ? -1.f : 1.f, g.IO.DeltaTime * 6.f);
		it_anim->second.text = ImLerp(it_anim->second.text, it_anim->second.opened_combo ? ImVec4(c::text::label::active.Value) : hovered ? ImVec4(c::text::label::hovered.Value) : ImVec4(c::text::label::default_col.Value), GetAnimSpeed());
		it_anim->second.background = ImLerp(it_anim->second.background, it_anim->second.opened_combo ? ImVec4(c::second_color.Value) : ImVec4(c::elements::background), g.IO.DeltaTime * 6.f);
		//it_anim->second.combo_size = ImLerp(it_anim->second.combo_size, it_anim->second.opened_combo ? (val * 32) + 25 : 0.f, g.IO.DeltaTime * 12.f);

		it_anim->second.combo_size = easing->easing_in_out<float>(id * 12, !it_anim->second.opened_combo, (val * 32) + 25, 0.2f, g.IO.DeltaTime * 15.f, interpolation_type::back);
		it_anim->second.alpha = easing->easing_in_out<float>(id * 13, !it_anim->second.opened_combo, 1.f, 0.f, g.IO.DeltaTime * 15.f, interpolation_type::back);

		it_anim->second.icon_col = ImLerp(it_anim->second.icon_col, it_anim->second.opened_combo ? ImVec4(c::anim::active.Value) : hovered ? ImVec4(c::description::hovered.Value) : ImVec4(c::description::default_col.Value), GetAnimSpeed());
		
		PushStyleVar(ImGuiStyleVar_Alpha, it_anim->second.total_alpha);
		GetWindowDrawList()->AddText(ImVec2(total_bb.Min.x, utils::center_text(total_bb.Min, total_bb.Max, label).y), GetColorU32(it_anim->second.text), label);
		GetWindowDrawList()->AddRectFilled(bb_box.Min, bb_box.Max, ImGui::GetColorU32(c::anim::default_col.Value), c::elements::rounding);

		PushClipRect(bb.Min, bb.Max, true);
		GetWindowDrawList()->AddText(ImVec2(bb_box.Min.x + 10.f, utils::center_text(total_bb.Min, total_bb.Max, preview_value).y), ImGui::GetColorU32(utils::GetColorWithAlpha(c::label::active, style.Alpha)), preview_value);
		PopClipRect();

		GetWindowDrawList()->AddRectFilled(ImVec2(bb.Max.x - 11.f - CalcTextSize(ICON_DOWN_LINE).x, bb.Min.y), ImVec2(bb.Max.x - 10.f - CalcTextSize(ICON_DOWN_LINE).x, bb.Max.y), ImGui::GetColorU32(utils::GetColorWithAlpha(c::text::label::default_col, 0.1f)), 0.f);

		ImRotateStart();
		GetWindowDrawList()->AddText(ImVec2(bb.Max.x - 5.f - CalcTextSize(ICON_DOWN_FILL).x, bb.GetCenter().y - CalcTextSize(ICON_DOWN_FILL).y / 2), GetColorU32(it_anim->second.icon_col), ICON_DOWN_FILL);
		ImRotateEnd(1.57f * it_anim->second.arrow_roll);

		PopStyleVar();

		ImVec2 viewport_size = ImGui::GetMainViewport()->Size;
		ImVec2 viewport_pos = ImGui::GetMainViewport()->Pos;

		// Проверяем видимость прямоугольника
		if (!IsRectVisible(bb.Min, bb.Max + ImVec2(0, 2))) {
			it_anim->second.opened_combo = false;
			it_anim->second.combo_size = 0.f;
		}

		if (!it_anim->second.opened_combo && it_anim->second.combo_size < 1.f)
			return false;

		ImVec2 window_size = ImVec2(bb.GetWidth(), it_anim->second.combo_size);
		ImVec2 window_pos = tooltip_pos;

		if (window_pos.x + window_size.x > viewport_pos.x + viewport_size.x) {
			window_pos.x = (viewport_pos.x + viewport_size.x) - window_size.x; // Сдвигаем влево
		}

		// Сдвиг по оси Y, если окно выходит за нижнюю границу
		if (window_pos.y + window_size.y > viewport_pos.y + viewport_size.y) {
			window_pos.y = (viewport_pos.y + viewport_size.y) - window_size.y; // Сдвигаем вверх
		}

		// Сдвиг по оси Y, если окно выходит за верхнюю границу
		if (window_pos.y < viewport_pos.y) {
			window_pos.y = viewport_pos.y; // Сдвигаем вниз
		}

		// Устанавливаем позицию перед открытием окна
		SetNextWindowPos(window_pos, ImGuiCond_Always);

		// Устанавливаем размер окна
		ImGui::SetNextWindowSize(window_size, ImGuiCond_Always);

		ImGuiWindowFlags window_flags = ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoScrollWithMouse;

		PushStyleColor(ImGuiCol_WindowBg, utils::ImColorToImVec4(c::background_color));
		PushStyleColor(ImGuiCol_BorderShadow, ImVec4(0.f, 0.f, 0.f, 1.f));
		PushStyleVar(ImGuiStyleVar_Alpha, it_anim->second.alpha);
		PushStyleVar(ImGuiStyleVar_WindowRounding, c::bg::rounding);
		PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(15, 15));
		PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
		
		ImGui::SetNextWindowFocus();
		// Открываем окно
		bool ret = Begin(label, NULL, window_flags);

		PushClipRect(ImVec2(0, 0), ImVec2(4000, 4000), false);
		ImGui::GetWindowDrawList()->AddShadowRect(ImGui::GetWindowPos(), ImGui::GetWindowPos() + ImGui::GetWindowSize(), ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, it_anim->second.alpha / 1.5f)), 65.f, ImVec2(0, 0), 0, c::elements::rounding);
		PopClipRect();

		PopStyleVar(3);
		PopStyleColor(2);

		it_anim->second.hovered = IsWindowHovered();

		if (multi && it_anim->second.hovered && g.IO.MouseClicked[0]) it_anim->second.opened_combo = false;

		return true;
	}

	void EndCombo()
	{
		End();
		PopStyleVar();
	}

	void MultiCombo(const char* label, bool variable[], const char* labels[], int count)
	{
		ImGuiContext& g = *GImGui;

		std::string preview = "None";

		for (auto i = 0, j = 0; i < count; i++)
		{
			if (variable[i])
			{
				if (j)
					preview += (", ") + (std::string)labels[i];
				else
					preview = labels[i];

				j++;
			}
		}

		if (BeginCombo(label, preview.c_str(), count))
		{
			ImGui::SetWindowFocus();
			for (auto i = 0; i < count; i++)
			{
				PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(15, 15));
				PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(15, 15));
				custom::Selectable(labels[i], &variable[i], ImGuiSelectableFlags_DontClosePopups);
				PopStyleVar(2);
			}
			End();
		}

		preview = ("None");
	}

	bool BeginComboPreview()
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;
		ImGuiComboPreviewData* preview_data = &g.ComboPreviewData;

		if (window->SkipItems || !(g.LastItemData.StatusFlags & ImGuiItemStatusFlags_Visible)) return false;

		IM_ASSERT(g.LastItemData.Rect.Min.x == preview_data->PreviewRect.Min.x && g.LastItemData.Rect.Min.y == preview_data->PreviewRect.Min.y);

		if (!window->ClipRect.Overlaps(preview_data->PreviewRect)) return false;

		preview_data->BackupCursorPos = window->DC.CursorPos;
		preview_data->BackupCursorMaxPos = window->DC.CursorMaxPos;
		preview_data->BackupCursorPosPrevLine = window->DC.CursorPosPrevLine;
		preview_data->BackupPrevLineTextBaseOffset = window->DC.PrevLineTextBaseOffset;
		preview_data->BackupLayout = window->DC.LayoutType;
		window->DC.CursorPos = preview_data->PreviewRect.Min + g.Style.FramePadding;
		window->DC.CursorMaxPos = window->DC.CursorPos;
		window->DC.LayoutType = ImGuiLayoutType_Horizontal;
		window->DC.IsSameLine = false;
		PushClipRect(preview_data->PreviewRect.Min, preview_data->PreviewRect.Max, true);

		return true;
	}

	void EndComboPreview()
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;
		ImGuiComboPreviewData* preview_data = &g.ComboPreviewData;

		ImDrawList* draw_list = window->DrawList;
		if (window->DC.CursorMaxPos.x < preview_data->PreviewRect.Max.x && window->DC.CursorMaxPos.y < preview_data->PreviewRect.Max.y)
			if (draw_list->CmdBuffer.Size > 1)
			{
				draw_list->_CmdHeader.ClipRect = draw_list->CmdBuffer[draw_list->CmdBuffer.Size - 1].ClipRect = draw_list->CmdBuffer[draw_list->CmdBuffer.Size - 2].ClipRect;
				draw_list->_TryMergeDrawCmds();
			}
		PopClipRect();
		window->DC.CursorPos = preview_data->BackupCursorPos;
		window->DC.CursorMaxPos = ImMax(window->DC.CursorMaxPos, preview_data->BackupCursorMaxPos);
		window->DC.CursorPosPrevLine = preview_data->BackupCursorPosPrevLine;
		window->DC.PrevLineTextBaseOffset = preview_data->BackupPrevLineTextBaseOffset;
		window->DC.LayoutType = preview_data->BackupLayout;
		window->DC.IsSameLine = false;
		preview_data->PreviewRect = ImRect();
	}

	static const char* Items_ArrayGetter(void* data, int idx)
	{
		const char* const* items = (const char* const*)data;
		return items[idx];
	}

	static const char* Items_SingleStringGetter(void* data, int idx)
	{
		const char* items_separated_by_zeros = (const char*)data;
		int items_count = 0;
		const char* p = items_separated_by_zeros;
		while (*p)
		{
			if (idx == items_count)
				break;
			p += strlen(p) + 1;
			items_count++;
		}
		return *p ? p : NULL;
	}

	bool Combo(const char* label, int* current_item, const char* (*getter)(void* user_data, int idx), void* user_data, int items_count, int popup_max_height_in_items)
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems) return false;

		const ImGuiID id = window->GetID(label);
		const ImVec2 pos = window->DC.CursorPos;
		const float avail_w = GetContentRegionAvail().x;
		const float row_h = 36.f;
		const ImRect total_bb(pos, pos + ImVec2(avail_w, row_h));

		ItemSize(total_bb, 0.f);
		if (!ItemAdd(total_bb, id)) return false;

		bool hovered = false, held = false;
		bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);

		const char* preview_value = "";
		if (*current_item >= 0 && *current_item < items_count)
			preview_value = getter(user_data, *current_item);
		if (!preview_value) preview_value = "";

		// Selector Box on the right
		float box_w = ImClamp(avail_w * 0.54f, 130.f, 260.f);
		float box_h = 28.f;
		ImVec2 box_min(total_bb.Max.x - box_w, pos.y + (row_h - box_h) * 0.5f);
		ImVec2 box_max(total_bb.Max.x, box_min.y + box_h);

		char popup_id[64];
		snprintf(popup_id, sizeof(popup_id), "##cb_pop_%08X", (unsigned int)id);

		if (pressed) {
			ImGui::OpenPopup(popup_id);
		}

		bool is_popup_open = ImGui::IsPopupOpen(popup_id);

		// Render row
		ImDrawList* dl = window->DrawList;
		float alpha = GetStyle().Alpha;

		// Label on the left
		ImVec2 l_sz = CalcTextSize(label);
		dl->AddText(ImVec2(total_bb.Min.x, pos.y + (row_h - l_sz.y) * 0.5f),
			ImGui::GetColorU32(ImVec4(0.85f, 0.88f, 0.95f, alpha)), label);

		// Box on the right
		ImU32 box_bg = ImGui::GetColorU32(ImVec4(0.06f, 0.08f, 0.12f, 0.95f * alpha));
		ImU32 box_border = is_popup_open 
			? ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.95f * alpha))
			: (hovered ? ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.30f * alpha)) : ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.12f * alpha)));

		dl->AddRectFilled(box_min, box_max, box_bg, 7.f);
		dl->AddRect(box_min, box_max, box_border, 7.f, 0, is_popup_open ? 1.5f : 1.0f);

		// Arrow icon on far right of box
		const char* arrow_ico = is_popup_open ? ICON_ARROW_UP_FILL : ICON_ARROW_DOWN_FILL;
		PushFont(font::inter_bold);
		ImVec2 arr_sz = CalcTextSize(arrow_ico);
		ImVec2 arr_pos(box_max.x - arr_sz.x - 8.f, box_min.y + (box_h - arr_sz.y) * 0.5f);
		dl->AddText(arr_pos, is_popup_open ? ImGui::GetColorU32(c::anim::active) : ImGui::GetColorU32(ImVec4(0.6f, 0.65f, 0.75f, alpha)), arrow_ico);

		// Preview text (clipped before arrow)
		dl->PushClipRect(ImVec2(box_min.x + 8.f, box_min.y), ImVec2(arr_pos.x - 4.f, box_max.y), true);
		ImVec2 pr_sz = CalcTextSize(preview_value);
		dl->AddText(ImVec2(box_min.x + 8.f, box_min.y + (box_h - pr_sz.y) * 0.5f),
			ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.95f * alpha)), preview_value);
		dl->PopClipRect();
		PopFont();

		// Popup Menu with Radio Selection Markers
		bool value_changed = false;
		float pop_w_req = ImMax(box_w + 60.f, 220.f);
		float est_pop_h = items_count * 37.f + 16.f;
		ImVec2 pop_pos(box_min.x, box_max.y + 4.f);
		if (pop_pos.y + est_pop_h > ImGui::GetIO().DisplaySize.y - 10.f) {
			pop_pos.y = ImMax(10.f, box_min.y - est_pop_h - 4.f);
		}
		ImGui::SetNextWindowPos(pop_pos, ImGuiCond_Always);
		ImGui::SetNextWindowSize(ImVec2(pop_w_req, 0.f), ImGuiCond_Always);

		PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.015f, 0.018f, 0.026f, 0.98f));
		PushStyleColor(ImGuiCol_Border, utils::ImColorToImVec4(c::anim::active));
		PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8.f, 8.f));
		PushStyleVar(ImGuiStyleVar_WindowRounding, 8.f);
		PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.2f);
		PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.f, 2.f));

		if (ImGui::BeginPopup(popup_id, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_AlwaysAutoResize)) {
			ImDrawList* pop_dl = ImGui::GetWindowDrawList();
			float pop_avail_w = GetContentRegionAvail().x;

			for (int i = 0; i < items_count; i++) {
				const char* item_text = getter(user_data, i);
				if (!item_text) item_text = "";

				bool is_sel = (i == *current_item);
				ImVec2 row_p0 = GetCursorScreenPos();
				ImVec2 row_p1 = row_p0 + ImVec2(pop_avail_w, 34.f);
				ImRect row_bb(row_p0, row_p1);

				PushID(i);
				ImGuiID opt_id = GetID("##opt");
				ItemSize(ImVec2(pop_avail_w, 34.f), 0.f);
				if (!ItemAdd(row_bb, opt_id)) {
					PopID();
					continue;
				}

				bool opt_hov = false, opt_held = false;
				bool opt_pressed = ButtonBehavior(row_bb, opt_id, &opt_hov, &opt_held);
				if (!opt_pressed && opt_hov && ImGui::IsMouseClicked(0)) {
					opt_pressed = true;
				}

				// Background highlight
				if (is_sel) {
					pop_dl->AddRectFilled(row_p0, row_p1, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.22f)), 6.f);
				} else if (opt_hov) {
					pop_dl->AddRectFilled(row_p0, row_p1, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.07f)), 6.f);
				}

				// Radio Circle Indicator
				ImVec2 rad_center(row_p0.x + 14.f, row_p0.y + 17.f);
				float rad_radius = 6.5f;
				if (is_sel) {
					pop_dl->AddCircleFilled(rad_center, rad_radius, ImGui::GetColorU32(c::anim::active), 16);
					pop_dl->AddCircleFilled(rad_center, 2.8f, IM_COL32(255, 255, 255, 255), 12);
				} else {
					pop_dl->AddCircle(rad_center, rad_radius, ImGui::GetColorU32(ImVec4(0.5f, 0.55f, 0.65f, 0.60f)), 16, 1.4f);
				}

				// Item Text
				PushFont(font::inter_bold);
				ImVec2 t_sz = CalcTextSize(item_text);
				pop_dl->AddText(ImVec2(row_p0.x + 28.f, row_p0.y + (34.f - t_sz.y) * 0.5f),
					is_sel ? IM_COL32(255, 255, 255, 255) : ImGui::GetColorU32(ImVec4(0.75f, 0.78f, 0.85f, 0.85f)), item_text);
				PopFont();

				if (opt_pressed) {
					*current_item = i;
					value_changed = true;
					ImGui::CloseCurrentPopup();
				}
				PopID();
			}
			ImGui::EndPopup();
		}

		PopStyleVar(4);
		PopStyleColor(2);

		if (value_changed)
			MarkItemEdited(id);

		return value_changed;
	}

	bool Combo(const char* label, int* current_item, const char* const items[], int items_count, int height_in_items)
	{
		const bool value_changed = Combo(label, current_item, Items_ArrayGetter, (void*)items, items_count, height_in_items);
		return value_changed;
	}

	bool Combo(const char* label, int* current_item, const char* items_separated_by_zeros, int height_in_items)
	{
		int items_count = 0;
		const char* p = items_separated_by_zeros;
		while (*p)
		{
			p += strlen(p) + 1;
			items_count++;
		}
		bool value_changed = Combo(label, current_item, Items_SingleStringGetter, (void*)items_separated_by_zeros, items_count, height_in_items);
		return value_changed;
	}



	struct select_state
	{
		ImVec4 text, background, stroke;
		float circle_radius, text_offset;
		float total_offset;
	};

	bool Selectable(const char* label, bool selected, ImGuiSelectableFlags flags, const ImVec2& size_arg)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems)
			return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;

		ImGuiID id = window->GetID(label);
		ImVec2 label_size = CalcTextSize(label, NULL, true);
		ImVec2 size(size_arg.x != 0.0f ? size_arg.x : label_size.x, size_arg.y != 0.0f ? size_arg.y : label_size.y);
		ImVec2 pos = window->DC.CursorPos;
		pos.y += window->DC.CurrLineTextBaseOffset;

		static std::map<ImGuiID, select_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end())
		{
			anim.insert({ id, select_state() });
			it_anim = anim.find(id);
		}

		ItemSize(size, 0.0f);

		const bool span_all_columns = (flags & ImGuiSelectableFlags_SpanAllColumns) != 0;
		const float min_x = span_all_columns ? window->ParentWorkRect.Min.x : pos.x;
		const float max_x = span_all_columns ? window->ParentWorkRect.Max.x : window->WorkRect.Max.x;
		if (size_arg.x == 0.0f || (flags & ImGuiSelectableFlags_SpanAvailWidth)) size.x = ImMax(label_size.x, max_x - min_x);

		const ImVec2 text_min = pos;
		const ImVec2 text_max(min_x + size.x, pos.y + size.y);

		ImRect bb(min_x + it_anim->second.total_offset, pos.y, text_max.x + it_anim->second.total_offset, text_max.y);
		if ((flags & ImGuiSelectableFlags_NoPadWithHalfSpacing) == 0)
		{
			const float spacing_x = span_all_columns ? 0.0f : style.ItemSpacing.x;
			const float spacing_y = style.ItemSpacing.y;
			const float spacing_L = IM_TRUNC(spacing_x * 0.50f);
			const float spacing_U = IM_TRUNC(spacing_y * 0.50f);
			bb.Min.x -= spacing_L;
			bb.Min.y -= spacing_U;
			bb.Max.x += (spacing_x - spacing_L);
			bb.Max.y += (spacing_y - spacing_U);
		}

		const float backup_clip_rect_min_x = window->ClipRect.Min.x;
		const float backup_clip_rect_max_x = window->ClipRect.Max.x;
		if (span_all_columns)
		{
			window->ClipRect.Min.x = window->ParentWorkRect.Min.x;
			window->ClipRect.Max.x = window->ParentWorkRect.Max.x;
		}

		const bool disabled_item = (flags & ImGuiSelectableFlags_Disabled) != 0;
		const bool item_add = ItemAdd(bb, id, NULL, disabled_item ? ImGuiItemFlags_Disabled : ImGuiItemFlags_None);
		if (span_all_columns)
		{
			window->ClipRect.Min.x = backup_clip_rect_min_x;
			window->ClipRect.Max.x = backup_clip_rect_max_x;
		}

		it_anim->second.total_offset = ImLerp(it_anim->second.total_offset, item_add ? 0.f : 150.f, c::anim::speed / 1.5f);


		if (!item_add) return false;

		const bool disabled_global = (g.CurrentItemFlags & ImGuiItemFlags_Disabled) != 0;
		if (disabled_item && !disabled_global) BeginDisabled();

		if (span_all_columns && window->DC.CurrentColumns) PushColumnsBackground();
		else if (span_all_columns && g.CurrentTable) TablePushBackgroundChannel();

		ImGuiButtonFlags button_flags = 0;
		if (flags & ImGuiSelectableFlags_NoHoldingActiveID) { button_flags |= ImGuiButtonFlags_NoHoldingActiveId; }
		if (flags & ImGuiSelectableFlags_NoSetKeyOwner) { button_flags |= ImGuiButtonFlags_NoSetKeyOwner; }
		if (flags & ImGuiSelectableFlags_SelectOnClick) { button_flags |= ImGuiButtonFlags_PressedOnClick; }
		if (flags & ImGuiSelectableFlags_SelectOnRelease) { button_flags |= ImGuiButtonFlags_PressedOnRelease; }
		if (flags & ImGuiSelectableFlags_AllowDoubleClick) { button_flags |= ImGuiButtonFlags_PressedOnClickRelease | ImGuiButtonFlags_PressedOnDoubleClick; }
		if ((flags & ImGuiSelectableFlags_AllowOverlap) || (g.LastItemData.InFlags & ImGuiItemFlags_AllowOverlap)) { button_flags |= ImGuiButtonFlags_AllowOverlap; }

		const bool was_selected = selected;
		bool hovered, held, pressed = ButtonBehavior(bb, id, &hovered, &held, button_flags);

		if ((flags & ImGuiSelectableFlags_SelectOnNav) && g.NavJustMovedToId != 0 && g.NavJustMovedToFocusScopeId == g.CurrentFocusScopeId)
			if (g.NavJustMovedToId == id)  selected = pressed = true;

		// Update NavId when clicking or when Hovering (this doesn't happen on most widgets), so navigation can be resumed with gamepad/keyboard
		if (pressed || (hovered && (flags & ImGuiSelectableFlags_SetNavIdOnHover)))
		{
			if (!g.NavDisableMouseHover && g.NavWindow == window && g.NavLayer == window->DC.NavLayerCurrent)
			{
				SetNavID(id, window->DC.NavLayerCurrent, g.CurrentFocusScopeId, WindowRectAbsToRel(window, bb)); // (bb == NavRect)
				g.NavDisableHighlight = true;
			}
		}
		if (pressed) MarkItemEdited(id);

		if (selected != was_selected)  g.LastItemData.StatusFlags |= ImGuiItemStatusFlags_ToggledSelection;


		if (g.NavId == id) RenderNavHighlight(bb, id, ImGuiNavHighlightFlags_TypeThin | ImGuiNavHighlightFlags_NoRounding);

		if (span_all_columns && window->DC.CurrentColumns) PopColumnsBackground();
		else if (span_all_columns && g.CurrentTable) TablePopBackgroundChannel();


		it_anim->second.text = ImLerp(it_anim->second.text, selected ? ImVec4(c::label::active.Value) : ImVec4(c::label::default_col.Value), GetAnimSpeed());
		it_anim->second.circle_radius = ImLerp(it_anim->second.circle_radius, selected ? style.Alpha * 3.f : 0.f, GetAnimSpeed());
		it_anim->second.text_offset = ImLerp(it_anim->second.text_offset, selected ? 20.f : 4.5f, GetAnimSpeed());
		it_anim->second.background = ImLerp(it_anim->second.background, selected ? ImVec4(c::background_color.Value) : ImVec4(utils::GetColorWithAlpha(c::background_color, 0.f).Value), GetAnimSpeed());
		it_anim->second.stroke = ImLerp(it_anim->second.stroke, selected ? ImVec4(c::child::stroke) : ImVec4(utils::GetColorWithAlpha(c::child::stroke, 0.f)), GetAnimSpeed());


		//window->DrawList->AddRect(bb.Min, bb.Max, GetColorU32(it_anim->second.stroke), c::elements::rounding);

		window->DrawList->AddCircleFilled(ImVec2(bb.Min.x + 9, bb.GetCenter().y), it_anim->second.circle_radius, c::anim::active);

		window->DrawList->AddText(ImVec2(bb.Min.x + it_anim->second.text_offset, utils::center_text(bb.Min, bb.Max, label).y), ImGui::GetColorU32(utils::GetColorWithAlpha(it_anim->second.text, style.Alpha)), label);

		if (pressed && (window->Flags & ImGuiWindowFlags_Popup) && !(flags & ImGuiSelectableFlags_DontClosePopups) && !(g.LastItemData.InFlags & ImGuiItemFlags_SelectableDontClosePopup)) CloseCurrentPopup();

		if (disabled_item && !disabled_global) EndDisabled();

		return pressed;
	}

	bool Selectable(const char* label, bool* p_selected, ImGuiSelectableFlags flags, const ImVec2& size_arg)
	{
		if (Selectable(label, *p_selected, flags, size_arg))
		{
			*p_selected = !*p_selected;
			return true;
		}
		return false;
	}

	static void ColorEditRestoreH(const float* col, float* H)
	{
		ImGuiContext& g = *GImGui;
		IM_ASSERT(g.ColorEditCurrentID != 0);
		if (g.ColorEditSavedID != g.ColorEditCurrentID || g.ColorEditSavedColor != ImGui::ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], 0)))
			return;
		*H = g.ColorEditSavedHue;
	}

	static void ColorEditRestoreHS(const float* col, float* H, float* S, float* V)
	{
		ImGuiContext& g = *GImGui;
		IM_ASSERT(g.ColorEditCurrentID != 0);
		if (g.ColorEditSavedID != g.ColorEditCurrentID || g.ColorEditSavedColor != ImGui::ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], 0))) return;

		if (*S == 0.0f || (*H == 0.0f && g.ColorEditSavedHue == 1))
			*H = g.ColorEditSavedHue;

		if (*V == 0.0f) *S = g.ColorEditSavedSat;
	}


	struct edit_state
	{
		ImVec4 text;
		ImVec4 icon;
		ImVec4 text_color, description_col;

		float menu_alpha = 0.f;
		bool enabled_popup;


		float total_offset = -400.f;
		float total_alpha = 0.f;
		float timer;
		bool is_visible, can_view;
	};

	bool ColorEdit4(const char* label, float col[4], ImGuiColorEditFlags flags)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		const ImGuiID id = window->GetID(label);

		const float avail_w = GetContentRegionAvail().x;
		const float card_h = 38.f;
		const ImRect total_bb(window->DC.CursorPos, window->DC.CursorPos + ImVec2(avail_w, card_h));

		ItemSize(total_bb, 0.f);
		if (!ItemAdd(total_bb, id)) return false;

		bool hovered, held;
		bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);

		float alpha = style.Alpha;
		ImDrawList* dl = window->DrawList;

		// Card Background
		dl->AddRectFilled(total_bb.Min, total_bb.Max, ImGui::GetColorU32(ImVec4(0.035f, 0.045f, 0.075f, 0.88f * alpha)), 8.f);
		ImU32 border_col = hovered 
			? ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.70f * alpha).Value) 
			: ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.08f * alpha));
		dl->AddRect(total_bb.Min, total_bb.Max, border_col, 8.f, 0, 1.f);

		// Circular colored swatch on left of card (+25% touch size)
		float circ_r = 12.f;
		ImVec2 circ_c(total_bb.Min.x + 20.f, total_bb.GetCenter().y);
		ImVec4 col_v4(col[0], col[1], col[2], (flags & ImGuiColorEditFlags_NoAlpha) ? 1.0f : col[3]);

		// Glow behind color circle
		dl->AddCircleFilled(circ_c, circ_r + 3.f, ImGui::GetColorU32(ImVec4(col[0], col[1], col[2], 0.25f * alpha)), 24);
		// Color circle
		dl->AddCircleFilled(circ_c, circ_r, ImGui::GetColorU32(ImVec4(col[0], col[1], col[2], col_v4.w * alpha)), 24);
		dl->AddCircle(circ_c, circ_r, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.35f * alpha)), 24, 1.2f);

		// Label inside card next to circle
		PushFont(font::inter_medium);
		ImVec2 label_pos(circ_c.x + circ_r + 10.f, total_bb.GetCenter().y - ImGui::GetTextLineHeight() * 0.5f);
		dl->AddText(label_pos, ImGui::GetColorU32(ImVec4(0.88f, 0.90f, 0.96f, (hovered ? 1.0f : 0.85f) * alpha)), label);
		PopFont();

		// Right side: HEX Code Text & Palette Icon
		char hex[16];
		int r = static_cast<int>(col[0] * 255.0f);
		int g_c = static_cast<int>(col[1] * 255.0f);
		int b = static_cast<int>(col[2] * 255.0f);
		snprintf(hex, sizeof(hex), "#%02X%02X%02X", ImClamp(r, 0, 255), ImClamp(g_c, 0, 255), ImClamp(b, 0, 255));

		PushFont(font::small_font);
		ImVec2 pal_sz = CalcTextSize(ICON_PALETTE_LINE);
		ImVec2 hex_sz = CalcTextSize(hex);
		ImU32 icon_col = hovered 
			? ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.95f * alpha).Value) 
			: ImGui::GetColorU32(ImVec4(0.5f, 0.55f, 0.65f, 0.70f * alpha));
		dl->AddText(ImVec2(total_bb.Max.x - pal_sz.x - 12.f, total_bb.GetCenter().y - pal_sz.y * 0.5f), icon_col, ICON_PALETTE_LINE);
		dl->AddText(ImVec2(total_bb.Max.x - pal_sz.x - 18.f - hex_sz.x, total_bb.GetCenter().y - hex_sz.y * 0.5f), ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (hovered ? 0.95f : 0.70f) * alpha)), hex);
		PopFont();

		// Popup Color Picker Modal Window
		char popup_id[64];
		snprintf(popup_id, sizeof(popup_id), "##picker_popup_%u", id);

		if (pressed) {
			ImGui::OpenPopup(popup_id);
		}

		bool value_changed = false;

		ImVec2 dsz = ImGui::GetIO().DisplaySize;
		float pop_x = ImClamp(total_bb.Min.x, 10.f, ImMax(10.f, dsz.x - 295.f));
		ImGui::SetNextWindowPos(ImVec2(pop_x, total_bb.Max.y + 4.f), ImGuiCond_Appearing);
		PushStyleVar(ImGuiStyleVar_WindowRounding, 12.f);
		PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(14.f, 14.f));
		PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.02f, 0.025f, 0.04f, 0.98f));
		PushStyleColor(ImGuiCol_Border, ImVec4(1.0f, 1.0f, 1.0f, 0.14f));

		if (ImGui::BeginPopup(popup_id, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoSavedSettings))
		{
			ImGuiColorEditFlags picker_flags = ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel;
			value_changed |= custom::ColorPicker4("##picker_inner", col, picker_flags);
			ImGui::EndPopup();
		}

		PopStyleColor(2);
		PopStyleVar(2);

		return value_changed;
	}


	// Helper for ColorPicker4()
	static void RenderArrowsForVerticalBar(ImDrawList* draw_list, ImVec2 pos, ImVec2 half_sz, float bar_w, float alpha)
	{
		ImU32 alpha8 = IM_F32_TO_INT8_SAT(alpha);
		ImGui::RenderArrowPointingAt(draw_list, ImVec2(pos.x + half_sz.x + 1, pos.y), ImVec2(half_sz.x + 2, half_sz.y + 1), ImGuiDir_Right, IM_COL32(0, 0, 0, alpha8));
		ImGui::RenderArrowPointingAt(draw_list, ImVec2(pos.x + half_sz.x, pos.y), half_sz, ImGuiDir_Right, IM_COL32(255, 255, 255, alpha8));
		ImGui::RenderArrowPointingAt(draw_list, ImVec2(pos.x + bar_w - half_sz.x - 1, pos.y), ImVec2(half_sz.x + 2, half_sz.y + 1), ImGuiDir_Left, IM_COL32(0, 0, 0, alpha8));
		ImGui::RenderArrowPointingAt(draw_list, ImVec2(pos.x + bar_w - half_sz.x, pos.y), half_sz, ImGuiDir_Left, IM_COL32(255, 255, 255, alpha8));
	}

	struct picker_state
	{
		float hue_bar;
		float alpha_bar;
		float circle;
		ImVec2 circle_move;
	};

	bool ColorPicker4(const char* label, float col[4], ImGuiColorEditFlags flags, const float* ref_col)
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems)
			return false;

		ImDrawList* draw_list = window->DrawList;
		ImGuiStyle& style = g.Style;
		ImGuiIO& io = g.IO;

		const float width = CalcItemWidth();
		g.NextItemData.ClearFlags();

		PushID(label);
		BeginGroup();

		if (!(flags & ImGuiColorEditFlags_NoSidePreview))
			flags |= ImGuiColorEditFlags_NoSmallPreview;

		if (!(flags & ImGuiColorEditFlags_NoOptions))
			ColorPickerOptionsPopup(col, flags);

		// Read stored options
		if (!(flags & ImGuiColorEditFlags_PickerMask_))
			flags |= ((g.ColorEditOptions & ImGuiColorEditFlags_PickerMask_) ? g.ColorEditOptions : ImGuiColorEditFlags_DefaultOptions_) & ImGuiColorEditFlags_PickerMask_;
		if (!(flags & ImGuiColorEditFlags_InputMask_))
			flags |= ((g.ColorEditOptions & ImGuiColorEditFlags_InputMask_) ? g.ColorEditOptions : ImGuiColorEditFlags_DefaultOptions_) & ImGuiColorEditFlags_InputMask_;
		IM_ASSERT(ImIsPowerOfTwo(flags & ImGuiColorEditFlags_PickerMask_)); // Check that only 1 is selected
		IM_ASSERT(ImIsPowerOfTwo(flags & ImGuiColorEditFlags_InputMask_));  // Check that only 1 is selected
		if (!(flags & ImGuiColorEditFlags_NoOptions))
			flags |= (g.ColorEditOptions & ImGuiColorEditFlags_AlphaBar);

		// Setup
		int components = (flags & ImGuiColorEditFlags_NoAlpha) ? 3 : 4;
		bool alpha_bar = (flags & ImGuiColorEditFlags_AlphaBar) && !(flags & ImGuiColorEditFlags_NoAlpha);
		ImVec2 picker_pos = window->DC.CursorPos;
		float square_sz = GetFrameHeight();
		// +25% Enlarged Dimensions for comfortable touch & desktop picking:
		// bars_width was 209.f -> 262.f (+25.3%)
		// sv_h was 129.f       -> 162.f (+25.5%)
		float bars_width = 262.f;
		float sv_h = 162.f;
		float sv_bar_size = 22.f;
		float bar0_pos_x = GetWindowPos().x + style.WindowPadding.x;
		float bar1_pos_x = bar0_pos_x;
		ImVec2 bar_pos = picker_pos + ImVec2(0, sv_h + 8.f);
		float bar0_y = bar_pos.y;
		float bar1_y = bar_pos.y + sv_bar_size + 8.f;

		float backup_initial_col[4];
		memcpy(backup_initial_col, col, components * sizeof(float));

		float H = col[0], S = col[1], V = col[2];
		float R = col[0], G = col[1], B = col[2];
		if (flags & ImGuiColorEditFlags_InputRGB)
		{
			// Hue is lost when converting from greyscale rgb (saturation=0). Restore it.
			ColorConvertRGBtoHSV(R, G, B, H, S, V);
			ColorEditRestoreHS(col, &H, &S, &V);
		}
		else if (flags & ImGuiColorEditFlags_InputHSV)
		{
			ColorConvertHSVtoRGB(H, S, V, R, G, B);
		}

		bool value_changed = false, value_changed_h = false, value_changed_sv = false;

		PushItemFlag(ImGuiItemFlags_NoNav, true);

		// SV rectangle logic
		InvisibleButton("sv", ImVec2(bars_width, sv_h));
		if (IsItemActive())
		{
			S = ImSaturate((io.MousePos.x - picker_pos.x) / (bars_width - 1.f));
			V = 1.0f - ImSaturate((io.MousePos.y - picker_pos.y) / (sv_h - 1.f));

			// Greatly reduces hue jitter and reset to 0 when hue == 255 and color is rapidly modified using SV square.
			if (g.ColorEditSavedColor == ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], 0)))
				H = g.ColorEditSavedHue;
			value_changed = value_changed_sv = true;
		}

		// Hue bar logic
		SetCursorScreenPos(ImVec2(bar0_pos_x, bar0_y));
		InvisibleButton("hue", ImVec2(bars_width, sv_bar_size));
		if (IsItemActive())
		{
			H = 1.f - ImSaturate((io.MousePos.x - bar_pos.x) / (bars_width - 1.f));
			value_changed = value_changed_h = true;
		}

		// Alpha bar logic
		if (alpha_bar)
		{
			SetCursorScreenPos(ImVec2(bar1_pos_x, bar1_y));
			InvisibleButton("alpha", ImVec2(bars_width, sv_bar_size));
			if (IsItemActive())
			{
				col[3] = ImSaturate((io.MousePos.x - bar_pos.x) / (bars_width - 1.f));
				value_changed = true;
			}
		}
		PopItemFlag(); // ImGuiItemFlags_NoNav

		// Convert back color to RGB
		if (value_changed_h || value_changed_sv)
		{
			if (flags & ImGuiColorEditFlags_InputRGB)
			{
				ColorConvertHSVtoRGB(H, S, V, col[0], col[1], col[2]);
				g.ColorEditSavedHue = H;
				g.ColorEditSavedSat = S;
				g.ColorEditSavedColor = ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], 0));
			}

			else if (flags & ImGuiColorEditFlags_InputHSV)
			{
				col[0] = H;
				col[1] = S;
				col[2] = V;
			}
		}

		// R,G,B and H,S,V slider color editor
		bool value_changed_fix_hue_wrap = false;

		if (value_changed_fix_hue_wrap && (flags & ImGuiColorEditFlags_InputRGB))
		{
			// Try to cancel hue wrap (after ColorEdit4 call), if any
			float new_H, new_S, new_V;
			ColorConvertRGBtoHSV(col[0], col[1], col[2], new_H, new_S, new_V);
			if (new_H <= 0 && H > 0)
			{
				if (new_V <= 0 && V != new_V)
					ColorConvertHSVtoRGB(H, S, new_V <= 0 ? V * 0.5f : new_V, col[0], col[1], col[2]);
				else if (new_S <= 0)
					ColorConvertHSVtoRGB(H, new_S <= 0 ? S * 0.5f : new_S, new_V, col[0], col[1], col[2]);
			}
		}

		if (value_changed)
		{
			if (flags & ImGuiColorEditFlags_InputRGB)
			{
				R = col[0];
				G = col[1];
				B = col[2];
				ColorConvertRGBtoHSV(R, G, B, H, S, V);
				ColorEditRestoreHS(col, &H, &S, &V);   // Fix local Hue as display below will use it immediately.
			}
			else if (flags & ImGuiColorEditFlags_InputHSV)
			{
				H = col[0];
				S = col[1];
				V = col[2];
				ColorConvertHSVtoRGB(H, S, V, R, G, B);
			}
		}
		ImU32 user_col32_striped_of_alpha = ColorConvertFloat4ToU32(ImVec4(R, G, B, style.Alpha)); // Important: this is still including the main rendering/style alpha!!

		const int style_alpha8 = IM_F32_TO_INT8_SAT(style.Alpha);
		const ImU32 col_black = IM_COL32(0, 0, 0, style_alpha8);
		const ImU32 col_white = IM_COL32(255, 255, 255, style_alpha8);
		const ImU32 col_midgrey = IM_COL32(128, 128, 128, style_alpha8);
		const ImU32 col_hues[7] = { IM_COL32(255,0,0,style_alpha8), IM_COL32(255,0,255,style_alpha8), IM_COL32(0,0,255,style_alpha8),IM_COL32(0,255,255,style_alpha8), IM_COL32(0,255,0,style_alpha8), IM_COL32(255,255,0,style_alpha8), IM_COL32(255,0,0,style_alpha8) };

		ImVec4 hue_color_f(1, 1, 1, style.Alpha); ColorConvertHSVtoRGB(H, 1, 1, hue_color_f.x, hue_color_f.y, hue_color_f.z);
		ImU32 hue_color32 = ColorConvertFloat4ToU32(hue_color_f);

		ImVec2 sv_cursor_pos;

		// Render SV Square (+25% Area)
		const int vtx_idx_0 = draw_list->VtxBuffer.Size;
		draw_list->AddRectFilled(picker_pos, picker_pos + ImVec2(bars_width, sv_h), col_white, 6.0f);
		const int vtx_idx_1 = draw_list->VtxBuffer.Size;
		ShadeVertsLinearColorGradientKeepAlpha(draw_list, vtx_idx_0, vtx_idx_1, picker_pos, picker_pos + ImVec2(bars_width, 0.0f), col_white, hue_color32);

		draw_list->AddRectFilledMultiColor(picker_pos, picker_pos + ImVec2(bars_width, sv_h), 0, 0, col_black, col_black, 6.f);

		sv_cursor_pos.x = ImClamp(IM_ROUND(picker_pos.x + ImSaturate(S) * bars_width), picker_pos.x + 2.f, picker_pos.x + bars_width - 2.f);
		sv_cursor_pos.y = ImClamp(IM_ROUND(picker_pos.y + ImSaturate(1.f - V) * sv_h), picker_pos.y + 2.f, picker_pos.y + sv_h - 2.f);

		static std::map<ImGuiID, picker_state> anim;
		auto it_anim = anim.find(ImGui::GetID(label));

		if (it_anim == anim.end())
		{
			anim.insert({ ImGui::GetID(label), picker_state() });
			it_anim = anim.find(ImGui::GetID(label));
		}

		for (int i = 0; i < 6; ++i)
			draw_list->AddRectFilledMultiColor(
				ImVec2(picker_pos.x + i * (bars_width / 6.f) - (i == 5 ? 1.f : 0.f), bar0_y + 3.f),
				ImVec2(picker_pos.x + (i + 1) * (bars_width / 6.f) + (i == 0 ? 1.f : 0.f), bar0_y + sv_bar_size - 1.f),
				col_hues[i], col_hues[i + 1], col_hues[i + 1], col_hues[i],
				8.f,
				i == 0 ? ImDrawFlags_RoundCornersLeft : i == 5 ? ImDrawFlags_RoundCornersRight : ImDrawFlags_RoundCornersNone
			);

		float bar0_line_x = IM_ROUND(bar_pos.x + (1.f - H) * bars_width);
		bar0_line_x = ImClamp(bar0_line_x, picker_pos.x + 4.f, picker_pos.x + bars_width - 4.f);

		it_anim->second.hue_bar = ImLerp(it_anim->second.hue_bar, bar0_line_x - bar_pos.x, g.IO.DeltaTime * 24.f);

		draw_list->AddCircleFilled(ImVec2(it_anim->second.hue_bar + bar_pos.x, bar0_y + sv_bar_size * 0.5f + 1.f), 7.5f, ImColor(255, 255, 255, 255), 30.f);
		draw_list->AddCircle(ImVec2(it_anim->second.hue_bar + bar_pos.x, bar0_y + sv_bar_size * 0.5f + 1.f), 7.5f, IM_COL32(0, 0, 0, 160), 30, 1.4f);

		it_anim->second.circle_move = ImLerp(it_anim->second.circle_move, sv_cursor_pos - bar_pos, g.IO.DeltaTime * 24.f);
		it_anim->second.circle = ImLerp(it_anim->second.circle, value_changed_sv ? 5.f : 8.f, g.IO.DeltaTime * 24.f);

		draw_list->AddCircle(it_anim->second.circle_move + bar_pos + ImVec2(0, 1), it_anim->second.circle, ImColor(255, 255, 255, 255), 32, 2.0f);
		draw_list->AddCircle(it_anim->second.circle_move + bar_pos + ImVec2(0, 1), it_anim->second.circle + 1.0f, IM_COL32(0, 0, 0, 150), 32, 1.2f);

		if (alpha_bar)
		{
			float alpha = ImSaturate(col[3]);
			draw_list->AddRectFilledMultiColor(
				picker_pos + ImVec2(0, bar1_y + 3.f - picker_pos.y),
				picker_pos + ImVec2(bars_width, bar1_y + sv_bar_size - 1.f - picker_pos.y),
				col_black, user_col32_striped_of_alpha, user_col32_striped_of_alpha, col_black,
				8.f
			);

			float bar1_line_x = IM_ROUND(bar_pos.x + alpha * bars_width);
			bar1_line_x = ImClamp(bar1_line_x, bar_pos.x + 4.f, picker_pos.x + bars_width - 4.f);
			it_anim->second.alpha_bar = ImLerp(it_anim->second.alpha_bar, bar1_line_x - bar_pos.x, g.IO.DeltaTime * 24.f);
			draw_list->AddCircleFilled(ImVec2(it_anim->second.alpha_bar + bar_pos.x, bar1_y + sv_bar_size * 0.5f + 1.f), 7.5f, ImColor(255, 255, 255, 255), 30.f);
			draw_list->AddCircle(ImVec2(it_anim->second.alpha_bar + bar_pos.x, bar1_y + sv_bar_size * 0.5f + 1.f), 7.5f, IM_COL32(0, 0, 0, 160), 30, 1.4f);
		}

		EndGroup();

		ImVec4 preset_colors[] = {
			ImVec4(244 / 255.f, 99 / 255.f, 17 / 255.f, 1.f),
			ImVec4(237 / 255.f, 28 / 255.f, 128 / 255.f, 1.f),
			ImVec4(112 / 255.f, 81 / 255.f, 204 / 255.f, 1.f),
			ImVec4(178 / 255.f, 99 / 255.f, 217 / 255.f, 1.f),
			ImVec4(230 / 255.f, 111 / 255.f, 176 / 255.f, 1.f),
			ImVec4(255 / 255.f, 202 / 255.f, 58 / 255.f, 1.f),

			ImVec4(217 / 255.f, 83 / 255.f, 79 / 255.f, 1.f),
			ImVec4(255 / 255.f, 107 / 255.f, 107 / 255.f, 1.f),
			ImVec4(67 / 255.f, 197 / 255.f, 94 / 255.f, 1.f),
			ImVec4(77 / 255.f, 130 / 255.f, 255 / 255.f, 1.f),
			ImVec4(128 / 255.f, 0 / 255.f, 128 / 255.f, 1.f),
			ImVec4(255 / 255.f, 182 / 255.f, 193 / 255.f, 1.f)
		};

		ImVec2 preset_start = ImGui::GetCursorScreenPos();
		float spacing = 14.f;
		ImVec2 box_size = ImVec2(32.f, 32.f);
		int preset_id = 0;

		for (int row = 0; row < 2; row++)
		{
			for (int col_idx = 0; col_idx < 6 && preset_id < IM_ARRAYSIZE(preset_colors); col_idx++, preset_id++)
			{
				ImVec2 box_pos = preset_start + ImVec2(col_idx * (box_size.x + spacing), row * (box_size.y + spacing));
				ImRect box_bb(box_pos, box_pos + box_size);

				static std::map<int, float> anim;
				anim[preset_id] = ImLerp(anim[preset_id], box_bb.Contains(ImGui::GetMousePos()) ? 1.f : 0.f, ImGui::GetIO().DeltaTime * 10.f);

				ImGui::GetWindowDrawList()->AddRectFilled(
					box_bb.Min, box_bb.Max,
					ImColor(preset_colors[preset_id]),
					8.f
				);

				bool is_active =
					(fabsf(col[0] - preset_colors[preset_id].x) < 0.01f &&
						fabsf(col[1] - preset_colors[preset_id].y) < 0.01f &&
						fabsf(col[2] - preset_colors[preset_id].z) < 0.01f);

				if (is_active)
				{
					ImGui::GetWindowDrawList()->AddRect(box_bb.Min, box_bb.Max, IM_COL32_WHITE, 8.f, 0, 2.0f);
				}

				if (box_bb.Contains(ImGui::GetMousePos()) && ImGui::IsMouseClicked(0))
				{
					col[0] = preset_colors[preset_id].x;
					col[1] = preset_colors[preset_id].y;
					col[2] = preset_colors[preset_id].z;
					col[3] = preset_colors[preset_id].w;
					value_changed = true;
				}
			}
		}

		ImGui::Dummy(ImVec2(5.f, box_size.y * 2.f + spacing + 6.f));

		// --- HEX INPUT ---
		ImGui::SetCursorScreenPos(preset_start + ImVec2(0, box_size.y * 2.f + spacing * 2.f));

		// Текст
		PushFont(font::inter_medium);
		ImGui::TextColored(ImColor(190, 195, 210), "HEX:");
		PopFont();

		ImGui::SameLine();
		ImGui::PushItemWidth(bars_width - 48.f);

		static char hex_input[8];
		snprintf(hex_input, sizeof(hex_input), "%02X%02X%02X",
			IM_F32_TO_INT8_SAT(col[0]),
			IM_F32_TO_INT8_SAT(col[1]),
			IM_F32_TO_INT8_SAT(col[2])
		);

		ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 2);

		if (ImGui::InputTextEx("Here color", NULL, hex_input, sizeof(hex_input), ImVec2(bars_width - 48.f, 26), ImGuiInputTextFlags_CharsHexadecimal | ImGuiInputTextFlags_CharsUppercase, NULL, NULL))
		{
			unsigned int hex_color = 0;
			if (sscanf(hex_input, "%06X", &hex_color) == 1)
			{
				col[0] = ((hex_color >> 16) & 0xFF) / 255.f;
				col[1] = ((hex_color >> 8) & 0xFF) / 255.f;
				col[2] = (hex_color & 0xFF) / 255.f;
				value_changed = true;
			}
		}

		ImGui::PopItemWidth();

		if (value_changed && memcmp(backup_initial_col, col, components * sizeof(float)) == 0) value_changed = false;
		//if (value_changed) MarkItemEdited(g.LastItemData.ID);

		PopID();
		return value_changed;
	}


	bool ColorButton(const char* desc_id, const ImVec4& col, ImGuiColorEditFlags flags, const ImVec2& size_arg)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems)
			return false;

		ImGuiContext& g = *GImGui;
		const ImGuiID id = window->GetID(desc_id);
		const float default_size = GetFrameHeight();
		const ImVec2 pos = window->DC.CursorPos;
		const float width = GetContentRegionMax().x - ImGui::GetStyle().WindowPadding.x;
		const ImRect rect(pos, pos + ImVec2(width, 19));

		const ImRect clickable(rect.Min + ImVec2(width - 25, 0), rect.Max - ImVec2(7, 0));

		ItemSize(ImRect(rect.Min, rect.Max - ImVec2(0, 0)));
		if (!ItemAdd(rect, id)) return false;

		bool hovered, held, pressed = ButtonBehavior(rect, id, &hovered, &held);

		if (flags & ImGuiColorEditFlags_NoAlpha) flags &= ~(ImGuiColorEditFlags_AlphaPreview | ImGuiColorEditFlags_AlphaPreviewHalf);

		ImVec4 col_rgb = col;
		if (flags & ImGuiColorEditFlags_InputHSV) ColorConvertHSVtoRGB(col_rgb.x, col_rgb.y, col_rgb.z, col_rgb.x, col_rgb.y, col_rgb.z);

		GetWindowDrawList()->AddRectFilled(clickable.Min, clickable.Max, GetColorU32(col_rgb), c::elements::rounding);

		RenderColorRectWithAlphaCheckerboard(window->DrawList, clickable.Min, clickable.Max, GetColorU32(col_rgb), ImMin(36, 29) / 2.99f, ImVec2(0.f, 0.f), c::elements::rounding);


		return pressed;
	}

	struct knob_state {
		float plus_float;
		int plus_int;
		ImVec4 background, circle, text;
		float slow_anim, circle_anim;
		float position;
	};


	bool KnobScalar(const char* label, ImGuiDataType data_type, void* p_data, const void* p_min, const void* p_max, const char* format, ImGuiSliderFlags flags)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		const ImGuiID id = window->GetID(label);
		const float w = GetContentRegionMax().x - style.WindowPadding.x;

		const ImVec2 label_size = CalcTextSize(label, NULL, true);

		const ImRect frame_bb(window->DC.CursorPos + ImVec2(0, 0), window->DC.CursorPos + ImVec2(w, 32));

		const ImRect slider_bb(window->DC.CursorPos + ImVec2(w - 30, 0), window->DC.CursorPos + ImVec2(w, 100));

		const ImRect total_bb(frame_bb.Min, frame_bb.Max + ImVec2(label_size.x > 0.0f ? label_size.x : 0.0f, 0.0f));

		const bool temp_input_allowed = (flags & ImGuiSliderFlags_NoInput) == 0;
		ItemSize(ImRect(total_bb.Min, total_bb.Max - ImVec2(0, 0)));

		if (!ItemAdd(total_bb, id, &frame_bb, temp_input_allowed ? ImGuiItemFlags_Inputable : 0)) return false;

		if (format == NULL) format = DataTypeGetInfo(data_type)->PrintFmt;

		bool hovered = ItemHoverable(frame_bb, id, g.LastItemData.InFlags), held, pressed = ButtonBehavior(frame_bb, id, &hovered, &held, NULL);

		ImRect grab_bb;

		static std::map<ImGuiID, knob_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end())
		{
			anim.insert({ id, knob_state() });
			it_anim = anim.find(id);
		}

		it_anim->second.circle_anim = ImLerp(it_anim->second.circle_anim, IsItemActive() ? 11.f : 10.f, g.IO.DeltaTime * 6.f);

#ifdef _WIN32
		if ((flags & ImGuiSliderFlags_Integer) == 0) {
			it_anim->second.plus_float = ImLerp(it_anim->second.plus_float, *(float*)p_data <= *(float*)p_max && hovered && GetAsyncKeyState(VK_OEM_PLUS) & 0x01 ? *(float*)p_data += 0.05f : *(float*)p_data >= *(float*)p_min && hovered && GetAsyncKeyState(VK_OEM_MINUS) & 0x01 ? *(float*)p_data -= 0.05f : 0, g.IO.DeltaTime * 6.f);
			if (*(float*)p_data > *(float*)p_max) *(float*)p_data = *(float*)p_max;
			if (*(float*)p_data < *(float*)p_min) *(float*)p_data = *(float*)p_min;
		}
		else
		{
			it_anim->second.plus_int = ImLerp(it_anim->second.plus_int, *(int*)p_data <= *(int*)p_max && hovered && GetAsyncKeyState(VK_OEM_PLUS) & 0x01 ? *(int*)p_data += 1 : *(int*)p_data >= *(int*)p_min && hovered && GetAsyncKeyState(VK_OEM_MINUS) & 0x01 ? *(int*)p_data -= 1 : 0, g.IO.DeltaTime * 6.f);
			if (*(int*)p_data > *(int*)p_max) *(int*)p_data = *(int*)p_max;
			if (*(int*)p_data < *(int*)p_min) *(int*)p_data = *(int*)p_min;
		}
#endif

		it_anim->second.text = ImLerp(it_anim->second.text, g.ActiveId == id ? ImVec4(c::text::label::active.Value) : hovered ? ImVec4(c::text::label::hovered.Value) : ImVec4(c::text::label::default_col.Value), g.IO.DeltaTime * 6.f);

		const bool value_changed = DragBehavior(id, data_type, p_data, 0.f, p_min, p_max, format, NULL);


		if (value_changed) MarkItemEdited(id);

		char value_buf[64];
		const char* value_buf_end = value_buf + DataTypeFormatString(value_buf, IM_ARRAYSIZE(value_buf), data_type, p_data, format);

		float radius = 10.f;
		float thickness = 3.f;

		it_anim->second.position = ImLerp(it_anim->second.position, *static_cast<float*>(p_data) / *reinterpret_cast<const float*>(p_max) * 6.25f, ImGui::GetIO().DeltaTime * 18.f);

		GetWindowDrawList()->PathClear();
		GetWindowDrawList()->PathArcTo(ImVec2(frame_bb.Max.x + radius - 22.f, frame_bb.Min.y + (32 / 2)), radius, 0.f, 2.f * IM_PI, 40.f);
		GetWindowDrawList()->PathStroke(GetColorU32(c::elements::background), 0, thickness);

		GetWindowDrawList()->PathClear();
		GetWindowDrawList()->PathArcTo(ImVec2(frame_bb.Max.x + radius - 22.f, frame_bb.Min.y + (32 / 2)), radius, IM_PI * 1.5f, IM_PI * 1.5f + it_anim->second.position, 40.f);
		GetWindowDrawList()->PathStroke(GetColorU32(c::anim::active.Value), 0, thickness);

		GetWindowDrawList()->AddCircleFilled(ImVec2(frame_bb.Max.x + radius - 22.f + ImCos(IM_PI * 1.5f + it_anim->second.position) * radius, frame_bb.Min.y + (32 / 2) + ImSin(IM_PI * 1.5f + it_anim->second.position) * radius), 2.f, ImGui::GetColorU32(c::label::active.Value));

		GetWindowDrawList()->AddText(ImVec2(frame_bb.Max.x - (40 + CalcTextSize(value_buf).x), frame_bb.Min.y + (32 - CalcTextSize(value_buf).y) / 2), ImGui::GetColorU32(c::text::label::default_col.Value), value_buf);

		GetWindowDrawList()->AddText(ImVec2(frame_bb.Max.x - w, frame_bb.Min.y + (32 - CalcTextSize(value_buf).y) / 2), GetColorU32(it_anim->second.text), label);

		return value_changed;
	}

	bool KnobFloat(const char* label, float* v, float v_min, float v_max, const char* format, ImGuiSliderFlags flags)
	{
		return KnobScalar(label, ImGuiDataType_Float, v, &v_min, &v_max, format, flags);
	}

	bool KnobInt(const char* label, int* v, int v_min, int v_max, const char* format, ImGuiSliderFlags flags)
	{
		return KnobScalar(label, ImGuiDataType_S32, v, &v_min, &v_max, format, flags | ImGuiSliderFlags_Integer);
	}

	struct slider_state {
		ImVec4 background, circle, text_color;
		float position, slow, circle_radius;
		ImVec4 minus_col, plus_col;
		bool disabled;
		bool held_mode;
		float grab_anim;


		float total_offset = -400.f;
		float total_alpha = 0.f;
		float timer;
		bool is_visible, can_view;
	};

	bool SliderScalar(const char* label, ImGuiDataType data_type, void* p_data, const void* p_min, const void* p_max, const char* format, ImGuiSliderFlags flags)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		const ImGuiID id = window->GetID(label);
		const float w = GetContentRegionAvail().x;

		static std::map<ImGuiID, slider_state> anim;
		auto it_anim = anim.find(id);
		if (it_anim == anim.end())
		{
			anim.insert({ id, slider_state() });
			it_anim = anim.find(id);
		}

		const ImVec2 label_size = CalcTextSize(label, NULL, true);
		const ImVec2 pos = window->DC.CursorPos;
		const float track_h = 6.0f;
		const float thumb_r = 8.0f;
		const float total_h = 12 + label_size.y + 8 + track_h + 12;

		const ImRect total_bb(pos + ImVec2(it_anim->second.total_offset, 0), pos + ImVec2(w, total_h) + ImVec2(it_anim->second.total_offset, 0));
		const ImRect track_bb(total_bb.Min + ImVec2(0, 12 + label_size.y + 8), total_bb.Max - ImVec2(0, 12));
		const bool temp_input_allowed = (flags & ImGuiSliderFlags_NoInput) == 0;

		ItemSize(total_bb);
		ItemAdd(total_bb, id, &total_bb, temp_input_allowed ? ImGuiItemFlags_Inputable : 0);
		if (format == NULL) format = DataTypeGetInfo(data_type)->PrintFmt;

		bool hovered = ItemHoverable(total_bb, id, g.LastItemData.InFlags), held, pressed = ButtonBehavior(total_bb, id, &hovered, &held, NULL);

		ImRect grab_bb;
		const bool value_changed = SliderBehavior(ImRect(track_bb.Min - ImVec2(0, thumb_r), track_bb.Max + ImVec2(0, thumb_r)), id, data_type, p_data, p_min, p_max, format, flags, &grab_bb);
		if (value_changed) MarkItemEdited(id);

		char value_buf[64];
		const char* value_buf_end = value_buf + DataTypeFormatString(value_buf, IM_ARRAYSIZE(value_buf), data_type, p_data, format);

		float dt = g.IO.DeltaTime;
		bool active_or_hovered = hovered || g.ActiveId == id;

		it_anim->second.circle_radius = ImLerp(it_anim->second.circle_radius, held ? 5.f : hovered ? 4.5f : 4.f, dt * 10.f);
		it_anim->second.text_color = ImLerp(it_anim->second.text_color, held ? ImVec4(c::text::label::active.Value) : hovered ? ImVec4(c::text::label::hovered.Value) : ImVec4(c::text::label::default_col.Value), dt * 10.f);

		it_anim->second.is_visible = !tab_want_to_change;
		if (tab_want_to_change || ImGui::GetWindowSize().y < 35) {
			it_anim->second.total_offset = GetAnimOffset();
			it_anim->second.total_alpha = 0.f;
			it_anim->second.timer = 0.f;
		}

		it_anim->second.timer += dt;
		float relative = (total_bb.GetCenter().y - ImGui::GetWindowPos().y) / ImGui::GetWindowSize().y;
		float delay = 0.1f + relative * 0.9f;
		float t_val = ImClamp((it_anim->second.timer - delay) / 0.3f, 0.f, 1.f);

		it_anim->second.total_alpha = ImLerp(it_anim->second.total_alpha, ImGui::GetStyle().Alpha, dt * t_val * 3);
		PushStyleVar(ImGuiStyleVar_Alpha, it_anim->second.total_alpha);
		it_anim->second.total_offset = ImLerp(it_anim->second.total_offset, 0.f, dt * t_val * 4);

		ImDrawList* draw = GetWindowDrawList();

		draw->AddText(ImVec2(total_bb.Min.x, total_bb.Min.y + 4), GetColorU32(it_anim->second.text_color), label);

		float normalized = 0.f;
		if (data_type == ImGuiDataType_Float) {
			if (*(float*)p_max != *(float*)p_min)
				normalized = (*(float*)p_data - *(float*)p_min) / (*(float*)p_max - *(float*)p_min);
		} else if (data_type == ImGuiDataType_S32) {
			if (*(int*)p_max != *(int*)p_min)
				normalized = (float)(*(int*)p_data - *(int*)p_min) / (float)(*(int*)p_max - *(int*)p_min);
		}
		normalized = ImClamp(normalized, 0.f, 1.f);
		ImVec2 val_size = CalcTextSize(value_buf);
		draw->AddText(ImVec2(total_bb.Max.x - val_size.x, total_bb.Min.y + 4),
			GetColorU32(it_anim->second.text_color), value_buf);

		float track_rounding = track_h / 2.f;
		draw->AddRectFilled(track_bb.Min, track_bb.Max,
			utils::GetColorWithAlpha(c::anim::default_col, 0.8f), track_rounding);

		float target_fill_w = normalized * track_bb.GetWidth();
		it_anim->second.slow = ImLerp(it_anim->second.slow, target_fill_w, dt * 25.f);

		float fill_w = ImClamp(it_anim->second.slow, 0.f, track_bb.GetWidth());
		if (fill_w > 1.f) {
			ImVec2 fill_max(track_bb.Min.x + fill_w, track_bb.Max.y);
			fade_rect_filled(draw, track_bb.Min, fill_max,
				ImGui::GetColorU32(c::anim::active.Value),
				ImGui::GetColorU32(c::dark_color.Value),
				fade_direction::horizontally, track_rounding, 0, true);

			if (active_or_hovered) {
				draw->AddShadowRect(track_bb.Min - ImVec2(0, 2), fill_max + ImVec2(0, 2),
					ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.2f)), 6.f, ImVec2(0, 0),
					ImDrawFlags_RoundCornersAll | ImDrawFlags_ShadowCutOutShapeBackground, track_rounding);
			}
		}

		float thumb_x = ImLerp(track_bb.Min.x + thumb_r, track_bb.Max.x - thumb_r, normalized);
		ImVec2 thumb_center(thumb_x, track_bb.GetCenter().y);

		it_anim->second.grab_anim = easing->easing_in_out<float>(id * 55, active_or_hovered, 0.0f, 1.0f, dt * 20.f, interpolation_type::back);
		float extra = it_anim->second.grab_anim * 2.f;
		float final_r = thumb_r + extra;

		draw->AddCircleFilled(thumb_center, final_r + 1.f, ImColor(0.f, 0.f, 0.f, 0.12f), 36);
		draw->AddCircleFilled(thumb_center, final_r, ImColor(1.f, 1.f, 1.f, 0.97f), 36);

		if (active_or_hovered) {
			float pulse = sinf(ImGui::GetTime() * 2.5f) * 0.1f + 0.9f;
			int vtx_start = draw->VtxBuffer.Size;
			draw->AddCircleFilled(thumb_center, final_r * 0.5f, ImColor(1.f, 1.f, 1.f, 1.f), 36);
			int vtx_end = draw->VtxBuffer.Size;
			float phase = ImGui::GetTime() * 0.4f;
			float angle = ImDegToRad(phase * 360.f);
			set_linear_color(draw, vtx_start, vtx_end,
				ImVec2(thumb_center.x - final_r, thumb_center.y),
				ImVec2(thumb_center.x + final_r, thumb_center.y),
				ImGui::GetColorU32(c::anim::active.Value),
				ImGui::GetColorU32(c::dark_color.Value), angle);
			for (int v = vtx_start; v < vtx_end; v++) {
				ImU32& col = draw->VtxBuffer[v].col;
				int a = (col >> 24) & 0xFF;
				a = (int)(a * pulse * 0.6f);
				col = (col & 0x00FFFFFF) | (a << 24);
			}
		}

		if (g.ActiveId == id)
		{
			bool mouse_in_motion = (g.IO.MouseDelta.x != 0 || g.IO.MouseDelta.y != 0);
			if (mouse_in_motion) {
				for (int i = 0; i < particle::PARTICLE_COUT / 6; ++i)
					particle::AddParticle(thumb_center, ImVec2(2, 2), 0);
			}
		}

		ImGui::PopStyleVar();

		return value_changed;
	}

	bool SliderFloat(const char* label, float* v, float v_min, float v_max, const char* format, ImGuiSliderFlags flags)
	{
		return SliderScalar(label, ImGuiDataType_Float, v, &v_min, &v_max, format, flags);
	}

	bool SliderInt(const char* label, int* v, int v_min, int v_max, const char* format, ImGuiSliderFlags flags)
	{
		return SliderScalar(label, ImGuiDataType_S32, v, &v_min, &v_max, format, flags);
	}

	bool Keybind(const char* label, int* key, int* mode)
	{
		ImGuiWindow* window = ImGui::GetCurrentWindow();
		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		ImGuiIO& io = g.IO;
		const ImGuiStyle& style = g.Style;

		const ImGuiID id = window->GetID(label);
		const float width = GetContentRegionAvail().x;

		const ImRect total_bb(window->DC.CursorPos, window->DC.CursorPos + ImVec2(width, 25));
		ItemSize(total_bb, 0.f);

		if (!ItemAdd(total_bb, id)) return false;

		static std::map<ImGuiID, key_state> anim;
		auto it_anim = anim.emplace(id, key_state()).first;

		bool hovered, held, pressed = ButtonBehavior(total_bb, id, &hovered, &held);

		it_anim->second.alpha = ImLerp(it_anim->second.alpha,
			hovered ? 1.f : 0.8f, io.DeltaTime * 5.f);
		it_anim->second.background = ImLerp(it_anim->second.background,
		hovered ? ImVec4(c::anim::default_col.Value) : ImVec4(c::anim::default_col.Value), io.DeltaTime * 5.f);
		it_anim->second.text = ImLerp(it_anim->second.text, hovered ? ImVec4(c::text::description::hovered.Value) : ImVec4(c::text::description::default_col.Value), io.DeltaTime * 5.f);

		it_anim->second.text_color = ImLerp(it_anim->second.text_color, it_anim->second.status != KEYBIND_NONE ? ImVec4(c::text::label::active.Value) : hovered ? ImVec4(c::text::label::hovered.Value) : ImVec4(c::text::label::default_col.Value), GetAnimSpeed());
		it_anim->second.description_col = ImLerp(it_anim->second.description_col, it_anim->second.status != KEYBIND_NONE ? ImVec4(c::text::description::active.Value) : hovered ? ImVec4(c::text::description::hovered.Value) : ImVec4(c::text::description::default_col.Value), GetAnimSpeed());
		it_anim->second.icon_col = ImLerp(it_anim->second.icon_col, it_anim->second.status == KEYBIND_WAITING ? ImVec4(c::anim::active.Value) : hovered ? ImVec4(c::description::hovered.Value) : ImVec4(c::description::default_col.Value), GetAnimSpeed());


		ImVec2 key_bb_pos = ImVec2(total_bb.Max.x - it_anim->second.size_x, total_bb.Min.y);
		ImVec2 key_bb_size = ImVec2(total_bb.Max.x, total_bb.Max.y);

		ImRect key_bb(key_bb_pos, key_bb_size);

		// 🎯 Заголовок
		ImVec2 text_pos = ImVec2(total_bb.Min.x + 10.f, total_bb.Min.y + 10.f);
		GetWindowDrawList()->AddText(ImVec2(total_bb.Min.x, total_bb.GetCenter().y - CalcTextSize(label).y / 2), GetColorU32(it_anim->second.text_color), label);


		// 📝 Установка текста статуса
		if (it_anim->second.status == KEYBIND_WAITING) {
			it_anim->second.key_name = "...";
		}
		else if (*key != 0) {
			it_anim->second.key_name = keys[*key];
		}
		else {
			it_anim->second.key_name = "None";
		}

		ImVec2 key_text_size = CalcTextSize(it_anim->second.key_name);
		float target_size_x = ImMax(60.f, key_text_size.x + 55.f);
		it_anim->second.size_x = ImLerp(it_anim->second.size_x, target_size_x, io.DeltaTime * 14.f);

		GetWindowDrawList()->AddShadowRect(key_bb.Min, key_bb.Max, ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, 0.35f)), 35.f, ImVec2(0, 0), ImDrawFlags_RoundCornersAll, c::elements::rounding);
		GetWindowDrawList()->AddRectFilled(key_bb.Min, key_bb.Max, GetColorU32(it_anim->second.background), style.FrameRounding);
		GetWindowDrawList()->AddText(ImVec2(key_bb.Min.x + 10, key_bb.GetCenter().y - key_text_size.y * 0.5f), ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, it_anim->second.alpha)), it_anim->second.key_name);

		GetWindowDrawList()->AddRectFilled(ImVec2(key_bb.Max.x - 16.f - CalcTextSize(ICON_KEYBOARD_LINE).x, key_bb.Min.y), ImVec2(key_bb.Max.x - 15.f - CalcTextSize(ICON_KEYBOARD_LINE).x, key_bb.Max.y), ImGui::GetColorU32(utils::GetColorWithAlpha(c::text::description::default_col, 0.1f)), 0.f);

		GetWindowDrawList()->AddText(ImVec2(key_bb.Max.x - 8.f - CalcTextSize(ICON_KEYBOARD_FILL).x, key_bb.GetCenter().y - CalcTextSize(ICON_KEYBOARD_FILL).y / 2), GetColorU32(it_anim->second.icon_col), ICON_KEYBOARD_FILL);



		// 🎮 Логика статусов
		if (pressed) {
			if (it_anim->second.status != KEYBIND_WAITING && !it_anim->second.clicked_to_waiting) {
				it_anim->second.status = KEYBIND_WAITING;
				it_anim->second.clicked_to_waiting = true;
				*key = 0;
			}
		}

		if (!io.MouseDown[0]) {
			it_anim->second.clicked_to_waiting = false;
		}

		bool value_changed = false;

		if (it_anim->second.status == KEYBIND_WAITING) {
			for (int i = 0; i < 5; i++) {
				if (io.MouseClicked[i]) {
					switch (i) {
					case 0: *key = 0x01; break;
					case 1: *key = 0x02; break;
					case 2: *key = 0x04; break;
					case 3: *key = 0x05; break;
					case 4: *key = 0x06; break;
					}
					it_anim->second.status = KEYBIND_ASSIGNED;
					value_changed = true;
				}
			}
			if (!value_changed) {
				for (int i = 0x08; i <= 0xA5; i++) {
					if (io.KeysDown[i]) {
						*key = i;
						it_anim->second.status = KEYBIND_ASSIGNED;
						value_changed = true;
					}
				}
			}

			if (IsKeyPressedMap(ImGuiKey_Escape)) {
				*key = 0;
				it_anim->second.status = KEYBIND_NONE;
			}
		}

		if (*key != 0 && it_anim->second.status != KEYBIND_WAITING) {
			it_anim->second.status = KEYBIND_ASSIGNED;
		}
		else if (*key == 0 && it_anim->second.status != KEYBIND_WAITING) {
			it_anim->second.status = KEYBIND_NONE;
		}

		return value_changed;
	}

	bool MiniBind(const char* label, int* key, int* mode)
	{
		ImGuiWindow* window = ImGui::GetCurrentWindow();
		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		ImGuiIO& io = g.IO;
		const ImGuiStyle& style = g.Style;

		const ImGuiID id = window->GetID(label);
		const float avail_w = GetContentRegionAvail().x;
		const float row_h = 28.f;

		const ImRect total_bb(window->DC.CursorPos, window->DC.CursorPos + ImVec2(avail_w, row_h));
		ItemSize(total_bb, 0.f);
		if (!ItemAdd(total_bb, id)) return false;

		static std::map<ImGuiID, key_state> anim;
		auto it_anim = anim.emplace(id, key_state()).first;

		bool hovered, held, pressed = ButtonBehavior(total_bb, id, &hovered, &held);
		float dt = io.DeltaTime;

		it_anim->second.alpha = ImLerp(it_anim->second.alpha, hovered ? 1.f : 0.85f, dt * 8.f);

		// Determine key name
		if (it_anim->second.status == KEYBIND_WAITING) {
			it_anim->second.key_name = "...";
		}
		else if (*key != 0 && *key < 256 && keys[*key] != nullptr) {
			it_anim->second.key_name = keys[*key];
		}
		else {
			it_anim->second.key_name = "None";
		}

		PushFont(font::small_font);
		ImVec2 key_text_size = CalcTextSize(it_anim->second.key_name);
		float pill_w = ImMax(68.f, key_text_size.x + 36.f);
		float pill_h = 24.f;

		ImVec2 pill_min(total_bb.Max.x - pill_w, total_bb.Min.y + (row_h - pill_h) * 0.5f);
		ImVec2 pill_max(total_bb.Max.x, pill_min.y + pill_h);
		ImRect pill_bb(pill_min, pill_max);

		ImDrawList* dl = window->DrawList;
		float alpha = ImGui::GetStyle().Alpha;

		// 1. Draw Left Label
		ImVec2 label_pos(total_bb.Min.x, total_bb.Min.y + (row_h - ImGui::GetTextLineHeight()) * 0.5f);
		dl->AddText(label_pos, ImGui::GetColorU32(ImVec4(0.85f, 0.88f, 0.95f, (hovered ? 1.0f : 0.85f) * alpha)), label);

		// 2. Draw Key Pill Background
		bool is_waiting = (it_anim->second.status == KEYBIND_WAITING);
		bool pill_hovered = pill_bb.Contains(ImGui::GetMousePos());

		ImVec4 bg_col = is_waiting ? ImVec4(c::anim::active.Value.x, c::anim::active.Value.y, c::anim::active.Value.z, 0.35f * alpha)
			: (pill_hovered ? ImVec4(0.08f, 0.10f, 0.16f, 0.95f * alpha) : ImVec4(0.035f, 0.045f, 0.075f, 0.90f * alpha));

		dl->AddRectFilled(pill_min, pill_max, ImGui::GetColorU32(bg_col), 6.f);
		dl->AddRect(pill_min, pill_max, ImGui::GetColorU32(ImLerp(ImVec4(1.f, 1.f, 1.f, 0.10f * alpha), utils::GetColorWithAlpha(c::anim::active, 0.85f * alpha), is_waiting ? 1.f : (pill_hovered ? 0.6f : 0.f))), 6.f, 0, 1.f);

		// Key text inside pill
		ImVec2 txt_p = pill_min + ImVec2(10.f, (pill_h - key_text_size.y) * 0.5f);
		ImVec4 txt_col = is_waiting ? ImVec4(1.f, 1.f, 1.f, 1.f) : (pill_hovered ? ImVec4(1.f, 1.f, 1.f, 0.95f * alpha) : ImVec4(0.75f, 0.80f, 0.90f, 0.85f * alpha));
		dl->AddText(txt_p, ImGui::GetColorU32(txt_col), it_anim->second.key_name);

		// Mini Keyboard Icon on right side of pill
		ImVec2 icon_sz = CalcTextSize(ICON_KEYBOARD_FILL);
		ImVec2 icon_pos(pill_max.x - icon_sz.x - 8.f, pill_min.y + (pill_h - icon_sz.y) * 0.5f);
		ImU32 icon_color_u32 = is_waiting ? ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 1.f)) : ImGui::GetColorU32(ImVec4(0.5f, 0.55f, 0.65f, 0.65f * alpha));
		dl->AddText(icon_pos, icon_color_u32, ICON_KEYBOARD_FILL);
		PopFont();

		// Click Handling
		if (pressed && (pill_hovered || hovered)) {
			if (it_anim->second.status != KEYBIND_WAITING && !it_anim->second.clicked_to_waiting) {
				it_anim->second.status = KEYBIND_WAITING;
				it_anim->second.clicked_to_waiting = true;
				*key = 0;
			}
		}

		if (!io.MouseDown[0]) {
			it_anim->second.clicked_to_waiting = false;
		}

		bool value_changed = false;

		if (it_anim->second.status == KEYBIND_WAITING) {
			for (int i = 0; i < 5; i++) {
				if (io.MouseClicked[i]) {
					switch (i) {
					case 0: *key = 0x01; break;
					case 1: *key = 0x02; break;
					case 2: *key = 0x04; break;
					case 3: *key = 0x05; break;
					case 4: *key = 0x06; break;
					}
					it_anim->second.status = KEYBIND_ASSIGNED;
					value_changed = true;
				}
			}
			if (!value_changed) {
				for (int i = 0x08; i <= 0xA5; i++) {
					if (io.KeysDown[i]) {
						*key = i;
						it_anim->second.status = KEYBIND_ASSIGNED;
						value_changed = true;
					}
				}
			}

			if (IsKeyPressedMap(ImGuiKey_Escape)) {
				*key = 0;
				it_anim->second.status = KEYBIND_NONE;
			}
		}

		if (*key != 0 && it_anim->second.status != KEYBIND_WAITING) {
			it_anim->second.status = KEYBIND_ASSIGNED;
		}
		else if (*key == 0 && it_anim->second.status != KEYBIND_WAITING) {
			it_anim->second.status = KEYBIND_NONE;
		}

		return value_changed;
	}

	bool Bindbox(const char* label, bool* v, int* key, int* mode)
	{
		std::string label_str = label;
		std::string key_str = label + std::string("##keybind");

		custom::MiniBind("Hello keybind", key, mode);
		ImGui::SameLine();

		ImGui::SetCursorPos(ImGui::GetCursorPos() + ImVec2(0, 2.5));

		custom::Checkbox(label, v);

		return false;
	}

	struct toggle_state {
		ImVec4 background;
		float smooth_swap, alpha_line, line_size;

		float total_offset = -400.f;
		float total_alpha = 0.f;
		float timer;
		bool is_visible, can_view;
	};

	bool ToggleButton(const char* first_text, const char* second_text, bool* v, const ImVec2& size_arg) {
		ImGuiWindow* window = GetCurrentWindow();

		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		const ImGuiID id = window->GetID(first_text);


		static std::map<ImGuiID, toggle_state> anim;
		auto it_anim = anim.find(id);

		if (it_anim == anim.end()) {
			anim.insert({ id, toggle_state() });
			it_anim = anim.find(id);
		}

		const ImVec2 label_size = CalcTextSize(first_text, NULL, true), pos = window->DC.CursorPos + ImVec2(it_anim->second.total_offset, 0.f);

		ImVec2 size = CalcItemSize(size_arg, label_size.x, label_size.y);

		const ImRect bb(pos, pos + size);

		const ImRect dark_bb(bb.Min, bb.Min + ImVec2(size.x / 2, size.y));
		const ImRect white_bb(bb.Min + ImVec2(size.x / 2, 0.f), bb.Max);

		ItemSize(size, 0.f);
		ItemAdd(bb, id);

		bool hovered, held, pressed = ButtonBehavior(bb, id, &hovered, &held, NULL);


		if (pressed)
			*v = !*v;


		it_anim->second.is_visible = !tab_want_to_change;
		if (tab_want_to_change || ImGui::GetWindowSize().y < 35) {
			it_anim->second.total_offset = GetAnimOffset();
			it_anim->second.total_alpha = 0.f;
			it_anim->second.timer = 0.f;
		}

		it_anim->second.timer += ImGui::GetIO().DeltaTime;
		float relative = (bb.GetCenter().y - ImGui::GetWindowPos().y) / ImGui::GetWindowSize().y;
		float delay = 0.1f + relative * 0.9f;
		float t = ImClamp((it_anim->second.timer - delay) / 0.3f, 0.f, 1.f);
		it_anim->second.total_offset = ImLerp(it_anim->second.total_offset, 0.f, ImGui::GetIO().DeltaTime * t * 4);
		it_anim->second.total_alpha = ImLerp(it_anim->second.total_alpha, ImGui::GetStyle().Alpha, ImGui::GetIO().DeltaTime * t * 3);


		it_anim->second.smooth_swap = ImLerp(it_anim->second.smooth_swap, *v ? 0.f : size.x / 2, g.IO.DeltaTime * 12.f);

		PushStyleVar(ImGuiStyleVar_Alpha, it_anim->second.total_alpha);
		GetWindowDrawList()->AddRectFilled(bb.Min, bb.Max, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::default_col, 1.f - (1.f - style.Alpha))), c::page::rounding);

		GetWindowDrawList()->AddRectFilled(bb.Min + ImVec2(it_anim->second.smooth_swap, 0.f), ImVec2(bb.Min.x + size.x / 2 + it_anim->second.smooth_swap, bb.Max.y), ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.5f - (1.f - style.Alpha))), c::page::rounding);

		GetWindowDrawList()->AddText(utils::center_text(dark_bb.Min, dark_bb.Max, first_text), ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 1.f - (1.f - style.Alpha))), first_text);
		GetWindowDrawList()->AddText(utils::center_text(white_bb.Min, white_bb.Max, second_text), ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 1.f - (1.f - style.Alpha))), second_text);
		PopStyleVar();

		return pressed;
	}


	bool Featuresbox(const char* label, bool* v)
	{
		std::string label_str = label;
		std::string key_str = label + std::string("##keybind");
		std::string popup_str = label + std::string("##popup");
		
		custom::Checkbox(label, v);

		ImGui::SameLine(0, 0);
		if (custom::rotated_text(ICON_SETTINGS_4_FILL, false))
			return true;

		return false;
	}

	void DrawHexGrid(
		const std::vector<std::string>& labels,
		const std::vector<int>& indicators)
	{
		struct HexState { bool active = false; ImVec4 bg_col = c::child::background; float ind_size = 0.0f; };
		static std::map<ImGuiID, HexState> anim;

		ImGuiWindow* window = ImGui::GetCurrentWindow();
		ImDrawList* draw = window->DrawList;
		float         dt = ImGui::GetIO().DeltaTime;
		ImVec2        origin = ImGui::GetCursorScreenPos();
		float         availX = ImGui::GetContentRegionAvail().x;

		const float r = 40.0f;
		const float hexW = 2.0f * r;
		const float hexH = sqrtf(3.0f) * r;
		const float xStep = hexW * 1.0f;
		const float yStep = hexH;

		const int counts[5] = { 5, 6, 5, 6, 5 };

		int idx = 0;
		for (int row = 0; row < 5; ++row)
		{
			int cnt = counts[row];
			float rowTotalWidth = (cnt - 1) * xStep + hexW;
			float startX = origin.x + (availX - rowTotalWidth) * 0.5f + r;
			float y = origin.y + row * yStep + r;

			for (int col = 0; col < cnt; ++col)
			{
				ImGui::PushID(idx);
				ImGuiID id = window->GetID("hex");
				auto& s = anim[id];

				ImVec2 cen(startX + col * xStep, y);

				ImRect bb(cen - ImVec2(r, r), cen + ImVec2(r, r));
				ImGui::ItemAdd(bb, id);

				bool hovered, held, pressed = ButtonBehavior(bb, id, &hovered, &held);
				if (pressed) s.active = !s.active;

				s.bg_col = easing->easing_in_out<ImVec4>(id * 2, s.active, c::anim::default_col, c::anim::active.Value, dt * 30.f, interpolation_type::back);
				s.ind_size = easing->easing_in_out<float>(id * 3, s.active, 0.0f, r * 0.15f, dt * 30.f, interpolation_type::back);

				ImVec2 pts[6];
				for (int i = 0; i < 6; ++i)
				{
					float a = IM_PI / 6 + i * IM_PI / 3;
					pts[i] = ImVec2(cen.x + cosf(a) * r, cen.y + sinf(a) * r);
				}
				draw->AddConvexPolyFilled(pts, 6, GetColorU32(s.bg_col));
				draw->AddPolyline(pts, 6, GetColorU32(c::child::stroke), true, 1.0f);

				const char* lab = labels[idx].c_str();
				ImVec2 ts = ImGui::CalcTextSize(lab);
				draw->AddText(
					ImVec2(cen.x - ts.x * 0.5f, cen.y - ts.y * 0.5f),
					ImGui::GetColorU32(c::label::default_col.Value),
					lab
				);

				if (idx < (int)indicators.size() && indicators[idx] != 0)
				{
					int v = indicators[idx];
					ImVec4 col = ImVec4(1, 1, 1, 0.1f);
					if (v == 1) col = ImVec4(0, 1, 0, 1);
					if (v == 2) col = ImVec4(1, 0, 0, 1);

					float r2 = r * 0.15f;
					ImVec2 cen2(cen.x, cen.y + r * 0.8f);
					ImVec2 pts2[6];
					for (int i = 0; i < 6; ++i)
					{
						float a = IM_PI / 6 + i * IM_PI / 3;
						pts2[i] = ImVec2(cen2.x + cosf(a) * r2, cen2.y + sinf(a) * r2);
					}
					draw->AddConvexPolyFilled(pts2, 6, GetColorU32(col));
				}

				ImGui::PopID();
				++idx;
			}
		}

		ImGui::Dummy(ImVec2(availX, 5 * yStep + hexH));
	}

	bool SearchBar(const char* hint, char* buf, size_t buf_size, const ImVec2& size_arg)
	{
		ImGuiWindow* window = ImGui::GetCurrentWindow();
		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		ImGuiID id = window->GetID("##custom_search_bar");
		ImVec2 pos = window->DC.CursorPos;
		ImVec2 size = ImFloor(size_arg);
		ImRect bb(pos, pos + size);

		ImGui::ItemSize(size, 0.0f);
		if (!ImGui::ItemAdd(bb, id)) return false;

		bool hovered = ImGui::ItemHoverable(bb, id, g.LastItemData.InFlags);
		bool value_changed = false;

		struct search_state {
			float focus_anim = 0.f;
			bool kb_open = false;
			float kb_anim = 0.f;
			int lang_layout = 0; // 0 = EN, 1 = RU
			float bksp_hold_time = 0.f;
			float bksp_repeat_timer = 0.f;
			bool is_dragging = false;
			ImVec2 drag_offset = ImVec2(0.f, 0.f);
			ImVec2 drag_start_mouse = ImVec2(0.f, 0.f);
			ImVec2 drag_start_offset = ImVec2(0.f, 0.f);
		};
		static std::map<ImGuiID, search_state> anim;
		auto& s = anim[id];

		// Toggle / Open on click on the search bar
		if (hovered && ImGui::IsMouseClicked(0)) {
			s.kb_open = true;
		}

		float alpha = ImGui::GetStyle().Alpha;
		float dt = g.IO.DeltaTime;
		ImDrawList* dl = window->DrawList;

		// Frame Background
		s.focus_anim = ImLerp(s.focus_anim, (s.kb_open || hovered || buf[0] != '\0') ? 1.f : 0.f, dt * 14.f);
		dl->AddRectFilled(bb.Min, bb.Max, ImGui::GetColorU32(ImVec4(0.015f, 0.02f, 0.035f, 0.90f * alpha)), 8.f);
		dl->AddRect(bb.Min, bb.Max, ImGui::GetColorU32(ImLerp(ImVec4(1.f, 1.f, 1.f, 0.10f * alpha), utils::GetColorWithAlpha(c::anim::active, 0.85f * alpha), s.focus_anim)), 8.f, 0, 1.2f);

		// Search icon
		PushFont(font::small_font);
		ImVec2 s_ic_sz = CalcTextSize(ICON_SEARCH_LINE);
		dl->AddText(ImVec2(bb.Min.x + 10.f, bb.Min.y + (size.y - s_ic_sz.y) * 0.5f),
			ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (s.kb_open ? 0.95f : 0.45f) * alpha)), ICON_SEARCH_LINE);
		PopFont();

		// Text or Placeholder Hint
		PushFont(font::small_font);
		float text_y = bb.Min.y + (size.y - ImGui::GetTextLineHeight()) * 0.5f;
		float text_x = bb.Min.x + 28.f;

		if (buf[0] != '\0')
		{
			// Render typed search string
			dl->PushClipRect(ImVec2(text_x, bb.Min.y), ImVec2(bb.Max.x - 22.f, bb.Max.y), true);
			dl->AddText(ImVec2(text_x, text_y), ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.95f * alpha)), buf);

			// Blinking cursor
			if (s.kb_open)
			{
				float text_w = font::small_font->CalcTextSizeA(font::small_font->FontSize, FLT_MAX, 0.f, buf).x;
				if (fmodf((float)ImGui::GetTime() * 2.5f, 2.0f) < 1.0f)
				{
					float cur_x = text_x + text_w + 1.f;
					dl->AddLine(ImVec2(cur_x, text_y + 1.f), ImVec2(cur_x, text_y + ImGui::GetTextLineHeight() - 1.f),
						ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.90f * alpha)), 1.5f);
				}
			}
			dl->PopClipRect();
		}
		else
		{
			// Placeholder hint
			if (hint && hint[0] != '\0')
			{
				dl->AddText(ImVec2(text_x, text_y), ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.35f * alpha)), hint);
			}
			// Blinking cursor even when empty
			if (s.kb_open)
			{
				if (fmodf((float)ImGui::GetTime() * 2.5f, 2.0f) < 1.0f)
				{
					dl->AddLine(ImVec2(text_x, text_y + 1.f), ImVec2(text_x, text_y + ImGui::GetTextLineHeight() - 1.f),
						ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.90f * alpha)), 1.5f);
				}
			}
		}
		PopFont();

		// Clear button (x)
		if (buf[0] != '\0')
		{
			ImVec2 clr_pos(bb.Max.x - 22.f, bb.Min.y + (size.y - 12.f) * 0.5f);
			ImRect clr_bb(clr_pos - ImVec2(3, 3), clr_pos + ImVec2(15, 15));
			bool clr_hovered = ImGui::IsMouseHoveringRect(clr_bb.Min, clr_bb.Max);
			if (clr_hovered && ImGui::IsMouseClicked(0))
			{
				buf[0] = '\0';
				value_changed = true;
			}
			PushFont(font::small_font);
			dl->AddText(clr_pos, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (clr_hovered ? 1.0f : 0.55f) * alpha)), ICON_CLOSE_FILL);
			PopFont();
		}

		// Process Physical Keyboard Input when search is open
		if (s.kb_open)
		{
			// Read characters typed from physical keyboard
			for (int n = 0; n < g.IO.InputQueueCharacters.Size; n++)
			{
				unsigned int c = (unsigned int)g.IO.InputQueueCharacters[n];
				if (c == '\t' || c == '\r' || c == '\n') continue;
				if (c < 32) continue;

				char utf8_bytes[5] = { 0 };
				ImTextCharToUtf8(utf8_bytes, c);
				size_t cur_len = strlen(buf);
				size_t add_len = strlen(utf8_bytes);
				if (cur_len + add_len < buf_size)
				{
					memcpy(buf + cur_len, utf8_bytes, add_len + 1);
					value_changed = true;
				}
			}

			// Backspace
			if (ImGui::IsKeyPressed(ImGuiKey_Backspace, true))
			{
				size_t len = strlen(buf);
				if (len > 0)
				{
					while (len > 0 && (buf[len - 1] & 0xC0) == 0x80)
						len--;
					if (len > 0) len--;
					buf[len] = '\0';
					value_changed = true;
				}
			}

			// Close keys
			if (ImGui::IsKeyPressed(ImGuiKey_Escape) || ImGui::IsKeyPressed(ImGuiKey_Enter))
			{
				s.kb_open = false;
			}
		}

		// =========================================================================
		// CUSTOM DRAGGABLE ON-SCREEN KEYBOARD POPUP (FOREGROUND)
		// =========================================================================
		s.kb_anim = ImLerp(s.kb_anim, s.kb_open ? 1.f : 0.f, dt * 16.f);

		if (s.kb_anim > 0.01f)
		{
			float kb_alpha = s.kb_anim * alpha;
			ImDrawList* fg = ImGui::GetForegroundDrawList();

			// Proportional, Touch-Friendly Dimensions (+40% Optimized)
			float kb_pad = 12.f;
			float key_gap = 4.5f;
			float key_w = (s.lang_layout == 1) ? 32.f : 34.f;
			float key_h = 32.f;

			// EN & RU character sets
			static const char* en_r1[] = { "1","2","3","4","5","6","7","8","9","0" };
			static const char* en_r2[] = { "q","w","e","r","t","y","u","i","o","p" };
			static const char* en_r3[] = { "a","s","d","f","g","h","j","k","l" };
			static const char* en_r4[] = { "z","x","c","v","b","n","m" };

			static const char* ru_r1[] = { "1","2","3","4","5","6","7","8","9","0" };
			static const char* ru_r2[] = { "й","ц","у","к","е","н","г","ш","щ","з","х" };
			static const char* ru_r3[] = { "ф","ы","в","а","п","р","о","л","д","ж","э" };
			static const char* ru_r4[] = { "я","ч","с","м","и","т","ь","б","ю" };

			int r1_count = 10;
			int r2_count = (s.lang_layout == 1) ? 11 : 10;
			int r3_count = (s.lang_layout == 1) ? 11 : 9;
			int r4_count = (s.lang_layout == 1) ? 9 : 7;

			int max_row_keys = ImMax(r1_count, ImMax(r2_count, ImMax(r3_count, r4_count)));
			float total_w = max_row_keys * (key_w + key_gap) - key_gap + kb_pad * 2.f;
			float total_h = 38.f + 34.f + 28.f + 5 * (key_h + key_gap) + kb_pad * 2.f + 4.f; // header + preview bar + chips + 5 rows

			// Base position + user dragged offset
			ImVec2 base_pos(bb.Min.x - 10.f, bb.Max.y + 8.f);
			ImVec2 kb_pos = base_pos + s.drag_offset;

			// Clamp inside viewport
			if (kb_pos.x + total_w > ImGui::GetIO().DisplaySize.x - 10.f)
				kb_pos.x = ImGui::GetIO().DisplaySize.x - total_w - 10.f;
			if (kb_pos.x < 10.f) kb_pos.x = 10.f;
			if (kb_pos.y + total_h > ImGui::GetIO().DisplaySize.y - 10.f)
				kb_pos.y = ImGui::GetIO().DisplaySize.y - total_h - 10.f;
			if (kb_pos.y < 10.f) kb_pos.y = 10.f;

			// Smooth slide-in
			float slide_y = (1.f - s.kb_anim) * 14.f;
			kb_pos.y += slide_y;
			ImVec2 kb_size(total_w, total_h);
			ImRect kb_rect(kb_pos, kb_pos + kb_size);

			float side_w = 240.f;
			float side_h = total_h;
			ImVec2 side_pos(kb_pos.x + total_w + 10.f, kb_pos.y);
			if (side_pos.x + side_w > ImGui::GetIO().DisplaySize.x - 10.f)
				side_pos.x = kb_pos.x - side_w - 10.f;

			ImRect side_rect(side_pos, side_pos + ImVec2(side_w, side_h));

			// =========================================================
			// HEADER DRAGGING & WINDOW MOVE PREVENTION
			// =========================================================
			float header_h = 36.f;
			ImRect header_bb(kb_pos, kb_pos + ImVec2(total_w - 38.f, header_h));
			ImRect side_hdr_bb(side_pos, side_pos + ImVec2(side_w, header_h));
			bool header_hov = ImGui::IsMouseHoveringRect(header_bb.Min, header_bb.Max) || ImGui::IsMouseHoveringRect(side_hdr_bb.Min, side_hdr_bb.Max);
			bool mouse_in_kb = ImGui::IsMouseHoveringRect(kb_rect.Min, kb_rect.Max) || ImGui::IsMouseHoveringRect(side_rect.Min, side_rect.Max);

			if (header_hov && ImGui::IsMouseClicked(0))
			{
				s.is_dragging = true;
				s.drag_start_mouse = ImGui::GetMousePos();
				s.drag_start_offset = s.drag_offset;
			}

			if (s.is_dragging)
			{
				if (ImGui::IsMouseDown(0))
				{
					s.drag_offset = s.drag_start_offset + (ImGui::GetMousePos() - s.drag_start_mouse);
				}
				else
				{
					s.is_dragging = false;
				}
			}

			g_keyboard_hovered = mouse_in_kb;
			g_keyboard_dragging = s.is_dragging;

			if (mouse_in_kb || s.is_dragging)
			{
				// Prevent moving the parent window
				if (g.MovingWindow == window)
					g.MovingWindow = NULL;

				// Absorb mouse active state so no widgets behind the keyboard activate
				if (ImGui::IsMouseClicked(0) || ImGui::IsMouseDown(0))
				{
					ImGui::SetActiveID(id, window);
					g.ActiveIdAllowOverlap = true;
				}

				// Block hover from reaching any background items
				if (g.HoveredId != 0 && g.HoveredId != id)
				{
					g.HoveredId = 0;
					g.HoveredIdPreviousFrame = 0;
				}
			}

			// Close when clicking outside both search bar, keyboard and side panel
			if (s.kb_open && !s.is_dragging && ImGui::IsMouseClicked(0))
			{
				if (!ImGui::IsMouseHoveringRect(bb.Min, bb.Max) && !ImGui::IsMouseHoveringRect(kb_rect.Min, kb_rect.Max) && !ImGui::IsMouseHoveringRect(side_rect.Min, side_rect.Max))
				{
					s.kb_open = false;
				}
			}

			// =========================================================
			// CARD BACKGROUND WITH DUAL GLOW & GLASSMORPHISM
			// =========================================================
			// 1. Ambient deep shadow
			fg->AddShadowRect(kb_pos, kb_pos + kb_size,
				ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, 0.70f * kb_alpha)), 36.f, ImVec2(0, 10), ImDrawFlags_RoundCornersAll, 16.f);
			
			// 2. Subtle colored accent glow shadow
			fg->AddShadowRect(kb_pos, kb_pos + kb_size,
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.12f * kb_alpha)), 20.f, ImVec2(0, 0), ImDrawFlags_RoundCornersAll, 16.f);

			// 3. Dark Frosted Glass Body
			fg->AddRectFilled(kb_pos, kb_pos + kb_size,
				ImGui::GetColorU32(ImVec4(0.02f, 0.025f, 0.045f, 0.96f * kb_alpha)), 16.f);

			// 4. Glowing glass rim
			fg->AddRect(kb_pos, kb_pos + kb_size,
				ImGui::GetColorU32(ImLerp(ImVec4(1.f, 1.f, 1.f, 0.14f * kb_alpha), utils::GetColorWithAlpha(c::anim::active, 0.80f * kb_alpha), s.kb_anim)), 16.f, 0, 1.2f);

			// =========================================================
			// HEADER BAR & DRAG HANDLE
			// =========================================================
			fg->AddRectFilled(kb_pos, kb_pos + ImVec2(total_w, header_h),
				ImGui::GetColorU32(ImVec4(0.035f, 0.045f, 0.075f, 0.90f * kb_alpha)), 16.f, ImDrawFlags_RoundCornersTop);
			fg->AddLine(kb_pos + ImVec2(12.f, header_h), kb_pos + ImVec2(total_w - 12.f, header_h),
				ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.08f * kb_alpha)), 1.f);

			PushFont(font::small_font);

			// Keyboard Icon + Title
			fg->AddText(kb_pos + ImVec2(14.f, 9.f),
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.95f * kb_alpha)), ICON_KEYBOARD_FILL);
			fg->AddText(kb_pos + ImVec2(34.f, 9.f),
				ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.85f * kb_alpha)), s.lang_layout == 1 ? "ВИРТУАЛЬНАЯ КЛАВИАТУРА" : "VIRTUAL KEYBOARD");

			// Center Drag Grip Indicator (::: GRIP :::)
			float grip_center_x = kb_pos.x + total_w * 0.5f + 20.f;
			float dot_y = kb_pos.y + 17.f;
			for (int d = -2; d <= 2; d++)
			{
				fg->AddCircleFilled(ImVec2(grip_center_x + d * 6.f, dot_y), 1.5f,
					ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (header_hov || s.is_dragging ? 0.65f : 0.25f) * kb_alpha)));
			}

			// Header Close Button (x) with round hover backdrop
			ImVec2 close_btn_pos(kb_pos.x + total_w - 24.f, kb_pos.y + 9.f);
			ImRect close_bb(close_btn_pos - ImVec2(6, 6), close_btn_pos + ImVec2(18, 18));
			bool close_hov = ImGui::IsMouseHoveringRect(close_bb.Min, close_bb.Max);
			if (close_hov)
			{
				fg->AddCircleFilled(close_btn_pos + ImVec2(6, 6), 11.f,
					ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.12f * kb_alpha)));
			}
			if (close_hov && ImGui::IsMouseClicked(0)) {
				s.kb_open = false;
			}
			fg->AddText(close_btn_pos, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (close_hov ? 1.0f : 0.55f) * kb_alpha)), ICON_CLOSE_FILL);

			// =========================================================
			// EMBEDDED SEARCH QUERY PREVIEW BAR INSIDE KEYBOARD
			// =========================================================
			float prev_y = kb_pos.y + header_h + 8.f;
			float prev_x = kb_pos.x + kb_pad;
			float prev_w = total_w - kb_pad * 2.f;
			float prev_h = 28.f;
			ImRect prev_bb(ImVec2(prev_x, prev_y), ImVec2(prev_x + prev_w, prev_y + prev_h));

			fg->AddRectFilled(prev_bb.Min, prev_bb.Max,
				ImGui::GetColorU32(ImVec4(0.015f, 0.02f, 0.035f, 0.85f * kb_alpha)), 8.f);
			fg->AddRect(prev_bb.Min, prev_bb.Max,
				ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.08f * kb_alpha)), 8.f, 0, 1.f);

			// Icon in Preview Bar
			fg->AddText(ImVec2(prev_x + 8.f, prev_y + 6.f),
				ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.45f * kb_alpha)), ICON_SEARCH_LINE);

			// Preview Text or Placeholder
			float ptxt_x = prev_x + 28.f;
			float ptxt_y = prev_y + 6.f;
			if (buf[0] != '\0')
			{
				fg->AddText(ImVec2(ptxt_x, ptxt_y),
					ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.95f * kb_alpha)), buf);

				// Glowing Cursor
				float ptxt_w = font::small_font->CalcTextSizeA(font::small_font->FontSize, FLT_MAX, 0.f, buf).x;
				if (fmodf((float)ImGui::GetTime() * 2.5f, 2.0f) < 1.0f)
				{
					fg->AddLine(ImVec2(ptxt_x + ptxt_w + 1.f, ptxt_y + 1.f), ImVec2(ptxt_x + ptxt_w + 1.f, ptxt_y + 14.f),
						ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.95f * kb_alpha)), 1.8f);
				}

				// Mini Clear Button inside Preview Bar
				ImVec2 pcl_pos(prev_x + prev_w - 18.f, prev_y + 7.f);
				ImRect pcl_bb(pcl_pos - ImVec2(3, 3), pcl_pos + ImVec2(15, 15));
				bool pcl_hov = ImGui::IsMouseHoveringRect(pcl_bb.Min, pcl_bb.Max);
				if (pcl_hov && ImGui::IsMouseClicked(0))
				{
					buf[0] = '\0';
					value_changed = true;
				}
				fg->AddText(pcl_pos, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (pcl_hov ? 1.0f : 0.50f) * kb_alpha)), ICON_CLOSE_FILL);
			}
			else
			{
				fg->AddText(ImVec2(ptxt_x, ptxt_y),
					ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.30f * kb_alpha)), s.lang_layout == 1 ? "Введите поисковый запрос..." : "Type search query...");

				// Cursor even when empty
				if (fmodf((float)ImGui::GetTime() * 2.5f, 2.0f) < 1.0f)
				{
					fg->AddLine(ImVec2(ptxt_x + 1.f, ptxt_y + 1.f), ImVec2(ptxt_x + 1.f, ptxt_y + 14.f),
						ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.95f * kb_alpha)), 1.8f);
				}
			}

			// =========================================================
			// QUICK SEARCH SUGGESTION CHIPS
			// =========================================================
			float chip_y = prev_y + prev_h + 6.f;
			float chip_x = kb_pos.x + kb_pad;
			static const char* chips_en[] = { "aim", "rcs", "trig", "esp", "cham", "bhop", "cfg" };
			static const char* chips_ru[] = { "аим", "отдач", "триг", "вх", "чам", "распрыг", "кфг" };
			const char** cur_chips = (s.lang_layout == 1) ? chips_ru : chips_en;
			int chip_count = 7;
			float chip_h = 22.f;

			for (int c_idx = 0; c_idx < chip_count; c_idx++)
			{
				const char* ch_label = cur_chips[c_idx];
				float ch_w = font::small_font->CalcTextSizeA(font::small_font->FontSize, FLT_MAX, 0.f, ch_label).x + 14.f;
				ImRect ch_bb(ImVec2(chip_x, chip_y), ImVec2(chip_x + ch_w, chip_y + chip_h));
				bool ch_hov = ImGui::IsMouseHoveringRect(ch_bb.Min, ch_bb.Max);
				bool ch_active = (strstr(buf, ch_label) != nullptr);

				if (ch_hov && ImGui::IsMouseClicked(0))
				{
					snprintf(buf, buf_size, "%s", ch_label);
					value_changed = true;
				}

				ImVec4 ch_bg = ch_active ? ImVec4(c::anim::active.Value.x, c::anim::active.Value.y, c::anim::active.Value.z, 0.35f * kb_alpha)
					: (ch_hov ? ImVec4(0.14f, 0.18f, 0.26f, 0.85f * kb_alpha) : ImVec4(0.06f, 0.08f, 0.13f, 0.70f * kb_alpha));

				fg->AddRectFilled(ch_bb.Min, ch_bb.Max, ImGui::GetColorU32(ch_bg), 6.f);
				fg->AddRect(ch_bb.Min, ch_bb.Max,
					ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (ch_active ? 0.50f : (ch_hov ? 0.30f : 0.08f)) * kb_alpha)), 6.f, 0, 1.f);

				ImVec2 txt_p(chip_x + 7.f, chip_y + 4.f);
				fg->AddText(txt_p, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (ch_active || ch_hov ? 1.0f : 0.75f) * kb_alpha)), ch_label);

				chip_x += ch_w + 4.f;
			}
			PopFont();

			// =========================================================
			// 3D GLASS KEYCAPS RENDERING
			// =========================================================
			PushFont(font::small_font);

			auto draw_key = [&](ImVec2 k_pos, ImVec2 k_sz, const char* label, bool is_special = false, bool is_active = false) -> bool
			{
				ImRect k_bb(k_pos, k_pos + k_sz);
				bool k_hov = ImGui::IsMouseHoveringRect(k_bb.Min, k_bb.Max);
				bool k_down = k_hov && ImGui::IsMouseDown(0);
				bool k_pressed = k_hov && ImGui::IsMouseClicked(0);

				// Press down physical displacement (+1px Y)
				float press_y = (k_down || is_active) ? 1.f : 0.f;
				ImRect draw_bb(ImVec2(k_bb.Min.x, k_bb.Min.y + press_y), ImVec2(k_bb.Max.x, k_bb.Max.y + press_y));

				ImVec4 bg_col;
				if (is_active) {
					bg_col = ImVec4(c::anim::active.Value.x, c::anim::active.Value.y, c::anim::active.Value.z, (k_hov ? 0.45f : 0.32f) * kb_alpha);
				} else if (is_special) {
					bg_col = k_hov ? ImVec4(0.18f, 0.22f, 0.34f, 0.95f * kb_alpha) : ImVec4(0.09f, 0.12f, 0.18f, 0.85f * kb_alpha);
				} else {
					bg_col = k_hov ? ImVec4(0.15f, 0.19f, 0.28f, 0.95f * kb_alpha) : ImVec4(0.06f, 0.08f, 0.12f, 0.80f * kb_alpha);
				}

				// Soft key shadow
				fg->AddRectFilled(ImVec2(draw_bb.Min.x, draw_bb.Min.y + 1.f), ImVec2(draw_bb.Max.x, draw_bb.Max.y + 1.f),
					ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, 0.35f * kb_alpha)), 7.f);

				// Keycap fill
				fg->AddRectFilled(draw_bb.Min, draw_bb.Max, ImGui::GetColorU32(bg_col), 7.f);

				// Top bevel highlight (3D glass reflection)
				fg->AddLine(ImVec2(draw_bb.Min.x + 3.f, draw_bb.Min.y + 1.f), ImVec2(draw_bb.Max.x - 3.f, draw_bb.Min.y + 1.f),
					ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (k_hov ? 0.25f : 0.12f) * kb_alpha)), 1.f);

				// Outer key border
				fg->AddRect(draw_bb.Min, draw_bb.Max,
					ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (is_active ? 0.60f : (k_hov ? 0.30f : 0.08f)) * kb_alpha)), 7.f, 0, 1.f);

				// Key text centered
				ImVec2 txt_sz = font::small_font->CalcTextSizeA(font::small_font->FontSize, FLT_MAX, 0.f, label);
				ImVec2 txt_p(draw_bb.Min.x + (k_sz.x - txt_sz.x) * 0.5f, draw_bb.Min.y + (k_sz.y - txt_sz.y) * 0.5f);
				fg->AddText(txt_p, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (k_hov || is_active ? 1.0f : 0.85f) * kb_alpha)), label);

				return k_pressed;
			};

			auto type_text = [&](const char* text)
			{
				size_t cur_len = strlen(buf);
				size_t add_len = strlen(text);
				if (cur_len + add_len < buf_size)
				{
					memcpy(buf + cur_len, text, add_len + 1);
					value_changed = true;
				}
			};

			float start_y = chip_y + chip_h + 8.f;
			float k_cx, k_cy;

			// ROW 1: Numbers 1-0
			k_cx = kb_pos.x + kb_pad;
			k_cy = start_y;
			const char** r1 = (s.lang_layout == 1) ? ru_r1 : en_r1;
			for (int i = 0; i < r1_count; i++)
			{
				if (draw_key(ImVec2(k_cx, k_cy), ImVec2(key_w, key_h), r1[i]))
					type_text(r1[i]);
				k_cx += key_w + key_gap;
			}

			// ROW 2: Top row
			k_cx = kb_pos.x + kb_pad;
			k_cy += key_h + key_gap;
			const char** r2 = (s.lang_layout == 1) ? ru_r2 : en_r2;
			for (int i = 0; i < r2_count; i++)
			{
				if (draw_key(ImVec2(k_cx, k_cy), ImVec2(key_w, key_h), r2[i]))
					type_text(r2[i]);
				k_cx += key_w + key_gap;
			}

			// ROW 3: Middle row
			k_cx = kb_pos.x + kb_pad;
			k_cy += key_h + key_gap;
			const char** r3 = (s.lang_layout == 1) ? ru_r3 : en_r3;
			for (int i = 0; i < r3_count; i++)
			{
				if (draw_key(ImVec2(k_cx, k_cy), ImVec2(key_w, key_h), r3[i]))
					type_text(r3[i]);
				k_cx += key_w + key_gap;
			}

			// ROW 4: Bottom row + Backspace
			k_cx = kb_pos.x + kb_pad;
			k_cy += key_h + key_gap;
			const char** r4 = (s.lang_layout == 1) ? ru_r4 : en_r4;
			for (int i = 0; i < r4_count; i++)
			{
				if (draw_key(ImVec2(k_cx, k_cy), ImVec2(key_w, key_h), r4[i]))
					type_text(r4[i]);
				k_cx += key_w + key_gap;
			}

			// Backspace key on row 4 with Press-and-Hold Continuous Erase
			float bksp_w = (s.lang_layout == 1) ? (key_w * 2.f + key_gap) : (key_w * 3.f + key_gap * 2.f);
			ImRect bksp_bb(ImVec2(k_cx, k_cy), ImVec2(k_cx + bksp_w, k_cy + key_h));
			bool bksp_hov = ImGui::IsMouseHoveringRect(bksp_bb.Min, bksp_bb.Max);
			bool bksp_down = bksp_hov && ImGui::IsMouseDown(0);
			bool bksp_clicked = bksp_hov && ImGui::IsMouseClicked(0);

			auto do_backspace = [&]() {
				size_t len = strlen(buf);
				if (len > 0)
				{
					while (len > 0 && (buf[len - 1] & 0xC0) == 0x80)
						len--;
					if (len > 0) len--;
					buf[len] = '\0';
					value_changed = true;
				}
			};

			if (bksp_clicked)
			{
				do_backspace();
				s.bksp_hold_time = 0.f;
				s.bksp_repeat_timer = 0.f;
			}
			else if (bksp_down)
			{
				s.bksp_hold_time += dt;
				if (s.bksp_hold_time > 0.28f)
				{
					s.bksp_repeat_timer += dt;
					if (s.bksp_repeat_timer >= 0.045f)
					{
						s.bksp_repeat_timer = 0.f;
						do_backspace();
					}
				}
			}
			else
			{
				s.bksp_hold_time = 0.f;
				s.bksp_repeat_timer = 0.f;
			}

			// Render Backspace visual button with active glow when held
			draw_key(ImVec2(k_cx, k_cy), ImVec2(bksp_w, key_h), "<- BACK", true, bksp_down);

			// ROW 5: Layout Switch + SPACE + Clear + Done
			k_cy += key_h + key_gap;
			k_cx = kb_pos.x + kb_pad;

			// Layout Switch Button (EN / RU) with active dot indicator
			float switch_w = key_w * 1.8f;
			if (draw_key(ImVec2(k_cx, k_cy), ImVec2(switch_w, key_h), s.lang_layout == 1 ? "RU" : "EN", true, true))
			{
				s.lang_layout = (s.lang_layout == 1) ? 0 : 1;
			}
			k_cx += switch_w + key_gap;

			// Clear Button
			float clr_w = key_w * 1.6f;
			if (draw_key(ImVec2(k_cx, k_cy), ImVec2(clr_w, key_h), "CLR", true))
			{
				buf[0] = '\0';
				value_changed = true;
			}
			k_cx += clr_w + key_gap;

			// Space Bar
			float done_w = key_w * 2.2f;
			float space_w = (kb_pos.x + total_w - kb_pad) - k_cx - done_w - key_gap;
			if (space_w < 50.f) space_w = 50.f;

			if (draw_key(ImVec2(k_cx, k_cy), ImVec2(space_w, key_h), s.lang_layout == 1 ? "ПРОБЕЛ" : "SPACE", true))
			{
				type_text(" ");
			}
			k_cx += space_w + key_gap;

			// Done / Search Confirm Button
			if (draw_key(ImVec2(k_cx, k_cy), ImVec2(done_w, key_h), s.lang_layout == 1 ? "ГОТОВО" : "OK", true, true))
			{
				s.kb_open = false;
			}

			// =========================================================
			// SMART SEARCH MINI-TABS SIDE PANEL (СПРАВА ОТ КЛАВИАТУРЫ)
			// =========================================================
			struct SearchFeature {
				const char* name_en;
				const char* name_ru;
				const char* path_en;
				const char* path_ru;
				const char* icon;
				int page;
				int subtab;
				const char* tags;
			};

			static const SearchFeature all_features[] = {
				{ "Aimbot Target", "Основной Аимбот", "AIMBOT > CORE", "АИМ > ОСНОВНОЙ", ICON_SWORD_FILL, 0, 0, "aim fov smooth hitbox аим фов наводка автоаим голова прицел доводка keybind" },
				{ "Silent Aim", "Бесшумный Аим", "AIMBOT > SILENT", "АИМ > САЙЛЕНТ", ICON_TARGET_FILL, 0, 1, "silent aim сайлент аим бесшумный тихий" },
				{ "Recoil Control (RCS)", "Контроль отдачи (RCS)", "AIMBOT > RCS", "АИМ > ОТДАЧА", ICON_SHIELD_FILL, 0, 1, "rcs recoil отдач контроль спрей spray" },
				{ "Triggerbot Engine", "Триггербот", "AIMBOT > TRIGGER", "АИМ > ТРИГГЕР", ICON_BOMB_FILL, 0, 2, "trigger trig триггер автовыстрел выстрел delay задержка" },
				{ "Wallhack & Box ESP", "ВХ и Боксы", "VISUALS > ESP", "ВИЗУАЛЫ > ВХ", ICON_EYE_2_FILL, 1, 0, "wh esp wallhack вх боксы box здоровье health distance дистанция броня armor оружие weapon" },
				{ "3D Skeleton Preview", "3D Превью Скелета", "VISUALS > 3D", "ВИЗУАЛЫ > 3D", ICON_USER_3_FILL, 1, 1, "3d skeleton скелет кости превью манекен bones модель" },
				{ "Player Chams", "Чамсы Игроков", "VISUALS > CHAMS", "ВИЗУАЛЫ > ЧАМСЫ", ICON_FIRE_FILL, 1, 2, "chams чамсы glow свечение цвет чамс модельки" },
				{ "Night Mode & World", "Ночной режим и Мир", "VISUALS > WORLD", "ВИЗУАЛЫ > МИР", ICON_MOONLIGHT_FILL, 1, 2, "night ночной smoke flash смок дым флешка вспышка world мир небо sky" },
				{ "Player Roster", "Список Игроков", "PLAYERS > ROSTER", "ИГРОКИ > СПИСОК", ICON_GROUP_3_FILL, 2, 0, "players roster список игроки онлайн team союзники враги health hp" },
				{ "Target Filters", "Фильтры Целей", "PLAYERS > FILTERS", "ИГРОКИ > ФИЛЬТРЫ", ICON_FILTER_FILL, 2, 1, "filters видимость visible снайпер боты bots snipers приоритет priority" },
				{ "Crosshair Studio", "Студия Прицела", "HUD > CROSSHAIR", "ХАД > ПРИЦЕЛ", ICON_COMPASS_FILL, 3, 0, "crosshair прицел dot точка dynamic динамический recoil follow" },
				{ "Sound ESP (Steps)", "Звуковой ESP (Шаги)", "HUD > SOUND", "ХАД > ЗВУК", ICON_VOLUME_FILL, 3, 1, "sound звук шаги steps rings кольца громкость volume hitsound" },
				{ "Bunnyhop (B-Hop)", "Баннихоп (Распрыг)", "MISC > MOVEMENT", "НАСТРОЙКИ > ДВИЖЕНИЕ", ICON_RUN_FILL, 4, 0, "bhop bunnyhop распрыг баннихоп strafe стрейф автострейф jump прыжок" },
				{ "Speedhack & Thirdperson", "Спидхак и 3-е лицо", "MISC > MOVEMENT", "НАСТРОЙКИ > ДВИЖЕНИЕ", ICON_FLASH_FILL, 4, 0, "speedhack скорость thirdperson от третьего лица камера fov" },
				{ "Configs & Presets", "Конфигурация (КФГ)", "MISC > CONFIGS", "НАСТРОЙКИ > КФГ", ICON_SETTINGS_4_FILL, 4, 1, "cfg config configs кфг конфиг пресет preset save load сохранить загрузить theme" }
			};
			static const int feature_count = sizeof(all_features) / sizeof(all_features[0]);

			// Search matching
			std::string q_str = buf;
			for (auto& c : q_str) c = (char)tolower((unsigned char)c);
			while (!q_str.empty() && q_str.back() == ' ') q_str.pop_back();

			std::vector<int> matched_indices;
			if (!q_str.empty())
			{
				for (int fi = 0; fi < feature_count; fi++)
				{
					const auto& feat = all_features[fi];
					std::string combined = std::string(feat.name_en) + " " + feat.name_ru + " " + feat.path_en + " " + feat.path_ru + " " + feat.tags;
					for (auto& c : combined) c = (char)tolower((unsigned char)c);

					if (combined.find(q_str) != std::string::npos)
					{
						matched_indices.push_back(fi);
					}
				}
			}

			// Side Panel Background & Glow
			fg->AddShadowRect(side_pos, side_pos + ImVec2(side_w, side_h),
				ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, 0.70f * kb_alpha)), 32.f, ImVec2(0, 10), ImDrawFlags_RoundCornersAll, 16.f);
			fg->AddShadowRect(side_pos, side_pos + ImVec2(side_w, side_h),
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.10f * kb_alpha)), 20.f, ImVec2(0, 0), ImDrawFlags_RoundCornersAll, 16.f);
			fg->AddRectFilled(side_pos, side_pos + ImVec2(side_w, side_h),
				ImGui::GetColorU32(ImVec4(0.02f, 0.025f, 0.045f, 0.96f * kb_alpha)), 16.f);
			fg->AddRect(side_pos, side_pos + ImVec2(side_w, side_h),
				ImGui::GetColorU32(ImLerp(ImVec4(1.f, 1.f, 1.f, 0.12f * kb_alpha), utils::GetColorWithAlpha(c::anim::active, 0.75f * kb_alpha), s.kb_anim)), 16.f, 0, 1.2f);

			// Side Panel Header
			fg->AddRectFilled(side_pos, side_pos + ImVec2(side_w, header_h),
				ImGui::GetColorU32(ImVec4(0.035f, 0.045f, 0.075f, 0.90f * kb_alpha)), 16.f, ImDrawFlags_RoundCornersTop);
			fg->AddLine(side_pos + ImVec2(10.f, header_h), side_pos + ImVec2(side_w - 10.f, header_h),
				ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.08f * kb_alpha)), 1.f);

			// Header Title & Icon
			fg->AddText(side_pos + ImVec2(12.f, 9.f),
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.95f * kb_alpha)), ICON_FLASH_FILL);
			fg->AddText(side_pos + ImVec2(30.f, 9.f),
				ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.85f * kb_alpha)), s.lang_layout == 1 ? "СМАРТ-ПЕРЕХОД" : "SMART JUMP");

			// Badge count
			char badge_str[32];
			if (!q_str.empty())
				snprintf(badge_str, sizeof(badge_str), "%d НАЙД.", (int)matched_indices.size());
			else
				snprintf(badge_str, sizeof(badge_str), "0");

			float bw = font::small_font->CalcTextSizeA(font::small_font->FontSize, FLT_MAX, 0.f, badge_str).x + 10.f;
			ImVec2 badge_pos(side_pos.x + side_w - bw - 10.f, side_pos.y + 8.f);
			fg->AddRectFilled(badge_pos, badge_pos + ImVec2(bw, 18.f),
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.25f * kb_alpha)), 5.f);
			fg->AddText(badge_pos + ImVec2(5.f, 2.f),
				ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.95f * kb_alpha)), badge_str);

			// Render matching mini-tabs
			float card_y = side_pos.y + header_h + 8.f;
			float card_w = side_w - 16.f;
			float item_card_h = 42.f;
			float card_gap = 5.f;
			int max_visible_cards = (int)((side_h - header_h - 16.f) / (item_card_h + card_gap));
			int display_count = ImMin((int)matched_indices.size(), max_visible_cards);

			if (matched_indices.empty())
			{
				// Empty state card
				ImVec2 no_pos(side_pos.x + 8.f, card_y);
				fg->AddRectFilled(no_pos, no_pos + ImVec2(card_w, 64.f),
					ImGui::GetColorU32(ImVec4(0.035f, 0.045f, 0.07f, 0.70f * kb_alpha)), 8.f);
				fg->AddRect(no_pos, no_pos + ImVec2(card_w, 64.f),
					ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.06f * kb_alpha)), 8.f, 0, 1.f);
				
				const char* empty_msg = q_str.empty()
					? (s.lang_layout == 1 ? "Введите запрос для\nпоиска функций..." : "Type query to search\ncheat functions...")
					: (s.lang_layout == 1 ? "Ничего не найдено" : "No functions found");
				fg->AddText(no_pos + ImVec2(12.f, 16.f),
					ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.40f * kb_alpha)), empty_msg);
			}
			else
			{
				for (int m = 0; m < display_count; m++)
				{
					const auto& feat = all_features[matched_indices[m]];
					ImVec2 item_pos(side_pos.x + 8.f, card_y);
					ImRect item_bb(item_pos, item_pos + ImVec2(card_w, item_card_h));
					bool item_hov = ImGui::IsMouseHoveringRect(item_bb.Min, item_bb.Max);
					bool is_current = (nav::active_page == feat.page &&
						((feat.page == 0 && nav::aim_sub == feat.subtab) ||
						 (feat.page == 1 && nav::vis_sub == feat.subtab) ||
						 (feat.page == 2 && nav::ply_sub == feat.subtab) ||
						 (feat.page == 3 && nav::rad_sub == feat.subtab) ||
						 (feat.page == 4 && nav::msc_sub == feat.subtab)));

					// Click on mini-tab: Jump to target function!
					if (item_hov && ImGui::IsMouseClicked(0))
					{
						nav::jump_to(feat.page, feat.subtab);
					}

					// Card background
					ImVec4 card_bg = is_current
						? ImVec4(c::anim::active.Value.x, c::anim::active.Value.y, c::anim::active.Value.z, 0.32f * kb_alpha)
						: (item_hov ? ImVec4(0.12f, 0.15f, 0.24f, 0.85f * kb_alpha) : ImVec4(0.05f, 0.07f, 0.11f, 0.75f * kb_alpha));

					fg->AddRectFilled(item_bb.Min, item_bb.Max, ImGui::GetColorU32(card_bg), 8.f);
					fg->AddRect(item_bb.Min, item_bb.Max,
						ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (is_current ? 0.60f : (item_hov ? 0.35f : 0.08f)) * kb_alpha)), 8.f, 0, 1.f);

					// Icon square
					ImVec2 icon_box_pos(item_pos.x + 6.f, item_pos.y + 7.f);
					fg->AddRectFilled(icon_box_pos, icon_box_pos + ImVec2(28.f, 28.f),
						ImGui::GetColorU32(ImVec4(0.08f, 0.11f, 0.18f, 0.80f * kb_alpha)), 6.f);
					fg->AddText(icon_box_pos + ImVec2(7.f, 6.f),
						ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.95f * kb_alpha)), feat.icon);

					// Titles
					const char* name_txt = (s.lang_layout == 1) ? feat.name_ru : feat.name_en;
					const char* path_txt = (s.lang_layout == 1) ? feat.path_ru : feat.path_en;

					fg->AddText(item_pos + ImVec2(40.f, 5.f),
						ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (item_hov || is_current ? 1.0f : 0.85f) * kb_alpha)), name_txt);

					fg->AddText(item_pos + ImVec2(40.f, 21.f),
						ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, (item_hov || is_current ? 0.90f : 0.60f) * kb_alpha)), path_txt);

					// Right Jump Arrow Indicator [ -> ]
					fg->AddText(item_pos + ImVec2(card_w - 20.f, 13.f),
						ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, (item_hov ? 1.0f : 0.40f) * kb_alpha)), "->");

					card_y += item_card_h + card_gap;
				}
			}

			PopFont();
		}

		return value_changed;
	}

	bool PresetSelector(int* active_preset)
	{
		struct preset_info { const char* icon; const char* name; };
		static const preset_info presets[4] = {
			{ ICON_SHIELD_FILL, "LEGIT" },
			{ ICON_TARGET_FILL, "SEMI-RAGE" },
			{ ICON_SKULL_FILL, "RAGE" },
			{ ICON_SETTINGS_4_FILL, "CUSTOM" }
		};

		ImGuiWindow* window = ImGui::GetCurrentWindow();
		if (window->SkipItems) return false;

		ImVec2 pos = window->DC.CursorPos;
		float total_w = 260.f;
		float btn_w = total_w / 4.f;
		float btn_h = 24.f;
		ImRect bb(pos, pos + ImVec2(total_w, btn_h));

		ImGui::ItemSize(bb.GetSize());
		if (!ImGui::ItemAdd(bb, 0)) return false;

		ImDrawList* dl = window->DrawList;
		float alpha = ImGui::GetStyle().Alpha;

		dl->AddRectFilled(bb.Min, bb.Max, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.04f * alpha)), 6.f);
		dl->AddRect(bb.Min, bb.Max, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.08f * alpha)), 6.f, 0, 1.f);

		bool changed = false;
		for (int i = 0; i < 4; i++) {
			ImVec2 p_min(bb.Min.x + i * btn_w, bb.Min.y);
			ImVec2 p_max(p_min.x + btn_w, p_min.y + btn_h);
			ImRect p_bb(p_min, p_max);

			bool hov = p_bb.Contains(ImGui::GetMousePos());
			if (hov && ImGui::IsMouseClicked(0)) {
				*active_preset = i;
				changed = true;
			}

			if (*active_preset == i) {
				dl->AddRectFilled(p_min + ImVec2(1, 1), p_max - ImVec2(1, 1),
					ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.85f * alpha)), 5.f);
				dl->AddShadowRect(p_min, p_max,
					ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.40f * alpha)), 8.f, ImVec2(0, 0), 0, 5.f);
			}

			ImU32 text_col = (*active_preset == i) ? IM_COL32(255, 255, 255, 255) : (hov ? IM_COL32(220, 225, 240, 230) : IM_COL32(140, 145, 160, 180));
			PushFont(font::small_font);
			ImVec2 txt_sz = CalcTextSize(presets[i].name);
			dl->AddText(p_min + (ImVec2(btn_w, btn_h) - txt_sz) * 0.5f, text_col, presets[i].name);
			PopFont();
		}

		return changed;
	}

	bool SubTabBar(const char** subtabs, int count, int* current_subtab)
	{
		ImGuiWindow* window = ImGui::GetCurrentWindow();
		if (window->SkipItems || count <= 0) return false;

		float dt = ImGui::GetIO().DeltaTime;
		float alpha = ImGui::GetStyle().Alpha;
		ImVec2 pos = window->DC.CursorPos;
		float bar_h = 28.f;

		// Calculate total width dynamically
		float total_tabs_w = 0.f;
		float item_widths[16];
		for (int i = 0; i < count; i++) {
			PushFont(font::small_font);
			item_widths[i] = CalcTextSize(subtabs[i]).x + 14.f;
			PopFont();
			total_tabs_w += item_widths[i] + (i < count - 1 ? 14.f : 0.f);
		}

		ImRect track_bb(pos, pos + ImVec2(total_tabs_w, bar_h));
		ImGui::ItemSize(track_bb.GetSize());
		if (!ImGui::ItemAdd(track_bb, window->GetID("SubTabBar"))) return false;

		ImDrawList* dl = window->DrawList;

		static std::map<ImGuiID, float> anim_map;
		bool changed = false;
		float curr_x = track_bb.Min.x;

		for (int i = 0; i < count; i++) {
			float item_w = item_widths[i];
			ImVec2 t_min(curr_x, track_bb.Min.y);
			ImVec2 t_max(curr_x + item_w, track_bb.Max.y);
			ImRect t_bb(t_min, t_max);

			ImGuiID item_id = window->GetID(i + 88123);
			auto& anim_val = anim_map[item_id];

			ItemAdd(t_bb, item_id);
			bool sub_hov = false, sub_held = false;
			bool sub_pressed = ButtonBehavior(t_bb, item_id, &sub_hov, &sub_held);
			if (sub_pressed || (sub_hov && ImGui::IsMouseClicked(0))) {
				if (*current_subtab != i) {
					*current_subtab = i;
					changed = true;
				}
			}

			bool is_active = (*current_subtab == i);
			anim_val = ImLerp(anim_val, is_active ? 1.f : (sub_hov ? 0.5f : 0.f), dt * 14.f);

			PushFont(font::small_font);
			ImVec2 txt_sz = CalcTextSize(subtabs[i]);
			ImVec2 txt_pos = t_min + (ImVec2(item_w, bar_h - 4.f) - txt_sz) * 0.5f;

			if (is_active) {
				DrawLetterWaveText(dl, subtabs[i], txt_pos, 0.0f, alpha, true);

				// Clean Glowing Underline
				float line_y = track_bb.Max.y - 2.f;
				float half_w = (txt_sz.x + 6.f) * 0.5f;
				float mid_x = txt_pos.x + txt_sz.x * 0.5f;
				dl->AddRectFilled(ImVec2(mid_x - half_w, line_y), ImVec2(mid_x + half_w, line_y + 2.f),
					ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.95f * alpha)), 1.f);
			} else {
				ImU32 col = ImLerpColor(ImColor(135, 140, 155, 180), ImColor(255, 255, 255, 255), anim_val);
				dl->AddText(txt_pos, col, subtabs[i]);
			}
			PopFont();

			curr_x += item_w + 14.f;
		}

		return changed;
	}

	bool InputText(const char* label, const char* hint, char* buf, size_t buf_size, const ImVec2& size_arg)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		ImGuiID id = window->GetID(label);
		ImVec2 pos = window->DC.CursorPos;
		ImVec2 size = size_arg.x <= 0.0f ? ImVec2(GetContentRegionAvail().x, size_arg.y <= 0.0f ? 36.f : size_arg.y) : size_arg;
		ImRect bb(pos, pos + size);

		ItemSize(size, 0.0f);
		if (!ItemAdd(bb, id)) return false;

		bool hovered = ItemHoverable(bb, id, g.LastItemData.InFlags);
		bool focused = IsItemActive();

		struct in_state { float focus_anim = 0.f; };
		static std::map<ImGuiID, in_state> anim;
		auto& s = anim[id];
		s.focus_anim = ImLerp(s.focus_anim, (focused || hovered || buf[0] != '\0') ? 1.f : 0.f, g.IO.DeltaTime * 12.f);

		ImDrawList* dl = window->DrawList;
		float alpha = GetStyle().Alpha;

		// Frame Background & Shadow
		dl->AddRectFilled(bb.Min, bb.Max, ImGui::GetColorU32(ImVec4(0.06f, 0.08f, 0.12f, 0.65f * alpha)), 8.f);
		dl->AddRect(bb.Min, bb.Max, ImGui::GetColorU32(ImLerp(ImVec4(1.f, 1.f, 1.f, 0.08f * alpha), utils::GetColorWithAlpha(c::anim::active, 0.60f * alpha), s.focus_anim)), 8.f, 0, 1.f);

		// Text Input Area
		SetCursorScreenPos(ImVec2(bb.Min.x + 12.f, bb.Min.y + (size.y - GetTextLineHeight()) * 0.5f));
		PushItemWidth(size.x - 24.f);
		PushStyleColor(ImGuiCol_FrameBg, ImVec4(0, 0, 0, 0));
		PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
		PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(c::text::label::active));

		char label_id[32];
		snprintf(label_id, sizeof(label_id), "##in_txt_%u", id);
		bool value_changed = InputTextWithHint(label_id, hint, buf, buf_size, ImGuiInputTextFlags_None);

		PopStyleColor(3);
		PopItemWidth();
		SetCursorScreenPos(ImVec2(pos.x, bb.Max.y + GetStyle().ItemSpacing.y));

		return value_changed;
	}

	struct side_item_state {
		float active_anim = 0.f;
		float hover_anim = 0.f;
		float press_anim = 0.f;
	};

	bool SideNav(const char** labels, const char** icons, int count, int* active_tab, const ImVec2& size_arg)
	{
		ImGuiWindow* window = GetCurrentWindow();
		if (window->SkipItems) return false;

		ImGuiContext& g = *GImGui;
		ImVec2 pos = window->DC.CursorPos;
		ImVec2 size = size_arg.x <= 0.0f ? ImVec2(185.f, GetContentRegionAvail().y) : size_arg;
		ImRect bb(pos, pos + size);

		ItemSize(size, 0.0f);

		ImDrawList* dl = window->DrawList;
		float alpha = GetStyle().Alpha;
		float dt = g.IO.DeltaTime;

		// 1. Detached Outer Card Background (Solid Non-Transparent Black)
		dl->AddShadowRect(bb.Min, bb.Max, ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, 0.85f * alpha)), 38.f, ImVec2(0, 8), ImDrawFlags_RoundCornersAll, 14.f);
		dl->AddRectFilled(bb.Min, bb.Max, ImGui::GetColorU32(ImVec4(0.010f, 0.012f, 0.018f, 1.0f)), 14.f);

		// Glass rim edges
		dl->AddRect(bb.Min, bb.Max, ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.12f * alpha)), 14.f, 0, 1.f);

		// =====================================================
		// MIRAGE LOGO - Premium Emblem Badge + Lettering
		// =====================================================
		{
			// 1. Emblem Image Badge above MIRAGE lettering
			GLuint logo_tex = GetMirageLogoTexture();
			float logo_sz = 52.f;
			float logo_y = bb.Min.y + 12.f;
			float logo_x = bb.Min.x + (size.x - logo_sz) * 0.5f;
			ImVec2 lp0(logo_x, logo_y);
			ImVec2 lp1(logo_x + logo_sz, logo_y + logo_sz);

			if (logo_tex) {
				// Soft ambient glow behind emblem
				float pulse = (sinf((float)ImGui::GetTime() * 2.0f) + 1.0f) * 0.5f;
				dl->AddShadowRect(lp0 + ImVec2(4, 4), lp1 - ImVec2(4, 4), 
					ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, (0.28f + pulse * 0.14f) * alpha)), 
					20.f, ImVec2(0, 0), ImDrawFlags_RoundCornersAll, 12.f);

				dl->AddImage((ImTextureID)(intptr_t)logo_tex, lp0, lp1);
			}

			// 2. Lettering below Emblem
			const char letters[] = { 'M','I','R','A','G','E' };
			const int lcount = 6;
			float spacing = 6.0f;

			PushFont(font::logo_font);

			// Measure total width
			float total_w = 0.f;
			float letter_widths[6];
			for (int i = 0; i < lcount; i++) {
				char tmp[2] = { letters[i], 0 };
				letter_widths[i] = CalcTextSize(tmp).x;
				total_w += letter_widths[i] + (i < lcount - 1 ? spacing : 0.f);
			}
			float font_h = CalcTextSize("M").y;

			float start_x = bb.Min.x + (size.x - total_w) * 0.5f;
			float base_y = lp1.y + 8.f;
			float cursor_x = start_x;

			// Render each letter
			for (int i = 0; i < lcount; i++) {
				char tmp[2] = { letters[i], 0 };
				ImVec2 lp(cursor_x, base_y);

				// Shadow
				dl->AddText(ImVec2(lp.x + 1.5f, lp.y + 1.5f), ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, 0.80f * alpha)), tmp);

				// Animated Gradient color per letter (Primary -> Secondary Accent)
				float t = (float)i / (float)(lcount - 1);
				float wave_t = (sinf((float)ImGui::GetTime() * 2.0f + t * 3.14159f) + 1.0f) * 0.5f;
				ImColor lc = ImLerpColor(c::anim::active, c::anim::secondary, wave_t);
				lc.Value.w *= alpha;
				dl->AddText(lp, ImGui::GetColorU32(lc), tmp);

				cursor_x += letter_widths[i] + spacing;
			}

			PopFont();

			// Accent line under logo with Primary -> Secondary gradient
			float line_y = base_y + font_h + 5.f;
			int vtx_s = dl->VtxBuffer.Size;
			dl->AddRectFilled(ImVec2(start_x, line_y), ImVec2(start_x + total_w, line_y + 1.5f), IM_COL32_WHITE, 0.f);
			int vtx_e = dl->VtxBuffer.Size;
			set_linear_color(dl, vtx_s, vtx_e, ImVec2(start_x, line_y), ImVec2(start_x + total_w, line_y + 1.5f), c::anim::active, c::anim::secondary, 0.f);

		}

		// 2. Vertical Tab Items Loop (+40% Scaled for 245px sidebar)
		float item_start_y = bb.Min.y + 116.f;
		float item_h = 44.f;
		float item_gap = 6.f;
		bool value_changed = false;

		static std::map<ImGuiID, side_item_state> anims;

		for (int i = 0; i < count; i++) {
			ImGuiID item_id = window->GetID(i + 98123);
			auto& s = anims[item_id];

			ImVec2 i_min(bb.Min.x + 12.f, item_start_y + i * (item_h + item_gap));
			ImVec2 i_max(bb.Max.x - 12.f, i_min.y + item_h);
			ImRect i_bb(i_min, i_max);

			ItemAdd(i_bb, item_id);

			bool hovered, held;
			bool pressed = ButtonBehavior(i_bb, item_id, &hovered, &held);

			if (pressed || (hovered && ImGui::IsMouseClicked(0))) {
				if (*active_tab != i) {
					*active_tab = i;
					value_changed = true;
				}
			}

			bool is_active = (*active_tab == i);
			s.active_anim = ImLerp(s.active_anim, is_active ? 1.f : 0.f, dt * 10.f);
			s.hover_anim = ImLerp(s.hover_anim, hovered ? 1.f : 0.f, dt * 12.f);

			// Background highlight for active / hovered tab
			if (s.active_anim > 0.01f || s.hover_anim > 0.01f) {
				float bg_a = ImMax(s.active_anim * 0.12f, s.hover_anim * 0.05f) * alpha;
				dl->AddRectFilled(i_min, i_max, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, bg_a)), 8.f);
			}

			// Active Perfectly Straight Needle Line expanding from center outwards
			float ease_t = s.active_anim * s.active_anim * (3.0f - 2.0f * s.active_anim);
			if (ease_t > 0.001f) {
				float center_x = floorf((i_min.x + i_max.x) * 0.5f);
				float max_half_w = (i_max.x - i_min.x - 28.f) * 0.5f;
				float current_half_w = max_half_w * ease_t;

				if (current_half_w > 1.0f) {
					float y_mid = floorf(i_max.y - 2.0f);
					float h_half = 1.0f; // Crisp 2px thick straight line
					float taper = ImMin(6.0f, current_half_w * 0.5f);

					ImVec2 pts[6] = {
						ImVec2(center_x - current_half_w, y_mid),
						ImVec2(center_x - current_half_w + taper, y_mid - h_half),
						ImVec2(center_x + current_half_w - taper, y_mid - h_half),
						ImVec2(center_x + current_half_w, y_mid),
						ImVec2(center_x + current_half_w - taper, y_mid + h_half),
						ImVec2(center_x - current_half_w + taper, y_mid + h_half)
					};

					dl->AddConvexPolyFilled(pts, 6, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.95f * ease_t * alpha)));
				}
			}

			// Colors: Muted inactive -> Crisp white active & accent icon
			ImU32 icon_col = ImGui::GetColorU32(ImLerpColor(ImColor(135, 140, 155, 200), c::anim::active, s.active_anim));
			ImU32 label_col = ImGui::GetColorU32(ImLerpColor(ImColor(145, 150, 165, 200), ImColor(255, 255, 255, 255), s.active_anim));

			PushFont(font::inter_bold);
			ImVec2 ic_sz = CalcTextSize(icons[i]);
			ImVec2 tx_sz = CalcTextSize(labels[i]);

			// Icon rendering: ONLY active tab glows with primary->secondary wave!
			ImVec2 icon_pos(i_min.x + 18.f, i_min.y + (item_h - ic_sz.y) * 0.5f);
			if (is_active) {
				fade_text_smooth(dl, icons[i], icon_pos, c::anim::active, c::anim::secondary);
			} else {
				dl->AddText(icon_pos, icon_col, icons[i]);
			}

			dl->AddText(ImVec2(i_min.x + 48.f, i_min.y + (item_h - tx_sz.y) * 0.5f), label_col, labels[i]);
			PopFont();
		}

		return value_changed;
	}
}



