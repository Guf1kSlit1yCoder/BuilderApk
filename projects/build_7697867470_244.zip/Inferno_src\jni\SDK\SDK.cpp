#include "SDK.hpp"
#include "../Core/UE4Helper.h"
#include "../Core/ActorPipeline.h"
#include <unordered_set>

namespace SDK
{

UFunction* g_fnReceiveDrawHUD = nullptr;
UFunction* g_fnDrawHUD = nullptr;
UFunction* g_fnPostRender = nullptr;
UFunction* g_fnCanvasDraw = nullptr;
UFunction* g_fnSetCanCanvasDraw = nullptr;
UFunction* g_fnOnNewWidgetCreated = nullptr;
UFunction* g_fnK2_DrawLine = nullptr;
UFunction* g_fnK2_DrawBox = nullptr;
UFunction* g_fnK2_DrawText = nullptr;
UFunction* g_fnK2_DrawTexture = nullptr;
UFunction* g_fnK2_Project = nullptr;
UFunction* g_fnGetCharacterHealthComponent = nullptr;
UFunction* g_fnGetHealth = nullptr;
UFunction* g_fnGetHealthMax = nullptr;
UFunction* g_fnGetInputTouchState = nullptr;

// ==================== StaticClass Implementations ====================

#define DEFINE_STATIC_CLASS(ClassName, TypeStr) \
UClass* ClassName::StaticClass() { \
    static UClass* ptr = nullptr; \
    if (!ptr) ptr = UObject::FindObjectFast<UClass>(TypeStr); \
    return ptr; \
}

DEFINE_STATIC_CLASS(UActorComponent, "ActorComponent")
DEFINE_STATIC_CLASS(USceneComponent, "SceneComponent")
DEFINE_STATIC_CLASS(UPrimitiveComponent, "PrimitiveComponent")
DEFINE_STATIC_CLASS(UMeshComponent, "MeshComponent")
DEFINE_STATIC_CLASS(USkinnedMeshComponent, "SkinnedMeshComponent")
DEFINE_STATIC_CLASS(USkeletalMeshComponent, "SkeletalMeshComponent")
DEFINE_STATIC_CLASS(USkeleton, "Skeleton")
DEFINE_STATIC_CLASS(USkeletalMesh, "SkeletalMesh")
DEFINE_STATIC_CLASS(UAbilitySystemComponent, "AbilitySystemComponent")
DEFINE_STATIC_CLASS(UCameraComponent, "CameraComponent")
DEFINE_STATIC_CLASS(UCharacterMovementComponent, "CharacterMovementComponent")
DEFINE_STATIC_CLASS(UCapsuleComponent, "CapsuleComponent")
DEFINE_STATIC_CLASS(AActor, "Actor")
DEFINE_STATIC_CLASS(APawn, "Pawn")
DEFINE_STATIC_CLASS(ACharacter, "Character")
DEFINE_STATIC_CLASS(ASGCharacterBase, "SGCharacterBase")
DEFINE_STATIC_CLASS(ASGCharacterFastRepProxy, "SGCharacterFastRepProxy")
DEFINE_STATIC_CLASS(ASGCharacter, "SGCharacter")
DEFINE_STATIC_CLASS(ASGAICharacter, "SGAICharacter")
DEFINE_STATIC_CLASS(AController, "Controller")
DEFINE_STATIC_CLASS(APlayerController, "PlayerController")
DEFINE_STATIC_CLASS(ASGPlayerController, "SGPlayerController")
DEFINE_STATIC_CLASS(APlayerCameraManager, "PlayerCameraManager")
DEFINE_STATIC_CLASS(APlayerState, "PlayerState")
DEFINE_STATIC_CLASS(ASGPlayerState, "SGPlayerState")
DEFINE_STATIC_CLASS(UPlayer, "Player")
DEFINE_STATIC_CLASS(ULocalPlayer, "LocalPlayer")
DEFINE_STATIC_CLASS(UGameViewportClient, "GameViewportClient")
DEFINE_STATIC_CLASS(UGameInstance, "GameInstance")
DEFINE_STATIC_CLASS(UEngine, "Engine")
DEFINE_STATIC_CLASS(ULevel, "Level")
DEFINE_STATIC_CLASS(UWorld, "World")
DEFINE_STATIC_CLASS(UCanvas, "Canvas")
DEFINE_STATIC_CLASS(AHUD, "HUD")
DEFINE_STATIC_CLASS(UGameplayStatics, "GameplayStatics")
DEFINE_STATIC_CLASS(USGGameplayStatics, "SGGameplayStatics")
DEFINE_STATIC_CLASS(UAttributeSet, "AttributeSet")
DEFINE_STATIC_CLASS(USGActorHealthAttributeSet, "SGActorHealthAttributeSet")
DEFINE_STATIC_CLASS(USGCharacterHealthAttributeSet, "SGCharacterHealthAttributeSet")
DEFINE_STATIC_CLASS(USGActorHealthComponent, "SGActorHealthComponent")
DEFINE_STATIC_CLASS(USGCharacterHealthComponent, "SGCharacterHealthComponent")
DEFINE_STATIC_CLASS(USGCharacterStatics, "SGCharacterStatics")
DEFINE_STATIC_CLASS(ASGPickup, "SGPickup")

// ==================== USceneComponent ====================

bool USceneComponent::TryGetWorldLocation(FVector& outLocation) const
{
    outLocation = {0,0,0};
    if (!Tools::IsPtrValid(this) || !Tools::IsReadable(this, sizeof(USceneComponent))) return false;

    // Reflected fields: AttachParent=0xF0, RelativeLocation=0x154,
    // bComponentToWorldUpdated=0x02 and bAbsoluteLocation=0x08 at 0x184.
    // An unattached root (or absolute-location component) already stores world
    // coordinates here. Prefer them to the reconstructed, unreflected 0x190 cache.
    const uint8_t flags = Pad_0x184[0];
    FVector location;
    if (!AttachParent || (flags & 0x08) != 0) {
        location = RelativeLocation;
    } else {
        // An attached RelativeLocation is NOT a world position. Do not return it
        // or walk arbitrary parent/socket chains when the world cache is missing.
        if ((flags & 0x02) == 0) return false;
        const FTransform world = ComponentToWorld;
        if (!world.IsValid()) return false;
        location = world.Translation;
    }
    if (!std::isfinite(location.X) || !std::isfinite(location.Y) || !std::isfinite(location.Z)) return false;
    outLocation = location; // The world origin is a valid location, not a failure.
    return true;
}

FVector USceneComponent::K2_GetComponentLocation()
{
    FVector location;
    TryGetWorldLocation(location);
    return location;
}

FRotator USceneComponent::K2_GetComponentRotation()
{
    if (!Tools::IsPtrValid(this)) return {0,0,0};
    if (!Tools::IsReadable(this, sizeof(USceneComponent))) return {0,0,0};

    if (std::isfinite(RelativeRotation.Pitch) &&
        std::isfinite(RelativeRotation.Yaw) &&
        std::isfinite(RelativeRotation.Roll))
    {
        return RelativeRotation;
    }
    return {0,0,0};
}

FVector USceneComponent::GetSocketLocation(FName InSocketName)
{
    static UFunction* fn = nullptr;
    if (!fn) fn = UObject::FindObject<UFunction>("Function Engine.SceneComponent.GetSocketLocation");

    if (fn && InSocketName.ComparisonIndex > 0)
    {
        struct {
            FName InSocketName;
            FVector ReturnValue;
        } params{};

        params.InSocketName = InSocketName;
        ProcessEvent(fn, &params);
        if (params.ReturnValue.SizeSquared() > 0.001f) {
            return params.ReturnValue;
        }
    }

    return K2_GetComponentLocation();
}

// ==================== USkeletalMeshComponent ====================

int32_t USkeletalMeshComponent::GetBoneIndex(const char* BoneName)
{
    if (!BoneName || !*BoneName) return -1;
    if (!Tools::IsPtrValid(this)) return -1;

    // 1. Fast O(1) Exact Arena Breakout humanoid skeleton bone index mapping
    if (strcasecmp(BoneName, "Head") == 0 || strcasecmp(BoneName, "head") == 0) return 16;
    if (strcasecmp(BoneName, "neck_01") == 0 || strcasecmp(BoneName, "neck") == 0 || strcasecmp(BoneName, "Neck") == 0) return 15;
    if (strcasecmp(BoneName, "spine_03") == 0 || strcasecmp(BoneName, "spine") == 0 || strcasecmp(BoneName, "Spine") == 0) return 14;
    if (strcasecmp(BoneName, "spine_02") == 0) return 13;
    if (strcasecmp(BoneName, "spine_01") == 0) return 12;
    if (strcasecmp(BoneName, "pelvis") == 0 || strcasecmp(BoneName, "Pelvis") == 0) return 1;

    if (strcasecmp(BoneName, "clavicle_l") == 0) return 52;
    if (strcasecmp(BoneName, "upperarm_l") == 0 || strcasecmp(BoneName, "UpperArm_L") == 0) return 53;
    if (strcasecmp(BoneName, "lowerarm_l") == 0 || strcasecmp(BoneName, "LowerArm_L") == 0) return 54;
    if (strcasecmp(BoneName, "hand_l") == 0 || strcasecmp(BoneName, "Hand_L") == 0) return 56;

    if (strcasecmp(BoneName, "clavicle_r") == 0) return 22;
    if (strcasecmp(BoneName, "upperarm_r") == 0 || strcasecmp(BoneName, "UpperArm_R") == 0) return 23;
    if (strcasecmp(BoneName, "lowerarm_r") == 0 || strcasecmp(BoneName, "LowerArm_R") == 0) return 24;
    if (strcasecmp(BoneName, "hand_r") == 0 || strcasecmp(BoneName, "Hand_R") == 0) return 26;

    if (strcasecmp(BoneName, "thigh_l") == 0 || strcasecmp(BoneName, "Thigh_L") == 0) return 2;
    if (strcasecmp(BoneName, "calf_l") == 0 || strcasecmp(BoneName, "Calf_L") == 0) return 4;
    if (strcasecmp(BoneName, "foot_l") == 0 || strcasecmp(BoneName, "Foot_L") == 0) return 5;
    if (strcasecmp(BoneName, "ball_l") == 0) return 6;

    if (strcasecmp(BoneName, "thigh_r") == 0 || strcasecmp(BoneName, "Thigh_R") == 0) return 7;
    if (strcasecmp(BoneName, "calf_r") == 0 || strcasecmp(BoneName, "Calf_R") == 0) return 9;
    if (strcasecmp(BoneName, "foot_r") == 0 || strcasecmp(BoneName, "Foot_R") == 0) return 10;
    if (strcasecmp(BoneName, "ball_r") == 0) return 11;

    return -1;
}

int32_t USkeletalMeshComponent::GetBoneIndex(FName BoneName)
{
    return GetBoneIndex(BoneName.GetName().c_str());
}

FVector USkeletalMeshComponent::GetBoneLocation(int boneId)
{
    if (boneId < 0 || !Tools::IsPtrValid(this)) return {0,0,0};

    uintptr_t base = reinterpret_cast<uintptr_t>(this);

    // Primary: CachedComponentSpaceTransforms at offset 0x9B8 (Component Space).
    // Keep the bounded, non-recursive buffer read; never probe unknown offsets.
    auto compSpaceArr = reinterpret_cast<const TArray<FTransform>*>(base + Offsets::SkeletalMeshComponent::CachedComponentSpaceTransforms);
    if (!Tools::IsReadable(compSpaceArr, sizeof(*compSpaceArr))) return {0,0,0};
    const auto transforms = *compSpaceArr;
    const int32_t num = transforms.Num();
    const int32_t max = transforms.Max();
    if (num >= 5 && num <= 300 && max >= num && max <= 600 && boneId < num) {
        const auto data = transforms.GetData();
        if (data && Tools::IsPtrValid(data) && ((reinterpret_cast<uintptr_t>(data) & 0xF) == 0) &&
            Tools::IsReadable(data + boneId, sizeof(FTransform))) {
            const FTransform boneTransform = data[boneId];
            const FTransform meshWorld = ComponentToWorld;
            if (boneTransform.IsValid() && meshWorld.IsValid()) {
                const FVector pos = meshWorld.TransformPosition(boneTransform.Translation);
                if (std::isfinite(pos.X) && std::isfinite(pos.Y) && std::isfinite(pos.Z)) {
                    return pos;
                }
            }
        }
    }

    return {0,0,0};
}

float UCapsuleComponent::GetScaledCapsuleRadius()
{
    const uintptr_t base = reinterpret_cast<uintptr_t>(this);
    if (base && Tools::IsReadable(reinterpret_cast<void*>(base + Offsets::CapsuleComponent::CapsuleRadius), sizeof(float)))
    {
        const float rawRadius = *reinterpret_cast<float*>(base + Offsets::CapsuleComponent::CapsuleRadius);
        if (rawRadius > 1.0f && rawRadius < 200.0f) return rawRadius;
    }
    return 34.0f;
}

float UCapsuleComponent::GetScaledCapsuleHalfHeight()
{
    const uintptr_t base = reinterpret_cast<uintptr_t>(this);
    if (base && Tools::IsReadable(reinterpret_cast<void*>(base + Offsets::CapsuleComponent::CapsuleHalfHeight), sizeof(float)))
    {
        const float rawHalfHeight = *reinterpret_cast<float*>(base + Offsets::CapsuleComponent::CapsuleHalfHeight);
        if (rawHalfHeight > 1.0f && rawHalfHeight < 300.0f) return rawHalfHeight;
    }
    return 88.0f;
}

FVector USkeletalMeshComponent::GetBoneLocationByName(const char* name)
{
    if (!name || !*name) return K2_GetComponentLocation();
    int idx = GetBoneIndex(name);
    if (idx >= 0)
    {
        FVector bLoc = GetBoneLocation(idx);
        if (bLoc.SizeSquared() > 0.001f) return bLoc;
    }
    return K2_GetComponentLocation();
}

// ==================== AActor ====================

FVector AActor::K2_GetActorLocation()
{
    if (!Tools::IsPtrValid(this)) return {0,0,0};
    return (RootComponent && Tools::IsPtrValid(RootComponent)) ? RootComponent->K2_GetComponentLocation() : FVector{0,0,0};
}

FRotator AActor::K2_GetActorRotation()
{
    if (!Tools::IsPtrValid(this)) return {0,0,0};
    return (RootComponent && Tools::IsPtrValid(RootComponent)) ? RootComponent->K2_GetComponentRotation() : FRotator{0,0,0};
}

float AActor::GetDistanceTo(AActor* OtherActor)
{
    if (!Tools::IsPtrValid(this) || !Tools::IsPtrValid(OtherActor)) return 0.0f;
    return K2_GetActorLocation().Distance(OtherActor->K2_GetActorLocation()) / 100.0f; // in meters
}

// ==================== ASGCharacter ====================

bool IsLiveSDKObject(const UObject* obj)
{
    if (!Tools::IsPtrValid(obj) || !Tools::IsReadable(obj, sizeof(UObject))) return false;
    const auto objects = UObject::GObjects;
    if (!Tools::IsPtrValid(objects)) return false;

    // Zero-syscall memory check doesn't guarantee the page is mapped in user space.
    // Use PVM_ReadAddr (process_vm_readv) to safely read InternalIndex without any SIGSEGV risk.
    int32_t internalIndex = -1;
    if (!Tools::PVM_ReadAddr(const_cast<uint8_t*>(reinterpret_cast<const uint8_t*>(obj)) + 0x0C, &internalIndex, sizeof(int32_t))) return false;
    if (internalIndex < 0 || internalIndex >= objects->Num()) return false;

    const auto item = objects->GetItemByIndex(internalIndex);
    if (!item || item->Object != obj || item->IsUnreachable() || item->IsPendingKill()) return false;

    UClass* cls = nullptr;
    if (!Tools::PVM_ReadAddr(const_cast<uint8_t*>(reinterpret_cast<const uint8_t*>(obj)) + 0x10, &cls, sizeof(UClass*))) return false;
    return cls && Tools::IsPtrValid(cls) && Tools::IsReadable(cls, sizeof(UClass));
}

// Only the exact dump classes (or their subclasses) establish a field layout.
// A substring such as "Health" also matches unrelated stats/classes.
bool HasSDKClass(const UObject* obj, const char* name)
{
    if (!IsLiveSDKObject(obj)) return false;
    auto cls = static_cast<UStruct*>(obj->ClassPrivate);
    for (int depth = 0; cls && depth < 32; ++depth, cls = cls->SuperStruct) {
        if (!Tools::IsPtrValid(cls) || !Tools::IsReadable(cls, sizeof(UStruct))) return false;
        if (cls->GetName() == name) return true;
    }
    return false;
}

// Reads 7-part body endurance from BP_CharacterEnduranceAttributeSet_Uam_C (Size: 0x1D0).
// In Arena Breakout, character damage is applied to body part endurances starting at offset 0x44:
//   +0x44: HeadEndurance,     +0x48: HeadEnduranceMax   (typically 35-37)
//   +0x4C: ChestEndurance,    +0x50: ChestEnduranceMax  (typically 85-88)
//   +0x54: StomachEndurance,  +0x58: StomachEnduranceMax (typically 70)
//   +0x5C: LeftArmEndurance,  +0x60: LeftArmEnduranceMax (typically 40-60)
//   +0x64: RightArmEndurance, +0x68: RightArmEnduranceMax (typically 40-60)
//   +0x6C: LeftLegEndurance,  +0x70: LeftLegEnduranceMax (typically 65)
//   +0x74: RightLegEndurance, +0x78: RightLegEnduranceMax (typically 65)
// Fatal kill happens when Head <= 0 or Chest <= 0 or total <= 0.
static bool ReadEnduranceValues(const UObject* attr, float& health, float& maxHealth, bool& isFatal)
{
    health = maxHealth = -1.0f;
    isFatal = false;
    if (!Tools::IsPtrValid(attr) || !Tools::IsReadable(attr, sizeof(UObject))) return false;

    const auto base = reinterpret_cast<const uint8_t*>(attr) + Offsets::Health::Health_Current;
    float parts[14]{};
    if (!Tools::IsReadable(base, sizeof(parts))) return false;
    std::memcpy(parts, base, sizeof(parts));

    float head = parts[0], headMax = parts[1];
    float chest = parts[2], chestMax = parts[3];
    if (!std::isfinite(headMax) || headMax < 10.0f || headMax > 200.0f) return false;
    if (!std::isfinite(chestMax) || chestMax < 20.0f || chestMax > 300.0f) return false;

    float currentSum = 0.0f;
    float maxSum = 0.0f;
    for (int i = 0; i < 7; ++i) {
        float cur = parts[i * 2];
        float mx = parts[i * 2 + 1];
        if (!std::isfinite(cur) || !std::isfinite(mx) || mx < 0.0f || mx > 500.0f) return false;
        currentSum += std::clamp(cur, 0.0f, mx);
        maxSum += mx;
    }

    if (maxSum < 100.0f || maxSum > 2000.0f) return false;

    if (head <= 0.0f || chest <= 0.0f || currentSum <= 0.0f) {
        isFatal = true;
        health = 0.0f;
        maxHealth = maxSum;
        return true;
    }

    health = currentSum;
    maxHealth = maxSum;
    return true;
}

// Reads standard Health/HealthMax pair or DBNO pool.
static bool ReadHealthValues(const UObject* attr, float& health, float& maxHealth, bool isKnocked = false)
{
    health = maxHealth = -1.0f;
    if (!Tools::IsPtrValid(attr) || !Tools::IsReadable(attr, sizeof(UObject))) return false;

    const auto base = reinterpret_cast<const uint8_t*>(attr);

    // 1. If knocked down (DBNO), prioritize DBNO bleed-out health pool at +0x54 / +0x58
    if (isKnocked) {
        const auto values54 = base + Offsets::Health::DBNO_Current;
        float pair54[2]{};
        if (Tools::IsReadable(values54, sizeof(pair54))) {
            std::memcpy(pair54, values54, sizeof(pair54));
            float dbnoHp = pair54[0], dbnoMax = pair54[1];
            if (std::isfinite(dbnoHp) && std::isfinite(dbnoMax) && dbnoMax >= 10.0f && dbnoMax <= 5000.0f && dbnoHp >= -100.0f && dbnoHp <= dbnoMax * 1.5f) {
                health = std::clamp(dbnoHp, 0.0f, dbnoMax);
                maxHealth = dbnoMax;
                return true;
            }
        }
    }

    // 2. Standard character health at +0x44 (Health) and +0x48 (HealthMax)
    const auto values44 = base + Offsets::Health::Health_Current;
    float pair44[2]{};
    if (Tools::IsReadable(values44, sizeof(pair44))) {
        std::memcpy(pair44, values44, sizeof(pair44));
        float hp = pair44[0], maxHp = pair44[1];
        if (std::isfinite(hp) && std::isfinite(maxHp) && maxHp >= 10.0f && maxHp <= 5000.0f && hp >= -1000.0f && hp <= maxHp * 1.5f) {
            health = std::clamp(hp, 0.0f, maxHp);
            maxHealth = maxHp;
            return true;
        }
    }

    // 3. Normalized health at +0x68 (1.0 = 100%) on AI health sets
    const auto values68 = base + Offsets::Health::Normalized;
    float val68 = 0.0f;
    if (Tools::IsReadable(values68, sizeof(val68))) {
        std::memcpy(&val68, values68, sizeof(val68));
        if (std::isfinite(val68) && val68 >= 0.0f && val68 <= 1.0f) {
            health = val68 * 100.0f;
            maxHealth = 100.0f;
            return true;
        }
    }

    return false;
}

bool ASGCharacter::TryGetHealth(float& health, float& maxHealth)
{
    health = maxHealth = -1.0f;
    if (!Tools::IsPtrValid(this)) return false;
    const bool knocked = IsKnocked();

    // 1. Primary: AbilitySystemComponent (+0x1698) -> SpawnedAttributes (+0x170)
    if (Tools::IsReadable(&AbilitySystemComponent, sizeof(AbilitySystemComponent))) {
        const auto asc = AbilitySystemComponent;
        if (Tools::IsPtrValid(asc) && Tools::IsReadable(&asc->SpawnedAttributes, sizeof(asc->SpawnedAttributes))) {
            const auto attributes = asc->SpawnedAttributes;
            const int count = attributes.Num();
            if (count > 0 && count <= 64 && attributes.Max() >= count &&
                Tools::IsPtrValid(attributes.GetData()) &&
                Tools::IsReadable(attributes.GetData(), count * sizeof(UObject*))) {

                UObject* localAttrs[64];
                const int safeCount = std::min(count, 64);
                if (Tools::Read(const_cast<UObject**>(attributes.GetData()), localAttrs, safeCount * sizeof(UObject*))) {
                    // Pass 1: True body-part damage in BP_CharacterEnduranceAttributeSet_Uam_C
                    for (int i = 0; i < safeCount; ++i) {
                        auto attr = localAttrs[i];
                        if (!Tools::IsPtrValid(attr) || !Tools::IsReadable(attr, sizeof(UObject))) continue;
                        const auto cls = attr->ClassPrivate;
                        if (!Tools::IsPtrValid(cls) || !Tools::IsReadable(cls, sizeof(UClass))) continue;
                        const std::string clsName = cls->GetName();
                        if (clsName.find("EnduranceAttributeSet") != std::string::npos) {
                            bool isFatal = false;
                            if (ReadEnduranceValues(attr, health, maxHealth, isFatal)) {
                                if (isFatal && knocked) break; // In DBNO, continue to find HealthAttributeSet for DBNO health
                                return true;
                            }
                        }
                    }

                    // Pass 2: HealthAttributeSet (DBNO bleed-out health or fallback)
                    for (int i = 0; i < safeCount; ++i) {
                        auto attr = localAttrs[i];
                        if (!Tools::IsPtrValid(attr) || !Tools::IsReadable(attr, sizeof(UObject))) continue;
                        const auto cls = attr->ClassPrivate;
                        if (!Tools::IsPtrValid(cls) || !Tools::IsReadable(cls, sizeof(UClass))) continue;
                        const std::string clsName = cls->GetName();
                        if (clsName.find("HealthAttributeSet") != std::string::npos ||
                            HasSDKClass(attr, "SGCharacterHealthAttributeSet") ||
                            HasSDKClass(attr, "SGActorHealthAttributeSet")) {
                            if (ReadHealthValues(attr, health, maxHealth, knocked)) return true;
                        }
                    }
                }
            }
        }
    }

    // 2. Direct component: USGCharacterEnduranceComponent
    const auto endComp = FindComponentByClassName("SGCharacterEnduranceComponent");
    if (endComp && Tools::IsPtrValid(endComp)) {
        const auto endBase = reinterpret_cast<const uint8_t*>(endComp);
        if (Tools::IsReadable(endBase + Offsets::Health::EnduranceComp_Attribute, sizeof(void*))) {
            auto attr = *reinterpret_cast<const UObject* const*>(endBase + Offsets::Health::EnduranceComp_Attribute);
            if (Tools::IsPtrValid(attr)) {
                bool isFatal = false;
                if (ReadEnduranceValues(attr, health, maxHealth, isFatal)) {
                    if (!isFatal || !knocked) return true;
                }
            }
        }
    }

    // 3. Fallback: FindComponentByClassName("SGCharacterHealthComponent")
    auto healthComp = GetCharacterHealthComponent();
    if (healthComp && Tools::IsReadable(&healthComp->AttributeSetClass, sizeof(healthComp->AttributeSetClass))) {
        auto attr = healthComp->AttributeSetClass;
        if (Tools::IsPtrValid(attr) && ReadHealthValues(attr, health, maxHealth, knocked)) {
            return true;
        }
    }

    return false;
}

USGCharacterHealthComponent* ASGCharacter::GetCharacterHealthComponent()
{
    // ASGCharacter has no direct component pointer field in dump_ClassOffsets, but
    // the component is an owned instance component, so it is reachable through the
    // instance-component arrays. USGCharacterHealthComponent (0x1A8) derives from
    // USGActorHealthComponent, which carries AttributeSetClass at 0xE0.
    return reinterpret_cast<USGCharacterHealthComponent*>(
        FindComponentByClassName("SGCharacterHealthComponent"));
}

float ASGCharacter::GetHealth()
{
    float health, maximum;
    return TryGetHealth(health, maximum) ? health : -1.0f;
}

float ASGCharacter::GetMaxHealth()
{
    float health, maximum;
    return TryGetHealth(health, maximum) ? maximum : -1.0f;
}

bool ASGCharacter::IsDead()
{
    if (!Tools::IsPtrValid(this) || !Tools::IsReadable(this, sizeof(UObject))) return true;

    UClass* cls = ClassPrivate;
    if (!Tools::IsPtrValid(cls) || !Tools::IsReadable(cls, sizeof(UClass))) return true;

    uintptr_t base = reinterpret_cast<uintptr_t>(this);

    // 1. AActor::bActorIsBeingDestroyed at offset 0x006C bit 3 (mask 0x08)
    if (Tools::IsReadable(reinterpret_cast<void*>(base + Offsets::Actor::ActorFlags), sizeof(uint8_t))) {
        uint8_t actorFlags = *reinterpret_cast<uint8_t*>(base + Offsets::Actor::ActorFlags);
        if (actorFlags & 0x08) return true; // bActorIsBeingDestroyed
    }

    // 2. AActor::bTearOff at offset 0x0068 bit 6 (mask 0x40) - server signals dead ragdoll
    if (Tools::IsReadable(reinterpret_cast<void*>(base + Offsets::Actor::NetFlags), sizeof(uint8_t))) {
        uint8_t netFlags = *reinterpret_cast<uint8_t*>(base + Offsets::Actor::NetFlags);
        if ((netFlags & 0x40) && !IsKnocked()) return true;
    }

    // 3. Check SGCharacterDeathComponent for confirmed death
    const auto deathComp = FindComponentByClassName("SGCharacterDeathComponent");
    if (deathComp && Tools::IsPtrValid(deathComp)) {
        const auto deathBase = reinterpret_cast<const uint8_t*>(deathComp);
        if (Tools::IsReadable(deathBase + Offsets::Health::DeathComp_psDied, sizeof(void*))) {
            void* psDied = *reinterpret_cast<void* const*>(deathBase + Offsets::Health::DeathComp_psDied);
            if (Tools::IsPtrValid(psDied)) return true;
        }
        if (Tools::IsReadable(deathBase + Offsets::Health::DeathComp_box, sizeof(void*))) {
            void* box = *reinterpret_cast<void* const*>(deathBase + Offsets::Health::DeathComp_box);
            if (Tools::IsPtrValid(box)) return true;
        }
    }

    // 4. No Mesh / no RootComponent = not spawned or already cleaned up.
    if (!Mesh || !Tools::IsPtrValid(Mesh)) return true;
    if (!RootComponent || !Tools::IsPtrValid(RootComponent)) return true;

    // 5. Knocked characters are alive while their DBNO health pool is > 0
    if (IsKnocked()) {
        float hp = -1.0f, maxHp = -1.0f;
        if (TryGetHealth(hp, maxHp) && maxHp > 0.0f && hp <= 0.0f) return true; // bled out
        return false;
    }

    // 6. Health == 0: character is dead but the actor hasn't been destroyed yet.
    float hp = -1.0f, maxHp = -1.0f;
    if (TryGetHealth(hp, maxHp) && maxHp > 0.0f && hp <= 0.0f) return true;

    return false;
}

int32_t ASGCharacter::GetTeamID()
{
    if (!Tools::IsPtrValid(this)) return -1;
    if (IsAI())
    {
        uintptr_t base = reinterpret_cast<uintptr_t>(this);
        if (Tools::IsReadable(reinterpret_cast<void*>(base + Offsets::SGAICharacter::AITeamIndex), sizeof(int32_t))) {
            int32_t aiTeam = *reinterpret_cast<int32_t*>(base + Offsets::SGAICharacter::AITeamIndex);
            if (aiTeam > 0 && aiTeam < 1000) return aiTeam;
        }
        return 0;
    }
    int32_t tid = PlayerInfo.TeamIndex;
    if (tid >= 0 && tid < 100) return tid;

    // Fallback: check PlayerState.TeamIndex at offset 0x5A0
    auto* ps = PlayerInfo.PlayerState;
    if (!ps && Tools::IsReadable(reinterpret_cast<uint8_t*>(this) + Offsets::Pawn::PlayerState, sizeof(void*))) {
        ps = reinterpret_cast<ASGPlayerState*>(*reinterpret_cast<SDK::APlayerState**>(reinterpret_cast<uint8_t*>(this) + Offsets::Pawn::PlayerState));
    }
    if (ps && Tools::IsPtrValid(ps)) {
        if (Tools::IsReadable(reinterpret_cast<uint8_t*>(ps) + Offsets::SGPlayerState::TeamIndex, sizeof(int32_t))) {
            int32_t psTid = *reinterpret_cast<const int32_t*>(reinterpret_cast<uint8_t*>(ps) + Offsets::SGPlayerState::TeamIndex);
            if (psTid >= 0 && psTid < 100) return psTid;
        }
    }
    return -1;
}

bool ASGCharacter::GetFastRepLocation(FVector& out)
{
    if (!Tools::IsPtrValid(this) || !Tools::IsReadable(this, sizeof(UObject))) return false;
    const uintptr_t self = reinterpret_cast<uintptr_t>(this);
    uintptr_t proxy = Tools::ReadMemory<uintptr_t>(self + Offsets::SGCharacter::CharacterFastRepProxy); // CharacterFastRepProxy
    if (!proxy || !Tools::IsPtrValid(reinterpret_cast<void*>(proxy))) {
        auto* p = ActorPipeline::GetFastRepForChar(const_cast<ASGCharacter*>(this));
        if (p) proxy = reinterpret_cast<uintptr_t>(p);
    }
    if (!proxy || !Tools::IsPtrValid(reinterpret_cast<void*>(proxy)) ||
        !Tools::IsReadable(reinterpret_cast<void*>(proxy + Offsets::FastRepProxy::Location), sizeof(FVector))) return false;
    const FVector loc = Tools::ReadMemory<FVector>(proxy + Offsets::FastRepProxy::Location); // FastReplicatedMovement.Location
    if (!std::isfinite(loc.X) || !std::isfinite(loc.Y) || !std::isfinite(loc.Z)) return false;
    if (loc.SizeSquared() < 0.001f) return false;                                   // dormant origin
    if (std::abs(loc.X) < 1.0f && std::abs(loc.Y) < 1.0f) return false;
    if (loc.Z < -50000.0f || loc.Z > 200000.0f) return false;
    out = loc;
    return true;
}

bool ASGCharacter::GetProxyPosition(FVector& out)
{
    if (!Tools::IsPtrValid(this) || !Tools::IsReadable(this, sizeof(UObject))) return false;
    const uintptr_t self = reinterpret_cast<uintptr_t>(this);
    uintptr_t proxy = Tools::ReadMemory<uintptr_t>(self + Offsets::SGCharacter::CharacterFastRepProxy); // CharacterFastRepProxy
    if (!proxy || !Tools::IsPtrValid(reinterpret_cast<void*>(proxy))) {
        auto* p = ActorPipeline::GetFastRepForChar(const_cast<ASGCharacter*>(this));
        if (p) proxy = reinterpret_cast<uintptr_t>(p);
    }
    if (!proxy || !Tools::IsPtrValid(reinterpret_cast<void*>(proxy)) ||
        !Tools::IsReadable(reinterpret_cast<void*>(proxy + Offsets::FastRepProxy::Location), sizeof(FVector))) return false;
    const FVector loc = Tools::ReadMemory<FVector>(proxy + Offsets::FastRepProxy::Location); // FastReplicatedMovement.Location
    auto sane = [](const FVector& v) {
        return std::isfinite(v.X) && std::isfinite(v.Y) && std::isfinite(v.Z) &&
               v.SizeSquared() > 0.001f &&
               (std::abs(v.X) >= 1.0f || std::abs(v.Y) >= 1.0f) &&
               v.Z >= -50000.0f && v.Z <= 200000.0f;
    };
    if (!sane(loc)) return false;
    if (Tools::IsReadable(reinterpret_cast<void*>(proxy + Offsets::FastRepProxy::PredictStopLocation), sizeof(FVector))) {
        const FVector stop = Tools::ReadMemory<FVector>(proxy + Offsets::FastRepProxy::PredictStopLocation); // PredictStopLocation
        if (sane(stop)) {
            // PredictStopLocation gives accurate X/Y but an unreliable Z (often ground-
            // projected -> markers sink underground). Take X/Y from the prediction and
            // the authoritative height from the replicated location.
            const float dx = stop.X - loc.X, dy = stop.Y - loc.Y;
            if (dx*dx + dy*dy < 5000.0f * 5000.0f) {
                out = stop;
                out.Z = loc.Z;
                return true;
            }
        }
    }
    out = loc;
    return true;
}

bool ASGCharacter::GetProxyVelocity(FVector& out)
{
    out = {0,0,0};
    if (!Tools::IsPtrValid(this) || !Tools::IsReadable(this, sizeof(UObject))) return false;
    const uintptr_t self = reinterpret_cast<uintptr_t>(this);
    uintptr_t proxy = Tools::ReadMemory<uintptr_t>(self + Offsets::SGCharacter::CharacterFastRepProxy);
    if (!proxy || !Tools::IsPtrValid(reinterpret_cast<void*>(proxy))) {
        auto* p = ActorPipeline::GetFastRepForChar(const_cast<ASGCharacter*>(this));
        if (p) proxy = reinterpret_cast<uintptr_t>(p);
    }
    if (!proxy || !Tools::IsPtrValid(reinterpret_cast<void*>(proxy)) ||
        !Tools::IsReadable(reinterpret_cast<void*>(proxy + Offsets::FastRepProxy::LinearVelocity), sizeof(FVector))) return false;
    const FVector v = Tools::ReadMemory<FVector>(proxy + Offsets::FastRepProxy::LinearVelocity); // FRepMovement.LinearVelocity
    if (!(v.X == v.X) || !(v.Y == v.Y) || !(v.Z == v.Z)) return false;
    if (v.X > 1e7f || v.X < -1e7f || v.Y > 1e7f || v.Y < -1e7f) return false;
    out = v;
    return true;
}

bool ASGCharacter::IsAI()
{
    if (!Tools::IsPtrValid(this) || !Tools::IsReadable(this, sizeof(UObject))) return false;
    UClass* cls = ClassPrivate;
    if (!Tools::IsPtrValid(cls) || !Tools::IsReadable(cls, sizeof(UClass))) return false;

    struct ClassKind { int32_t nameIndex; bool isAI; };
    static thread_local UWorld* lastWorld = nullptr;
    static thread_local std::unordered_map<UClass*, ClassKind> kinds;
    if (lastWorld != UE4Helper::g_World) {
        kinds.clear();
        lastWorld = UE4Helper::g_World;
    }

    if (!Tools::IsPtrValid(cls) || !Tools::IsReadable(cls, sizeof(UClass))) return false;
    const int32_t nameIndex = cls->NamePrivate.ComparisonIndex;
    auto found = kinds.find(cls);
    if (found != kinds.end() && found->second.nameIndex == nameIndex) return found->second.isAI;

    // Classify each concrete class once; never scan GObjects looking for an AI
    // class which may not be loaded yet. Invalid names are retried, not cached.
    bool isAI = false;
    auto curr = static_cast<UStruct*>(cls);
    for (int depth = 0; curr && depth < 32; ++depth) {
        if (!Tools::IsPtrValid(curr) || !Tools::IsReadable(curr, sizeof(UStruct))) return false;
        const std::string name = curr->GetName();
        if (name.empty() || name == "None") return false;
        // SGFramework.SGAICharacter — standard AI hierarchy (AICharacter in name)
        // MFNPCAI.* — Arena Breakout's NPC AI package (NPCAICharacter, NPCAIController)
        // UamAI / BP_AI — legacy blueprint patterns
        if (name.find("AICharacter") != std::string::npos ||
            name.find("NPCAICharacter") != std::string::npos ||
            name.find("MFNPCAI") != std::string::npos ||
            name.find("UamAI") != std::string::npos ||
            name.find("BP_AI") != std::string::npos) {
            isAI = true;
            break;
        }
        curr = curr->SuperStruct;
    }
    kinds[cls] = {nameIndex, isAI};
    return isAI;
}

// IsNPC: detects Arena Breakout's MFNPCAI-package characters (scripted actors, not
// standard AI bots). They share the SGCharacterBase hierarchy but are tagged with
// MFNPCAI or NPCAICharacter in their class chain. Shown as "ACTOR" in the overlay.
bool ASGCharacter::IsNPC()
{
    if (!Tools::IsPtrValid(this) || !Tools::IsReadable(this, sizeof(UObject))) return false;
    UClass* cls = ClassPrivate;
    if (!Tools::IsPtrValid(cls) || !Tools::IsReadable(cls, sizeof(UClass))) return false;
    auto curr = static_cast<UStruct*>(cls);
    for (int depth = 0; curr && depth < 24; ++depth) {
        if (!Tools::IsPtrValid(curr) || !Tools::IsReadable(curr, sizeof(UStruct))) return false;
        const std::string name = curr->GetName();
        if (name.empty() || name == "None") return false;
        if (name.find("MFNPCAI") != std::string::npos ||
            name.find("NPCAICharacter") != std::string::npos) return true;
        // Stop at SGAICharacter — standard bots are NOT NPCs
        if (name.find("SGAICharacter") != std::string::npos) return false;
        curr = curr->SuperStruct;
    }
    return false;
}

USkeletalMeshComponent* ASGCharacter::GetMeshComponent()
{
    if (!Tools::IsPtrValid(this)) return nullptr;
    return (Mesh && Tools::IsPtrValid(Mesh)) ? Mesh : nullptr;
}

UActorComponent* AActor::FindComponentByClassName(const char* className) const
{
    if (!className || !IsLiveSDKObject(this)) return nullptr;

    // InstanceComponents (0x2D0) and BlueprintCreatedComponents (0x2E0) are plain
    // TArrays of UActorComponent* - the only component containers with a layout we
    // can walk safely (OwnedComponentMap is a TMap we have no iterator for).
    const TArray<UActorComponent*>* lists[2] = { &InstanceComponents, &BlueprintCreatedComponents };
    for (const auto* list : lists) {
        if (!Tools::IsReadable(list, sizeof(TArray<UActorComponent*>))) continue;
        const int count = list->Num();
        if (count <= 0 || count > 256 || list->Max() < count) continue;

        UActorComponent* const* data = list->GetData();
        if (!Tools::IsPtrValid(data) || !Tools::IsReadable(data, count * sizeof(UActorComponent*))) continue;

        // Snapshot to local stack buffer (up to 128 components).
        // This eliminates race conditions where the game thread clears or reallocates
        // BlueprintCreatedComponents / InstanceComponents mid-loop during death or lobby exit.
        constexpr int MAX_LOCAL = 128;
        const int safeCount = std::min(count, MAX_LOCAL);
        UActorComponent* localComps[MAX_LOCAL];
        if (!Tools::Read(const_cast<UActorComponent**>(data), localComps, safeCount * sizeof(UActorComponent*))) continue;

        for (int i = 0; i < safeCount; ++i) {
            auto comp = localComps[i];
            if (!comp || !Tools::IsPtrValid(comp)) continue;
            if (HasSDKClass(comp, className)) return comp;
        }
    }

    return nullptr;
}

static bool BoneToWorld(const USkeletalMeshComponent* mesh, const USceneComponent* root,
                        const FVector& rootPos, const FTransform& bone, FVector& position)
{
    if (!bone.IsValid()) return false;
    const auto plausible = [&](const FVector& p) {
        return std::isfinite(p.X) && std::isfinite(p.Y) && std::isfinite(p.Z) &&
            (p - rootPos).SizeSquared() <= 500.0f * 500.0f;
    };

    // 1. Primary: Direct world transform from mesh ComponentToWorld (+0x190)
    // Matches native UE4: component-space bone transformed by the live mesh world transform.
    if (mesh && Tools::IsPtrValid(mesh) && Tools::IsReadable(mesh, sizeof(USkeletalMeshComponent))) {
        const FTransform world = mesh->ComponentToWorld;
        if (world.IsValid()) {
            const FVector pos = world.TransformPosition(bone.Translation);
            if (plausible(pos)) {
                position = pos;
                return true;
            }
        }
    }

    // 2. Fallback: Convert bone translation from mesh space into root space, then world space
    if (mesh && root && Tools::IsPtrValid(mesh) && Tools::IsPtrValid(root) &&
        Tools::IsReadable(mesh, sizeof(USkeletalMeshComponent)) &&
        Tools::IsReadable(root, sizeof(USceneComponent))) {
        FVector relScale = mesh->RelativeScale3D;
        if (!std::isfinite(relScale.X) || std::abs(relScale.X) < 0.001f || std::abs(relScale.X) > 10.0f) relScale = {1.0f, 1.0f, 1.0f};
        if (!std::isfinite(relScale.Y) || std::abs(relScale.Y) < 0.001f || std::abs(relScale.Y) > 10.0f) relScale.Y = 1.0f;
        if (!std::isfinite(relScale.Z) || std::abs(relScale.Z) < 0.001f || std::abs(relScale.Z) > 10.0f) relScale.Z = 1.0f;

        FVector relLoc = mesh->RelativeLocation;
        FRotator relRot = mesh->RelativeRotation;
        if (!std::isfinite(relLoc.X) || !std::isfinite(relLoc.Y) || !std::isfinite(relLoc.Z) ||
            std::abs(relLoc.Z) < 5.0f || std::abs(relLoc.Z) > 150.0f ||
            std::abs(relLoc.X) > 100.0f || std::abs(relLoc.Y) > 100.0f) {
            relLoc = {0.0f, 0.0f, -88.0f};
        }
        if (!std::isfinite(relRot.Pitch) || !std::isfinite(relRot.Yaw) || !std::isfinite(relRot.Roll)) {
            relRot = {0.0f, -90.0f, 0.0f};
        }

        const FVector scaled{bone.Translation.X * relScale.X,
                             bone.Translation.Y * relScale.Y,
                             bone.Translation.Z * relScale.Z};
        const FVector inRoot = relLoc + relRot.RotateVector(scaled);

        if (root->ComponentToWorld.IsValid()) {
            const FVector pos = root->ComponentToWorld.TransformPosition(inRoot);
            if (plausible(pos)) {
                position = pos;
                return true;
            }
        }

        FRotator actorRot = root->RelativeRotation;
        const FVector pos = rootPos + actorRot.RotateVector(inRoot);
        if (plausible(pos)) {
            position = pos;
            return true;
        }
    }
    return false;
}

static bool TryCopyTransforms(const USkeletalMeshComponent* comp, FTransform* outPose, int& outNum)
{
    if (!comp || !Tools::IsPtrValid(comp)) return false;
    if (!Tools::IsReadable(comp, sizeof(USkeletalMeshComponent))) return false;

    const auto& transforms = comp->CachedComponentSpaceTransforms;
    const int num = transforms.Num();
    const int max = transforms.Max();
    if (num < 5 || num > 300 || max < num || max > 600) return false;

    const auto* data = transforms.GetData();
    if (!data || !Tools::IsPtrValid(data)) return false;
    if ((reinterpret_cast<uintptr_t>(data) & 0xF) != 0) return false;
    if (!Tools::IsReadable(data, num * sizeof(FTransform))) return false;

    std::memcpy(outPose, data, num * sizeof(FTransform));
    outNum = num;
    return true;
}

bool ASGCharacter::GetBonePositions(const char* const* names, int count, FVector* positions)
{
    if (!names || !positions || count <= 0 || count > 32) return false;
    for (int i = 0; i < count; ++i) positions[i] = {0,0,0};
    if (!Tools::IsPtrValid(this)) return false;

    const auto root = RootComponent;
    FVector rootPos{0,0,0};
    bool hasRootPos = false;
    if (root && Tools::IsPtrValid(root)) {
        hasRootPos = root->TryGetWorldLocation(rootPos) && rootPos.SizeSquared() > 0.001f;
    }
    if (!hasRootPos && CapsuleComponent && Tools::IsPtrValid(CapsuleComponent)) {
        hasRootPos = CapsuleComponent->TryGetWorldLocation(rootPos) && rootPos.SizeSquared() > 0.001f;
    }
    if (!hasRootPos) return false;

    auto mesh = GetMeshComponent();

    USkeletalMeshComponent* source = nullptr;
    if (mesh && Tools::IsPtrValid(mesh) && Tools::IsReadable(mesh, sizeof(USkeletalMeshComponent))) {
        source = mesh;
        // Follow MasterPoseComponent only if source does NOT already have evaluated transforms
        const int bones = source->CachedComponentSpaceTransforms.Num();
        if (bones < 5 || bones > 300) {
            USkeletalMeshComponent* visited[4]{};
            int visitedCount = 0;
            for (; visitedCount < 4; ++visitedCount) {
                visited[visitedCount] = source;
                const auto weak = source->MasterPoseComponent;
                USkinnedMeshComponent* master = nullptr;
                if (weak.ObjectSerialNumber > 0) {
                    master = weak.Get();
                }
                if (!master) {
                    uintptr_t raw = *reinterpret_cast<const uintptr_t*>(reinterpret_cast<const uint8_t*>(source) + Offsets::SkeletalMeshComponent::MasterPoseComponent);
                    if (raw >= 0x1000000000ULL && raw <= 0x7FFFFFFFFFFFULL) {
                        auto* candidate = reinterpret_cast<USkinnedMeshComponent*>(raw);
                        if (IsLiveSDKObject(candidate) && HasSDKClass(candidate, "SkeletalMeshComponent")) {
                            master = candidate;
                        }
                    }
                }
                if (!master) break;

                bool cycle = false;
                for (int i = 0; i <= visitedCount; ++i) cycle |= (master == visited[i]);
                if (cycle || !IsLiveSDKObject(master) || !Tools::IsReadable(master, sizeof(USkeletalMeshComponent))) break;
                source = static_cast<USkeletalMeshComponent*>(master);
                const int mBones = source->CachedComponentSpaceTransforms.Num();
                if (mBones >= 5 && mBones <= 300) break;
            }
        }
    }

    FTransform pose[300];
    int num = 0;
    bool copied = false;
    if (source && TryCopyTransforms(source, pose, num)) {
        copied = true;
    }

    // Fallback A: if master pose had no transforms, read directly from mesh
    if (!copied && mesh && source != mesh && TryCopyTransforms(mesh, pose, num)) {
        source = mesh;
        copied = true;
    }

    bool any = false;
    if (copied && source) {
        for (int i = 0; i < count; ++i) {
            const int index = source->GetBoneIndex(names[i]);
            FVector position;
            if (index >= 0 && index < num && BoneToWorld(source, root, rootPos, pose[index], position)) {
                positions[i] = position;
                any = true;
            }
        }
    }

    // Fallback C: Procedural stance-adaptive calculation for budgeted/frozen remote pawns and bots
    if (!any && rootPos.SizeSquared() > 0.001f) {
        FRotator rot = K2_GetActorRotation();
        float halfHeight = 88.0f;
        if (CapsuleComponent && Tools::IsPtrValid(CapsuleComponent)) {
            float hh = CapsuleComponent->GetScaledCapsuleHalfHeight();
            if (hh >= 20.0f && hh <= 140.0f) halfHeight = hh;
        }
        float hScale = std::clamp(halfHeight / 88.0f, 0.25f, 1.25f);
        const bool isProne = (halfHeight < 35.0f);
        const bool isCrouch = (!isProne && halfHeight < 72.0f);

        for (int i = 0; i < count; ++i) {
            const char* boneName = names[i];
            if (!boneName) continue;
            FVector offset{0,0,0};
            if (isProne) {
                if (strcasecmp(boneName, "Head") == 0 || strcasecmp(boneName, "head") == 0) offset = {70.0f, 0.0f, 15.0f};
                else if (strcasecmp(boneName, "neck_01") == 0 || strcasecmp(boneName, "neck") == 0) offset = {55.0f, 0.0f, 12.0f};
                else if (strcasecmp(boneName, "spine_03") == 0 || strcasecmp(boneName, "spine") == 0) offset = {30.0f, 0.0f, 8.0f};
                else if (strcasecmp(boneName, "pelvis") == 0) offset = {0.0f, 0.0f, 5.0f};
                else if (strcasecmp(boneName, "upperarm_l") == 0) offset = {50.0f, -20.0f, 10.0f};
                else if (strcasecmp(boneName, "lowerarm_l") == 0) offset = {65.0f, -22.0f, 5.0f};
                else if (strcasecmp(boneName, "hand_l") == 0) offset = {75.0f, -22.0f, 2.0f};
                else if (strcasecmp(boneName, "upperarm_r") == 0) offset = {50.0f, 20.0f, 10.0f};
                else if (strcasecmp(boneName, "lowerarm_r") == 0) offset = {65.0f, 22.0f, 5.0f};
                else if (strcasecmp(boneName, "hand_r") == 0) offset = {75.0f, 22.0f, 2.0f};
                else if (strcasecmp(boneName, "thigh_l") == 0) offset = {-25.0f, -12.0f, 5.0f};
                else if (strcasecmp(boneName, "calf_l") == 0) offset = {-55.0f, -12.0f, 4.0f};
                else if (strcasecmp(boneName, "foot_l") == 0) offset = {-80.0f, -12.0f, 2.0f};
                else if (strcasecmp(boneName, "thigh_r") == 0) offset = {-25.0f, 12.0f, 5.0f};
                else if (strcasecmp(boneName, "calf_r") == 0) offset = {-55.0f, 12.0f, 4.0f};
                else if (strcasecmp(boneName, "foot_r") == 0) offset = {-80.0f, 12.0f, 2.0f};
            } else if (isCrouch) {
                if (strcasecmp(boneName, "Head") == 0 || strcasecmp(boneName, "head") == 0) offset = {12.0f, 0.0f, 48.0f};
                else if (strcasecmp(boneName, "neck_01") == 0 || strcasecmp(boneName, "neck") == 0) offset = {10.0f, 0.0f, 38.0f};
                else if (strcasecmp(boneName, "spine_03") == 0 || strcasecmp(boneName, "spine") == 0) offset = {5.0f, 0.0f, 22.0f};
                else if (strcasecmp(boneName, "pelvis") == 0) offset = {0.0f, 0.0f, -5.0f};
                else if (strcasecmp(boneName, "upperarm_l") == 0) offset = {5.0f, -18.0f, 32.0f};
                else if (strcasecmp(boneName, "lowerarm_l") == 0) offset = {12.0f, -22.0f, 16.0f};
                else if (strcasecmp(boneName, "hand_l") == 0) offset = {18.0f, -20.0f, 2.0f};
                else if (strcasecmp(boneName, "upperarm_r") == 0) offset = {5.0f, 18.0f, 32.0f};
                else if (strcasecmp(boneName, "lowerarm_r") == 0) offset = {12.0f, 22.0f, 16.0f};
                else if (strcasecmp(boneName, "hand_r") == 0) offset = {18.0f, 20.0f, 2.0f};
                else if (strcasecmp(boneName, "thigh_l") == 0) offset = {12.0f, -14.0f, -15.0f};
                else if (strcasecmp(boneName, "calf_l") == 0) offset = {-10.0f, -14.0f, -42.0f};
                else if (strcasecmp(boneName, "foot_l") == 0) offset = {5.0f, -14.0f, -58.0f};
                else if (strcasecmp(boneName, "thigh_r") == 0) offset = {12.0f, 14.0f, -15.0f};
                else if (strcasecmp(boneName, "calf_r") == 0) offset = {-10.0f, 14.0f, -42.0f};
                else if (strcasecmp(boneName, "foot_r") == 0) offset = {5.0f, 14.0f, -58.0f};
            } else {
                if (strcasecmp(boneName, "Head") == 0 || strcasecmp(boneName, "head") == 0) offset = {0.0f, 0.0f, 75.0f * hScale};
                else if (strcasecmp(boneName, "neck_01") == 0 || strcasecmp(boneName, "neck") == 0) offset = {0.0f, 0.0f, 60.0f * hScale};
                else if (strcasecmp(boneName, "spine_03") == 0 || strcasecmp(boneName, "spine") == 0) offset = {0.0f, 0.0f, 35.0f * hScale};
                else if (strcasecmp(boneName, "pelvis") == 0) offset = {0.0f, 0.0f, 0.0f};
                else if (strcasecmp(boneName, "upperarm_l") == 0) offset = {0.0f, -20.0f, 52.0f * hScale};
                else if (strcasecmp(boneName, "lowerarm_l") == 0) offset = {5.0f, -26.0f, 30.0f * hScale};
                else if (strcasecmp(boneName, "hand_l") == 0) offset = {8.0f, -28.0f, 12.0f * hScale};
                else if (strcasecmp(boneName, "upperarm_r") == 0) offset = {0.0f, 20.0f, 52.0f * hScale};
                else if (strcasecmp(boneName, "lowerarm_r") == 0) offset = {5.0f, 26.0f, 30.0f * hScale};
                else if (strcasecmp(boneName, "hand_r") == 0) offset = {8.0f, 28.0f, 12.0f * hScale};
                else if (strcasecmp(boneName, "thigh_l") == 0) offset = {0.0f, -12.0f, -10.0f * hScale};
                else if (strcasecmp(boneName, "calf_l") == 0) offset = {0.0f, -12.0f, -48.0f * hScale};
                else if (strcasecmp(boneName, "foot_l") == 0) offset = {2.0f, -12.0f, -85.0f * hScale};
                else if (strcasecmp(boneName, "thigh_r") == 0) offset = {0.0f, 12.0f, -10.0f * hScale};
                else if (strcasecmp(boneName, "calf_r") == 0) offset = {0.0f, 12.0f, -48.0f * hScale};
                else if (strcasecmp(boneName, "foot_r") == 0) offset = {2.0f, 12.0f, -85.0f * hScale};
            }
            positions[i] = rootPos + rot.RotateVector(offset);
        }
        any = true;
    }

    return any;
}

FVector ASGCharacter::GetBonePos(const char* boneName, const FVector& fallback, bool allowApproximation)
{
    if (!Tools::IsPtrValid(this)) return fallback;
    FVector actual;
    if (GetBonePositions(&boneName, 1, &actual)) return actual;
    FVector rootPos{0,0,0};
    if (RootComponent && Tools::IsPtrValid(RootComponent))
    {
        rootPos = RootComponent->K2_GetComponentLocation();
    }

    // The skeleton renderer requires actual bones. Other callers may explicitly
    // retain the legacy approximate target fallback.
    if (!allowApproximation) return fallback;

    if (rootPos.SizeSquared() > 0.001f && boneName)
    {
        FRotator rot = K2_GetActorRotation();
        float halfHeight = 88.0f;
        if (CapsuleComponent && Tools::IsPtrValid(CapsuleComponent))
        {
            float hh = CapsuleComponent->GetScaledCapsuleHalfHeight();
            if (hh >= 20.0f && hh <= 140.0f) halfHeight = hh;
        }
        float hScale = std::clamp(halfHeight / 88.0f, 0.25f, 1.25f);
        const bool isProne = (halfHeight < 35.0f);
        const bool isCrouch = (!isProne && halfHeight < 72.0f);

        // Prone stance adaptation (crawling on ground)
        if (isProne)
        {
            if (strcasecmp(boneName, "Head") == 0 || strcasecmp(boneName, "head") == 0) return rootPos + rot.RotateVector({70.0f, 0.0f, 15.0f});
            if (strcasecmp(boneName, "neck_01") == 0 || strcasecmp(boneName, "neck") == 0) return rootPos + rot.RotateVector({55.0f, 0.0f, 12.0f});
            if (strcasecmp(boneName, "spine_03") == 0 || strcasecmp(boneName, "spine") == 0) return rootPos + rot.RotateVector({30.0f, 0.0f, 8.0f});
            if (strcasecmp(boneName, "pelvis") == 0) return rootPos + rot.RotateVector({0.0f, 0.0f, 5.0f});
            if (strcasecmp(boneName, "upperarm_l") == 0) return rootPos + rot.RotateVector({50.0f, -20.0f, 10.0f});
            if (strcasecmp(boneName, "lowerarm_l") == 0) return rootPos + rot.RotateVector({65.0f, -22.0f, 5.0f});
            if (strcasecmp(boneName, "hand_l") == 0) return rootPos + rot.RotateVector({75.0f, -22.0f, 2.0f});
            if (strcasecmp(boneName, "upperarm_r") == 0) return rootPos + rot.RotateVector({50.0f, 20.0f, 10.0f});
            if (strcasecmp(boneName, "lowerarm_r") == 0) return rootPos + rot.RotateVector({65.0f, 22.0f, 5.0f});
            if (strcasecmp(boneName, "hand_r") == 0) return rootPos + rot.RotateVector({75.0f, 22.0f, 2.0f});
            if (strcasecmp(boneName, "thigh_l") == 0) return rootPos + rot.RotateVector({-25.0f, -12.0f, 5.0f});
            if (strcasecmp(boneName, "calf_l") == 0) return rootPos + rot.RotateVector({-55.0f, -12.0f, 4.0f});
            if (strcasecmp(boneName, "foot_l") == 0) return rootPos + rot.RotateVector({-80.0f, -12.0f, 2.0f});
            if (strcasecmp(boneName, "thigh_r") == 0) return rootPos + rot.RotateVector({-25.0f, 12.0f, 5.0f});
            if (strcasecmp(boneName, "calf_r") == 0) return rootPos + rot.RotateVector({-55.0f, 12.0f, 4.0f});
            if (strcasecmp(boneName, "foot_r") == 0) return rootPos + rot.RotateVector({-80.0f, 12.0f, 2.0f});
        }
        else if (isCrouch)
        {
            if (strcasecmp(boneName, "Head") == 0 || strcasecmp(boneName, "head") == 0) return rootPos + rot.RotateVector({12.0f, 0.0f, 48.0f});
            if (strcasecmp(boneName, "neck_01") == 0 || strcasecmp(boneName, "neck") == 0) return rootPos + rot.RotateVector({10.0f, 0.0f, 38.0f});
            if (strcasecmp(boneName, "spine_03") == 0 || strcasecmp(boneName, "spine") == 0) return rootPos + rot.RotateVector({5.0f, 0.0f, 22.0f});
            if (strcasecmp(boneName, "pelvis") == 0) return rootPos + rot.RotateVector({0.0f, 0.0f, -5.0f});
            if (strcasecmp(boneName, "upperarm_l") == 0) return rootPos + rot.RotateVector({5.0f, -18.0f, 32.0f});
            if (strcasecmp(boneName, "lowerarm_l") == 0) return rootPos + rot.RotateVector({12.0f, -22.0f, 16.0f});
            if (strcasecmp(boneName, "hand_l") == 0) return rootPos + rot.RotateVector({18.0f, -20.0f, 2.0f});
            if (strcasecmp(boneName, "upperarm_r") == 0) return rootPos + rot.RotateVector({5.0f, 18.0f, 32.0f});
            if (strcasecmp(boneName, "lowerarm_r") == 0) return rootPos + rot.RotateVector({12.0f, 22.0f, 16.0f});
            if (strcasecmp(boneName, "hand_r") == 0) return rootPos + rot.RotateVector({18.0f, 20.0f, 2.0f});
            if (strcasecmp(boneName, "thigh_l") == 0) return rootPos + rot.RotateVector({12.0f, -14.0f, -15.0f});
            if (strcasecmp(boneName, "calf_l") == 0) return rootPos + rot.RotateVector({-10.0f, -14.0f, -42.0f});
            if (strcasecmp(boneName, "foot_l") == 0) return rootPos + rot.RotateVector({5.0f, -14.0f, -58.0f});
            if (strcasecmp(boneName, "thigh_r") == 0) return rootPos + rot.RotateVector({12.0f, 14.0f, -15.0f});
            if (strcasecmp(boneName, "calf_r") == 0) return rootPos + rot.RotateVector({-10.0f, 14.0f, -42.0f});
            if (strcasecmp(boneName, "foot_r") == 0) return rootPos + rot.RotateVector({5.0f, 14.0f, -58.0f});
        }
        else
        {
            // Standing stance (proportional scaling)
            if (strcasecmp(boneName, "Head") == 0 || strcasecmp(boneName, "head") == 0) return rootPos + rot.RotateVector({0.0f, 0.0f, 75.0f * hScale});
            if (strcasecmp(boneName, "neck_01") == 0 || strcasecmp(boneName, "neck") == 0) return rootPos + rot.RotateVector({0.0f, 0.0f, 60.0f * hScale});
            if (strcasecmp(boneName, "spine_03") == 0 || strcasecmp(boneName, "spine") == 0) return rootPos + rot.RotateVector({0.0f, 0.0f, 35.0f * hScale});
            if (strcasecmp(boneName, "pelvis") == 0) return rootPos + rot.RotateVector({0.0f, 0.0f, 0.0f});
            if (strcasecmp(boneName, "upperarm_l") == 0) return rootPos + rot.RotateVector({0.0f, -20.0f, 52.0f * hScale});
            if (strcasecmp(boneName, "lowerarm_l") == 0) return rootPos + rot.RotateVector({5.0f, -26.0f, 30.0f * hScale});
            if (strcasecmp(boneName, "hand_l") == 0) return rootPos + rot.RotateVector({8.0f, -28.0f, 12.0f * hScale});
            if (strcasecmp(boneName, "upperarm_r") == 0) return rootPos + rot.RotateVector({0.0f, 20.0f, 52.0f * hScale});
            if (strcasecmp(boneName, "lowerarm_r") == 0) return rootPos + rot.RotateVector({5.0f, 26.0f, 30.0f * hScale});
            if (strcasecmp(boneName, "hand_r") == 0) return rootPos + rot.RotateVector({8.0f, 28.0f, 12.0f * hScale});
            if (strcasecmp(boneName, "thigh_l") == 0) return rootPos + rot.RotateVector({0.0f, -12.0f, -10.0f * hScale});
            if (strcasecmp(boneName, "calf_l") == 0) return rootPos + rot.RotateVector({0.0f, -12.0f, -48.0f * hScale});
            if (strcasecmp(boneName, "foot_l") == 0) return rootPos + rot.RotateVector({2.0f, -12.0f, -85.0f * hScale});
            if (strcasecmp(boneName, "thigh_r") == 0) return rootPos + rot.RotateVector({0.0f, 12.0f, -10.0f * hScale});
            if (strcasecmp(boneName, "calf_r") == 0) return rootPos + rot.RotateVector({0.0f, 12.0f, -48.0f * hScale});
            if (strcasecmp(boneName, "foot_r") == 0) return rootPos + rot.RotateVector({2.0f, 12.0f, -85.0f * hScale});
        }
    }

    return rootPos.SizeSquared() > 0.001f ? rootPos : fallback;
}

FVector ASGCharacter::GetBoneLocation(int boneId)
{
    auto meshComp = GetMeshComponent();
    if (meshComp && Tools::IsPtrValid(meshComp))
    {
        FVector bonePos = meshComp->GetBoneLocation(boneId);
        if (bonePos.SizeSquared() > 0.001f) return bonePos;
    }
    FVector rootPos = (RootComponent && Tools::IsPtrValid(RootComponent)) ? RootComponent->K2_GetComponentLocation() : FVector{0,0,0};
    if (rootPos.SizeSquared() < 0.001f) return {0,0,0};
    FVector pos = rootPos;
    if (boneId == 0) pos.Z += 75.0f;
    else if (boneId == 1) pos.Z += 60.0f;
    else if (boneId == 2) pos.Z += 35.0f;
    return pos;
}

bool ASGCharacter::IsKnocked()
{
    if (!Tools::IsPtrValid(this) || IsAI()) return false;

    // Downed state lives on USGCharacterDBNOComponent (0x258) as bIsDBNO at +0x1A8.
    // The field is replicated (OnRep_bIsDBNO), so it is valid on the client - which
    // is exactly the case an overlay sees. Read it directly; do not infer DBNO from
    // health, since a downed player still has nonzero DBNO health.
    const auto comp = FindComponentByClassName("SGCharacterDBNOComponent");
    if (!comp || !Tools::IsReadable(reinterpret_cast<const uint8_t*>(comp) + Offsets::Health::DBNOComp_bIsDBNO, sizeof(uint8_t)))
        return false;
    return *reinterpret_cast<const uint8_t*>(reinterpret_cast<const uint8_t*>(comp) + Offsets::Health::DBNOComp_bIsDBNO) != 0;
}

// ==================== USGActorHealthComponent ====================

float USGActorHealthComponent::GetHealth()
{
    if (!IsLiveSDKObject(this) || !Tools::IsReadable(&AttributeSetClass, sizeof(AttributeSetClass))) return -1.0f;
    const auto attr = AttributeSetClass; // the sole dump-confirmed field, 0xE0
    float health, maximum;
    return HasSDKClass(attr, "SGActorHealthAttributeSet") && ReadHealthValues(attr, health, maximum)
        ? health : -1.0f;
}

float USGActorHealthComponent::GetHealthMax()
{
    if (!IsLiveSDKObject(this) || !Tools::IsReadable(&AttributeSetClass, sizeof(AttributeSetClass))) return -1.0f;
    const auto attr = AttributeSetClass;
    float health, maximum;
    return HasSDKClass(attr, "SGActorHealthAttributeSet") && ReadHealthValues(attr, health, maximum)
        ? maximum : -1.0f;
}

// ==================== AController ====================

bool AController::LineOfSightTo(AActor* Other, const FVector& ViewPoint, bool bAlternateChecks)
{
    static UFunction* fn = nullptr;
    if (!fn) fn = UObject::FindObject<UFunction>("Function Engine.Controller.LineOfSightTo");

    if (fn && Other)
    {
        struct {
            AActor* Other;
            FVector ViewPoint;
            bool bAlternateChecks;
            bool ReturnValue;
        } params{Other, ViewPoint, bAlternateChecks, false};

        ProcessEvent(fn, &params);
        return params.ReturnValue;
    }
    return false;
}

void APlayerController::GetPlayerViewPoint(FVector& outLocation, FRotator& outRotation)
{
    outLocation = {0.0f, 0.0f, 0.0f};
    outRotation = {0.0f, 0.0f, 0.0f};
    if (!Tools::IsPtrValid(this)) return;

    FCameraView view;
    if (PlayerCameraManager && Tools::IsPtrValid(PlayerCameraManager) &&
        PlayerCameraManager->GetCameraView(view)) {
        outLocation = view.Location;
        outRotation = view.Rotation;
        outRotation.Roll = 0.0f;
        return;
    }

    if (Character && Tools::IsPtrValid(Character)) {
        outLocation = Character->K2_GetActorLocation() + FVector{0.0f, 0.0f, 65.0f};
        outRotation = ControlRotation;
        outRotation.Roll = 0.0f;
        return;
    }

    outRotation = ControlRotation;
    outRotation.Roll = 0.0f;
}

// ==================== APlayerCameraManager ====================

bool APlayerCameraManager::GetCameraView(FCameraView& outView) const
{
    outView = {};
    if (!Tools::IsPtrValid(this)) return false;

    const auto readSample = [](const uint8_t* cache, FCameraCacheSample& sample) {
        if (!Tools::IsReadable(cache, sizeof(sample))) return false;
        // Copy the whole POV, including aspect/FOV mode, from one cache.
        std::memcpy(&sample, cache, sizeof(sample));
        const auto& v = sample.POV;
        return std::isfinite(sample.Timestamp) && sample.Timestamp >= 0.0f &&
               std::isfinite(v.Location.X) && std::isfinite(v.Location.Y) && std::isfinite(v.Location.Z) &&
               std::isfinite(v.Rotation.Pitch) && std::isfinite(v.Rotation.Yaw) && std::isfinite(v.Rotation.Roll) &&
               std::isfinite(v.FOV) && v.FOV > 0.0f && v.FOV < 180.0f &&
               v.ProjectionMode == 0 && v.FOVMode <= 2 &&
               std::isfinite(v.OffCenterProjectionOffset.X) && std::isfinite(v.OffCenterProjectionOffset.Y) &&
               (((v.ProjectionFlags & 0x01) == 0 && v.FOVMode != 2) ||
                (std::isfinite(v.AspectRatio) && v.AspectRatio > 0.0f));
    };

    FCameraCacheSample privateSample, publicSample;
    const bool privateValid = readSample(CameraCachePrivate, privateSample);
    const bool publicValid = readSample(CameraCache, publicSample);
    if (!privateValid && !publicValid) return false;

    // A zero rotation/location is legitimate. Choose the whole newest valid POV;
    // never splice a rotation or FOV from a stale cache into another cache's origin.
    outView = privateValid && (!publicValid || privateSample.Timestamp >= publicSample.Timestamp)
        ? privateSample.POV : publicSample.POV;
    return true;
}

FVector APlayerCameraManager::GetCameraLocation() const
{
    FCameraView view;
    return GetCameraView(view) ? view.Location : FVector{0,0,0};
}

FRotator APlayerCameraManager::GetCameraRotation() const
{
    FCameraView view;
    return GetCameraView(view) ? view.Rotation : FRotator{0,0,0};
}

float APlayerCameraManager::GetFOVAngle() const
{
    FCameraView view;
    if (GetCameraView(view)) return view.FOV;
    if (Tools::IsPtrValid(this) && Tools::IsReadable(&DefaultFOV, sizeof(DefaultFOV)) &&
        std::isfinite(DefaultFOV) && DefaultFOV > 0.0f && DefaultFOV < 180.0f) return DefaultFOV;
    return 90.0f;
}

void APlayerCameraManager::StopAllCameraShakes(bool bImmediately)
{
}

// ==================== APlayerController ====================

bool APlayerController::ProjectWorldLocationToScreen(const FVector& WorldLocation, bool bPlayerViewportRelative, FVector2D* ScreenLocation)
{
    if (!ScreenLocation) return false;
    return false;
}

void APlayerController::GetInputTouchState(uint8_t FingerIndex, float& LocationX, float& LocationY, bool& bIsCurrentlyPressed)
{
    UFunction* fn = g_fnGetInputTouchState;
    if (!fn) {
        fn = UObject::FindObjectFast<UFunction>("GetInputTouchState");
        if (fn) g_fnGetInputTouchState = fn;
    }

    if (fn)
    {
        struct {
            uint8_t FingerIndex;
            uint8_t Pad[3];
            float LocationX;
            float LocationY;
            bool bIsCurrentlyPressed;
        } params{FingerIndex, {0,0,0}, 0.0f, 0.0f, false};

        ProcessEvent(fn, &params);
        LocationX = params.LocationX;
        LocationY = params.LocationY;
        bIsCurrentlyPressed = params.bIsCurrentlyPressed;
    }
}

// ==================== UCanvas ====================

void UCanvas::K2_DrawLine(const FVector2D& ScreenPositionA, const FVector2D& ScreenPositionB, float Thickness, const FLinearColor& RenderColor)
{
    UFunction* fn = g_fnK2_DrawLine;
    if (!fn) {
        fn = UObject::FindObjectFast<UFunction>("K2_DrawLine");
        if (fn) g_fnK2_DrawLine = fn;
    }

    if (fn)
    {
        struct {
            FVector2D ScreenPositionA;
            FVector2D ScreenPositionB;
            float Thickness;
            FLinearColor RenderColor;
        } params{ScreenPositionA, ScreenPositionB, Thickness, RenderColor};

        ProcessEvent(fn, &params);
    }
}

void UCanvas::K2_DrawBox(const FVector2D& ScreenPosition, const FVector2D& ScreenSize, float Thickness, const FLinearColor& RenderColor)
{
    UFunction* fn = g_fnK2_DrawBox;
    if (!fn) {
        fn = UObject::FindObjectFast<UFunction>("K2_DrawBox");
        if (fn) g_fnK2_DrawBox = fn;
    }

    if (fn)
    {
        struct {
            FVector2D ScreenPosition;
            FVector2D ScreenSize;
            float Thickness;
            FLinearColor RenderColor;
        } params{ScreenPosition, ScreenSize, Thickness, RenderColor};

        ProcessEvent(fn, &params);
    }
}

void UCanvas::K2_DrawText(UObject* RenderFont, const FString& RenderText, const FVector2D& ScreenPosition, const FVector2D& Scale, const FLinearColor& RenderColor, float Kerning, const FLinearColor& ShadowColor, const FVector2D& ShadowOffset, bool bCentreX, bool bCentreY, bool bOutlined, const FLinearColor& OutlineColor)
{
    UFunction* fn = g_fnK2_DrawText;
    if (!fn) {
        fn = UObject::FindObjectFast<UFunction>("K2_DrawText");
        if (fn) g_fnK2_DrawText = fn;
    }

    if (fn)
    {
        struct {
            UObject* RenderFont;
            FString RenderText;
            FVector2D ScreenPosition;
            FVector2D Scale;
            FLinearColor RenderColor;
            float Kerning;
            FLinearColor ShadowColor;
            FVector2D ShadowOffset;
            bool bCentreX;
            bool bCentreY;
            bool bOutlined;
            uint8_t Pad_57; // Align OutlineColor to 0x58 (Canvas_K2_DrawText_Params)
            FLinearColor OutlineColor;
        } params{RenderFont, RenderText, ScreenPosition, Scale, RenderColor, Kerning, ShadowColor, ShadowOffset, bCentreX, bCentreY, bOutlined, 0, OutlineColor};

        ProcessEvent(fn, &params);
    }
}

void UCanvas::K2_DrawTexture(UObject* RenderTexture, const FVector2D& ScreenPosition, const FVector2D& ScreenSize, const FVector2D& CoordinatePosition, const FVector2D& CoordinateSize, const FLinearColor& RenderColor, uint8_t BlendMode, float Rotation, const FVector2D& PivotPoint)
{
    UFunction* fn = g_fnK2_DrawTexture;
    if (!fn) {
        fn = UObject::FindObjectFast<UFunction>("K2_DrawTexture");
        if (fn) g_fnK2_DrawTexture = fn;
    }

    if (fn)
    {
        struct {
            UObject* RenderTexture;
            FVector2D ScreenPosition;
            FVector2D ScreenSize;
            FVector2D CoordinatePosition;
            FVector2D CoordinateSize;
            FLinearColor RenderColor;
            uint8_t BlendMode;
            uint8_t Pad[3];
            float Rotation;
            FVector2D PivotPoint;
        } params{RenderTexture, ScreenPosition, ScreenSize, CoordinatePosition, CoordinateSize, RenderColor, BlendMode, {0,0,0}, Rotation, PivotPoint};

        ProcessEvent(fn, &params);
    }
}

FVector UCanvas::K2_Project(const FVector& WorldLocation)
{
    UFunction* fn = g_fnK2_Project;
    if (!fn) {
        fn = UObject::FindObjectFast<UFunction>("K2_Project");
        if (fn) g_fnK2_Project = fn;
    }

    if (fn)
    {
        struct {
            FVector WorldLocation;
            FVector ReturnValue;
        } params{WorldLocation, {0,0,0}};

        ProcessEvent(fn, &params);
        return params.ReturnValue;
    }
    return {0,0,0};
}

// ==================== Precache All Functions ====================

void PrecacheAllFunctions()
{
    if (!UObject::GObjects || !Tools::IsPtrValid(UObject::GObjects)) {
        LOGE("[Precache] GObjects is not valid!");
        return;
    }

    int32_t count = UObject::GObjects->Num();
    LOGI("[Precache] Scanning %d GObjects for essential UFunctions, Fonts, and Textures...", count);

    UObject* fallbackFont = nullptr;
    UObject* fallbackTexture = nullptr;

    for (int32_t i = 0; i < count; i++) {
        UObject* obj = UObject::GObjects->GetByIndex(i);
        if (!obj || !obj->ClassPrivate) continue;

        std::string clsName = obj->ClassPrivate->GetName();

        // 1. Precache Font
        if (!UE4Helper::g_Font && clsName == "Font") {
            std::string objName = obj->GetName();
            if (objName == "RobotoDistanceField" || objName == "DefaultRegularFont" ||
                objName == "SmallFont" || objName == "Multilingual_Font" ||
                objName == "ChinaEnglishFont_Font" || objName == "Default__Font") {
                UE4Helper::g_Font = obj;
                LOGI("[Precache] Bound Primary Font: %s (%p)", objName.c_str(), obj);
            } else if (!fallbackFont) {
                fallbackFont = obj;
            }
        }

        // 2. Precache White Texture
        if (!UE4Helper::g_WhiteTexture && clsName == "Texture2D") {
            std::string objName = obj->GetName();
            if (objName == "WhiteSquareTexture" || objName == "G_Common_White_Tex" ||
                objName == "T_White_1x1_Default_Linear" || objName == "DefaultTexture") {
                UE4Helper::g_WhiteTexture = obj;
                LOGI("[Precache] Bound White Texture: %s (%p)", objName.c_str(), obj);
            } else if (!fallbackTexture) {
                fallbackTexture = obj;
            }
        }

        // 3. Precache UFunctions
        if (clsName != "Function") continue;

        auto fn = reinterpret_cast<UFunction*>(obj);
        std::string fnName = fn->GetName();

        if (fnName == "ReceiveDrawHUD" && !g_fnReceiveDrawHUD) {
            g_fnReceiveDrawHUD = fn;
            LOGI("[Precache] Bound ReceiveDrawHUD: %p (idx: %d, full: %s)", fn, fn->NamePrivate.ComparisonIndex, fn->GetFullName().c_str());
        }
        else if (fnName == "DrawHUD" && !g_fnDrawHUD) {
            g_fnDrawHUD = fn;
            LOGI("[Precache] Bound DrawHUD: %p (idx: %d, full: %s)", fn, fn->NamePrivate.ComparisonIndex, fn->GetFullName().c_str());
        }
        else if (fnName == "PostRender" && !g_fnPostRender) {
            g_fnPostRender = fn;
            LOGI("[Precache] Bound PostRender: %p (idx: %d, full: %s)", fn, fn->NamePrivate.ComparisonIndex, fn->GetFullName().c_str());
        }
        else if (fnName == "CanvasDraw" && !g_fnCanvasDraw) {
            g_fnCanvasDraw = fn;
            LOGI("[Precache] Bound CanvasDraw: %p (idx: %d, full: %s)", fn, fn->NamePrivate.ComparisonIndex, fn->GetFullName().c_str());
        }
        else if (fnName == "SetCanCanvasDraw" && !g_fnSetCanCanvasDraw) {
            g_fnSetCanCanvasDraw = fn;
            LOGI("[Precache] Bound SetCanCanvasDraw: %p (idx: %d, full: %s)", fn, fn->NamePrivate.ComparisonIndex, fn->GetFullName().c_str());
        }
        else if (fnName == "OnNewWidgetCreated" && !g_fnOnNewWidgetCreated) {
            g_fnOnNewWidgetCreated = fn;
            LOGI("[Precache] Bound OnNewWidgetCreated: %p (idx: %d, full: %s)", fn, fn->NamePrivate.ComparisonIndex, fn->GetFullName().c_str());
        }
        else if (fnName == "K2_DrawLine" && !g_fnK2_DrawLine) {
            g_fnK2_DrawLine = fn;
            LOGI("[Precache] Bound K2_DrawLine: %p (idx: %d)", fn, fn->NamePrivate.ComparisonIndex);
        }
        else if (fnName == "K2_DrawBox" && !g_fnK2_DrawBox) {
            g_fnK2_DrawBox = fn;
            LOGI("[Precache] Bound K2_DrawBox: %p (idx: %d)", fn, fn->NamePrivate.ComparisonIndex);
        }
        else if (fnName == "K2_DrawText" && !g_fnK2_DrawText) {
            g_fnK2_DrawText = fn;
            LOGI("[Precache] Bound K2_DrawText: %p (idx: %d)", fn, fn->NamePrivate.ComparisonIndex);
        }
        else if (fnName == "K2_DrawTexture" && !g_fnK2_DrawTexture) {
            g_fnK2_DrawTexture = fn;
            LOGI("[Precache] Bound K2_DrawTexture: %p (idx: %d)", fn, fn->NamePrivate.ComparisonIndex);
        }
        else if (fnName == "K2_Project" && !g_fnK2_Project) {
            g_fnK2_Project = fn;
            LOGI("[Precache] Bound K2_Project: %p (idx: %d)", fn, fn->NamePrivate.ComparisonIndex);
        }
        // Health getters are name-only matches here, but the game ships many
        // unrelated "GetHealth"/"GetHealthMax" natives (UNPCAIStatics,
        // INPCCharacterHealthInterface, USGPlayerStatics, ...). Taking the first
        // one found in the array binds the WRONG function and a Static native
        // invoked through ProcessEvent corrupts the stack. Require the owner to
        // be the SGFramework statics/interface we actually intend to call.
        else if (fnName == "GetCharacterHealthComponent" && !g_fnGetCharacterHealthComponent) {
            const std::string owner = fn->GetOuter() ? fn->GetOuter()->GetName() : std::string();
            if (owner == "SGCharacter") {
                g_fnGetCharacterHealthComponent = fn;
                LOGI("[Precache] Bound GetCharacterHealthComponent: %p (idx: %d)", fn, fn->NamePrivate.ComparisonIndex);
            }
        }
        else if (fnName == "GetHealth" && !g_fnGetHealth) {
            const std::string owner = fn->GetOuter() ? fn->GetOuter()->GetName() : std::string();
            if (owner == "SGActorStatics" || owner == "SGPlayerStatics") {
                g_fnGetHealth = fn;
                LOGI("[Precache] Bound GetHealth: %p (owner: %s, idx: %d)", fn, owner.c_str(), fn->NamePrivate.ComparisonIndex);
            }
        }
        else if (fnName == "GetHealthMax" && !g_fnGetHealthMax) {
            const std::string owner = fn->GetOuter() ? fn->GetOuter()->GetName() : std::string();
            if (owner == "SGActorStatics" || owner == "SGPlayerStatics") {
                g_fnGetHealthMax = fn;
                LOGI("[Precache] Bound GetHealthMax: %p (owner: %s, idx: %d)", fn, owner.c_str(), fn->NamePrivate.ComparisonIndex);
            }
        }
        else if (fnName == "GetInputTouchState" && !g_fnGetInputTouchState) {
            g_fnGetInputTouchState = fn;
            LOGI("[Precache] Bound GetInputTouchState: %p (idx: %d)", fn, fn->NamePrivate.ComparisonIndex);
        }
    }

    if (!UE4Helper::g_Font && fallbackFont) {
        UE4Helper::g_Font = fallbackFont;
        LOGI("[Precache] Bound Fallback Font: %s (%p)", fallbackFont->GetName().c_str(), fallbackFont);
    }
    if (!UE4Helper::g_WhiteTexture && fallbackTexture) {
        UE4Helper::g_WhiteTexture = fallbackTexture;
        LOGI("[Precache] Bound Fallback Texture: %s (%p)", fallbackTexture->GetName().c_str(), fallbackTexture);
    }

    LOGI("[Precache] Complete! CanvasDraw=%p, SetCanCanvasDraw=%p, OnNewWidgetCreated=%p, K2_DrawText=%p, Font=%p, Texture=%p",
         g_fnCanvasDraw, g_fnSetCanCanvasDraw, g_fnOnNewWidgetCreated, g_fnK2_DrawText, UE4Helper::g_Font, UE4Helper::g_WhiteTexture);
}

// ==================== UWorld ====================

void UWorld::GetActors(std::vector<AActor*>& outActors) const
{
    outActors.clear();
    if (!Tools::IsPtrValid(this) || !Tools::IsReadable(this, sizeof(UWorld))) return;

    // Reuse the hash table between frames. The previous implementation sorted
    // the complete actor list every frame (O(N log N)), which becomes expensive
    // on maps containing many actors. Pointer hashing gives the same de-duplication
    // in O(N) average time and avoids repeated bucket allocations.
    static thread_local std::unordered_set<AActor*> seenActors;
    static thread_local std::vector<ULevel*> visitedLevels;
    seenActors.clear();
    visitedLevels.clear();

    const auto appendActors = [&](const TArray<AActor*>& source) {
        const auto actors = source; // Snapshot only the 16-byte TArray header.
        const int32_t count = actors.Num();
        const auto data = actors.GetData();
        if (count <= 0 || count > 50000 || actors.Max() < count || !Tools::IsPtrValid(data)) return;
        if (!Tools::IsReadable(data, sizeof(AActor*) * static_cast<size_t>(count))) return;

        // Keep the same hard upper bound as before. Reserve once when the map
        // grows so the normal frame path does not repeatedly reallocate.
        const size_t remaining = 250000u - std::min<size_t>(outActors.size(), 250000u);
        if (static_cast<size_t>(count) > remaining) return;
        if (seenActors.bucket_count() < 1024) seenActors.reserve(4096);

        for (int32_t i = 0; i < count; ++i) {
            AActor* actor = data[i];
            if (Tools::IsPtrValid(actor) && seenActors.insert(actor).second) {
                outActors.push_back(actor);
            }
        }
    };

    const auto appendLevel = [&](ULevel* level) {
        if (!Tools::IsPtrValid(level) || !Tools::IsReadable(level, sizeof(ULevel))) return;
        if (level->OwningWorld != this) return;
        if (std::find(visitedLevels.begin(), visitedLevels.end(), level) != visitedLevels.end()) return;
        visitedLevels.push_back(level);
        // The native list and reflected cluster can contain different subsets.
        // Never replace all dynamic actors with the cluster alone.
        appendActors(level->Actors);
        const auto cluster = level->ActorCluster;
        if (Tools::IsPtrValid(cluster) && Tools::IsReadable(cluster, sizeof(ULevelActorContainer))) {
            appendActors(cluster->Actors);
        }
    };

    appendLevel(PersistentLevel);
    const auto levels = Levels; // 0x138: ULevel*, NOT StreamingLevels at 0x88.
    if (levels.Num() > 0 && levels.Num() <= 1024 && levels.Max() >= levels.Num() &&
        Tools::IsPtrValid(levels.GetData()) &&
        Tools::IsReadable(levels.GetData(), sizeof(ULevel*) * static_cast<size_t>(levels.Num()))) {
        for (int32_t i = 0; i < levels.Num(); ++i) appendLevel(levels[i]);
    }
    // Deduplicate the union without allocating a hash node for every actor/frame.
    // De-duplication is done during insertion; no full-vector sort is needed.
}

// ==================== UGameplayStatics ====================

void UGameplayStatics::GetAllActorsOfClass(UObject* WorldContextObject, UClass* ActorClass, TArray<AActor*>* OutActors)
{
    if (!WorldContextObject || !ActorClass || !OutActors) return;

    static UFunction* fn = nullptr;
    if (!fn) fn = UObject::FindObject<UFunction>("Function Engine.GameplayStatics.GetAllActorsOfClass");

    auto statics = UObject::FindObjectFast<UGameplayStatics>("Default__GameplayStatics");
    if (!statics) statics = (UGameplayStatics*)StaticClass();

    if (fn && statics)
    {
        struct {
            UObject* WorldContextObject;
            UClass* ActorClass;
            TArray<AActor*> OutActors;
        } params{WorldContextObject, ActorClass, {}};

        statics->ProcessEvent(fn, &params);
        *OutActors = params.OutActors;
    }
    else
    {
        // Only a verified UWorld context can be interpreted as the world layout.
        const auto worldClass = UWorld::StaticClass();
        if (!worldClass || !WorldContextObject->IsA(worldClass)) return;
        UWorld* world = static_cast<UWorld*>(WorldContextObject);
        std::vector<AActor*> actors;
        world->GetActors(actors);
        // TArray::Add does not grow. Reserve the required result capacity first.
        TArray<AActor*> result(static_cast<int>(actors.size()));
        if (!actors.empty() && !result.GetData()) return;
        for (AActor* actor : actors) {
            if (Tools::IsReadable(actor, sizeof(UObject)) && actor->IsA(ActorClass)) result.Add(actor);
        }
        *OutActors = result;
    }
}

bool UGameplayStatics::ProjectWorldToScreen(APlayerController* Player, const FVector& WorldPosition, FVector2D& ScreenPosition, bool bPlayerViewportRelative)
{
    if (!Player) return false;
    return Player->ProjectWorldLocationToScreen(WorldPosition, bPlayerViewportRelative, &ScreenPosition);
}

bool USGGameplayStatics::ProjectWorldToScreenDualFov(APlayerController* Player, const FVector& WorldPosition, FVector2D& ScreenPosition, bool bPlayerViewportRelative)
{
    if (!Player) return false;

    static UFunction* fn = nullptr;
    if (!fn) fn = UObject::FindObject<UFunction>("Function SGFramework.SGGameplayStatics.ProjectWorldToScreenDualFov");

    auto statics = UObject::FindObjectFast<USGGameplayStatics>("Default__SGGameplayStatics");
    if (fn && statics && Tools::IsPtrValid(statics))
    {
        struct {
            APlayerController* Player;
            FVector WorldPosition;
            FVector2D ScreenPosition;
            bool bPlayerViewportRelative;
            bool ReturnValue;
        } params{Player, WorldPosition, {0,0}, bPlayerViewportRelative, false};

        statics->ProcessEvent(fn, &params);
        ScreenPosition = params.ScreenPosition;
        return params.ReturnValue;
    }

    return UGameplayStatics::ProjectWorldToScreen(Player, WorldPosition, ScreenPosition, bPlayerViewportRelative);
}

// ==================== USGCharacterStatics ====================

FVector USGCharacterStatics::GetBoneLocationByName(ACharacter* Character, const char* BoneName)
{
    if (!Character || !BoneName || !*BoneName) return {0,0,0};
    auto sgChar = reinterpret_cast<ASGCharacter*>(Character);
    return sgChar->GetBonePos(BoneName);
}

} // namespace SDK
