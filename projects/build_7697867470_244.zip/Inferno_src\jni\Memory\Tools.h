#pragma once
#include <iostream>
#include <stdio.h>
#include <string>
#include <unistd.h>
#include <stdint.h>
#include <inttypes.h>
#include <vector>
#include <map>
#include <chrono>
#include <fstream>
#include <thread>
#include <pthread.h>
#include <dirent.h>
#include <libgen.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <sys/syscall.h>
#include <fcntl.h>
#include <android/log.h>

#define TAG "ArenaAndroid"

namespace Tools {
    void LogToFile(const char* level, const char* fmt, ...);
}

// Release builds strip ALL logging. Besides hiding behaviour from logcat, this
// removes every log format string from the binary — those strings ("[MainThread]",
// "[Unload]", "Arena Android Engine", log-file paths, ...) are a trivial static
// fingerprint for anticheat/analysts. Set to 1 only for local debugging.
#ifndef ARENA_LOG_ENABLED
#define ARENA_LOG_ENABLED 0
#endif

#if ARENA_LOG_ENABLED
#define LOGD(...) do { __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__); ::Tools::LogToFile("DEBUG", __VA_ARGS__); } while(0)
#define LOGE(...) do { __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__); ::Tools::LogToFile("ERROR", __VA_ARGS__); } while(0)
#define LOGI(...) do { __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__); ::Tools::LogToFile("INFO",  __VA_ARGS__); } while(0)
#define LOGW(...) do { __android_log_print(ANDROID_LOG_WARN,  TAG, __VA_ARGS__); ::Tools::LogToFile("WARN",  __VA_ARGS__); } while(0)
#else
#define LOGD(...) do {} while(0)
#define LOGE(...) do {} while(0)
#define LOGI(...) do {} while(0)
#define LOGW(...) do {} while(0)
#endif

// Per-actor diagnostics must not flush files on the swap thread in normal builds.
#if defined(ARENA_VERBOSE_FRAME_LOGS)
#define LOG_FRAME(...) LOGI(__VA_ARGS__)
#else
#define LOG_FRAME(...) do {} while(0)
#endif

typedef uintptr_t kaddr;

namespace Tools {
    bool Read(void *addr, void *buffer, size_t length);
    bool Write(void *addr, void *buffer, size_t length);
    bool ReadAddr(void *addr, void *buffer, size_t length);
    bool WriteAddr(void *addr, void *buffer, size_t length);
    bool PVM_ReadAddr(void *addr, void *buffer, size_t length);
    bool PVM_WriteAddr(void *addr, void *buffer, size_t length);
    bool IsPtrValid(const void *addr);
    bool IsReadable(const void *addr, size_t length);
    uintptr_t GetBaseAddress(const char *name);
    uintptr_t GetEndAddress(const char *name);
    uintptr_t FindPattern(const char *lib, const char* pattern);
    void InstallCrashHandler();

    template<typename T>
    T ReadMemory(uintptr_t address) {
        T buffer{};
        Read((void*)address, &buffer, sizeof(T));
        return buffer;
    }

    template<typename T>
    bool WriteMemory(uintptr_t address, T value) {
        return WriteAddr((void*)address, &value, sizeof(T));
    }

    std::string RandomString(const int len);
}
