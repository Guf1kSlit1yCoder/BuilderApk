@echo off
setlocal enabledelayedexpansion

echo ========================================================
echo Arena Breakout ESP - ADB Injector Launcher
echo ========================================================

set ADB="C:\Users\GAMER\AppData\Local\Android\Sdk\platform-tools\adb.exe"
if not exist %ADB% set ADB=adb

echo [1/3] Checking connected device...
%ADB% get-state >nul 2>&1
if errorlevel 1 (
    echo [WAIT] Waiting for Android device connection...
    %ADB% wait-for-device
)

echo [2/3] Checking library file...
if exist "libs\arm64-v8a\libarena_esp.so" (
    echo [PUSH] Copying libs\arm64-v8a\libarena_esp.so to /data/local/tmp/...
    %ADB% push libs\arm64-v8a\libarena_esp.so /data/local/tmp/libarena_esp.so
    %ADB% shell "su -c 'chmod 777 /data/local/tmp/libarena_esp.so'"
) else (
    echo [INFO] Local libarena_esp.so not found, using existing file on phone.
)

echo [3/3] Executing injector...
%ADB% shell su -c "/data/local/tmp/injector --package com.eu.mf.uamo --libs /data/local/tmp/libarena_esp.so --memfd"

if errorlevel 1 (
    echo [ERROR] Injection command returned an error code.
) else (
    echo [SUCCESS] Injection request executed successfully!
)

pause
