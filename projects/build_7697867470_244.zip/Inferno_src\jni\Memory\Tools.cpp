#include "Tools.h"
#include "AntiCrack/ObfStr.h"
#include <cstring>
#include <cstdlib>
#include <signal.h>
#include <errno.h>
#include <atomic>
#include <ucontext.h>

#if defined(__arm__)
#define process_vm_readv_syscall 376
#define process_vm_writev_syscall 377
#elif defined(__aarch64__)
#define process_vm_readv_syscall 270
#define process_vm_writev_syscall 271
#elif defined(__i386__)
#define process_vm_readv_syscall 347
#define process_vm_writev_syscall 348
#else
#define process_vm_readv_syscall 310
#define process_vm_writev_syscall 311
#endif

pid_t target_pid = -1;

ssize_t process_v(pid_t __pid, const struct iovec *__local_iov, unsigned long __local_iov_count, const struct iovec *__remote_iov, unsigned long __remote_iov_count, unsigned long __flags, bool iswrite) {
    return syscall((iswrite ? process_vm_writev_syscall : process_vm_readv_syscall), __pid, __local_iov, __local_iov_count, __remote_iov, __remote_iov_count, __flags);
}

bool pvm(void *address, void *buffer, size_t size, bool write = false) {
    struct iovec local[1];
    struct iovec remote[1];
    local[0].iov_base = buffer;
    local[0].iov_len = size;
    remote[0].iov_base = address;
    remote[0].iov_len = size;

    if (target_pid == -1) {
        target_pid = getpid();
    }

    ssize_t bytes = process_v(target_pid, local, 1, remote, 1, 0, write);
    return bytes == (ssize_t)size;
}

bool Tools::Read(void *addr, void *buffer, size_t length) {
    if (!addr || !buffer || length == 0) return false;
    if (!IsReadable(addr, length)) return false;
    memcpy(buffer, addr, length);
    return true;
}

bool Tools::Write(void *addr, void *buffer, size_t length) {
    if (!addr || !buffer || length == 0) return false;
    return memcpy(addr, buffer, length) != nullptr;
}

bool Tools::ReadAddr(void *addr, void *buffer, size_t length) {
    if (!addr || !buffer || length == 0) return false;
    return Read(addr, buffer, length);
}

bool Tools::WriteAddr(void *addr, void *buffer, size_t length) {
    if (!addr || !buffer) return false;
    uintptr_t page_size = (uintptr_t)sysconf(_SC_PAGESIZE);
    uintptr_t page_start = (uintptr_t)addr & ~(page_size - 1);
    if (mprotect((void *)page_start, page_size * 2, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
        return PVM_WriteAddr(addr, buffer, length);
    }
    return memcpy(addr, buffer, length) != nullptr;
}

bool Tools::PVM_ReadAddr(void *addr, void *buffer, size_t length) {
    return pvm(addr, buffer, length, false);
}

bool Tools::PVM_WriteAddr(void *addr, void *buffer, size_t length) {
    return pvm(addr, buffer, length, true);
}

// Instant, zero-syscall pointer sanity check for internal in-process memory
bool Tools::IsPtrValid(const void *addr) {
    if (!addr) return false;
    uintptr_t ptr = reinterpret_cast<uintptr_t>(addr);
#if defined(__aarch64__)
    // Strip ARM64 top-byte tag (TBI / MTE on Android 11+)
    uintptr_t untagged = ptr & 0x00FFFFFFFFFFFFFFULL;
    // Android 64-bit user space: valid heap, code, stack, and mmap addresses
    return (untagged >= 0x10000ULL && untagged <= 0x00007FFFFFFFFFFFULL);
#elif defined(__arm__)
    return (ptr >= 0x10000 && ptr <= 0xFFFFFFFF);
#else
    return ptr != 0;
#endif
}

// Zero-syscall fast memory readability validation
bool Tools::IsReadable(const void *addr, size_t length) {
    if (!addr || length == 0) return false;
    uintptr_t ptr = reinterpret_cast<uintptr_t>(addr);
#if defined(__aarch64__)
    uintptr_t untagged = ptr & 0x00FFFFFFFFFFFFFFULL;
    if (untagged < 0x10000ULL || untagged > 0x00007FFFFFFFFFFFULL) return false;
    if (length > 1) {
        uintptr_t endUntagged = (ptr + length - 1) & 0x00FFFFFFFFFFFFFFULL;
        if (endUntagged < 0x10000ULL || endUntagged > 0x00007FFFFFFFFFFFULL) return false;
    }
#elif defined(__arm__)
    if (ptr < 0x10000 || ptr > 0xFFFFFFFF) return false;
#endif
    return true;
}

uintptr_t Tools::GetBaseAddress(const char *name) {
    uintptr_t base = 0;
    char line[512];
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return 0;

    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, name) != nullptr) {
            uintptr_t tmpBase = 0;
            if (sscanf(line, "%" PRIXPTR "-", &tmpBase) == 1) {
                base = tmpBase;
                break;
            }
        }
    }
    fclose(f);
    return base;
}

uintptr_t Tools::GetEndAddress(const char *name) {
    uintptr_t end = 0;
    char line[512];
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return 0;

    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, name) != nullptr) {
            uintptr_t tmpEnd = 0;
            if (sscanf(line, "%*" PRIXPTR "-%" PRIXPTR, &tmpEnd) == 1) {
                end = tmpEnd;
            } else if (end) {
                break;
            }
        }
    }
    fclose(f);
    return end;
}

#define INRANGE(x, a, b) (x >= a && x <= b)
#define getBits(x) (INRANGE((x & (~0x20)), 'A', 'F') ? ((x & (~0x20)) - 'A' + 0xa) : (INRANGE(x, '0', '9') ? x - '0' : 0))
#define getByte(x) (getBits(x[0]) << 4 | getBits(x[1]))

uintptr_t Tools::FindPattern(const char *lib, const char *pattern) {
    auto start = GetBaseAddress(lib);
    if (!start) return 0;
    auto end = GetEndAddress(lib);
    if (!end) return 0;

    auto curPat = reinterpret_cast<const unsigned char *>(pattern);
    uintptr_t firstMatch = 0;
    for (uintptr_t pCur = start; pCur < end; ++pCur) {
        if (*(uint8_t *) curPat == (uint8_t) '?' || *(uint8_t *) pCur == getByte(curPat)) {
            if (!firstMatch) firstMatch = pCur;
            curPat += ((curPat[0] == '?' && curPat[1] == '?') || curPat[0] != '?') ? 2 : 1;
            if (!*curPat) return firstMatch;
            curPat++;
            if (!*curPat) return firstMatch;
        } else if (firstMatch) {
            pCur = firstMatch;
            curPat = reinterpret_cast<const unsigned char *>(pattern);
            firstMatch = 0;
        }
    }
    return 0;
}

std::string Tools::RandomString(const int len) {
    static const char alphanum[] =
            "0123456789"
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            "abcdefghijklmnopqrstuvwxyz";
    std::string tmp_s;
    tmp_s.reserve(len);

    for (int i = 0; i < len; ++i) {
        tmp_s += alphanum[rand() % (sizeof(alphanum) - 1)];
    }

    return tmp_s;
}

// ==================== Crash Signal Handler ====================
static struct sigaction old_sa_segv;
static struct sigaction old_sa_bus;
static struct sigaction old_sa_fpe;
static struct sigaction old_sa_ill;
static struct sigaction old_sa_abrt;
static std::atomic<bool> s_HandlingCrash{false};

static void CrashSignalHandler(int sig, siginfo_t* info, void* ucontext) {
    if (s_HandlingCrash.exchange(true)) {
        // Prevent infinite recursion loop in crash handler
        signal(sig, SIG_DFL);
        raise(sig);
        return;
    }

    void* faultAddr = info ? info->si_addr : nullptr;
    const char* sigName = "UNKNOWN";
    if (sig == SIGSEGV) sigName = "SIGSEGV (Segmentation fault)";
    else if (sig == SIGBUS) sigName = "SIGBUS (Bus error)";
    else if (sig == SIGFPE) sigName = "SIGFPE (Floating point exception)";
    else if (sig == SIGILL) sigName = "SIGILL (Illegal instruction)";
    else if (sig == SIGABRT) sigName = "SIGABRT (Abort)";

    uintptr_t pc = 0;
    uintptr_t lr = 0;
    uintptr_t sp = 0;
#if defined(__aarch64__)
    if (ucontext) {
        auto uc = reinterpret_cast<ucontext_t*>(ucontext);
        pc = uc->uc_mcontext.pc;
        lr = uc->uc_mcontext.regs[30];
        sp = uc->uc_mcontext.sp;
    }
#elif defined(__arm__)
    if (ucontext) {
        auto uc = reinterpret_cast<ucontext_t*>(ucontext);
        pc = uc->uc_mcontext.arm_pc;
        lr = uc->uc_mcontext.arm_lr;
        sp = uc->uc_mcontext.arm_sp;
    }
#endif

    LOGE("==================== CRASH DETECTED ====================");
    LOGE("[CRASH] Signal %d: %s", sig, sigName);
    LOGE("[CRASH] Fault Address: %p", faultAddr);
    LOGE("[CRASH] Thread ID: %d", gettid());
    LOGE("[CRASH] PC: 0x%" PRIxPTR " | LR: 0x%" PRIxPTR " | SP: 0x%" PRIxPTR, pc, lr, sp);

    uintptr_t espBase = Tools::GetBaseAddress("libarena_esp.so");
    uintptr_t ue4Base = Tools::GetBaseAddress((const char*)OBFSTR("libUE4.so"));
    if (espBase && pc >= espBase && pc < espBase + 0x10000000) {
        LOGE("[CRASH] -> PC is inside libarena_esp.so + 0x%" PRIxPTR, pc - espBase);
    }
    if (ue4Base && pc >= ue4Base && pc < ue4Base + 0x20000000) {
        LOGE("[CRASH] -> PC is inside libUE4.so + 0x%" PRIxPTR, pc - ue4Base);
    }
    if (espBase && lr >= espBase && lr < espBase + 0x10000000) {
        LOGE("[CRASH] -> LR is inside libarena_esp.so + 0x%" PRIxPTR, lr - espBase);
    }
    if (ue4Base && lr >= ue4Base && lr < ue4Base + 0x20000000) {
        LOGE("[CRASH] -> LR is inside libUE4.so + 0x%" PRIxPTR, lr - ue4Base);
    }
    LOGE("========================================================");

    struct sigaction* old_sa = nullptr;
    if (sig == SIGSEGV) old_sa = &old_sa_segv;
    else if (sig == SIGBUS) old_sa = &old_sa_bus;
    else if (sig == SIGFPE) old_sa = &old_sa_fpe;
    else if (sig == SIGILL) old_sa = &old_sa_ill;
    else if (sig == SIGABRT) old_sa = &old_sa_abrt;

    // Reset this signal to default handler to avoid any handler loop
    signal(sig, SIG_DFL);

    if (old_sa && old_sa->sa_sigaction && old_sa->sa_handler != SIG_DFL && old_sa->sa_handler != SIG_IGN) {
        old_sa->sa_sigaction(sig, info, ucontext);
    } else if (old_sa && old_sa->sa_handler && old_sa->sa_handler != SIG_DFL && old_sa->sa_handler != SIG_IGN) {
        old_sa->sa_handler(sig);
    } else {
        raise(sig);
    }

    // In case previous handler returns instead of terminating, exit immediately to prevent repeating instruction
    _exit(128 + sig);
}

#include <mutex>
#include <cstdarg>
#include <cstring>

void Tools::LogToFile(const char* level, const char* fmt, ...) {
    static FILE* s_LogFile = nullptr;
    static bool s_TriedOpen = false;
    static std::mutex s_LogMutex;
    std::lock_guard<std::mutex> lock(s_LogMutex);

    if (!s_LogFile && !s_TriedOpen) {
        s_TriedOpen = true;
        s_LogFile = fopen("/sdcard/Download/arena_log.txt", "a");
        if (!s_LogFile) {
            s_LogFile = fopen("/data/data/com.eu.mf.uamo/files/arena_log.txt", "a");
        }
        if (s_LogFile) {
            fprintf(s_LogFile, "\n=== ARENA ENGINE LOG SESSION START ===\n");
            fflush(s_LogFile);
        }
    }

    if (s_LogFile) {
        auto now = std::chrono::system_clock::now();
        auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;
        time_t t = std::chrono::system_clock::to_time_t(now);
        struct tm tm_info;
        localtime_r(&t, &tm_info);
        char timeBuf[32];
        strftime(timeBuf, sizeof(timeBuf), "%H:%M:%S", &tm_info);
        fprintf(s_LogFile, "[%s.%03d][%s] ", timeBuf, static_cast<int>(ms.count()), level ? level : "INFO");

        va_list args;
        va_start(args, fmt);
        vfprintf(s_LogFile, fmt, args);
        va_end(args);

        fprintf(s_LogFile, "\n");
        static auto lastFlush = std::chrono::steady_clock::now();
        const auto clockNow = std::chrono::steady_clock::now();
        const bool urgent = level && (std::strcmp(level, "ERROR") == 0 || std::strcmp(level, "WARN") == 0);
        if (urgent || clockNow - lastFlush >= std::chrono::seconds(1)) {
            fflush(s_LogFile);
            lastFlush = clockNow;
        }
    }
}

void Tools::InstallCrashHandler() {
    // Disabled to prevent conflicts with Android ART Garbage Collector and CrashSight
}
