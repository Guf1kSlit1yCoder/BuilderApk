#include "liquid_glass_gl.h"
#include <GLES3/gl3.h>
#include <cstring>
#include <cstdio>
#include <android/log.h>

#define LG_TAG "LiquidGlass"
#if defined(ARENA_LOG_ENABLED) && ARENA_LOG_ENABLED
#define LOGI_LG(...) __android_log_print(ANDROID_LOG_INFO,  LG_TAG, __VA_ARGS__)
#define LOGE_LG(...) __android_log_print(ANDROID_LOG_ERROR, LG_TAG, __VA_ARGS__)
#else
#define LOGI_LG(...) do {} while(0)
#define LOGE_LG(...) do {} while(0)
#endif

namespace LiquidGlass
{

// ─── GLSL ES 3.0 shaders ────────────────────────────────────────────────────

static const char* kVertSrc = R"GLSL(#version 300 es
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aUV;
layout(location = 2) in vec4 aColor;  // pre-normalised by GL (GL_UNSIGNED_BYTE, GL_TRUE)

uniform vec2 uResolution;

out vec4  vColor;

void main() {
    vColor      = aColor;
    gl_Position = vec4(
        aPos.x *  2.0 / uResolution.x - 1.0,
        1.0  -  aPos.y *  2.0 / uResolution.y,
        0.0, 1.0
    );
}
)GLSL";

static const char* kFragSrc = R"GLSL(#version 300 es
precision highp float;

uniform vec2      uResolution;
uniform vec2      uCenter;
uniform vec2      uHalfSize;
uniform float     uExponent;
uniform float     uBlur;
uniform float     uLensBand;
uniform float     uLensStrength;
uniform float     uAberration;
uniform float     uTint;
uniform float     uRim;
uniform float     uEdgeSoftness;
uniform float     uShape;
uniform sampler2D uBackdrop;  // slot 1

in  vec4 vColor;
out vec4 fragColor;

// px is in ImGui top-left screen space; snapshot was captured with bottom-left GL origin
vec3 Bg(vec2 px) {
    vec2 uv = vec2(px.x / uResolution.x, 1.0 - px.y / uResolution.y);
    return textureLod(uBackdrop, clamp(uv, vec2(0.0), vec2(1.0)), 0.0).rgb;
}

float sdHyperellipse(vec2 p, vec2 ab, float n, out vec2 nrm) {
    vec2  q  = max(abs(p) / ab, vec2(1e-4));
    float G  = pow(pow(q.x, n) + pow(q.y, n), 1.0 / n);
    vec2  g  = pow(q / G, vec2(n - 1.0)) / ab;
    vec2  s  = sign(p);
    float gl = max(length(g), 1e-4);
    nrm = s * g / gl;
    return (G - 1.0) / gl;
}

float sdCapsule(vec2 p, vec2 ab, out vec2 nrm) {
    float r  = ab.y;
    float sx = max(ab.x - r, 0.0);
    vec2  a  = vec2(-sx, 0.0);
    vec2  b  = vec2( sx, 0.0);
    vec2  pa = p - a;
    vec2  ba = b - a;
    float h  = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-8), 0.0, 1.0);
    vec2  q  = pa - ba * h;
    nrm = q / max(length(q), 1e-4);
    return length(q) - r;
}

void main() {
    // gl_FragCoord has Y bottom-up; convert to ImGui top-down
    vec2  frag    = vec2(gl_FragCoord.x, uResolution.y - gl_FragCoord.y);
    vec2  p       = frag - uCenter;
    float minHalf = min(uHalfSize.x, uHalfSize.y);
    float size    = 2.0 * minHalf;

    vec2  nrm;
    float d;
    if (uShape < 0.5)
        d = sdHyperellipse(p, uHalfSize, clamp(uExponent, 2.0, 16.0), nrm);
    else
        d = sdCapsule(p, uHalfSize, nrm);

    float mask = clamp(0.5 - d / max(uEdgeSoftness, 0.001), 0.0, 1.0);
    if (mask <= 0.0) discard;

    // Lens refraction
    float inv            = max(-d, 0.0) / size;
    float distFromCenter = 1.0 - clamp(inv / uLensBand, 0.0, 1.0);
    float distortion     = 1.0 - sqrt(clamp(1.0 - distFromCenter * distFromCenter, 0.0, 1.0));
    vec2  offset         = distortion * nrm * minHalf * uLensStrength;
    vec2  coord          = frag - offset;

    // Chromatic aberration (edge-only)
    vec2 shift = nrm * uAberration * distFromCenter * distFromCenter;

    // 5x5 Gaussian blur, per-channel CA positions
    float blurRadius = uBlur * (1.0 - distFromCenter * 0.5);
    vec3  acc  = vec3(0.0);
    float wsum = 0.0;
    for (int x = -2; x <= 2; x++) {
        for (int y = -2; y <= 2; y++) {
            vec2  o = vec2(float(x), float(y)) * blurRadius;
            float w = exp(-0.25 * float(x*x + y*y));
            acc.r += Bg(coord - shift + o).r * w;
            acc.g += Bg(coord         + o).g * w;
            acc.b += Bg(coord + shift + o).b * w;
            wsum  += w;
        }
    }
    vec3 col = (acc / wsum) * uTint;

    // Rim highlight
    float rimW = pow(distFromCenter, 3.0);
    vec2  L    = normalize(vec2(-0.6, -0.8));
    float hi   = clamp(dot(nrm,  L), 0.0, 1.0);
    float lo   = clamp(dot(nrm, -L), 0.0, 1.0) * 0.35;
    col += uRim * rimW * (hi + lo);

    col      *= vColor.rgb;
    fragColor = vec4(col, mask * vColor.a);
}
)GLSL";

// ─── state ──────────────────────────────────────────────────────────────────

static GLuint g_Program  = 0;
static GLuint g_SnapTex  = 0;
static int    g_SnapW    = 0;
static int    g_SnapH    = 0;

static GLint  g_uResolution;
static GLint  g_uCenter;
static GLint  g_uHalfSize;
static GLint  g_uExponent;
static GLint  g_uBlur;
static GLint  g_uLensBand;
static GLint  g_uLensStrength;
static GLint  g_uAberration;
static GLint  g_uTint;
static GLint  g_uRim;
static GLint  g_uEdgeSoftness;
static GLint  g_uShape;
static GLint  g_uBackdrop;

// ─── helpers ────────────────────────────────────────────────────────────────

static GLuint CompileShader(GLenum type, const char* src)
{
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[512];
        glGetShaderInfoLog(s, sizeof(buf), nullptr, buf);
        LOGE_LG("Shader compile error: %s", buf);
        glDeleteShader(s);
        return 0;
    }
    return s;
}

// ─── public API ─────────────────────────────────────────────────────────────

bool Init()
{
    GLuint vs = CompileShader(GL_VERTEX_SHADER,   kVertSrc);
    GLuint fs = CompileShader(GL_FRAGMENT_SHADER, kFragSrc);
    if (!vs || !fs) { glDeleteShader(vs); glDeleteShader(fs); return false; }

    g_Program = glCreateProgram();
    glAttachShader(g_Program, vs);
    glAttachShader(g_Program, fs);
    glLinkProgram(g_Program);
    glDeleteShader(vs);
    glDeleteShader(fs);

    GLint ok = 0;
    glGetProgramiv(g_Program, GL_LINK_STATUS, &ok);
    if (!ok) {
        char buf[512];
        glGetProgramInfoLog(g_Program, sizeof(buf), nullptr, buf);
        LOGE_LG("Program link error: %s", buf);
        glDeleteProgram(g_Program);
        g_Program = 0;
        return false;
    }

    g_uResolution   = glGetUniformLocation(g_Program, "uResolution");
    g_uCenter       = glGetUniformLocation(g_Program, "uCenter");
    g_uHalfSize     = glGetUniformLocation(g_Program, "uHalfSize");
    g_uExponent     = glGetUniformLocation(g_Program, "uExponent");
    g_uBlur         = glGetUniformLocation(g_Program, "uBlur");
    g_uLensBand     = glGetUniformLocation(g_Program, "uLensBand");
    g_uLensStrength = glGetUniformLocation(g_Program, "uLensStrength");
    g_uAberration   = glGetUniformLocation(g_Program, "uAberration");
    g_uTint         = glGetUniformLocation(g_Program, "uTint");
    g_uRim          = glGetUniformLocation(g_Program, "uRim");
    g_uEdgeSoftness = glGetUniformLocation(g_Program, "uEdgeSoftness");
    g_uShape        = glGetUniformLocation(g_Program, "uShape");
    g_uBackdrop     = glGetUniformLocation(g_Program, "uBackdrop");

    LOGI_LG("Init OK, program=%u", g_Program);
    return true;
}

void Shutdown()
{
    if (g_SnapTex) { glDeleteTextures(1, &g_SnapTex); g_SnapTex = 0; }
    if (g_Program) { glDeleteProgram(g_Program);       g_Program = 0; }
    g_SnapW = g_SnapH = 0;
}

void CaptureSnapshot(int width, int height)
{
    if (!g_Program || width <= 0 || height <= 0) return;

    if (!g_SnapTex || g_SnapW != width || g_SnapH != height) {
        if (g_SnapTex) glDeleteTextures(1, &g_SnapTex);
        glGenTextures(1, &g_SnapTex);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, g_SnapTex);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
        g_SnapW = width;
        g_SnapH = height;
        glActiveTexture(GL_TEXTURE0);
    }

    // Copy the current draw framebuffer into the snapshot texture.
    // This is called before ImGui renders, so we capture the game's frame.
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, g_SnapTex);
    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, width, height);
    glActiveTexture(GL_TEXTURE0);
}

// ─── per-draw callback data ──────────────────────────────────────────────────

struct DrawData {
    float center[2];
    float halfSize[2];
    float exponent;
    float blur;
    float lensBand;
    float lensStrength;
    float aberration;
    float tint;
    float rim;
    float edgeSoftness;
    float shape;
    float resW, resH;
};

static void GlassCallback(const ImDrawList*, const ImDrawCmd* cmd)
{
    if (!g_Program || !g_SnapTex) return;

    const DrawData* d = static_cast<const DrawData*>(cmd->UserCallbackData);

    // Save state imgui cares about
    GLint prevProgram = 0;
    glGetIntegerv(GL_CURRENT_PROGRAM, &prevProgram);

    glUseProgram(g_Program);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, g_SnapTex);

    glUniform2f(g_uResolution,   d->resW,        d->resH);
    glUniform2f(g_uCenter,       d->center[0],   d->center[1]);
    glUniform2f(g_uHalfSize,     d->halfSize[0], d->halfSize[1]);
    glUniform1f(g_uExponent,     d->exponent);
    glUniform1f(g_uBlur,         d->blur);
    glUniform1f(g_uLensBand,     d->lensBand);
    glUniform1f(g_uLensStrength, d->lensStrength);
    glUniform1f(g_uAberration,   d->aberration);
    glUniform1f(g_uTint,         d->tint);
    glUniform1f(g_uRim,          d->rim);
    glUniform1f(g_uEdgeSoftness, d->edgeSoftness);
    glUniform1f(g_uShape,        d->shape);
    glUniform1i(g_uBackdrop,     1);  // texture unit 1

    // Leave GL_TEXTURE0 for imgui
    glActiveTexture(GL_TEXTURE0);
}

// Static slot — only one glass draw per frame (menu background)
static DrawData g_DrawDataSlot;

void Draw(ImDrawList* dl, ImVec2 center, ImVec2 halfSize, const Params& p, ImU32 tint)
{
    if (!g_Program) return;

    const ImGuiIO& io = ImGui::GetIO();

    g_DrawDataSlot.center[0]    = center.x;
    g_DrawDataSlot.center[1]    = center.y;
    g_DrawDataSlot.halfSize[0]  = halfSize.x;
    g_DrawDataSlot.halfSize[1]  = halfSize.y;
    g_DrawDataSlot.exponent     = p.exponent;
    g_DrawDataSlot.blur         = p.blur;
    g_DrawDataSlot.lensBand     = p.lensBand;
    g_DrawDataSlot.lensStrength = p.lensStrength;
    g_DrawDataSlot.aberration   = p.aberration;
    g_DrawDataSlot.tint         = p.tint;
    g_DrawDataSlot.rim          = p.rim;
    g_DrawDataSlot.edgeSoftness = p.edgeSoftness;
    g_DrawDataSlot.shape        = p.shape;
    g_DrawDataSlot.resW         = io.DisplaySize.x;
    g_DrawDataSlot.resH         = io.DisplaySize.y;

    dl->AddCallback(GlassCallback, &g_DrawDataSlot);

    const float margin = 2.0f;
    ImVec2 a(center.x - halfSize.x - margin, center.y - halfSize.y - margin);
    ImVec2 b(center.x + halfSize.x + margin, center.y + halfSize.y + margin);
    dl->PrimReserve(6, 4);
    dl->PrimRect(a, b, tint);

    dl->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
}

} // namespace LiquidGlass
