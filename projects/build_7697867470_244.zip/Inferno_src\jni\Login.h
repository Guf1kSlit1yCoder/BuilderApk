#pragma once
#include <string>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <ctime>
#include <jni.h>
#include <android/log.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "SDK/obfuscate.h"
#include "AntiCrack/ObfStr.h"
#include "AntiCrack/Sha256.h"
#include "AntiCrack/VmCore.h"
#include "AntiCrack/license_bytecode.h"
#include "AntiCrack/session_bytecode.h"
#include "AntiCrack/Crypto.h"
#include "AntiCrack/AntiDebug.h"
#include "AntiCrack/RsaNative.h"
#include "AntiCrack/AuthGate.h"
#include "AntiCrack/Integrity.h"

// Release build: strip all logcat output (set to 0 for debug/diagnostics).
#define ARENA_RELEASE 1

#define LG_TAG "ArenaLogin"
#if ARENA_RELEASE
  #define LG_I(...) ((void)0)
  #define LG_E(...) ((void)0)
#else
  #define LG_I(...) __android_log_print(ANDROID_LOG_INFO,  LG_TAG, __VA_ARGS__)
  #define LG_E(...) __android_log_print(ANDROID_LOG_ERROR, LG_TAG, __VA_ARGS__)
#endif

// Defined in Main.cpp (not static)
extern JavaVM* g_JavaVM;

namespace Login {

// ──────────────────────────────────────────────────────────────────────────────
//  Config (obfuscated at compile-time, decrypted on use)
// ──────────────────────────────────────────────────────────────────────────────
static inline const char* _SrvUrl() { return OBFUSCATE("https://miragedemomod.space/connect"); }
static inline const char* _KeyPath() { return OBFUSCATE("/sdcard/Download/arena_key.dat"); }

inline std::string      g_ErrMsg;
inline std::string      g_Expiry;
inline std::atomic<bool> g_LoggedIn{false};
// Э4: server-authenticated offset-unlock secret (parsed from `uk`). Consumed by
// SDK::UObject::SetOffsetKey after a successful login to recover real offsets.
inline std::atomic<uint32_t> g_UnlockKey{0};
// System 3: session key = the VM login verdict (non-zero only after a genuine
// login). Features re-verify it through the VM every frame, so bypassing auth
// (verdict never produced) leaves the cheat non-functional even if AuthGate is
// patched. g_SessionCheck = MIX(key) lets the per-frame VM confirm consistency.
inline std::atomic<uint64_t> g_SessionKey{0};
inline std::atomic<uint64_t> g_SessionCheck{0};
// True when the last DoLogin failed due to no server response (network), so the
// killswitch heartbeat can tolerate blips instead of killing a legit session.
inline std::atomic<bool> g_NetError{false};

// ──────────────────────────────────────────────────────────────────────────────
//  Tiny MD5 (no external deps)
// ──────────────────────────────────────────────────────────────────────────────
namespace _md5 {
    static const uint32_t T[64] = {
        0xd76aa478,0xe8c7b756,0x242070db,0xc1bdceee,0xf57c0faf,0x4787c62a,0xa8304613,0xfd469501,
        0x698098d8,0x8b44f7af,0xffff5bb1,0x895cd7be,0x6b901122,0xfd987193,0xa679438e,0x49b40821,
        0xf61e2562,0xc040b340,0x265e5a51,0xe9b6c7aa,0xd62f105d,0x02441453,0xd8a1e681,0xe7d3fbc8,
        0x21e1cde6,0xc33707d6,0xf4d50d87,0x455a14ed,0xa9e3e905,0xfcefa3f8,0x676f02d9,0x8d2a4c8a,
        0xfffa3942,0x8771f681,0x6d9d6122,0xfde5380c,0xa4beea44,0x4bdecfa9,0xf6bb4b60,0xbebfbc70,
        0x289b7ec6,0xeaa127fa,0xd4ef3085,0x04881d05,0xd9d4d039,0xe6db99e5,0x1fa27cf8,0xc4ac5665,
        0xf4292244,0x432aff97,0xab9423a7,0xfc93a039,0x655b59c3,0x8f0ccc92,0xffeff47d,0x85845dd1,
        0x6fa87e4f,0xfe2ce6e0,0xa3014314,0x4e0811a1,0xf7537e82,0xbd3af235,0x2ad7d2bb,0xeb86d391
    };
    static const int S[64] = {
        7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,
        5, 9,14,20,5, 9,14,20,5, 9,14,20,5, 9,14,20,
        4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,
        6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21
    };
    inline uint32_t rol(uint32_t v, int n) { return (v << n) | (v >> (32 - n)); }

    static std::string Compute(const std::string& msg) {
        uint64_t orig_len = msg.size();
        std::string data = msg;
        data += '\x80';
        while (data.size() % 64 != 56) data += '\x00';
        uint64_t bits = orig_len * 8;
        for (int i = 0; i < 8; i++) data += (char)((bits >> (i * 8)) & 0xFF);

        uint32_t a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;

        for (size_t off = 0; off < data.size(); off += 64) {
            uint32_t M[16];
            for (int i = 0; i < 16; i++) {
                M[i] = (uint8_t)data[off+i*4]
                     | ((uint8_t)data[off+i*4+1] << 8)
                     | ((uint8_t)data[off+i*4+2] << 16)
                     | ((uint8_t)data[off+i*4+3] << 24);
            }
            uint32_t A = a0, B = b0, C = c0, D = d0;
            for (int i = 0; i < 64; i++) {
                uint32_t F, g;
                if (i < 16)      { F = (B & C) | (~B & D); g = i; }
                else if (i < 32) { F = (D & B) | (~D & C); g = (5*i+1) % 16; }
                else if (i < 48) { F = B ^ C ^ D;           g = (3*i+5) % 16; }
                else             { F = C ^ (B | ~D);         g = (7*i) % 16;   }
                uint32_t tmp = D; D = C; C = B;
                B = B + rol(A + F + T[i] + M[g], S[i]);
                A = tmp;
            }
            a0 += A; b0 += B; c0 += C; d0 += D;
        }

        char out[33];
        uint32_t digest[4] = {a0, b0, c0, d0};
        for (int i = 0; i < 4; i++) {
            snprintf(out + i*8, 9, "%02x%02x%02x%02x",
                (digest[i]) & 0xFF, (digest[i] >> 8) & 0xFF,
                (digest[i] >> 16) & 0xFF, (digest[i] >> 24) & 0xFF);
        }
        return std::string(out, 32);
    }
} // namespace _md5

// ──────────────────────────────────────────────────────────────────────────────
//  JNI helpers
// ──────────────────────────────────────────────────────────────────────────────
static bool _JniFail(JNIEnv* env) {
    if (env->ExceptionCheck()) { env->ExceptionClear(); return true; }
    return false;
}

static std::string _JStr(JNIEnv* env, jstring js) {
    if (!js) return "";
    const char* c = env->GetStringUTFChars(js, nullptr);
    std::string r = c ? c : "";
    if (c) env->ReleaseStringUTFChars(js, c);
    return r;
}

static JNIEnv* _AttachEnv(JavaVM* vm, bool& attached) {
    JNIEnv* env = nullptr;
    attached = false;
    if (!vm) return nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) == JNI_OK) attached = true;
        else return nullptr;
    }
    return env;
}

// ──────────────────────────────────────────────────────────────────────────────
//  Device info
// ──────────────────────────────────────────────────────────────────────────────
static std::string _GetAndroidID(JNIEnv* env) {
    env->PushLocalFrame(16);
    std::string result;
    jclass atCls = env->FindClass("android/app/ActivityThread");
    if (_JniFail(env) || !atCls) { env->PopLocalFrame(nullptr); return "unknown"; }
    jmethodID curApp = env->GetStaticMethodID(atCls, "currentApplication", "()Landroid/app/Application;");
    if (_JniFail(env)) { env->PopLocalFrame(nullptr); return "unknown"; }
    jobject app = env->CallStaticObjectMethod(atCls, curApp);
    if (_JniFail(env) || !app) { env->PopLocalFrame(nullptr); return "unknown"; }

    jclass ctxCls = env->FindClass("android/content/Context");
    jmethodID getCR = env->GetMethodID(ctxCls, "getContentResolver", "()Landroid/content/ContentResolver;");
    jobject cr = env->CallObjectMethod(app, getCR);
    if (_JniFail(env) || !cr) { env->PopLocalFrame(nullptr); return "unknown"; }

    jclass ss = env->FindClass("android/provider/Settings$Secure");
    jmethodID getString = env->GetStaticMethodID(ss, "getString",
        "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");
    jstring key = env->NewStringUTF(OBFSTR("android_id"));
    jstring val = (jstring)env->CallStaticObjectMethod(ss, getString, cr, key);
    if (!_JniFail(env) && val) result = _JStr(env, val);
    env->PopLocalFrame(nullptr);
    return result.empty() ? "unknown" : result;
}

static std::string _GetBuildField(JNIEnv* env, const char* field) {
    env->PushLocalFrame(8);
    jclass bc = env->FindClass("android/os/Build");
    if (_JniFail(env) || !bc) { env->PopLocalFrame(nullptr); return ""; }
    jfieldID fid = env->GetStaticFieldID(bc, field, "Ljava/lang/String;");
    if (_JniFail(env)) { env->PopLocalFrame(nullptr); return ""; }
    jstring s = (jstring)env->GetStaticObjectField(bc, fid);
    std::string r = _JStr(env, s);
    env->PopLocalFrame(nullptr);
    return r;
}

static std::string _GetUUID(JNIEnv* env, const std::string& seed) {
    env->PushLocalFrame(16);
    jclass uuidCls = env->FindClass("java/util/UUID");
    if (_JniFail(env) || !uuidCls) { env->PopLocalFrame(nullptr); return _md5::Compute(seed); }
    jmethodID nameUUID = env->GetStaticMethodID(uuidCls, "nameUUIDFromBytes", "([B)Ljava/util/UUID;");
    jmethodID toStr    = env->GetMethodID(uuidCls, "toString", "()Ljava/lang/String;");
    if (_JniFail(env)) { env->PopLocalFrame(nullptr); return _md5::Compute(seed); }
    jbyteArray ba = env->NewByteArray((jsize)seed.size());
    env->SetByteArrayRegion(ba, 0, (jsize)seed.size(), (const jbyte*)seed.data());
    jobject uobj = env->CallStaticObjectMethod(uuidCls, nameUUID, ba);
    if (_JniFail(env) || !uobj) { env->PopLocalFrame(nullptr); return _md5::Compute(seed); }
    jstring js = (jstring)env->CallObjectMethod(uobj, toStr);
    std::string r = _JStr(env, js);
    env->PopLocalFrame(nullptr);
    return r;
}

// ──────────────────────────────────────────────────────────────────────────────
//  HTTP POST via JNI HttpURLConnection
// ──────────────────────────────────────────────────────────────────────────────
// Certificate pinning: require the TLS chain to contain our expected Let's Encrypt
// intermediate (CN=YR2) by its DER SHA-256. Stops a MITM/fake server even before
// the RSA response check. Pinned to the intermediate (stable) rather than the leaf
// (which renews). Returns true if the pin is present (or connection is not HTTPS).
static bool _CertPinOk(JNIEnv* env, jobject connObj) {
    static const char* PIN =
        OBFSTR("238b85a0099c65b970477d5724f1a1d475ce5058cffe4efa8733899bdb863c47");
    bool ok = false;
    env->PushLocalFrame(32);
    do {
        jclass httpsCls = env->FindClass("javax/net/ssl/HttpsURLConnection");
        if (_JniFail(env) || !httpsCls) break;
        if (!env->IsInstanceOf(connObj, httpsCls)) { ok = true; break; }
        jmethodID getCerts = env->GetMethodID(httpsCls, "getServerCertificates",
                                              "()[Ljava/security/cert/Certificate;");
        if (_JniFail(env) || !getCerts) break;
        jobjectArray certs = (jobjectArray)env->CallObjectMethod(connObj, getCerts);
        if (_JniFail(env) || !certs) break;
        jsize cnt = env->GetArrayLength(certs);
        jclass certCls = env->FindClass("java/security/cert/Certificate");
        jmethodID getEnc = env->GetMethodID(certCls, "getEncoded", "()[B");
        for (jsize i = 0; i < cnt && !ok; ++i) {
            jobject c = env->GetObjectArrayElement(certs, i);
            if (!c) continue;
            jbyteArray der = (jbyteArray)env->CallObjectMethod(c, getEnc);
            if (_JniFail(env) || !der) { env->DeleteLocalRef(c); continue; }
            jsize dl = env->GetArrayLength(der);
            jbyte* db = env->GetByteArrayElements(der, nullptr);
            if (db) {
                uint8_t h[32]; AntiCrack::Sha256::Hash(db, (size_t)dl, h);
                char hex[65]; for (int k = 0; k < 32; ++k) snprintf(hex + k * 2, 3, "%02x", h[k]);
                if (strcmp(hex, PIN) == 0) ok = true;
                env->ReleaseByteArrayElements(der, db, JNI_ABORT);
            }
            env->DeleteLocalRef(der); env->DeleteLocalRef(c);
        }
    } while (false);
    env->PopLocalFrame(nullptr);
    return ok;
}

static std::string _HttpPost(const std::string& urlStr, const std::string& body) {
    JavaVM* vm = g_JavaVM;
    if (!vm) return "";
    bool attached = false;
    JNIEnv* env = _AttachEnv(vm, attached);
    if (!env) return "";

    std::string result;
    env->PushLocalFrame(64);
    do {
        // URL url = new URL(urlStr);
        jclass urlCls = env->FindClass("java/net/URL");
        if (_JniFail(env) || !urlCls) break;
        jmethodID urlCtor = env->GetMethodID(urlCls, "<init>", "(Ljava/lang/String;)V");
        if (_JniFail(env)) break;
        jstring jurl = env->NewStringUTF(urlStr.c_str());
        jobject urlObj = env->NewObject(urlCls, urlCtor, jurl);
        if (_JniFail(env) || !urlObj) break;

        // HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        jmethodID openConn = env->GetMethodID(urlCls, "openConnection", "()Ljava/net/URLConnection;");
        jobject connObj = env->CallObjectMethod(urlObj, openConn);
        if (_JniFail(env) || !connObj) break;
        LG_I("HTTP: openConnection OK");

        jclass httpCls = env->FindClass("java/net/HttpURLConnection");
        if (_JniFail(env) || !httpCls) break;

        // conn.setRequestMethod("POST")
        jmethodID setMethod = env->GetMethodID(httpCls, "setRequestMethod", "(Ljava/lang/String;)V");
        env->CallVoidMethod(connObj, setMethod, env->NewStringUTF("POST"));
        if (_JniFail(env)) break;

        // conn.setDoOutput(true)
        jmethodID setDoOutput = env->GetMethodID(httpCls, "setDoOutput", "(Z)V");
        env->CallVoidMethod(connObj, setDoOutput, JNI_TRUE);

        // conn.setConnectTimeout(8000); conn.setReadTimeout(8000);
        jmethodID setConn = env->GetMethodID(httpCls, "setConnectTimeout", "(I)V");
        jmethodID setRead = env->GetMethodID(httpCls, "setReadTimeout",    "(I)V");
        env->CallVoidMethod(connObj, setConn, (jint)8000);
        env->CallVoidMethod(connObj, setRead, (jint)8000);
        _JniFail(env);

        // conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        jmethodID setProp = env->GetMethodID(httpCls, "setRequestProperty",
                                             "(Ljava/lang/String;Ljava/lang/String;)V");
        env->CallVoidMethod(connObj, setProp,
            env->NewStringUTF("Content-Type"),
            env->NewStringUTF("application/x-www-form-urlencoded"));
        env->CallVoidMethod(connObj, setProp,
            env->NewStringUTF("User-Agent"),
            env->NewStringUTF("Arena/1.0"));
        _JniFail(env);

        // OutputStream os = conn.getOutputStream(); os.write(bytes); os.close();
        jclass urlConnCls = env->FindClass("java/net/URLConnection");
        jmethodID getOS = env->GetMethodID(urlConnCls, "getOutputStream", "()Ljava/io/OutputStream;");
        jobject osObj = env->CallObjectMethod(connObj, getOS);
        if (_JniFail(env) || !osObj) break;
        LG_I("HTTP: getOutputStream OK");

        jclass osCls = env->GetObjectClass(osObj);
        jmethodID write = env->GetMethodID(osCls, "write", "([B)V");
        jmethodID close = env->GetMethodID(osCls, "close", "()V");
        jbyteArray ba = env->NewByteArray((jsize)body.size());
        env->SetByteArrayRegion(ba, 0, (jsize)body.size(), (const jbyte*)body.data());
        env->CallVoidMethod(osObj, write, ba);
        env->CallVoidMethod(osObj, close);
        _JniFail(env);

        // int code = conn.getResponseCode();
        jmethodID getRespCode = env->GetMethodID(httpCls, "getResponseCode", "()I");
        jint respCode = env->CallIntMethod(connObj, getRespCode);
        _JniFail(env);
        LG_I("HTTP response code: %d", (int)respCode);

        // Certificate pinning: abort if the TLS chain is not our server's.
        if (!_CertPinOk(env, connObj)) {
            LG_E("HTTP: certificate pin mismatch — aborting");
            AntiCrack::AntiDebug::I().AddStrike(3);
            break;
        }

        // InputStream is = conn.getInputStream(); read all; conn.disconnect();
        jmethodID getIS = env->GetMethodID(httpCls, "getInputStream", "()Ljava/io/InputStream;");
        jobject isObj = env->CallObjectMethod(connObj, getIS);
        if (_JniFail(env) || !isObj) break;

        jclass isCls = env->GetObjectClass(isObj);
        jmethodID readFn = env->GetMethodID(isCls, "read", "([BII)I");
        jmethodID closeFn = env->GetMethodID(isCls, "close", "()V");

        jbyteArray buf = env->NewByteArray(4096);
        jint n;
        while ((n = env->CallIntMethod(isObj, readFn, buf, (jint)0, (jint)4096)) > 0) {
            if (_JniFail(env)) break;
            jbyte* raw = env->GetByteArrayElements(buf, nullptr);
            if (raw) { result.append((const char*)raw, (size_t)n); env->ReleaseByteArrayElements(buf, raw, JNI_ABORT); }
        }
        env->CallVoidMethod(isObj, closeFn);
        _JniFail(env);

        jmethodID disconnect = env->GetMethodID(httpCls, "disconnect", "()V");
        env->CallVoidMethod(connObj, disconnect);
        _JniFail(env);
    } while (false);

    env->PopLocalFrame(nullptr);
    if (attached) vm->DetachCurrentThread();
    return result;
}

// ──────────────────────────────────────────────────────────────────────────────
//  Simple JSON field extractors (no external JSON lib needed)
// ──────────────────────────────────────────────────────────────────────────────
static std::string _JsonStr(const std::string& json, const char* key) {
    std::string k = std::string("\"") + key + "\":\"";
    size_t p = json.find(k);
    if (p == std::string::npos) return "";
    p += k.size();
    size_t q = json.find('"', p);
    return (q == std::string::npos) ? "" : json.substr(p, q - p);
}

static bool _JsonBool(const std::string& json, const char* key) {
    std::string k = std::string("\"") + key + "\":";
    size_t p = json.find(k);
    if (p == std::string::npos) return false;
    p += k.size();
    while (p < json.size() && json[p] == ' ') p++;
    return json.substr(p, 4) == "true";
}

// ──────────────────────────────────────────────────────────────────────────────
//  RSA signature verification (server signs with private key, we verify with public)
// ──────────────────────────────────────────────────────────────────────────────
// X.509 SubjectPublicKeyInfo (DER, base64) of server_public.pem — obfuscated so it
// can't be trivially located and swapped for an attacker's own key.
static inline const char* _PubKey() {
    return OBFUSCATE(
        "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApf5HdVtXvYS07QvO0iH7"
        "p+btOHzExVsIW6xrSrFPjqaiWxNApEvIpgsFYLqjXUGHvK1vmjxTNm8ejckORKCR"
        "qmFKcjKBNNwiI5U8ofyUNXVtjjJaL9RJMfq3t9rGKA+JXRjWsuIHxF2NJSPDNwkj"
        "f03yL9I5+z4XY0YF2XYkk+MSzX6mVpyexnX/nUOtElUkyV8v1zogsfLHpOrW5ldw"
        "Y399ngIV7yPx0YUidd+9Nt/V47JDTF5pVc6TnyrHzx/Bb6duG7o51AfgEQG+eQAb"
        "6xwdjxWvfNGnX9VYeEz8pjgws4F4fOplqw1yxxqLnE6an8NbXP4pBDismTHOaxyU"
        "jQIDAQAB");
}

static std::string _MakeNonce() {
    unsigned char b[16];
    bool got = false;
    FILE* f = fopen("/dev/urandom", "rb");
    if (f) { got = (fread(b, 1, sizeof(b), f) == sizeof(b)); fclose(f); }
    if (!got) {
        uint64_t s = (uint64_t)time(nullptr) ^ ((uint64_t)(uintptr_t)&b << 16);
        for (int i = 0; i < 16; i++) { s = s * 6364136223846793005ULL + 1442695040888963407ULL; b[i] = (unsigned char)(s >> 56); }
    }
    char out[33];
    for (int i = 0; i < 16; i++) snprintf(out + i * 2, 3, "%02x", b[i]);
    return std::string(out, 32);
}

// Verify base64 signature over `payload` entirely in native code (no JNI / no
// java.security.Signature in the trust path) and seal the authorization state.
// `recovered` receives the hash carried in the signature for the branchless fold.
// Returns true only on a genuine PKCS#1 v1.5 (SHA-256) signature.
static bool _VerifyNative(const std::string& payload, const std::string& sigB64,
                          uint8_t recovered[32]) {
    memset(recovered, 0, 32);
    if (sigB64.empty()) return false;
    uint8_t sig[384]; size_t siglen = 0;
    if (!AntiCrack::Base64Decode(sigB64.c_str(), sigB64.size(), sig, &siglen)) return false;
    if (siglen != 256) return false;
    return AntiCrack::RsaVerifySha256(payload, sig, siglen, recovered);
}

// ──────────────────────────────────────────────────────────────────────────────
//  Clipboard
// ──────────────────────────────────────────────────────────────────────────────
inline std::string GetClipboardText() {
    JavaVM* vm = g_JavaVM;
    if (!vm) return "";
    bool attached = false;
    JNIEnv* env = _AttachEnv(vm, attached);
    if (!env) return "";

    std::string result;
    env->PushLocalFrame(32);
    do {
        // ctx = ActivityThread.currentApplication()
        jclass atCls = env->FindClass("android/app/ActivityThread");
        if (_JniFail(env) || !atCls) break;
        jmethodID curApp = env->GetStaticMethodID(atCls, "currentApplication",
                                                   "()Landroid/app/Application;");
        if (_JniFail(env)) break;
        jobject ctx = env->CallStaticObjectMethod(atCls, curApp);
        if (_JniFail(env) || !ctx) break;

        // ClipboardManager cm = (ClipboardManager) ctx.getSystemService("clipboard")
        jclass ctxCls = env->FindClass("android/content/Context");
        jmethodID getSvc = env->GetMethodID(ctxCls, "getSystemService",
                                             "(Ljava/lang/String;)Ljava/lang/Object;");
        if (_JniFail(env)) break;
        jstring svcName = env->NewStringUTF("clipboard");
        jobject cm = env->CallObjectMethod(ctx, getSvc, svcName);
        if (_JniFail(env) || !cm) break;

        // ClipData cd = cm.getPrimaryClip()
        jclass cmCls = env->GetObjectClass(cm);
        jmethodID getClip = env->GetMethodID(cmCls, "getPrimaryClip",
                                              "()Landroid/content/ClipData;");
        if (_JniFail(env) || !getClip) break;
        jobject cd = env->CallObjectMethod(cm, getClip);
        if (_JniFail(env) || !cd) break;

        // ClipData.Item item = cd.getItemAt(0)
        jclass cdCls = env->GetObjectClass(cd);
        jmethodID getCnt  = env->GetMethodID(cdCls, "getItemCount", "()I");
        jmethodID getItem = env->GetMethodID(cdCls, "getItemAt",
                                              "(I)Landroid/content/ClipData$Item;");
        if (_JniFail(env)) break;
        jint cnt = env->CallIntMethod(cd, getCnt);
        if (_JniFail(env) || cnt <= 0) break;
        jobject item = env->CallObjectMethod(cd, getItem, (jint)0);
        if (_JniFail(env) || !item) break;

        // CharSequence cs = item.coerceToText(ctx)
        jclass itemCls = env->GetObjectClass(item);
        jmethodID coerce = env->GetMethodID(itemCls, "coerceToText",
                                             "(Landroid/content/Context;)Ljava/lang/CharSequence;");
        if (_JniFail(env) || !coerce) break;
        jobject cs = env->CallObjectMethod(item, coerce, ctx);
        if (_JniFail(env) || !cs) break;

        // String s = cs.toString()
        jclass csCls = env->GetObjectClass(cs);
        jmethodID toStr = env->GetMethodID(csCls, "toString", "()Ljava/lang/String;");
        if (_JniFail(env)) break;
        jstring js = (jstring)env->CallObjectMethod(cs, toStr);
        if (!_JniFail(env) && js) result = _JStr(env, js);
    } while (false);

    env->PopLocalFrame(nullptr);
    if (attached) vm->DetachCurrentThread();
    return result;
}

// ──────────────────────────────────────────────────────────────────────────────
//  Save / Load key
// ──────────────────────────────────────────────────────────────────────────────
static void SaveKey(const std::string& key) {
    FILE* f = fopen(_KeyPath(), "w");
    if (f) { fputs(key.c_str(), f); fclose(f); }
}

static std::string LoadKey() {
    FILE* f = fopen(_KeyPath(), "r");
    if (!f) return "";
    char buf[256] = {};
    fgets(buf, sizeof(buf), f);
    fclose(f);
    std::string s = buf;
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r' || s.back() == ' '))
        s.pop_back();
    return s;
}

// ──────────────────────────────────────────────────────────────────────────────
//  Anti-tamper: debugger / Frida detection
// ──────────────────────────────────────────────────────────────────────────────
static bool _TracerAttached() {
    FILE* f = fopen(OBFUSCATE("/proc/self/status"), "r");
    if (!f) return false;
    char line[256]; bool traced = false;
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, OBFUSCATE("TracerPid:"), 10) == 0) {
            traced = (atoi(line + 10) != 0);
            break;
        }
    }
    fclose(f);
    return traced;
}

static bool _InjectInMaps() {
    FILE* f = fopen(OBFUSCATE("/proc/self/maps"), "r");
    if (!f) return false;
    char line[512]; bool found = false;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, OBFUSCATE("frida")) ||
            strstr(line, OBFUSCATE("gum-js-loop")) ||
            strstr(line, OBFUSCATE("linjector")) ||
            strstr(line, OBFUSCATE("gadget"))) { found = true; break; }
    }
    fclose(f);
    return found;
}

static bool _FridaPortOpen() {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) return false;
    int fl = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, fl | O_NONBLOCK);
    struct sockaddr_in a; memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_port   = htons(27042);
    inet_pton(AF_INET, OBFUSCATE("127.0.0.1"), &a.sin_addr);
    bool open = false;
    if (connect(s, (struct sockaddr*)&a, sizeof(a)) == 0) {
        open = true;
    } else {
        struct pollfd pfd;
        pfd.fd = s;
        pfd.events = POLLOUT;
        pfd.revents = 0;
        if (poll(&pfd, 1, 120) > 0) {
            if ((pfd.revents & POLLOUT) && !(pfd.revents & (POLLERR | POLLHUP))) {
                int err = 0; socklen_t el = sizeof(err);
                getsockopt(s, SOL_SOCKET, SO_ERROR, &err, &el);
                open = (err == 0);
            }
        }
    }
    close(s);
    return open;
}

static bool _SecCheck() {
    return _TracerAttached() || _InjectInMaps() || _FridaPortOpen();
}

// ──────────────────────────────────────────────────────────────────────────────
//  Main login call (runs on background thread from Menu)
// ──────────────────────────────────────────────────────────────────────────────
// License verdict computed by the bytecode VM (license_bytecode.h), not a C++
// branch. Inputs: the verification flags + the recovered-hash limbs. Returns 0 to
// reject; otherwise non-zero session material. The pass/fail logic lives in the
// bytecode, so there is no single if() for a cracker to NOP.
static uint64_t _LicenseCheck(bool tokenMatch, bool sigOk, bool secBad,
                              const uint8_t recovered[32]) {
    uint64_t in[7];
    in[0] = tokenMatch ? 1u : 0u;
    in[1] = sigOk ? 1u : 0u;
    in[2] = secBad ? 1u : 0u;
    for (int i = 0; i < 4; ++i) {
        uint64_t v = 0;
        for (int b = 0; b < 8; ++b) v = (v << 8) | recovered[i * 8 + b];
        in[3 + i] = v;
    }
    return AntiCrack::LicenseVM::Run(AntiCrack::g_LicenseBytecode,
                                     AntiCrack::g_LicenseBytecodeLen, in, 7);
}

inline bool DoLogin(const std::string& key) {
    g_ErrMsg = "";
    g_NetError = false;
    if (key.empty()) { g_ErrMsg = (const char*)OBFSTR("Key is empty"); return false; }

    // Anti-tamper gate: refuse to authenticate under a debugger / Frida.
    if (_SecCheck()) { g_ErrMsg = (const char*)OBFUSCATE("Connection error"); return false; }

    JavaVM* vm = g_JavaVM;
    if (!vm) { g_ErrMsg = (const char*)OBFSTR("VM not ready"); return false; }
    bool attached = false;
    JNIEnv* env = _AttachEnv(vm, attached);
    if (!env) { g_ErrMsg = (const char*)OBFSTR("JNI attach failed"); return false; }

    // Build HWID seed
    std::string androidId = _GetAndroidID(env);
    std::string model     = _GetBuildField(env, "MODEL");
    std::string brand     = _GetBuildField(env, "BRAND");
    std::string hwSeed    = key + androidId + model + brand;
    std::string uuid      = _GetUUID(env, hwSeed);

    if (attached) vm->DetachCurrentThread();

    LG_I("Login attempt: key=%.8s..., uuid=%s", key.c_str(), uuid.c_str());

    // POST (with a fresh nonce for anti-replay / signature binding)
    std::string nonce = _MakeNonce();
    std::string body = "game=pubg&user_key=" + key + "&serial=" + uuid + "&nonce=" + nonce + "&toxic=0&toxiv=0";
    std::string resp = _HttpPost(_SrvUrl(), body);

    if (resp.empty()) { g_NetError = true; g_ErrMsg = (const char*)OBFSTR("No server response"); LG_E("Login failed: empty response"); return false; }
    g_NetError = false;
    LG_I("Server response: %s", resp.c_str());

    // Parse
    if (!_JsonBool(resp, "status")) {
        g_ErrMsg = _JsonStr(resp, "reason");
        if (g_ErrMsg.empty()) g_ErrMsg = (const char*)OBFSTR("Server rejected key");
        LG_E("Login failed: %s", g_ErrMsg.c_str());
        return false;
    }

    std::string expiry = _JsonStr(resp, "EXP");
    std::string token  = _JsonStr(resp, "token");
    std::string real   = _JsonStr(resp, "real");

    // If server didn't send "real", build fallback (same as Maximus)
    if (real.empty()) {
        real = std::string((const char*)OBFUSCATE("pubg-")) + key + "-" + uuid + (const char*)OBFUSCATE("-Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E");
    }

    // Compute the token match as a flag (no branch): the verdict is decided by the
    // bytecode VM below, together with the signature result and anti-tamper state.
    std::string expectedToken = _md5::Compute(real);
    bool tokenMatch = (token == expectedToken);

    // Authoritative check: RSA signature over key|serial|expiry|nonce|unlockSecret,
    // verified in native code. The server (Connect.php) signs exactly these five
    // fields; `uk` is the offset-unlock secret, authenticated by the signature so
    // an attacker cannot forge it. Fake servers can't produce the signature (no
    // private key); replays fail (fresh nonce). Recovered hash seals the gate.
    std::string sig = _JsonStr(resp, "sig");
    std::string uk  = _JsonStr(resp, "uk");
    std::string sigPayload = key + "|" + uuid + "|" + expiry + "|" + nonce + "|" + uk;
    uint8_t recovered[32];
    bool sigOk = _VerifyNative(sigPayload, sig, recovered);

#ifdef ARENA_DIAG
    // DIAGNOSTIC BUILD: dump exactly what the client built + the raw server
    // response so the signed payload can be compared byte-for-byte. Remove for release.
    {
        uint8_t dh[32]; AntiCrack::Sha256::Hash(sigPayload, dh);
        char hhex[65]; for (int i=0;i<32;i++) snprintf(hhex+i*2,3,"%02x",dh[i]);
        uint8_t dsig[384]; size_t dsl=0; AntiCrack::Base64Decode(sig.c_str(), sig.size(), dsig, &dsl);
        FILE* df = fopen("/sdcard/Download/arena_debug.txt", "w");
        if (df) {
            fprintf(df, "sigOk=%d\n", (int)sigOk);
            fprintf(df, "--- client sigPayload (len=%zu) ---\n[%s]\n", sigPayload.size(), sigPayload.c_str());
            fprintf(df, "sha256(payload)=%s\n", hhex);
            fprintf(df, "key=[%s]\nserial(uuid)=[%s]\nexpiry=[%s]\nnonce=[%s]\nuk=[%s]\n",
                    key.c_str(), uuid.c_str(), expiry.c_str(), nonce.c_str(), uk.c_str());
            fprintf(df, "sig_b64(len=%zu)=[%s]\nsig_decoded_len=%zu\n", sig.size(), sig.c_str(), dsl);
            fprintf(df, "--- raw server response ---\n%s\n", resp.c_str());
            fclose(df);
        }
    }
#endif

    // Single verdict from the bytecode VM over {tokenMatch, sigOk, secBad, hash}.
    // No separate token/signature branches to patch — the logic is in the bytecode.
    bool secBad = _SecCheck();
    uint64_t verdict = _LicenseCheck(tokenMatch, sigOk, secBad, recovered);
    if (verdict == 0) {
        // Server said status=true but token/signature did not verify — that is a
        // forged/MITM response (a plain wrong key is rejected earlier with status=
        // false), so feed the anti-debug strike system.
        AntiCrack::AntiDebug::I().AddStrike(3);
        AntiCrack::AuthGate::I().Clear();
        g_SessionKey.store(0);
        g_SessionCheck.store(0);
        g_ErrMsg = (const char*)OBFSTR("Signature invalid");
        LG_E("Login failed: license verdict rejected");
        return false;
    }

    // System 3: publish the session key (VM verdict) + its MIX, for the per-frame
    // feature gate. Only a genuine login produces a consistent pair.
    g_SessionKey.store(verdict);
    g_SessionCheck.store(AntiCrack::SplitMix64(verdict));

    // Seal the gate from the recovered hash; re-sample anti-tamper so a tracer
    // that attached after the opening check poisons the sealed cookie.
    AntiCrack::AuthGate::I().Seal(recovered, secBad);

    // Э4: publish the authenticated unlock secret (hex). The caller applies it to
    // SDK::SetOffsetKey + re-inits so real offsets become available only now.
    g_UnlockKey.store((uint32_t)strtoul(uk.c_str(), nullptr, 16));

    g_Expiry   = expiry;
    g_LoggedIn = true;
    SaveKey(key);
    LG_I("Login SUCCESS! Expiry: %s", expiry.c_str());
    return AntiCrack::AuthGate::I().Authorized();
}

// Single source of truth for "is the cheat unlocked" — recomputed, salted,
// self-checked, AND gated on code integrity (a patched image never authorizes).
inline bool Authorized() {
    return AntiCrack::Integrity::I().Ok() && AntiCrack::AuthGate::I().Authorized();
}

// System 3: per-frame session check, run THROUGH the VM (not a plain C++ compare).
// Returns true only when the session key is the genuine non-zero verdict and its
// MIX matches — i.e. a real login happened. Cheap (~7-op VM run).
inline bool SessionValid() {
    uint64_t k = g_SessionKey.load();
    if (k == 0) return false;
    uint64_t in[2] = { k, g_SessionCheck.load() };
    return AntiCrack::LicenseVM::Run(AntiCrack::g_SessionBytecode,
                                     AntiCrack::g_SessionBytecodeLen, in, 2) != 0;
}

inline void Logout() {
    AntiCrack::AuthGate::I().Clear();
    g_SessionKey.store(0);
    g_SessionCheck.store(0);
    g_LoggedIn = false;
}

// Device-bound 32-byte key for config encryption: SHA256(ANDROID_ID | salt).
// Fetches ANDROID_ID via the same ContentResolver JNI path used at login.
inline void GetDeviceConfigKey(uint8_t out[32]) {
    std::string aid = "unknown";
    JavaVM* vm = g_JavaVM;
    if (vm) {
        bool attached = false;
        JNIEnv* env = _AttachEnv(vm, attached);
        if (env) { aid = _GetAndroidID(env); if (attached) vm->DetachCurrentThread(); }
    }
    AntiCrack::DeriveConfigKey(aid, out);
}

// Killswitch heartbeat: re-authenticate with the saved key against the server.
// A genuine rejection (ban / disabled key / expiry / tracer) kills the session
// immediately; transient network failures are tolerated for a few tries so a
// connectivity blip never logs out a legitimate user.
inline void Heartbeat() {
    if (!g_LoggedIn.load()) return;
    std::string key = LoadKey();
    if (key.empty()) return;

    static int s_netFails = 0;
    if (DoLogin(key)) {            // still valid -> re-sealed, keep running
        s_netFails = 0;
        return;
    }
    if (g_NetError.load()) {       // server unreachable -> tolerate blips
        if (++s_netFails >= 3) { Logout(); s_netFails = 0; }
        return;
    }
    // Server answered and said NO (ban / disabled / expired / tamper) -> kill now.
    s_netFails = 0;
    Logout();
}

} // namespace Login
