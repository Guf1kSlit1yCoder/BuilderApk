#include "Basic.hpp"
#include "Memory/Tools.h"
#include <mutex>
#include <algorithm>

// Trampoline or direct pointer for ProcessEvent
void* (*orig_ProcessEvent)(SDK::UObject* obj, SDK::UFunction* func, void* params) = nullptr;

namespace SDK
{
TUObjectArray *UObject::GObjects = nullptr;
void *UObject::GNames = nullptr;
uintptr_t UObject::ProcessEventAddr = 0;
int32_t UObject::ProcessEventIndex = UEPointers::ProcessEventIndex;
uintptr_t UObject::GLibBase = 0;

static std::unordered_map<std::string, int32_t> g_FNameCache;
static std::mutex g_FNameMutex;

// Э4: offset-unmask key (server-authenticated unlockSecret). 0 until login, so
// offsets stay scrambled and the cheat finds nothing before a genuine auth.
static uint32_t g_OffsetKey = 0;

static inline uint64_t _SplitMix64(uint64_t x) {
    x += 0x9E3779B97F4A7C15ULL;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL;
    return x ^ (x >> 31);
}

void UObject::SetOffsetKey(uint32_t key) { g_OffsetKey = key; }

uintptr_t UObject::UnmaskPtr(uintptr_t masked) {
    return masked ^ (uintptr_t)_SplitMix64((uint64_t)g_OffsetKey);
}

void UObject::Init(uintptr_t libBase)
{
    if (libBase == 0) {
        LOGE("[SDK::Init] libBase is 0! Initialization aborted.");
        return;
    }

    GLibBase = libBase;
    GNames = reinterpret_cast<void*>(libBase + UnmaskPtr(UEPointers::Names));
    GObjects = reinterpret_cast<TUObjectArray*>(libBase + UnmaskPtr(UEPointers::ObjObjects));
    ProcessEventAddr = libBase + UnmaskPtr(UEPointers::ProcessEvent);
    ProcessEventIndex = UEPointers::ProcessEventIndex;

    LOGI("==================================================");
    LOGI("[SDK::Init] Initializing SDK for Arena Breakout");
    LOGI("[SDK::Init] libBase:          0x%" PRIXPTR, libBase);
    LOGI("[SDK::Init] GNames:           0x%" PRIXPTR " (offset 0x%" PRIXPTR ")", reinterpret_cast<uintptr_t>(GNames), UEPointers::Names);
    LOGI("[SDK::Init] GObjects:         0x%" PRIXPTR " (offset 0x%" PRIXPTR ")", reinterpret_cast<uintptr_t>(GObjects), UEPointers::ObjObjects);
    LOGI("[SDK::Init] ProcessEventAddr: 0x%" PRIXPTR " (offset 0x%" PRIXPTR ", VTable idx %d)", ProcessEventAddr, UEPointers::ProcessEvent, ProcessEventIndex);

    // Validate GObjects pointer
    if (Tools::IsPtrValid(GObjects)) {
        int32_t numObj = GObjects->Num();
        LOGI("[SDK::Init] GObjects is valid! Element count: %d (Max: %d)", numObj, GObjects->MaxElements);
        if (numObj > 0) {
            for (int i = 0; i < std::min(numObj, 5); i++) {
                UObject* obj = GObjects->GetByIndex(i);
                if (obj && Tools::IsPtrValid(obj)) {
                    LOGI("[SDK::Init] UObject[%d] at %p, Name: '%s'", i, obj, obj->GetName().c_str());
                }
            }
        }
    } else {
        LOGW("[SDK::Init] GObjects address 0x%" PRIXPTR " is not readable yet. Will re-check in loop.", reinterpret_cast<uintptr_t>(GObjects));
    }

    // Validate GNames pointer
    if (Tools::IsPtrValid(GNames)) {
        LOGI("[SDK::Init] GNames pointer is readable!");
    } else {
        LOGW("[SDK::Init] GNames address is not readable yet.");
    }
    LOGI("==================================================");
}

std::string FString::ToString() const
{
    if (!Data || NumElements <= 0 || !Tools::IsPtrValid(Data)) return "";
    if (!Tools::IsReadable(Data, 2)) return "";

    // In UE4 on Android, TCHAR is char16_t (uint16_t, 2 bytes).
    // On Linux/Android NDK without -fshort-wchar, sizeof(wchar_t) is 4 bytes.
    // Auto-detect whether Data is 16-bit (UTF-16) or 32-bit (UTF-32).
    bool is16Bit = true;
    if (NumElements >= 2 && Tools::IsReadable(Data, 8)) {
        const uint8_t* b = reinterpret_cast<const uint8_t*>(Data);
        if (b[1] == 0 && b[2] == 0 && b[3] == 0 && (b[4] != 0 || b[5] != 0)) {
            is16Bit = false;
        }
    }

    std::string out;
    const int maxLen = (NumElements > 0 && NumElements < 128) ? NumElements : 128;
    out.reserve(maxLen * 3);

    const uint16_t* p16 = reinterpret_cast<const uint16_t*>(Data);
    const uint32_t* p32 = reinterpret_cast<const uint32_t*>(Data);

    for (int i = 0; i < maxLen; ++i) {
        uint32_t cp = 0;
        if (is16Bit) {
            if (!Tools::IsReadable(&p16[i], sizeof(uint16_t))) break;
            uint16_t u16 = p16[i];
            if (u16 == 0) break;
            if (u16 >= 0xD800 && u16 <= 0xDBFF && i + 1 < maxLen) {
                if (Tools::IsReadable(&p16[i + 1], sizeof(uint16_t))) {
                    uint16_t low = p16[i + 1];
                    if (low >= 0xDC00 && low <= 0xDFFF) {
                        ++i;
                        cp = 0x10000 + ((static_cast<uint32_t>(u16 - 0xD800) << 10) | (low - 0xDC00));
                    } else {
                        cp = u16;
                    }
                } else {
                    cp = u16;
                }
            } else {
                cp = u16;
            }
        } else {
            if (!Tools::IsReadable(&p32[i], sizeof(uint32_t))) break;
            cp = p32[i];
            if (cp == 0) break;
        }

        // Convert Unicode codepoint to valid UTF-8
        if (cp < 0x80) {
            out.push_back(static_cast<char>(cp));
        } else if (cp < 0x800) {
            out.push_back(static_cast<char>(0xC0 | ((cp >> 6) & 0x1F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else if (cp < 0x10000) {
            out.push_back(static_cast<char>(0xE0 | ((cp >> 12) & 0x0F)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else if (cp <= 0x10FFFF) {
            out.push_back(static_cast<char>(0xF0 | ((cp >> 18) & 0x07)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        }
    }
    return out;
}

static uint8_t* GetNameEntry(int32_t id)
{
    if (!UObject::GNames || id < 0) return nullptr;
    uintptr_t namesPtr = reinterpret_cast<uintptr_t>(UObject::GNames);
    if (!Tools::IsPtrValid(reinterpret_cast<void*>(namesPtr))) return nullptr;

    uint32_t block = static_cast<uint32_t>(id) >> UEOffsets::FNamePool::BlocksBit;
    uint32_t offset = (static_cast<uint32_t>(id) & ((1 << UEOffsets::FNamePool::BlocksBit) - 1)) * UEOffsets::FNamePool::Stride;

    if (block >= 8192) return nullptr;

    uintptr_t blockPtrAddr = namesPtr + UEOffsets::FNamePool::BlocksOff + block * sizeof(uint8_t*);
    if (!Tools::IsReadable(reinterpret_cast<void*>(blockPtrAddr), sizeof(uint8_t*))) return nullptr;

    uint8_t* chunk = *reinterpret_cast<uint8_t**>(blockPtrAddr);
    if (!chunk || !Tools::IsPtrValid(chunk)) return nullptr;

    uint8_t* entry = chunk + offset;
    if (!Tools::IsReadable(entry, 2)) return nullptr;

    return entry;
}

std::string FName::GetName() const
{
    if (ComparisonIndex <= 0) return "None";

    uint8_t* entry = GetNameEntry(ComparisonIndex);
    if (!entry) return "None";

    if (!Tools::IsReadable(entry, 2)) return "None";
    uint16_t header = *reinterpret_cast<uint16_t*>(entry);
    size_t len = header >> 6;
    if (len == 0 || len > 512) return "None";

    const char* strPtr = reinterpret_cast<const char*>(entry + 2);
    if (!Tools::IsReadable(const_cast<char*>(strPtr), len)) return "None";

    std::string name(strPtr, len);
    if (Number > 0)
    {
        name += "_" + std::to_string(Number - 1);
    }
    return name;
}

FName::FName(const char *name) : ComparisonIndex(0), Number(0)
{
    if (!name || !*name || !UObject::GNames) return;

    std::string sname(name);
    {
        std::lock_guard<std::mutex> lock(g_FNameMutex);
        auto it = g_FNameCache.find(sname);
        if (it != g_FNameCache.end())
        {
            ComparisonIndex = it->second;
            return;
        }
    }

    uintptr_t namesPtr = reinterpret_cast<uintptr_t>(UObject::GNames);
    if (namesPtr < 0x10000000 || namesPtr > 0x7FFFFFFFFFFF) return;

    uint8_t** blocks = reinterpret_cast<uint8_t**>(namesPtr + UEOffsets::FNamePool::BlocksOff);
    size_t targetLen = sname.length();

    for (uint32_t b = 0; b < 64; b++)
    {
        uint8_t* chunk = blocks[b];
        uintptr_t uChunk = reinterpret_cast<uintptr_t>(chunk);
        if (!chunk || uChunk < 0x10000000 || uChunk > 0x7FFFFFFFFFFF || (uChunk & 7) != 0) break;

        // Verify chunk accessibility once per 128KB block
        if (!Tools::IsPtrValid(chunk)) break;

        uint32_t offset = 0;
        int zeroCount = 0;
        while (offset < 0x10000 * UEOffsets::FNamePool::Stride)
        {
            uint8_t* entry = chunk + offset;
            uint16_t header = *reinterpret_cast<uint16_t*>(entry);
            size_t len = header >> 6;
            if (len == 0 || len > 1024)
            {
                zeroCount++;
                if (zeroCount > 100) break; // End of allocated names in this chunk
                offset += UEOffsets::FNamePool::Stride;
                continue;
            }
            zeroCount = 0;

            const char* entryStr = reinterpret_cast<const char*>(entry + 2);
            if (len == targetLen && strncasecmp(entryStr, name, len) == 0)
            {
                int32_t foundIndex = (b << UEOffsets::FNamePool::BlocksBit) | (offset / UEOffsets::FNamePool::Stride);
                ComparisonIndex = foundIndex;
                {
                    std::lock_guard<std::mutex> lock(g_FNameMutex);
                    g_FNameCache[sname] = foundIndex;
                }
                LOGI("[FName] Found '%s' in FNamePool -> Index %d (Block %u, Offset 0x%X)", name, foundIndex, b, offset);
                return;
            }

            uint32_t entrySize = 2 + static_cast<uint32_t>(len);
            offset += (entrySize + 1) & ~1;
        }
    }
}

bool FWeakObjectPtr::IsValid() const
{
    if (!UObject::GObjects || !Tools::IsPtrValid(UObject::GObjects)) return false;
    UObject *obj = UObject::GObjects->GetByIndex(ObjectIndex);
    if (!obj || !Tools::IsPtrValid(obj)) return false;
    FUObjectItem *item = UObject::GObjects->GetItemByIndex(ObjectIndex);
    return item && Tools::IsPtrValid(item) && item->SerialNumber == ObjectSerialNumber;
}

UObject *FWeakObjectPtr::Get() const
{
    if (IsValid())
    {
        return UObject::GObjects->GetByIndex(ObjectIndex);
    }
    return nullptr;
}

std::string UObject::GetName() const
{
    if (!Tools::IsPtrValid(const_cast<UObject*>(this))) return "None";
    return NamePrivate.GetName();
}

std::string UObject::GetFullName() const
{
    if (!Tools::IsPtrValid(const_cast<UObject*>(this))) return "None";
    std::string name = GetName();
    int depth = 0;
    for (UObject *outer = OuterPrivate; outer && Tools::IsPtrValid(outer) && depth < 20; outer = outer->OuterPrivate, depth++)
    {
        name = outer->GetName() + "." + name;
    }
    return (ClassPrivate && Tools::IsPtrValid(ClassPrivate) ? ClassPrivate->GetName() : "Class") + " " + name;
}

std::string UObject::GetCppName() const
{
    return GetName();
}

bool UObject::IsA(UClass *cmp) const
{
    if (!cmp || !ClassPrivate) return false;
    if (!Tools::IsPtrValid(cmp) || !Tools::IsPtrValid(ClassPrivate)) return false;
    if (!Tools::IsReadable(ClassPrivate, sizeof(UClass))) return false;

    UStruct *super = ClassPrivate;
    int depth = 0;
    while (super != nullptr && depth < 64)
    {
        if (super == cmp) return true;
        if (!Tools::IsPtrValid(super)) break;
        if (!Tools::IsReadable(super, sizeof(UStruct))) break;

        UStruct* nextSuper = super->SuperStruct;
        if (nextSuper && !Tools::IsPtrValid(nextSuper)) break;
        super = nextSuper;
        depth++;
    }
    return false;
}

void UObject::ProcessEvent(UFunction *function, void *parms)
{
    if (!function || !Tools::IsPtrValid(function) || !Tools::IsPtrValid(this)) return;

    if (orig_ProcessEvent)
    {
        orig_ProcessEvent(this, function, parms);
        return;
    }

    // Direct invocation via ProcessEventAddr / VTable is unsafe across threads
    // (Render thread / GLES vs GameThread) and disabled to guarantee zero SIGSEGV.
}

UClass *UObject::StaticClass() { return nullptr; }
UClass *UField::StaticClass() { return nullptr; }
UClass *UStruct::StaticClass() { return nullptr; }
UClass *UClass::StaticClass() { return nullptr; }
UClass *UFunction::StaticClass() { return nullptr; }

int32_t UStruct::FindPropertyOffset(const char* propName) const
{
    if (!propName || !*propName) return -1;
    for (const UStruct* curr = this; curr && Tools::IsPtrValid(const_cast<UStruct*>(curr)); curr = curr->SuperStruct)
    {
        uintptr_t prop = reinterpret_cast<uintptr_t>(curr->ChildProperties);
        while (prop && Tools::IsPtrValid(reinterpret_cast<void*>(prop)))
        {
            FName* pName = reinterpret_cast<FName*>(prop + UEOffsets::FField::NamePrivate);
            if (pName && pName->ComparisonIndex > 0 && pName->ComparisonIndex < 2000000)
            {
                std::string name = pName->GetName();
                if (strcasecmp(name.c_str(), propName) == 0)
                {
                    return *reinterpret_cast<int32_t*>(prop + UEOffsets::FProperty::Offset_Internal);
                }
            }
            prop = *reinterpret_cast<uintptr_t*>(prop + UEOffsets::FField::Next);
        }
    }
    return -1;
}

} // namespace SDK
