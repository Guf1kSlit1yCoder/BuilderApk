#pragma once
// ──────────────────────────────────────────────────────────────────────────────
//  Crypto.h — self-contained AES-256-CTR + HMAC-SHA256 (encrypt-then-MAC).
//
//  Used to encrypt the on-disk config so nothing readable is written to storage,
//  bound to the device via a key derived from ANDROID_ID. No dependency on
//  libking.so / OpenSSL — same approach as the rest of the project (MD5/SHA256/RSA
//  are all hand-rolled), so there is no fragile dlsym into a third-party lib.
//
//  Blob layout:  [16-byte nonce][ciphertext][32-byte HMAC tag]
//  Key material (32 bytes) is split into encKey = SHA256(key|0x01) and
//  macKey = SHA256(key|0x02).
// ──────────────────────────────────────────────────────────────────────────────
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <string>
#include "Sha256.h"

namespace AntiCrack {

// ── AES-256 (forward only; CTR needs just the encrypt direction) ───────────────
namespace _aes {
    static const uint8_t SBOX[256] = {
        0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
        0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
        0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
        0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
        0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
        0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
        0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
        0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
        0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
        0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
        0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
        0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
        0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
        0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
        0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
        0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
    };
    static inline uint8_t xtime(uint8_t x) { return (uint8_t)((x << 1) ^ ((x >> 7) * 0x1b)); }

    struct Ctx { uint8_t rk[240]; }; // 15 round keys * 16

    static void KeyExpand(Ctx& c, const uint8_t key[32]) {
        memcpy(c.rk, key, 32);
        uint8_t rcon = 1;
        for (int i = 8; i < 60; ++i) {
            uint8_t t[4];
            memcpy(t, &c.rk[(i - 1) * 4], 4);
            if (i % 8 == 0) {
                uint8_t tmp = t[0]; t[0] = SBOX[t[1]] ^ rcon; t[1] = SBOX[t[2]];
                t[2] = SBOX[t[3]]; t[3] = SBOX[tmp];
                rcon = xtime(rcon);
            } else if (i % 8 == 4) {
                for (int j = 0; j < 4; ++j) t[j] = SBOX[t[j]];
            }
            for (int j = 0; j < 4; ++j) c.rk[i * 4 + j] = c.rk[(i - 8) * 4 + j] ^ t[j];
        }
    }

    static void EncryptBlock(const Ctx& c, const uint8_t in[16], uint8_t out[16]) {
        uint8_t s[16]; memcpy(s, in, 16);
        for (int i = 0; i < 16; ++i) s[i] ^= c.rk[i];
        for (int round = 1; round <= 14; ++round) {
            for (int i = 0; i < 16; ++i) s[i] = SBOX[s[i]];
            uint8_t t;
            t = s[1]; s[1] = s[5]; s[5] = s[9]; s[9] = s[13]; s[13] = t;
            t = s[2]; s[2] = s[10]; s[10] = t; t = s[6]; s[6] = s[14]; s[14] = t;
            t = s[15]; s[15] = s[11]; s[11] = s[7]; s[7] = s[3]; s[3] = t;
            if (round != 14) {
                for (int col = 0; col < 4; ++col) {
                    uint8_t* p = &s[col * 4];
                    uint8_t a0 = p[0], a1 = p[1], a2 = p[2], a3 = p[3];
                    uint8_t x = a0 ^ a1 ^ a2 ^ a3;
                    p[0] ^= x ^ xtime(a0 ^ a1);
                    p[1] ^= x ^ xtime(a1 ^ a2);
                    p[2] ^= x ^ xtime(a2 ^ a3);
                    p[3] ^= x ^ xtime(a3 ^ a0);
                }
            }
            for (int i = 0; i < 16; ++i) s[i] ^= c.rk[round * 16 + i];
        }
        memcpy(out, s, 16);
    }

    // AES-256-CTR: in-place XOR of `data` with the keystream. nonce = 16-byte IV.
    static void CTR(const uint8_t key[32], const uint8_t nonce[16],
                    uint8_t* data, size_t len) {
        Ctx c; KeyExpand(c, key);
        uint8_t ctr[16]; memcpy(ctr, nonce, 16);
        uint8_t ks[16];
        for (size_t off = 0; off < len; off += 16) {
            EncryptBlock(c, ctr, ks);
            size_t n = (len - off < 16) ? (len - off) : 16;
            for (size_t i = 0; i < n; ++i) data[off + i] ^= ks[i];
            for (int i = 15; i >= 0; --i) { if (++ctr[i]) break; } // ++ counter (big-endian)
        }
    }
} // namespace _aes

// ── HMAC-SHA256 ────────────────────────────────────────────────────────────────
inline void HmacSha256(const uint8_t* key, size_t keyLen,
                       const uint8_t* msg, size_t msgLen, uint8_t out[32]) {
    uint8_t k[64] = {0};
    if (keyLen > 64) { Sha256::Hash(key, keyLen, k); } else { memcpy(k, key, keyLen); }
    uint8_t ipad[64], opad[64];
    for (int i = 0; i < 64; ++i) { ipad[i] = k[i] ^ 0x36; opad[i] = k[i] ^ 0x5c; }
    uint8_t inner[32];
    { Sha256 h; h.Update(ipad, 64); h.Update(msg, msgLen); h.Final(inner); }
    { Sha256 h; h.Update(opad, 64); h.Update(inner, 32); h.Final(out); }
}

// Derive the 32-byte config key from device material: SHA256(androidId | salt).
inline void DeriveConfigKey(const std::string& androidId, uint8_t out[32]) {
    Sha256 h;
    h.Update(androidId.data(), androidId.size());
    static const uint8_t salt[] = { 0x41,0x72,0x6e,0x43,0x66,0x67,0x5f,0x76,0x31,0x9e,0x3b,0x7a };
    h.Update(salt, sizeof(salt));
    h.Final(out);
}

// Encrypt-then-MAC. Returns blob = nonce(16) | ciphertext | tag(32).
inline std::string SealConfig(const std::string& plain, const uint8_t key[32]) {
    uint8_t encKey[32], macKey[32];
    { Sha256 h; h.Update(key, 32); uint8_t b = 0x01; h.Update(&b, 1); h.Final(encKey); }
    { Sha256 h; h.Update(key, 32); uint8_t b = 0x02; h.Update(&b, 1); h.Final(macKey); }

    uint8_t nonce[16];
    { // nonce from SHA256(plain|key) truncated — deterministic but key-bound; fine for a local config
        Sha256 h; h.Update(plain.data(), plain.size()); h.Update(key, 32);
        uint8_t d[32]; h.Final(d); memcpy(nonce, d, 16);
    }

    std::string ct = plain;
    _aes::CTR(encKey, nonce, (uint8_t*)ct.data(), ct.size());

    std::string blob;
    blob.append((const char*)nonce, 16);
    blob.append(ct);
    uint8_t tag[32];
    HmacSha256(macKey, 32, (const uint8_t*)blob.data(), blob.size(), tag);
    blob.append((const char*)tag, 32);
    return blob;
}

// Verify tag + decrypt. Returns false (and leaves `out` empty) on tamper/wrong key.
inline bool OpenConfig(const std::string& blob, const uint8_t key[32], std::string& out) {
    out.clear();
    if (blob.size() < 16 + 32) return false;
    uint8_t encKey[32], macKey[32];
    { Sha256 h; h.Update(key, 32); uint8_t b = 0x01; h.Update(&b, 1); h.Final(encKey); }
    { Sha256 h; h.Update(key, 32); uint8_t b = 0x02; h.Update(&b, 1); h.Final(macKey); }

    const size_t bodyLen = blob.size() - 32;
    uint8_t tag[32];
    HmacSha256(macKey, 32, (const uint8_t*)blob.data(), bodyLen, tag);
    uint8_t diff = 0;
    for (int i = 0; i < 32; ++i) diff |= (uint8_t)(tag[i] ^ (uint8_t)blob[bodyLen + i]);
    if (diff != 0) return false; // tampered / wrong device key

    uint8_t nonce[16]; memcpy(nonce, blob.data(), 16);
    std::string ct = blob.substr(16, bodyLen - 16);
    _aes::CTR(encKey, nonce, (uint8_t*)ct.data(), ct.size());
    out = ct;
    return true;
}

} // namespace AntiCrack
