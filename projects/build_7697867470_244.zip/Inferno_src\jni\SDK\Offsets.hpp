#pragma once
#include <cstdint>

namespace UEOffsets
{

namespace Config
{
    constexpr bool isUsingCasePreservingName = false;
    constexpr bool IsUsingFNamePool = true;
    constexpr bool isUsingOutlineNumberName = false;
}

namespace FName
{
    constexpr uintptr_t ComparisonIndex = 0x0;
    constexpr uintptr_t Number = 0x4;
    constexpr uintptr_t DisplayIndex = 0x0;
    constexpr uintptr_t Size = 0x8;
}

namespace FNameEntry
{
    constexpr uintptr_t Index = 0x0;
    constexpr uintptr_t Name = 0x0;
}

namespace FNamePool
{
    constexpr int32_t Stride = 2;
    constexpr int32_t BlocksBit = 16;
    constexpr uintptr_t BlocksOff = 0x48;
}

namespace FNamePoolEntry
{
    constexpr uintptr_t Header = 0x0;
}

namespace FUObjectArray
{
    constexpr uintptr_t ObjObjects = 0x40;
}

namespace TUObjectArray
{
    constexpr uintptr_t Objects = 0x0;
    constexpr uintptr_t NumElements = 0x14;
    constexpr uintptr_t NumElementsPerChunk = 0x10000;
}

namespace FUObjectItem
{
    constexpr uintptr_t Object = 0x0;
    constexpr uintptr_t Size = 0x18;
}

namespace UObject
{
    constexpr uintptr_t ObjectFlags = 0x8;
    constexpr uintptr_t InternalIndex = 0xc;
    constexpr uintptr_t ClassPrivate = 0x10;
    constexpr uintptr_t NamePrivate = 0x18;
    constexpr uintptr_t OuterPrivate = 0x20;
}

namespace UField
{
    constexpr uintptr_t Next = 0x28;
}

namespace UEnum
{
    constexpr uintptr_t Names = 0x40;
}

namespace UStruct
{
    constexpr uintptr_t SuperStruct = 0x40;
    constexpr uintptr_t Children = 0x48;
    constexpr uintptr_t ChildProperties = 0x50;
    constexpr uintptr_t PropertiesSize = 0x58;
}

namespace UFunction
{
    constexpr uintptr_t EFunctionFlags = 0xb0;
    constexpr uintptr_t NumParams = 0xb4;
    constexpr uintptr_t ParamSize = 0xb6;
    constexpr uintptr_t Func = 0xd8;
}

namespace FField
{
    constexpr uintptr_t ClassPrivate = 0x8;
    constexpr uintptr_t Next = 0x20;
    constexpr uintptr_t NamePrivate = 0x28;
    constexpr uintptr_t FlagsPrivate = 0x40;
}

namespace FProperty
{
    constexpr uintptr_t ArrayDim = 0x34;
    constexpr uintptr_t ElementSize = 0x38;
    constexpr uintptr_t PropertyFlags = 0x40;
    constexpr uintptr_t Offset_Internal = 0x4c;
    constexpr uintptr_t Size = 0x78;
}

} // namespace UEOffsets

namespace UEPointers
{
    // ── MASKED (Э4) ──────────────────────────────────────────────────────────
    // The real library-relative pointers are NOT stored here. Each value below is
    // real ^ SplitMix64(unlockSecret). The real offset is recovered at runtime by
    // SDK::UnmaskPtr() only after login, using the server-authenticated `uk`
    // (unlockSecret). A static dump of the .so sees these scrambled 64-bit values,
    // not the offsets; a login bypass never gets the secret, so the cheat reads
    // garbage instead of unlocking.
    //
    // ROTATION: to kill a leaked offset set, change `unlockSecret` in Connect.php
    // AND regenerate these five constants = real ^ SplitMix64(newSecret).
    // Current secret: 0x5a3c9e17  ->  mask64 = 0xaf9f11728c0e4bb4
    constexpr uintptr_t Names        = 0xaf9f11728338f574ULL; // real 0x0f36bec0
    constexpr uintptr_t UObjectArray = 0xaf9f11728336f604ULL; // real 0x0f38bdb0
    constexpr uintptr_t ObjObjects   = 0xaf9f11728336f644ULL; // real 0x0f38bdf0
    constexpr uintptr_t Engine       = 0xaf9f117283537a8cULL; // real 0x0f5d3138
    constexpr uintptr_t World = 0x0;
    constexpr uintptr_t ProcessEvent = 0xaf9f11728a4a9094ULL; // real 0x0644db20
    constexpr int32_t ProcessEventIndex = 71;
}

// ════════════════════════════════════════════════════════════════════════════
// GAME OFFSETS (Game-specific & UE actor/component offsets)
// When the game updates, update the values in this file!
// ════════════════════════════════════════════════════════════════════════════
namespace Offsets
{
    // ==================== AActor ====================
    namespace Actor
    {
        constexpr uintptr_t NetFlags             = 0x0068; // bit 5 (0x20): bHidden, bit 6 (0x40): bTearOff
        constexpr uintptr_t ActorFlags           = 0x006C; // bit 3 (0x08): bActorIsBeingDestroyed
        constexpr uintptr_t RootComponent        = 0x0158;
        constexpr uintptr_t OwnedComponentMap    = 0x0220;
        constexpr uintptr_t InstanceComponents   = 0x02D0;
        constexpr uintptr_t WeaponCmpCacheArray  = 0x0AF8; // 19 elements
    }

    // ==================== APawn ====================
    namespace Pawn
    {
        constexpr uintptr_t PlayerState          = 0x0330;
        constexpr uintptr_t Controller           = 0x0348;
    }

    // ==================== ACharacter ====================
    namespace Character
    {
        constexpr uintptr_t Mesh                 = 0x0370;
        constexpr uintptr_t CharacterMovement    = 0x0378;
        constexpr uintptr_t CapsuleComponent     = 0x0380;
    }

    // ==================== UCapsuleComponent ====================
    namespace CapsuleComponent
    {
        constexpr uintptr_t CapsuleHalfHeight    = 0x0690;
        constexpr uintptr_t CapsuleRadius        = 0x0694;
    }

    // ==================== USceneComponent ====================
    namespace SceneComponent
    {
        constexpr uintptr_t AttachParent         = 0x00F0;
        constexpr uintptr_t AttachSocketName     = 0x00F8;
        constexpr uintptr_t AttachChildren       = 0x0100;
        constexpr uintptr_t RelativeLocation     = 0x0154;
        constexpr uintptr_t RelativeRotation     = 0x0160;
        constexpr uintptr_t RelativeScale3D      = 0x016C;
        constexpr uintptr_t ComponentVelocity    = 0x0178;
        constexpr uintptr_t Flags185             = 0x0185; // bit 3 (0x08): bHiddenInGame
        constexpr uintptr_t ComponentToWorld     = 0x0190;
    }

    // ==================== USkeletalMeshComponent ====================
    namespace SkeletalMeshComponent
    {
        constexpr uintptr_t SkeletalMesh         = 0x06D0;
        constexpr uintptr_t MasterPoseComponent  = 0x06D8;
        constexpr uintptr_t LastSubmitTime       = 0x0678;
        constexpr uintptr_t LastRenderTimeOnScreen = 0x067C;
        constexpr uintptr_t Flags858             = 0x0858; // bit 0 (0x01): bRecentlyRendered
        constexpr uintptr_t CachedComponentSpaceTransforms = 0x09B8;

        constexpr uintptr_t RenderTimestampOffsets[] = { 0x067C, 0x0678 };
    }

    // ==================== ASGCharacter ====================
    namespace SGCharacter
    {
        constexpr uintptr_t CharacterCameraComponent = 0x1588;
        constexpr uintptr_t CurrentViewerPC          = 0x15A8;
        constexpr uintptr_t gid                      = 0x15E0;
        constexpr uintptr_t FactionType              = 0x15E8;
        constexpr uintptr_t CharacterSex             = 0x15E9;
        constexpr uintptr_t PlayerInfo               = 0x1600;
        constexpr uintptr_t PlayerInfo_PlayerState   = 0x1610; // FSGPlayerInfo.PlayerState
        constexpr uintptr_t PlayerInfo_Character     = 0x1618; // FSGPlayerInfo.Character
        constexpr uintptr_t SGCharacterMovement      = 0x1640;
        constexpr uintptr_t AbilitySystemComponent   = 0x1698;
        constexpr uintptr_t DesiredFOV               = 0x1B50;
        constexpr uintptr_t CharacterFastRepProxy    = 0x1BA0;
        constexpr uintptr_t CharacterProxy           = 0x1BA8;

        constexpr uintptr_t WeaponManagerOffsets[]   = { 0x1838, 0x19A0, 0x1F68 };
    }

    // ==================== ASGCharacterFastRepProxy ====================
    namespace FastRepProxy
    {
        constexpr uintptr_t BindingCharacter                    = 0x0300;
        constexpr uintptr_t Acceleration                        = 0x0308;
        constexpr uintptr_t PredictStopLocation                 = 0x0314;
        constexpr uintptr_t CurrentSlideAlongWeight             = 0x0320;
        constexpr uintptr_t VehicleCameraRelativeRotation       = 0x0324;
        constexpr uintptr_t LinearVelocity                      = 0x0330;
        constexpr uintptr_t AngularVelocity                     = 0x033C;
        constexpr uintptr_t Location                            = 0x0348;
        constexpr uintptr_t Rotation                            = 0x0354;
        constexpr uintptr_t RepPhysicsFlags                     = 0x0360;
        constexpr uintptr_t LocationQuantizationLevel           = 0x0361;
        constexpr uintptr_t VelocityQuantizationLevel           = 0x0362;
        constexpr uintptr_t RotationQuantizationLevel           = 0x0363;
        constexpr uintptr_t RepVersionIndex                     = 0x0364;
        constexpr uintptr_t ReplicatedServerLastTransformUpdateTimeStamp = 0x0368;
        constexpr uintptr_t PlayerViewInfo                      = 0x036C;
        constexpr uintptr_t ReplicatedMovementMode              = 0x0370;
        constexpr uintptr_t WeaponLeanAimTypeInfo               = 0x0374;
        constexpr uintptr_t MovementFlags                       = 0x037C;
    }

    // ==================== ASGAICharacter ====================
    namespace SGAICharacter
    {
        constexpr uintptr_t AITeamIndex          = 0x1E58;
        constexpr uintptr_t MasterPlayerGID      = 0x1E60;
        constexpr uintptr_t AIUID                = 0x1E68;
        constexpr uintptr_t PathGroupID          = 0x1E70;
        constexpr uintptr_t AILevel              = 0x1E80;
        constexpr uintptr_t AIName               = 0x1FD0;
    }

    // ==================== APlayerState ====================
    namespace PlayerState
    {
        constexpr uintptr_t Score                = 0x0300;
        constexpr uintptr_t PlayerId             = 0x0304;
        constexpr uintptr_t ActivePawn           = 0x0360;
        constexpr uintptr_t PlayerNamePrivate    = 0x0440;
    }

    // ==================== ASGPlayerState ====================
    namespace SGPlayerState
    {
        constexpr uintptr_t AltTeamIndex         = 0x0518;
        constexpr uintptr_t gid                  = 0x0550;
        constexpr uintptr_t TeamIndex            = 0x05A0;
        constexpr uintptr_t TeamName             = 0x05A8;
        constexpr uintptr_t ZonePlayerName       = 0x0668;
    }

    // ==================== AController ====================
    namespace Controller
    {
        constexpr uintptr_t PlayerState          = 0x0308;
        constexpr uintptr_t Pawn                 = 0x0330;
        constexpr uintptr_t Character            = 0x0340;
        constexpr uintptr_t TransformComponent   = 0x0348;
        constexpr uintptr_t ControlRotation      = 0x0368;
    }

    // ==================== APlayerController ====================
    namespace PlayerController
    {
        constexpr uintptr_t Player               = 0x0378;
        constexpr uintptr_t AcknowledgedPawn     = 0x0380;
        constexpr uintptr_t ControllingDirTrackInst = 0x0388;
        constexpr uintptr_t MyHUD                = 0x0390;
        constexpr uintptr_t PlayerCameraManager  = 0x0398;
        constexpr uintptr_t bIsLocalPlayerController = 0x064C;
    }

    // ==================== USGPlayerInput ====================
    namespace SGPlayerInput
    {
        constexpr uintptr_t LeftFireBtnPressed       = 0x03E0;
        constexpr uintptr_t RightFireBtnPressed      = 0x03E1;
        constexpr uintptr_t bQuickMeleeFireBtnPressed = 0x03E2;
    }

    // ==================== ASGPlayerController ====================
    namespace SGPlayerController
    {
        constexpr uintptr_t SGPlayerInput        = 0x0700;
        constexpr uintptr_t ControlledCharacter  = 0x0990;
    }

    // ==================== APlayerCameraManager ====================
    namespace PlayerCameraManager
    {
        constexpr uintptr_t PCOwner              = 0x0300;
        constexpr uintptr_t DefaultFOV           = 0x0318;
        constexpr uintptr_t CameraCache          = 0x0370;
        constexpr uintptr_t CameraCachePOV       = 0x0380; // 0x370 + 0x10
        constexpr uintptr_t CameraCachePOV_Rot   = 0x038C;
        constexpr uintptr_t CameraCachePOV_FOV   = 0x0398;
        constexpr uintptr_t CameraCachePrivate   = 0x1EC0;
    }

    // ==================== FCameraView (MinimalViewInfo) ====================
    namespace CameraView
    {
        constexpr uintptr_t Location             = 0x0000;
        constexpr uintptr_t Rotation             = 0x000C;
        constexpr uintptr_t FOV                  = 0x0018;
        constexpr uintptr_t DesiredFOV           = 0x001C;
        constexpr uintptr_t AspectRatio          = 0x0030;
        constexpr uintptr_t ProjectionFlags      = 0x0034;
        constexpr uintptr_t ProjectionMode       = 0x0035;
        constexpr uintptr_t OffCenterProjectionOffset = 0x0660;
        constexpr uintptr_t FOVMode              = 0x0668;
    }

    // ==================== UWorld ====================
    namespace World
    {
        constexpr uintptr_t PersistentLevel      = 0x0030;
        constexpr uintptr_t StreamingLevelsPad   = 0x0088;
        constexpr uintptr_t Levels               = 0x0138;
        constexpr uintptr_t OwningGameInstance   = 0x0180;

        constexpr uintptr_t TimeSecondsOffsets[] = { 0x01AC, 0x01A8, 0x01B0 };
    }

    // ==================== ULevel ====================
    namespace Level
    {
        constexpr uintptr_t Actors               = 0x0098;
        constexpr uintptr_t OwningWorld          = 0x00B8;
        constexpr uintptr_t ActorCluster         = 0x00D8;
    }

    // ==================== UGameViewportClient ====================
    namespace GameViewportClient
    {
        constexpr uintptr_t World                = 0x0070;
        constexpr uintptr_t GameInstance         = 0x0078;
    }

    // ==================== UGameInstance ====================
    namespace GameInstance
    {
        constexpr uintptr_t LocalPlayers         = 0x0038;
    }

    // ==================== UEngine ====================
    namespace Engine
    {
        constexpr uintptr_t GameViewport         = 0x0788;
    }

    // ==================== Health & Attributes ====================
    namespace Health
    {
        // Attribute Sets
        constexpr uintptr_t Health_Current       = 0x0044; // USGActorHealthAttributeSet::Health / Endurance parts base
        constexpr uintptr_t Health_Max           = 0x0048; // USGActorHealthAttributeSet::HealthMax
        constexpr uintptr_t DBNO_Current         = 0x0054; // USGCharacterHealthAttributeSet::DBNOHealth
        constexpr uintptr_t DBNO_Max             = 0x0058; // USGCharacterHealthAttributeSet::DBNOHealthMax
        constexpr uintptr_t Normalized           = 0x0068; // AI health normalized (0.0..1.0)

        // Health Components
        constexpr uintptr_t ActorHealthComp_AttributeSet = 0x00E0; // USGActorHealthComponent::AttributeSetClass
        constexpr uintptr_t AbilitySystem_SpawnedAttributes = 0x0170; // UAbilitySystemComponent::SpawnedAttributes
        constexpr uintptr_t EnduranceComp_Attribute     = 0x0A98; // USGCharacterEnduranceComponent
        constexpr uintptr_t DBNOComp_bIsDBNO             = 0x01A8; // USGCharacterDBNOComponent::bIsDBNO
        constexpr uintptr_t DeathComp_psDied             = 0x0860; // SGCharacterDeathComponent::psDied
        constexpr uintptr_t DeathComp_box                = 0x0250; // SGCharacterDeathComponent::box
    }

    // ==================== Weapons & Inventory ====================
    namespace Weapon
    {
        constexpr uintptr_t WeaponManager_CurrentWeapon       = 0x0130;
        constexpr uintptr_t WeaponManager_LastUsedWeapon      = 0x0470;
        constexpr uintptr_t WeaponTrace_CurrentWeapon         = 0x0410;
        constexpr uintptr_t Inventory_WeaponContainer         = 0x0810;
        constexpr uintptr_t Container_MaxStackCount           = 0x0118;
        constexpr uintptr_t Container_ContainDataList         = 0x01D0;
        constexpr uintptr_t Container_ContainDataListForRep   = 0x01E0;
        constexpr uintptr_t Assemble_CachedMagazine           = 0x0270;
        constexpr uintptr_t Assemble_ClientCachedMagazine     = 0x0278;
        constexpr uintptr_t Assemble_AssembledInventoryList   = 0x01E8;
        constexpr uintptr_t Bore_CurShotBullet                = 0x0120;
        constexpr uintptr_t Ammo_IsReloading                  = 0x0118;
        constexpr uintptr_t Ammo_FallbackClip                 = 0x010C;
        constexpr uintptr_t Ammo_FallbackMax                  = 0x00E8;
    }

    // ==================== Loot Containers & Boxes ====================
    namespace LootBox
    {
        constexpr uintptr_t CurFSMState              = 0x0988; // AUALockLootContainer::CurFSMState (FString)
        constexpr uintptr_t SpendUseProgress         = 0x08B8; // AUALockLootContainer::SpendUseProgress (float)
        constexpr uintptr_t Perf_RotateAnimState     = 0x0170; // SGInventoryContainerInteractPerformanceComponent
        constexpr uintptr_t Perf_TranslateAnimState  = 0x01BC;
        constexpr uintptr_t Perf_IsBySearch          = 0x01BD;
        constexpr uintptr_t Search_IsSearching       = 0x0128; // SGInventoryContainerSearchingComponent
        constexpr uintptr_t Search_SearchChars       = 0x0108; // RoughSearchedFinishedCharacterList
        constexpr uintptr_t Search_SearchActors      = 0x0118; // RoughSearchedFinishedActorList
        constexpr uintptr_t Mgr_ContainerOccupyState = 0x0153; // SGInventoryContainerMgrComponent (3 = Empty)
        constexpr uintptr_t Common_IsSearched        = 0x0478; // SGInventoryCommonDataComponent (bool)
    }
}

namespace GameOffsets = Offsets;
