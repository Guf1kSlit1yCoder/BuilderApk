#define IMGUI_DEFINE_MATH_OPERATORS
#pragma once

#include <string>
#include <cmath>
#include <iostream>
#include <cstdint>
#include <cstdlib>
#include <map>
#include <algorithm>
#include <random>
#include <vector>

#if __has_include("imgui.h")
#include "imgui.h"
#include "imgui_internal.h"
#elif __has_include("imgui/imgui.h")
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"
#elif __has_include("Files/imgui/imgui.h")
#include "Files/imgui/imgui.h"
#include "Files/imgui/imgui_internal.h"
#else
#include "../imgui/imgui.h"
#include "../imgui/imgui_internal.h"
#endif

#include "vandal_main.h"
inline bool getRandomBool(double probability = 0.5) {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::bernoulli_distribution dist(probability);
    return dist(gen);
}


using namespace ImGui;

namespace particle {

    struct Particle {
        float posX, posY, velocityX, velocityY, alpha;
        int lifespan, seed, flag, delay;
        float alphaTimer;
        Particle() : posX(0), posY(0), velocityX(0), velocityY(0), alpha(0.f), lifespan(0), seed(0), flag(0), delay(0), alphaTimer(0.f) {}
    };

    static int PARTICLE_COUT = 35;
    const int MAX_PARTICLES = 6048;
    inline Particle particles[MAX_PARTICLES];

    inline void AddParticle(ImVec2 origin, ImVec2 size, float flag) {
        Particle newParticle;
        newParticle.posX = origin.x + size.x / 2;
        newParticle.posY = origin.y;
        newParticle.velocityX = ((float)rand() / 32767) * 1.5f - 0.75f;
        newParticle.velocityY = ((float)rand() / 32767) * 0.5f - (flag ? 2.f : 0.5f);

        newParticle.lifespan = rand() % (flag ? 250 : 299);
        newParticle.seed = rand();
        newParticle.flag = static_cast<int>(flag);
        newParticle.alpha = 0.f;
        newParticle.alphaTimer = 0.f;

        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (particles[i].lifespan == 0) {
                particles[i] = newParticle;
                break;
            }
        }
    }

    inline void RenderEffects(ImDrawList* drawList, ImVec2 renderSize, float timeOffset) {
        int activeParticles = 0;
        for (int i = 0; i < MAX_PARTICLES; i++) {
            Particle& particle = particles[i];
            if (particle.lifespan) {
                if (particle.delay) {
                    particle.delay--;
                }
                else {
                    particle.posX += particle.velocityX;
                    particle.posY += particle.velocityY;
                    particle.velocityY += ImGui::GetIO().DeltaTime;
                    particle.lifespan -= (particle.velocityY > 0) ? 1 : 0;

                    particle.alpha = ImLerp(0.f, 1.f, ImMin(1.f, particle.alphaTimer)); // Быстрое увеличение до 1
                    if (particle.alphaTimer >= 1.f) {
                        particle.alpha = ImLerp(1.f, 0.f, ImMax(0.f, particle.alphaTimer - 1.f)); // Плавное уменьшение до 0
                    }
                    particle.alphaTimer += 0.01f;

                    ImVec2 points[4];
                    float scale = (static_cast<float>(rand()) / RAND_MAX * 1.5f + 0.1f) * (particle.flag + 1);

                    float noise = (timeOffset * (particle.lifespan < 0 ? 0 : 1)) + (i * static_cast<float>(rand()) / RAND_MAX * 2.5 - 1.5);
                    float sinAngle = sin(noise) * scale;
                    float cosAngle = cos(noise) * scale;

                    for (int j = 0; j < 4; j++) {
                        float angle = 2 * IM_PI * j / 4 + (static_cast<float>(rand()) / RAND_MAX - 0.5) * IM_PI / 8;
                        points[j].x = particle.posX - cosAngle * cos(angle) - sinAngle * sin(angle);
                        points[j].y = particle.posY + sinAngle * cos(angle) + cosAngle * sin(angle);
                    }

                    int red = 128 + (rand() % 128);
                    int green = 128 + (rand() % 128);
                    int blue = 128 + (rand() % 128);

                    drawList->AddShadowConvexPoly(points, 4, utils::GetColorWithAlpha(i % 2 == 0 ? c::anim::active : c::dark_color, particle.alpha), 35.f, ImVec2(0, 0));
                    drawList->AddConvexPolyFilled(points, 4, utils::GetColorWithAlpha(i % 2 == 0 ? c::anim::active : c::dark_color, particle.alpha));

                    if (!particle.lifespan && particle.flag) {

                    }
                }
                if (particle.flag)
                    activeParticles++;
            }
        }
    }
}


inline float ImDegToRad(float degrees)
{
    return degrees * (IM_PI / 180.0f);
}

enum fade_direction : int
{
    vertically,
    horizontally,
    diagonally,
    diagonally_reversed,
};

inline float sample_flow_gradient_t(float t)
{
    t = t - floorf(t);
    if (t < 0.5f)
        return t * 2.f;
    return 1.f - (t - 0.5f) * 2.f;
}

// Улучшенная версия для плавной анимации
inline float sample_flow_gradient_t_smooth(float t)
{
    t = t - floorf(t);
    // Используем синусоидальную волну для более плавных переходов
    return 0.5f * sinf(t * IM_PI * 2.0f - IM_PI / 2.0f) + 0.5f;
}

// Волнообразная анимация с несколькими гармониками
inline float sample_flow_gradient_t_wave(float t)
{
    t = t - floorf(t);
    // Комбинация нескольких синусоид для сложной волны
    float wave1 = sinf(t * IM_PI * 2.0f) * 0.4f;
    float wave2 = sinf(t * IM_PI * 4.0f + 0.5f) * 0.3f;
    float wave3 = sinf(t * IM_PI * 6.0f + 1.0f) * 0.2f;
    return 0.5f + wave1 + wave2 + wave3;
}

// Плавный градиент с эффектом пульсации
inline float sample_flow_gradient_t_pulse(float t)
{
    t = t - floorf(t);
    // Квадратичная функция для плавного ускорения/замедления
    if (t < 0.5f)
        return 2.0f * t * t;
    t = 1.0f - t;
    return 2.0f * t * t;
}

inline void set_linear_color_flow(ImDrawList* draw_list, int vert_start_idx, int vert_end_idx, ImVec2 gradient_p0, ImVec2 gradient_p1, ImU32 col0, ImU32 col1, float phase)
{
    ImVec2 gradient_extent = gradient_p1 - gradient_p0;
    float gradient_inv_length2 = 1.0f / ImLengthSqr(gradient_extent);
    ImDrawVert* vert_start = draw_list->VtxBuffer.Data + vert_start_idx;
    ImDrawVert* vert_end = draw_list->VtxBuffer.Data + vert_end_idx;
    const int col0_r = (int)(col0 >> IM_COL32_R_SHIFT) & 0xFF;
    const int col0_g = (int)(col0 >> IM_COL32_G_SHIFT) & 0xFF;
    const int col0_b = (int)(col0 >> IM_COL32_B_SHIFT) & 0xFF;
    const int col_delta_r = ((int)(col1 >> IM_COL32_R_SHIFT) & 0xFF) - col0_r;
    const int col_delta_g = ((int)(col1 >> IM_COL32_G_SHIFT) & 0xFF) - col0_g;
    const int col_delta_b = ((int)(col1 >> IM_COL32_B_SHIFT) & 0xFF) - col0_b;

    for (ImDrawVert* vert = vert_start; vert < vert_end; vert++)
    {
        float d = ImDot(vert->pos - gradient_p0, gradient_extent);
        float t = d * gradient_inv_length2 + phase;
        float blend = sample_flow_gradient_t(t);
        int r = (int)(col0_r + col_delta_r * blend);
        int g = (int)(col0_g + col_delta_g * blend);
        int b = (int)(col0_b + col_delta_b * blend);
        vert->col = (r << IM_COL32_R_SHIFT) | (g << IM_COL32_G_SHIFT) | (b << IM_COL32_B_SHIFT) | (vert->col & IM_COL32_A_MASK);
    }
}

// Улучшенная версия с плавной анимацией
inline void set_linear_color_flow_enhanced(ImDrawList* draw_list, int vert_start_idx, int vert_end_idx, ImVec2 gradient_p0, ImVec2 gradient_p1, ImU32 col0, ImU32 col1, float phase, float animation_type = 0.0f)
{
    ImVec2 gradient_extent = gradient_p1 - gradient_p0;
    float gradient_inv_length2 = 1.0f / ImLengthSqr(gradient_extent);
    ImDrawVert* vert_start = draw_list->VtxBuffer.Data + vert_start_idx;
    ImDrawVert* vert_end = draw_list->VtxBuffer.Data + vert_end_idx;
    const int col0_r = (int)(col0 >> IM_COL32_R_SHIFT) & 0xFF;
    const int col0_g = (int)(col0 >> IM_COL32_G_SHIFT) & 0xFF;
    const int col0_b = (int)(col0 >> IM_COL32_B_SHIFT) & 0xFF;
    const int col_delta_r = ((int)(col1 >> IM_COL32_R_SHIFT) & 0xFF) - col0_r;
    const int col_delta_g = ((int)(col1 >> IM_COL32_G_SHIFT) & 0xFF) - col0_g;
    const int col_delta_b = ((int)(col1 >> IM_COL32_B_SHIFT) & 0xFF) - col0_b;

    // Выбор типа анимации на основе animation_type
    for (ImDrawVert* vert = vert_start; vert < vert_end; vert++)
    {
        float d = ImDot(vert->pos - gradient_p0, gradient_extent);
        float t = d * gradient_inv_length2 + phase;
        
        float blend;
        if (animation_type < 0.33f)
            blend = sample_flow_gradient_t_smooth(t); // Плавная синусоида
        else if (animation_type < 0.66f)
            blend = sample_flow_gradient_t_wave(t);    // Сложная волна
        else
            blend = sample_flow_gradient_t_pulse(t);  // Пульсирующая
        
        int r = (int)(col0_r + col_delta_r * blend);
        int g = (int)(col0_g + col_delta_g * blend);
        int b = (int)(col0_b + col_delta_b * blend);
        vert->col = (r << IM_COL32_R_SHIFT) | (g << IM_COL32_G_SHIFT) | (b << IM_COL32_B_SHIFT) | (vert->col & IM_COL32_A_MASK);
    }
}

inline void set_linear_color(ImDrawList* draw_list, int vert_start_idx, int vert_end_idx, ImVec2 gradient_p0, ImVec2 gradient_p1, ImU32 col0, ImU32 col1, float angle = 0.f)
{
    ImVec2 gradient_extent = gradient_p1 - gradient_p0;

    float cos_angle = cosf(angle);
    float sin_angle = sinf(angle);
    float rotated_x = cos_angle * gradient_extent.x - sin_angle * gradient_extent.y;
    float rotated_y = sin_angle * gradient_extent.x + cos_angle * gradient_extent.y;

    ImVec2 rotated_p1 = gradient_p0 + ImVec2(rotated_x, rotated_y);

    float gradient_inv_length2 = 1.0f / ImLengthSqr(rotated_p1 - gradient_p0);
    ImDrawVert* vert_start = draw_list->VtxBuffer.Data + vert_start_idx;
    ImDrawVert* vert_end = draw_list->VtxBuffer.Data + vert_end_idx;
    const int col0_r = (int)(col0 >> IM_COL32_R_SHIFT) & 0xFF;
    const int col0_g = (int)(col0 >> IM_COL32_G_SHIFT) & 0xFF;
    const int col0_b = (int)(col0 >> IM_COL32_B_SHIFT) & 0xFF;
    const int col_delta_r = ((int)(col1 >> IM_COL32_R_SHIFT) & 0xFF) - col0_r;
    const int col_delta_g = ((int)(col1 >> IM_COL32_G_SHIFT) & 0xFF) - col0_g;
    const int col_delta_b = ((int)(col1 >> IM_COL32_B_SHIFT) & 0xFF) - col0_b;

    for (ImDrawVert* vert = vert_start; vert < vert_end; vert++)
    {
        float d = ImDot(vert->pos - gradient_p0, rotated_p1 - gradient_p0);
        float t = ImClamp(d * gradient_inv_length2, 0.0f, 1.0f);
        int r = (int)(col0_r + col_delta_r * t);
        int g = (int)(col0_g + col_delta_g * t);
        int b = (int)(col0_b + col_delta_b * t);
        vert->col = (r << IM_COL32_R_SHIFT) | (g << IM_COL32_G_SHIFT) | (b << IM_COL32_B_SHIFT) | (vert->col & IM_COL32_A_MASK);
    }
}

inline void fade_rect_filled(ImDrawList* draw, const ImVec2& pos_min, const ImVec2& pos_max, ImU32 col_one, ImU32 col_two, fade_direction direction, float rounding, ImDrawFlags flags, bool filled)
{
    const ImVec2 fade_pos_in = (direction == fade_direction::diagonally_reversed) ? ImVec2(pos_max.x, pos_min.y) : pos_min;

    const ImVec2 fade_pos_out = (direction == fade_direction::vertically) ? ImVec2(pos_min.x, pos_max.y) :
        (direction == fade_direction::horizontally) ? ImVec2(pos_max.x, pos_min.y) :
        (direction == fade_direction::diagonally) ? pos_max :
        (direction == fade_direction::diagonally_reversed) ? ImVec2(pos_min.x, pos_max.y) : ImVec2(0, 0);

    const int vtx_buffer_start = draw->VtxBuffer.Size;
    if (filled)
        draw->AddRectFilled(pos_min, pos_max, ImColor(1.f, 1.f, 1.f, ImColor(col_one).Value.w), rounding, flags);
    else
        draw->AddRect(pos_min, pos_max, ImColor(1.f, 1.f, 1.f, 1.f), rounding, flags);

    const int vtx_buffer_end = draw->VtxBuffer.Size;
    set_linear_color(draw, vtx_buffer_start, vtx_buffer_end, fade_pos_in, fade_pos_out, col_one, col_two);
}

inline void fade_text(ImDrawList* draw, const char* text, ImVec2 pos, ImU32 col_one, ImU32 col_two, float animation_time, ImFont* font = nullptr, float font_size = 0.f)
{
    if (!font)
        font = ImGui::GetFont();
    if (font_size <= 0.f)
        font_size = ImGui::GetFontSize();

    ImVec2 text_size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, text);

    // Получаем позиции начала и конца текста
    ImVec2 gradient_p0 = pos;
    ImVec2 gradient_p1 = pos + ImVec2(text_size.x, 0); // горизонтальный градиент

    int vtx_start = draw->VtxBuffer.Size;

    draw->AddText(font, font_size, pos, IM_COL32_WHITE, text);

    int vtx_end = draw->VtxBuffer.Size;

    float angle = ImDegToRad(animation_time * 360.f);

    set_linear_color(draw, vtx_start, vtx_end, gradient_p0, gradient_p1, col_one, col_two, angle);
}

inline void fade_text_flow(ImDrawList* draw, const char* text, ImVec2 pos, ImU32 col_one, ImU32 col_two, float phase, ImFont* font = nullptr, float font_size = 0.f)
{
    if (!font)
        font = ImGui::GetFont();
    if (font_size <= 0.f)
        font_size = ImGui::GetFontSize();

    ImVec2 text_size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, text);
    ImVec2 gradient_p0 = pos;
    ImVec2 gradient_p1 = pos + ImVec2(text_size.x, text_size.y);

    int vtx_start = draw->VtxBuffer.Size;
    draw->AddText(font, font_size, pos, IM_COL32_WHITE, text);
    int vtx_end = draw->VtxBuffer.Size;

    set_linear_color_flow(draw, vtx_start, vtx_end, gradient_p0, gradient_p1, col_one, col_two, phase);
}

// Глобальная система анимации времени
namespace global_animation {
    static float global_time = 0.0f;
    
    inline void Update() {
        // Используем ImGui::GetTime() для стабильной анимации
        global_time = ImGui::GetTime();
    }
    
    inline float GetTime() {
        return global_time;
    }
    
    inline float GetTimeOffset(ImGuiID id) {
        return global_time + id * 0.05f; // Небольшое смещение для разнообразия
    }
}

// Continuous silky-smooth gradient animation without rotation clamping pauses
inline void fade_text_smooth(ImDrawList* draw, const char* text, ImVec2 pos, ImU32 primary_color, ImU32 secondary_color, ImFont* font = nullptr, float font_size = 0.f)
{
    if (!font)
        font = ImGui::GetFont();
    if (font_size <= 0.f)
        font_size = ImGui::GetFontSize();

    float time = (float)ImGui::GetTime() * 2.2f;
    float phase = (sinf(time) + 1.0f) * 0.5f;

    ImColor col_a = ImLerpColor(primary_color, secondary_color, phase);
    ImColor col_b = ImLerpColor(secondary_color, primary_color, phase);

    ImVec2 text_size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, text);
    float text_w = ImMax(text_size.x, 1.0f);

    int vtx_start = draw->VtxBuffer.Size;
    draw->AddText(font, font_size, pos, IM_COL32_WHITE, text);
    int vtx_end = draw->VtxBuffer.Size;

    set_linear_color(draw, vtx_start, vtx_end, pos, pos + ImVec2(text_w, 0.f), ImGui::GetColorU32(col_a), ImGui::GetColorU32(col_b), 0.f);
}

// Version with ID for unique smooth animation per widget
inline void fade_text_smooth_id(ImDrawList* draw, const char* text, ImVec2 pos, ImU32 primary_color, ImU32 secondary_color, ImGuiID id, ImFont* font = nullptr, float font_size = 0.f)
{
    if (!font)
        font = ImGui::GetFont();
    if (font_size <= 0.f)
        font_size = ImGui::GetFontSize();

    float time = (float)ImGui::GetTime() * 2.2f + (float)(id & 0xFFFF) * 0.12f;
    float phase = (sinf(time) + 1.0f) * 0.5f;

    ImColor col_a = ImLerpColor(primary_color, secondary_color, phase);
    ImColor col_b = ImLerpColor(secondary_color, primary_color, phase);

    ImVec2 text_size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, text);
    float text_w = ImMax(text_size.x, 1.0f);

    int vtx_start = draw->VtxBuffer.Size;
    draw->AddText(font, font_size, pos, IM_COL32_WHITE, text);
    int vtx_end = draw->VtxBuffer.Size;

    set_linear_color(draw, vtx_start, vtx_end, pos, pos + ImVec2(text_w, 0.f), ImGui::GetColorU32(col_a), ImGui::GetColorU32(col_b), 0.f);
}

// Letter-by-letter animated liquid wave gradient (Primary <-> Secondary Accent) matching MIRAGE logo
inline void DrawLetterWaveText(ImDrawList* draw, const char* text, ImVec2 pos, float spacing = 0.0f, float alpha = 1.0f, bool with_shadow = true, ImFont* font = nullptr, float font_size = 0.f)
{
    if (!text || !*text || !draw) return;
    if (!font)
        font = ImGui::GetFont();
    if (font_size <= 0.f)
        font_size = ImGui::GetFontSize();

    // 1. Count UTF-8 glyphs properly without splitting multi-byte sequences (Cyrillic, Arabic, Latin)
    int total_chars = 0;
    for (const char* p = text; *p; ) {
        unsigned char c = (unsigned char)*p;
        int step = 1;
        if ((c & 0x80) == 0) step = 1;
        else if ((c & 0xE0) == 0xC0) step = 2;
        else if ((c & 0xF0) == 0xE0) step = 3;
        else if ((c & 0xF8) == 0xF0) step = 4;
        p += step;
        total_chars++;
    }

    // 2. Iterate each UTF-8 glyph and draw with sine-wave gradient
    float cur_x = pos.x;
    int char_idx = 0;
    float time = (float)ImGui::GetTime() * 2.2f;

    for (const char* p = text; *p; ) {
        unsigned char c = (unsigned char)*p;
        int step = 1;
        if ((c & 0x80) == 0) step = 1;
        else if ((c & 0xE0) == 0xC0) step = 2;
        else if ((c & 0xF0) == 0xE0) step = 3;
        else if ((c & 0xF8) == 0xF0) step = 4;

        char glyph[8] = { 0 };
        for (int b = 0; b < step && p[b]; b++) {
            glyph[b] = p[b];
        }

        ImVec2 g_sz = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, glyph);
        float gw = g_sz.x;

        if (glyph[0] != ' ' || glyph[1] != '\0') {
            float t = (total_chars > 1) ? ((float)char_idx / (float)(total_chars - 1)) : 0.0f;
            float wave_t = (sinf(time + t * 3.14159f) + 1.0f) * 0.5f;

            ImColor col = ImLerpColor(c::anim::active, c::anim::secondary, wave_t);
            col.Value.w *= alpha;

            if (with_shadow) {
                draw->AddText(font, font_size, ImVec2(cur_x + 1.2f, pos.y + 1.2f),
                    ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, 0.85f * alpha)), glyph);
            }
            draw->AddText(font, font_size, ImVec2(cur_x, pos.y), ImGui::GetColorU32(col), glyph);
        }

        cur_x += gw + spacing;
        p += step;
        char_idx++;
    }
}

// Плавная анимация для прямоугольников
inline void fade_rect_smooth(ImDrawList* draw, const ImVec2& pos_min, const ImVec2& pos_max, ImU32 col_one, ImU32 col_two, float rounding = 0.0f)
{
    float time = global_animation::GetTime();
    
    // Легкое смещение градиента
    float width = pos_max.x - pos_min.x;
    float height = pos_max.y - pos_min.y;
    
    float offset_x = sinf(time * 0.3f) * width * 0.05f;
    float offset_y = cosf(time * 0.4f) * height * 0.05f;
    
    // Используем смещенные точки для градиента
    ImVec2 animated_min = pos_min + ImVec2(offset_x, offset_y);
    ImVec2 animated_max = pos_max + ImVec2(-offset_x, -offset_y);
    
    // Плавное вращение градиента
    float angle = time * 0.15f;
    
    // Применяем градиент с анимацией
    fade_rect_filled(draw, animated_min, animated_max, col_one, col_two, fade_direction::diagonally, rounding, 0, true);
}

// Генератор плавной фазы анимации
inline float GetSmoothGradientPhase()
{
    static float phase = 0.0f;
    phase += ImGui::GetIO().DeltaTime * 0.8f; // Медленная, плавная анимация
    if (phase > IM_PI * 4.0f) phase -= IM_PI * 4.0f;
    return phase;
}

// Генератор более динамичной фазы анимации с волнами
inline float GetDynamicGradientPhase()
{
    static float phase = 0.0f;
    phase += ImGui::GetIO().DeltaTime * 1.2f; // Средняя скорость
    
    // Добавляем небольшие вариации для более живой анимации
    float time = ImGui::GetTime();
    float variation = sinf(time * 0.3f) * 0.1f;
    
    return phase + variation;
}

// Система управления анимациями
namespace tab_animations {
    enum AnimationStyle {
        STYLE_SMOOTH = 0,     // Плавная синусоида
        STYLE_WAVE = 1,       // Сложная волна
        STYLE_PULSE = 2,      // Пульсирующая
        STYLE_FLOW = 3,       // Текучая
        STYLE_ENERGY = 4      // Энергетическая
    };
    
    static AnimationStyle current_style = STYLE_SMOOTH;
    
    // Получить фазу анимации в зависимости от стиля
    inline float GetAnimationPhase(ImGuiID id, float base_time)
    {
        float phase = base_time;
        
        switch (current_style) {
            case STYLE_SMOOTH:
                phase += sinf(base_time * 0.5f) * 0.2f;
                break;
            case STYLE_WAVE:
                phase += sinf(base_time * 0.8f + id * 0.01f) * 0.3f + 
                        sinf(base_time * 1.5f + id * 0.02f) * 0.2f;
                break;
            case STYLE_PULSE:
                phase = fmodf(base_time * 0.3f, 1.0f);
                break;
            case STYLE_FLOW:
                phase += cosf(base_time * 0.4f + id * 0.03f) * 0.4f;
                break;
            case STYLE_ENERGY:
                phase += (sinf(base_time * 1.2f) + cosf(base_time * 2.1f)) * 0.25f;
                break;
        }
        
        return phase;
    }
    
    // Получить смещение для анимации градиента
    inline ImVec2 GetGradientOffset(ImVec2 text_size, float time, ImGuiID id)
    {
        ImVec2 offset(0, 0);
        
        switch (current_style) {
            case STYLE_SMOOTH:
                offset.x = sinf(time * 0.6f) * text_size.x * 0.2f;
                offset.y = cosf(time * 0.5f) * text_size.y * 0.15f;
                break;
            case STYLE_WAVE:
                offset.x = sinf(time * 0.8f + id * 0.01f) * text_size.x * 0.25f;
                offset.y = cosf(time * 0.7f + id * 0.02f) * text_size.y * 0.2f;
                break;
            case STYLE_PULSE:
                {
                    float pulse = sinf(time * 1.5f) * 0.5f + 0.5f;
                    offset.x = sinf(time * 0.4f) * text_size.x * 0.15f * pulse;
                    offset.y = cosf(time * 0.3f) * text_size.y * 0.1f * pulse;
                }
                break;
            case STYLE_FLOW:
                offset.x = sinf(time * 0.3f) * text_size.x * 0.3f + cosf(time * 0.2f) * text_size.x * 0.1f;
                offset.y = cosf(time * 0.4f) * text_size.y * 0.2f + sinf(time * 0.1f) * text_size.y * 0.05f;
                break;
            case STYLE_ENERGY:
                offset.x = (sinf(time * 1.0f) + cosf(time * 1.8f)) * text_size.x * 0.15f;
                offset.y = (cosf(time * 0.9f) + sinf(time * 2.2f)) * text_size.y * 0.1f;
                break;
        }
        
        return offset;
    }
    
    // Получить масштаб градиента
    inline float GetGradientScale(float time, ImGuiID id)
    {
        float scale = 1.0f;
        
        switch (current_style) {
            case STYLE_SMOOTH:
                scale += sinf(time * 0.4f) * 0.08f;
                break;
            case STYLE_WAVE:
                scale += (sinf(time * 0.6f) + cosf(time * 1.2f)) * 0.05f;
                break;
            case STYLE_PULSE:
                scale += sinf(time * 2.0f) * 0.12f;
                break;
            case STYLE_FLOW:
                scale += cosf(time * 0.5f + id * 0.01f) * 0.06f;
                break;
            case STYLE_ENERGY:
                scale += (sinf(time * 1.5f) * 0.1f + cosf(time * 2.5f) * 0.05f);
                break;
        }
        
        return scale;
    }
    
    // Установить стиль анимации
    inline void SetAnimationStyle(AnimationStyle style)
    {
        current_style = style;
    }
    
    // Циклическое переключение стилей
    inline void CycleAnimationStyle()
    {
        current_style = static_cast<AnimationStyle>((current_style + 1) % 5);
    }
}


enum interpolation_type {
    expo,
    back,
    quint,
    bounce,
    elastic,
};

class c_easing
{

public:

    template <typename T>
    T* anim_container(T** state_ptr, ImGuiID id)
    {
        T* state = static_cast<T*>(GetStateStorage()->GetVoidPtr(id));
        if (!state)
            GetStateStorage()->SetVoidPtr(id, state = new T());

        *state_ptr = state;
        return state;
    }

private:


    float easing_value;

    // Easing functions
    float ease_in_quint(float t) {
        return 1 - pow(1 - t, 5);
    }

    float ease_in_expo(float t) {
        return (t == 0.0f) ? 0.0f : pow(2, 10 * t - 10);
    }

    float ease_in_elastic(float t) {
        const float c4 = (2 * IM_PI) / 2;
        return (t <= 0.01f) ? 0.0f : (t >= 0.60f) ? 1.0f : pow(2, -10 * t) * sin((t * 10 - 0.75) * c4) + 1;
    }

    float ease_in_back(float t) {
        const float c1 = 1.70158;
        const float c3 = c1 + 1;
        return 1 + c3 * pow(t - 1, 3) + c1 * pow(t - 1, 2);
    }


    float ease_in_bounce(float t) {
        float n1 = 7.5625f;
        const float d1 = 2.75f;

        if (t < 1.0f / d1) {
            return n1 * t * t;
        }
        else if (t < 2.0f / d1) {
            float reduced_t = t - 1.5f / d1;
            return n1 * reduced_t * reduced_t + 0.75f;
        }
        else if (t < 2.5f / d1) {
            float reduced_t = t - 2.25f / d1;
            return n1 * reduced_t * reduced_t + 0.9375f;
        }
        else {
            float reduced_t = t - 2.625f / d1;
            return n1 * reduced_t * reduced_t + 0.984375f;
        }
    }

public:
    struct easing_state {
        float animTime = 0.0f;
        bool reverse = false;
    };

    template <typename T>
    T easing_in_out(int animation_id, bool callback, T min, T max, float speed, interpolation_type type) {
        easing_state* state = anim_container(&state, GetCurrentWindow()->GetID(animation_id));

        state->animTime = (callback != state->reverse) ? 0.0f : ImMin(state->animTime + 0.1f * speed, 1.0f);
        state->reverse = callback;

        easing_value = (type == elastic) ? ease_in_elastic(state->animTime) :
            (type == bounce) ? ease_in_bounce(state->animTime) :
            (type == back) ? ease_in_back(state->animTime) :
            (type == expo) ? ease_in_expo(state->animTime) :
            (type == quint) ? ease_in_quint(state->animTime) : 0;

        if constexpr (std::is_same_v<T, float>) {
            return callback ? easing_value * (max - min) + min : easing_value * (min - max) + max;
        }
        else if constexpr (std::is_same_v<T, ImVec4>) {
            return ImVec4(
                callback ? easing_value * (max.x - min.x) + min.x : easing_value * (min.x - max.x) + max.x,
                callback ? easing_value * (max.y - min.y) + min.y : easing_value * (min.y - max.y) + max.y,
                callback ? easing_value * (max.z - min.z) + min.z : easing_value * (min.z - max.z) + max.z,
                callback ? easing_value * (max.w - min.w) + min.w : easing_value * (min.w - max.w) + max.w
            );
        }

        return T();
    }

    template <typename T>
    T easing_in(int animation_id, T min, T max, float speed, interpolation_type type) {
        easing_state* state = anim_container(&state, GetCurrentWindow()->GetID(animation_id));
        state->animTime = ImClamp(state->animTime + speed, 0.0f, 1.0f);

        float t = state->animTime;
        float eased = (type == back) ? ease_in_back(t) :
            (type == bounce) ? ease_in_bounce(t) :
            (type == expo) ? ease_in_expo(t) :
            (type == elastic) ? ease_in_elastic(t) :
            (type == quint) ? ease_in_quint(t) : t;

        return ImLerp(min, max, eased);
    }

    template <typename T>
    T easing_out(int animation_id, T min, T max, float speed, interpolation_type type) {
        easing_state* state = anim_container(&state, GetCurrentWindow()->GetID(animation_id));
        state->animTime = ImClamp(state->animTime + speed, 0.0f, 1.0f);

        float t = state->animTime;
        float eased = (type == back) ? ease_out_back(t) : t;

        return ImLerp(min, max, eased);
    }

    float ease_out_back(float t) {
        const float c1 = 1.70158f;
        const float c3 = c1 + 1.0f;
        return 1 + c3 * pow(t - 1, 3) + c1 * pow(t - 1, 2);
    }


    // Специализация для ImVec2
    template <>
    ImVec2 easing_in_out<ImVec2>(int animation_id, bool callback, ImVec2 min, ImVec2 max, float speed, interpolation_type type) {
        easing_state* state = anim_container(&state, GetCurrentWindow()->GetID(animation_id));

        state->animTime = (callback != state->reverse) ? 0.0f : ImMin(state->animTime + 0.1f * speed, 1.0f);
        state->reverse = callback;

        easing_value = (type == elastic) ? ease_in_elastic(state->animTime) :
            (type == bounce) ? ease_in_bounce(state->animTime) :
            (type == back) ? ease_in_back(state->animTime) :
            (type == expo) ? ease_in_expo(state->animTime) :
            (type == quint) ? ease_in_quint(state->animTime) : 0;

        ImVec2 result;
        result.x = callback ? easing_value * (max.x - min.x) + min.x : easing_value * (min.x - max.x) + max.x;
        result.y = callback ? easing_value * (max.y - min.y) + min.y : easing_value * (min.y - max.y) + max.y;
        return result;
    }
};

inline std::unique_ptr<c_easing> easing = std::make_unique<c_easing>();



namespace custom
{
	void				ItemBackground(ImGuiID id, ImRect bb, bool hovered);
	bool				Tab(const char* label, const char* icon, int* v, int number);;
	bool				SquareTab(const char* label, const char* icon, int* v, int number);;
	bool				SubTab(const char* label, int* v, int number, ImColor color);
    bool				ToggleButton(const char* first_text, const char* second_text, bool* v, const ImVec2& size_arg);
	bool				ThemeButton(const char* id_theme, bool dark, const ImVec2& size_arg);
	bool				rotated_text(const char* label, bool active);
	bool				Button(const char* label, const ImVec2& size_arg);
    bool                InActiveButton(const char* label, const ImVec2& size_arg);

    bool                ChildEx(const char* name, ImGuiID id, const ImVec2& size_arg, bool cap, ImGuiWindowFlags flags, const char* icon = "");
	bool				Child(const char* str_id, const ImVec2& size = ImVec2(0, 0), bool cap = false, ImGuiWindowFlags flags = 0, bool space = false, const char* icon = "");
	bool				ChildID(ImGuiID id, const ImVec2& size = ImVec2(0, 0), bool cap = false, ImGuiWindowFlags flags = 0);
	void				EndChild();

	void				BeginGroup();
	void				EndGroup();

	bool				Checkbox(const char* label, bool* v);
	bool				CheckboxClicked(const char* label, bool* v);
    void                DrawHexGrid(
        const std::vector<std::string>& labels,
        const std::vector<int>& indicators);

	bool			    Selectable(const char* label, bool selected = false, ImGuiSelectableFlags flags = 0, const ImVec2& size = ImVec2(0, 0));
	bool				Selectable(const char* label, bool* p_selected, ImGuiSelectableFlags flags = 0, const ImVec2& size = ImVec2(0, 0));

	bool				BeginCombo(const char* label, const char* preview_value, int val = 0, bool multi = false, ImGuiComboFlags flags = 0);
	void				EndCombo();
	void				MultiCombo(const char* label, bool variable[], const char* labels[], int count);
	bool				Combo(const char* label, int* current_item, const char* const items[], int items_count, int popup_max_height_in_items = -1);
	bool				Combo(const char* label, int* current_item, const char* items_separated_by_zeros, int popup_max_height_in_items = -1);
	bool				Combo(const char* label, int* current_item, const char* (*getter)(void* user_data, int idx), void* user_data, int items_count, int popup_max_height_in_items = -1);

	bool				ColorButton(const char* desc_id, const ImVec4& col, ImGuiColorEditFlags flags = 0, const ImVec2& size = ImVec2(0, 0));
	bool				ColorEdit4(const char* label, float col[4], ImGuiColorEditFlags flags = 0);
	bool			    ColorPicker4(const char* label, float col[4], ImGuiColorEditFlags flags = 0, const float* ref_col = NULL);

	bool				KnobScalar(const char* label, ImGuiDataType data_type, void* p_data, const void* p_min, const void* p_max, const char* format, ImGuiSliderFlags flags = 0);
	bool				KnobFloat(const char* label, float* v, float v_min, float v_max, const char* format, ImGuiSliderFlags flags = 0);
	bool				KnobInt(const char* label, int* v, int v_min, int v_max, const char* format, ImGuiSliderFlags flags = 0);

	bool				SliderScalar(const char* label, ImGuiDataType data_type, void* p_data, const void* p_min, const void* p_max, const char* format, ImGuiSliderFlags flags = 0);
	bool				SliderFloat(const char* label, float* v, float v_min, float v_max, const char* format = "%d", ImGuiSliderFlags flags = 0);
	bool				SliderInt(const char* label, int* v, int v_min, int v_max, const char* format = "%d", ImGuiSliderFlags flags = 0);

	void				Separator_line();

	void				SeparatorEx(ImGuiSeparatorFlags flags, float thickness);
	void				Separator();


    bool				Keybind(const char* label, int* key, int* mode);
    bool				MiniBind(const char* label, int* key, int* mode);
    bool                Bindbox(const char* label, bool* v, int* key, int* mode);
    bool                Featuresbox(const char* label, bool* v);

    bool                SearchBar(const char* hint, char* buf, size_t buf_size, const ImVec2& size_arg);
    bool                PresetSelector(int* active_preset);
    bool                SubTabBar(const char** subtabs, int count, int* current_subtab);
    bool                InputText(const char* label, const char* hint, char* buf, size_t buf_size, const ImVec2& size_arg = ImVec2(0, 0));
    bool                SideNav(const char** labels, const char** icons, int count, int* active_tab, const ImVec2& size_arg = ImVec2(0, 0));

    inline bool         g_keyboard_hovered = false;
    inline bool         g_keyboard_dragging = false;
}

namespace nav
{
    inline int active_page = 0;
    inline int aim_sub = 0;
    inline int vis_sub = 0;
    inline int ply_sub = 0;
    inline int rad_sub = 0;
    inline int msc_sub = 0;

    inline void jump_to(int page, int subtab)
    {
        active_page = page;
        if (page == 0) aim_sub = subtab;
        else if (page == 1) vis_sub = subtab;
        else if (page == 2) ply_sub = subtab;
        else if (page == 3) rad_sub = subtab;
        else if (page == 4) msc_sub = subtab;
    }
}

// Плавная анимация для слайдеров с учетом позиции
inline void fade_slider_smooth(ImDrawList* draw, const ImVec2& pos_min, const ImVec2& pos_max, float value_normalized, ImU32 col_one, ImU32 col_two, float rounding = 0.0f)
{
    float time = global_animation::GetTime();
    
    // Плавная волна для анимации заполнения
    float wave = sinf(time * 0.6f) * 0.3f + 0.7f;
    
    // Вычисляем конец заполнения с учетом значения
    float fill_width = (pos_max.x - pos_min.x) * value_normalized;
    ImVec2 fill_end = ImVec2(pos_min.x + fill_width, pos_max.y);
    
    // Легкая пульсация конца заполнения
    ImVec2 animated_end = ImLerp(fill_end, ImVec2(fill_end.x + 2.0f, fill_end.y), wave * 0.1f);
    
    // Легкое смещение градиента для слайдера
    float offset_x = sinf(time * 0.4f) * (pos_max.x - pos_min.x) * 0.03f;
    float offset_y = cosf(time * 0.5f) * (pos_max.y - pos_min.y) * 0.02f;
    
    ImVec2 gradient_p0 = pos_min + ImVec2(offset_x, offset_y);
    ImVec2 gradient_p1 = animated_end + ImVec2(-offset_x, -offset_y);
    
    // Плавный градиент для слайдера
    fade_rect_filled(draw, pos_min, animated_end, col_one, col_two, 
                     fade_direction::horizontally, rounding, 0, true);
}

// Улучшенная версия для более динамичной анимации слайдеров
inline void fade_slider_dynamic(ImDrawList* draw, const ImVec2& pos_min, const ImVec2& pos_max, float value_normalized, ImU32 col_one, ImU32 col_two, ImGuiID id, float rounding = 0.0f)
{
    float time = global_animation::GetTimeOffset(id);
    
    // Динамичная волна с учетом ID для разнообразия
    float wave1 = sinf(time * 0.7f + id * 0.01f) * 0.25f;
    float wave2 = cosf(time * 1.2f + id * 0.02f) * 0.15f;
    float combined_wave = wave1 + wave2 + 0.7f;
    
    // Вычисляем конец заполнения
    float fill_width = (pos_max.x - pos_min.x) * value_normalized;
    ImVec2 fill_end = ImVec2(pos_min.x + fill_width, pos_max.y);
    
    // Анимированный конец с эффектом пульсации
    float pulse = sinf(time * 1.5f) * 0.2f + 0.8f;
    ImVec2 animated_end = ImLerp(fill_end, ImVec2(fill_end.x + 3.0f * pulse, fill_end.y), 0.1f);
    
    // Более выраженное смещение градиента
    float offset_x = sinf(time * 0.6f + id * 0.05f) * (pos_max.x - pos_min.x) * 0.05f;
    float offset_y = cosf(time * 0.8f + id * 0.03f) * (pos_max.y - pos_min.y) * 0.03f;
    
    ImVec2 gradient_p0 = pos_min + ImVec2(offset_x, offset_y);
    ImVec2 gradient_p1 = animated_end + ImVec2(-offset_x, -offset_y);
    
    // Динамичный градиент
    fade_rect_filled(draw, pos_min, animated_end, col_one, col_two, 
                     fade_direction::horizontally, rounding, 0, true);
}


// Прямая анимация прямоугольника с плавным градиентом
inline void fade_rect_smooth_direct(ImDrawList* draw, const ImVec2& pos_min, const ImVec2& pos_max, ImU32 col_one, ImU32 col_two, float rounding = 0.0f)
{
    float time = global_animation::GetTime();
    
    // Легкое смещение градиента
    float width = pos_max.x - pos_min.x;
    float height = pos_max.y - pos_min.y;
    
    float offset_x = sinf(time * 0.6f) * width * 0.08f;
    float offset_y = cosf(time * 0.8f) * height * 0.07f;
    
    // Используем смещенные точки для градиента
    ImVec2 gradient_p0 = pos_min + ImVec2(offset_x, offset_y);
    ImVec2 gradient_p1 = pos_max + ImVec2(-offset_x, -offset_y);
    
    // Плавное вращение градиента
    float angle = time * 0.3f;
    
    // Создаем прямоугольник
    const int vtx_buffer_start = draw->VtxBuffer.Size;
    draw->AddRectFilled(pos_min, pos_max, ImColor(1.f, 1.f, 1.f, ImColor(col_one).Value.w), rounding, 0);
    const int vtx_buffer_end = draw->VtxBuffer.Size;
    
    // Применяем анимированный градиент
    set_linear_color(draw, vtx_buffer_start, vtx_buffer_end, gradient_p0, gradient_p1, col_one, col_two, angle);
}

// Улучшенная версия с ID
inline void fade_rect_smooth_id(ImDrawList* draw, const ImVec2& pos_min, const ImVec2& pos_max, ImU32 col_one, ImU32 col_two, ImGuiID id, float rounding = 0.0f)
{
    float time = global_animation::GetTimeOffset(id);
    
    // Более динамичное смещение градиента
    float width = pos_max.x - pos_min.x;
    float height = pos_max.y - pos_min.y;
    
    float offset_x = sinf(time * 0.8f + id * 0.01f) * width * 0.11f;
    float offset_y = cosf(time * 1.0f + id * 0.02f) * height * 0.09f;
    
    // Используем смещенные точки для градиента
    ImVec2 gradient_p0 = pos_min + ImVec2(offset_x, offset_y);
    ImVec2 gradient_p1 = pos_max + ImVec2(-offset_x, -offset_y);
    
    // Плавное вращение градиента с учетом ID
    float angle = time * 0.4f + id * 0.001f;
    
    // Создаем прямоугольник
    const int vtx_buffer_start = draw->VtxBuffer.Size;
    draw->AddRectFilled(pos_min, pos_max, ImColor(1.f, 1.f, 1.f, ImColor(col_one).Value.w), rounding, 0);
    const int vtx_buffer_end = draw->VtxBuffer.Size;
    
    // Применяем анимированный градиент
    set_linear_color(draw, vtx_buffer_start, vtx_buffer_end, gradient_p0, gradient_p1, col_one, col_two, angle);
}


// Прямая анимация слайдера с плавным градиентом
inline void fade_slider_smooth_direct(ImDrawList* draw, const ImVec2& pos_min, const ImVec2& pos_max, float value_normalized, ImU32 col_one, ImU32 col_two, float rounding = 0.0f)
{
    float time = global_animation::GetTime();
    
    // Плавная волна для анимации заполнения
    float wave = sinf(time * 1.2f) * 0.3f + 0.7f;
    
    // Вычисляем конец заполнения с учетом значения
    float fill_width = (pos_max.x - pos_min.x) * value_normalized;
    ImVec2 fill_end = ImVec2(pos_min.x + fill_width, pos_max.y);
    
    // Легкая пульсация конца заполнения
    ImVec2 animated_end = ImLerp(fill_end, ImVec2(fill_end.x + 3.0f, fill_end.y), wave * 0.15f);
    
    // Легкое смещение градиента для слайдера
    float offset_x = sinf(time * 0.8f) * (pos_max.x - pos_min.x) * 0.05f;
    float offset_y = cosf(time * 1.0f) * (pos_max.y - pos_min.y) * 0.04f;
    
    // Используем смещенные точки для градиента
    ImVec2 gradient_p0 = pos_min + ImVec2(offset_x, offset_y);
    ImVec2 gradient_p1 = animated_end + ImVec2(-offset_x, -offset_y);
    
    // Плавное вращение градиента
    float angle = time * 0.2f;
    
    // Создаем заполнение слайдера
    const int vtx_buffer_start = draw->VtxBuffer.Size;
    draw->AddRectFilled(pos_min, animated_end, ImColor(1.f, 1.f, 1.f, ImColor(col_one).Value.w), rounding, 0);
    const int vtx_buffer_end = draw->VtxBuffer.Size;
    
    // Применяем анимированный градиент
    set_linear_color(draw, vtx_buffer_start, vtx_buffer_end, gradient_p0, gradient_p1, col_one, col_two, angle);
}

// Динамичная версия с ID
inline void fade_slider_dynamic_direct(ImDrawList* draw, const ImVec2& pos_min, const ImVec2& pos_max, float value_normalized, ImU32 col_one, ImU32 col_two, ImGuiID id, float rounding = 0.0f)
{
    float time = global_animation::GetTimeOffset(id);
    
    // Динамичная волна с учетом ID для разнообразия
    float wave1 = sinf(time * 1.4f + id * 0.01f) * 0.25f;
    float wave2 = cosf(time * 2.4f + id * 0.02f) * 0.15f;
    float combined_wave = wave1 + wave2 + 0.7f;
    
    // Вычисляем конец заполнения
    float fill_width = (pos_max.x - pos_min.x) * value_normalized;
    ImVec2 fill_end = ImVec2(pos_min.x + fill_width, pos_max.y);
    
    // Анимированный конец с эффектом пульсации
    float pulse = sinf(time * 3.0f) * 0.2f + 0.8f;
    ImVec2 animated_end = ImLerp(fill_end, ImVec2(fill_end.x + 4.0f * pulse, fill_end.y), 0.15f);
    
    // Более выраженное смещение градиента
    float offset_x = sinf(time * 1.2f + id * 0.05f) * (pos_max.x - pos_min.x) * 0.07f;
    float offset_y = cosf(time * 1.6f + id * 0.03f) * (pos_max.y - pos_min.y) * 0.05f;
    
    // Используем смещенные точки для градиента
    ImVec2 gradient_p0 = pos_min + ImVec2(offset_x, offset_y);
    ImVec2 gradient_p1 = animated_end + ImVec2(-offset_x, -offset_y);
    
    // Динамичное вращение градиента
    float angle = time * 0.3f + id * 0.001f;
    
    // Создаем заполнение слайдера
    const int vtx_buffer_start = draw->VtxBuffer.Size;
    draw->AddRectFilled(pos_min, animated_end, ImColor(1.f, 1.f, 1.f, ImColor(col_one).Value.w), rounding, 0);
    const int vtx_buffer_end = draw->VtxBuffer.Size;
    
    // Применяем динамичный градиент
    set_linear_color(draw, vtx_buffer_start, vtx_buffer_end, gradient_p0, gradient_p1, col_one, col_two, angle);
}

// =========================================================================
// NON-STANDARD UNCONVENTIONAL ANIMATION SYSTEM
// =========================================================================

// 1. Sleek Dual-Tone Cyan & Magenta Neon Border Sweep
inline void DrawRainbowGlowingBorder(ImDrawList* dl, ImVec2 min, ImVec2 max, float rounding, float thickness, float alpha)
{
    float time = ImGui::GetTime() * 1.8f;
    float phase = (sinf(time) * 0.5f + 0.5f);

    ImColor cyan(0, 240, 255, (int)(255 * alpha * 0.85f));
    ImColor magenta(217, 70, 239, (int)(255 * alpha * 0.85f));
    ImU32 border_col = ImLerpColor(ImGui::GetColorU32(cyan), ImGui::GetColorU32(magenta), phase);

    dl->AddRect(min - ImVec2(1.f, 1.f), max + ImVec2(1.f, 1.f), ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, 0.6f * alpha)), rounding + 1.f, 0, thickness + 1.f);
    dl->AddRect(min, max, border_col, rounding, 0, thickness);
}

// 2. Interactive Neural Constellation Particle Network
inline void DrawTechConstellationMesh(ImDrawList* dl, ImVec2 min, ImVec2 max, float alpha)
{
    struct MeshNode {
        ImVec2 pos;
        ImVec2 vel;
    };
    static const int NODE_COUNT = 32;
    static MeshNode nodes[NODE_COUNT];
    static bool init = false;

    float width = max.x - min.x;
    float height = max.y - min.y;
    if (width <= 10.f || height <= 10.f) return;

    if (!init) {
        for (int i = 0; i < NODE_COUNT; i++) {
            nodes[i].pos = ImVec2(min.x + (rand() % 1000) / 1000.f * width, min.y + (rand() % 1000) / 1000.f * height);
            nodes[i].vel = ImVec2(((rand() % 1000) / 1000.f - 0.5f) * 20.f, ((rand() % 1000) / 1000.f - 0.5f) * 20.f);
        }
        init = true;
    }

    float dt = ImGui::GetIO().DeltaTime;
    ImVec2 mouse = ImGui::GetMousePos();

    // Update positions
    for (int i = 0; i < NODE_COUNT; i++) {
        nodes[i].pos += nodes[i].vel * dt;
        if (nodes[i].pos.x < min.x) { nodes[i].pos.x = min.x; nodes[i].vel.x *= -1.f; }
        if (nodes[i].pos.x > max.x) { nodes[i].pos.x = max.x; nodes[i].vel.x *= -1.f; }
        if (nodes[i].pos.y < min.y) { nodes[i].pos.y = min.y; nodes[i].vel.y *= -1.f; }
        if (nodes[i].pos.y > max.y) { nodes[i].pos.y = max.y; nodes[i].vel.y *= -1.f; }

        // Draw node dot
        dl->AddCircleFilled(nodes[i].pos, 2.f, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.45f * alpha)), 8);
    }

    // Connect node lines
    float max_dist = 110.f;
    for (int i = 0; i < NODE_COUNT; i++) {
        for (int j = i + 1; j < NODE_COUNT; j++) {
            float dx = nodes[i].pos.x - nodes[j].pos.x;
            float dy = nodes[i].pos.y - nodes[j].pos.y;
            float dist = sqrtf(dx * dx + dy * dy);
            if (dist < max_dist) {
                float line_alpha = (1.f - (dist / max_dist)) * 0.22f * alpha;
                dl->AddLine(nodes[i].pos, nodes[j].pos, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, line_alpha)), 1.f);
            }
        }

        // Connection to mouse if close
        float m_dx = nodes[i].pos.x - mouse.x;
        float m_dy = nodes[i].pos.y - mouse.y;
        float m_dist = sqrtf(m_dx * m_dx + m_dy * m_dy);
        if (m_dist < 130.f) {
            float m_alpha = (1.f - (m_dist / 130.f)) * 0.4f * alpha;
            dl->AddLine(nodes[i].pos, mouse, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, m_alpha)), 1.2f);
        }
    }
}

// 3. Interactive Animated Tactical 2D Radar Canvas
inline void DrawAnimatedRadarWidget(ImDrawList* dl, ImVec2 center, float radius, float alpha)
{
    float time = ImGui::GetTime();

    // Radar dark background & outer ring
    dl->AddCircleFilled(center, radius, ImGui::GetColorU32(ImVec4(0.04f, 0.05f, 0.08f, 0.9f * alpha)), 48);
    dl->AddCircle(center, radius, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.5f * alpha)), 48, 1.5f);
    dl->AddCircle(center, radius * 0.66f, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.08f * alpha)), 36, 1.f);
    dl->AddCircle(center, radius * 0.33f, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.08f * alpha)), 36, 1.f);

    // Crosshair axis lines
    dl->AddLine(ImVec2(center.x - radius, center.y), ImVec2(center.x + radius, center.y), ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.1f * alpha)), 1.f);
    dl->AddLine(ImVec2(center.x, center.y - radius), ImVec2(center.x, center.y + radius), ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.1f * alpha)), 1.f);

    // Rotating radar scanner line
    float sweep_angle = time * 2.2f;
    ImVec2 sweep_dir(cosf(sweep_angle), sinf(sweep_angle));
    ImVec2 sweep_end = center + sweep_dir * radius;

    dl->AddLine(center, sweep_end, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.8f * alpha)), 1.5f);

    // Dynamic Blips (Enemies & Teammates)
    struct RadarBlip { float r_frac; float angle_off; bool is_enemy; const char* label; };
    static const RadarBlip blips[] = {
        { 0.45f, 0.8f, true, "12m" },
        { 0.70f, 2.4f, true, "45m" },
        { 0.30f, 4.1f, false, "TEAM" },
        { 0.82f, 5.2f, true, "88m" },
        { 0.55f, 3.5f, true, "32m" }
    };

    for (int i = 0; i < 5; i++) {
        float b_angle = blips[i].angle_off + sinf(time * 0.5f + i) * 0.1f;
        float b_dist = radius * blips[i].r_frac;
        ImVec2 b_pos = center + ImVec2(cosf(b_angle) * b_dist, sinf(b_angle) * b_dist);

        ImU32 b_col = blips[i].is_enemy
            ? ImGui::GetColorU32(ImVec4(1.f, 0.25f, 0.35f, alpha))
            : ImGui::GetColorU32(ImVec4(0.2f, 0.85f, 1.f, alpha));

        // Pulsing glow aura around blip
        float pulse = (sinf(time * 4.f + i) * 0.5f + 0.5f) * 3.f;
        dl->AddCircleFilled(b_pos, 3.5f + pulse, ImGui::GetColorU32(utils::GetColorWithAlpha(ImColor(b_col), 0.3f)), 16);
        dl->AddCircleFilled(b_pos, 3.f, b_col, 16);
    }

    // Self center arrow indicator
    ImVec2 self_top(center.x, center.y - 6.f);
    ImVec2 self_left(center.x - 5.f, center.y + 5.f);
    ImVec2 self_right(center.x + 5.f, center.y + 5.f);
    dl->AddTriangleFilled(self_top, self_left, self_right, ImGui::GetColorU32(c::anim::active));
}

// 4. Interactive Animated 3D-esque Skeleton Mannequin ESP Preview
inline void DrawAnimatedSkeletonPreview(ImDrawList* dl, ImVec2 center, float scale, float alpha)
{
    float time = ImGui::GetTime();
    float sway = sinf(time * 1.8f) * 4.f * scale;

    // Body Skeleton Joint Nodes (Simulated 3D projection)
    ImVec2 head = center + ImVec2(sway * 0.5f, -90.f * scale);
    ImVec2 neck = center + ImVec2(sway * 0.3f, -70.f * scale);
    ImVec2 l_shoulder = center + ImVec2(-28.f * scale + sway * 0.2f, -65.f * scale);
    ImVec2 r_shoulder = center + ImVec2(28.f * scale + sway * 0.2f, -65.f * scale);
    ImVec2 l_elbow = center + ImVec2(-42.f * scale + sway * 0.1f, -30.f * scale + sinf(time * 2.f) * 5.f);
    ImVec2 r_elbow = center + ImVec2(42.f * scale + sway * 0.1f, -30.f * scale - sinf(time * 2.f) * 5.f);
    ImVec2 pelvis = center + ImVec2(sway * 0.1f, 10.f * scale);
    ImVec2 l_knee = center + ImVec2(-20.f * scale, 55.f * scale);
    ImVec2 r_knee = center + ImVec2(20.f * scale, 55.f * scale);
    ImVec2 l_foot = center + ImVec2(-22.f * scale, 95.f * scale);
    ImVec2 r_foot = center + ImVec2(22.f * scale, 95.f * scale);

    ImU32 bone_col = ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.9f * alpha));
    ImU32 box_col = ImGui::GetColorU32(c::anim::active);

    // Bounding Box with animated corner brackets
    ImVec2 box_min = center + ImVec2(-48.f * scale + sway * 0.2f, -105.f * scale);
    ImVec2 box_max = center + ImVec2(48.f * scale + sway * 0.2f, 105.f * scale);

    dl->AddRect(box_min - ImVec2(1, 1), box_max + ImVec2(1, 1), IM_COL32(0, 0, 0, 180), 3.f);
    dl->AddRect(box_min, box_max, box_col, 3.f, 0, 1.5f);

    // Health Bar Meter on left side of ESP box
    ImVec2 hp_min(box_min.x - 7.f, box_min.y);
    ImVec2 hp_max(box_min.x - 3.f, box_max.y);
    dl->AddRectFilled(hp_min - ImVec2(1, 1), hp_max + ImVec2(1, 1), IM_COL32(0, 0, 0, 180), 2.f);
    dl->AddRectFilled(hp_min, hp_max, ImGui::GetColorU32(ImVec4(0.2f, 0.9f, 0.45f, 0.95f * alpha)), 2.f);

    // Armor Bar Meter on right side of ESP box
    ImVec2 arm_min(box_max.x + 3.f, box_min.y);
    ImVec2 arm_max(box_max.x + 7.f, box_max.y);
    dl->AddRectFilled(arm_min - ImVec2(1, 1), arm_max + ImVec2(1, 1), IM_COL32(0, 0, 0, 180), 2.f);
    dl->AddRectFilled(arm_min, arm_max, ImGui::GetColorU32(ImVec4(0.25f, 0.65f, 1.f, 0.95f * alpha)), 2.f);

    // Distance & Weapon Telemetry Badges
    PushFont(font::small_font);
    dl->AddText(ImVec2(box_min.x, box_min.y - 16.f), ImGui::GetColorU32(c::text::label::active), "Enemy_Target [100 HP]");
    dl->AddText(ImVec2(box_min.x, box_max.y + 4.f), ImGui::GetColorU32(c::text::description::default_col), "AK-47 | 24.8m");
    PopFont();

    // Snapline from top screen
    dl->AddLine(ImVec2(center.x, center.y - 140.f * scale), head, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.4f * alpha)), 1.f);

    // Skeleton Bone Connections
    dl->AddCircle(head, 12.f * scale, bone_col, 16, 1.5f);
    dl->AddLine(neck, pelvis, bone_col, 1.5f);
    dl->AddLine(neck, l_shoulder, bone_col, 1.5f);
    dl->AddLine(neck, r_shoulder, bone_col, 1.5f);
    dl->AddLine(l_shoulder, l_elbow, bone_col, 1.5f);
    dl->AddLine(r_shoulder, r_elbow, bone_col, 1.5f);
    dl->AddLine(pelvis, l_knee, bone_col, 1.5f);
    dl->AddLine(pelvis, r_knee, bone_col, 1.5f);
    dl->AddLine(l_knee, l_foot, bone_col, 1.5f);
    dl->AddLine(r_knee, r_foot, bone_col, 1.5f);

    // Joints glowing dots
    ImVec2 joints[] = { head, neck, l_shoulder, r_shoulder, l_elbow, r_elbow, pelvis, l_knee, r_knee, l_foot, r_foot };
    for (int i = 0; i < 11; i++) {
        dl->AddCircleFilled(joints[i], 2.5f * scale, ImGui::GetColorU32(c::anim::active), 12);
    }
}

// 5. Interactive Animated Aimbot FOV Target Canvas
inline void DrawAnimatedAimbotFOVVisualizer(ImDrawList* dl, ImVec2 center, float radius, float alpha)
{
    float time = ImGui::GetTime();

    // Outer FOV Circle with pulsing dashed ticks
    dl->AddCircle(center, radius, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.7f * alpha)), 64, 1.5f);
    dl->AddCircleFilled(center, radius, ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.04f * alpha)), 64);

    // Crosshair Lines
    dl->AddLine(center - ImVec2(10, 0), center + ImVec2(10, 0), ImGui::GetColorU32(ImVec4(1, 1, 1, 0.8f * alpha)), 1.5f);
    dl->AddLine(center - ImVec2(0, 10), center + ImVec2(0, 10), ImGui::GetColorU32(ImVec4(1, 1, 1, 0.8f * alpha)), 1.5f);

    // Dynamic Moving Target Head (Smooth orbiting path)
    float orb_angle = time * 1.5f;
    float orb_r = radius * 0.45f;
    ImVec2 target_head = center + ImVec2(cosf(orb_angle) * orb_r, sinf(orb_angle * 0.7f) * orb_r * 0.6f);

    // Lock-on connection beam line
    dl->AddLine(center, target_head, ImGui::GetColorU32(ImVec4(1.f, 0.25f, 0.35f, 0.75f * alpha)), 1.2f);

    // Target Head circle & cross lock
    dl->AddCircle(target_head, 9.f, ImGui::GetColorU32(ImVec4(1.f, 0.2f, 0.3f, 0.9f * alpha)), 16, 1.5f);
    dl->AddCircleFilled(target_head, 3.f, ImGui::GetColorU32(ImVec4(1.f, 0.2f, 0.3f, 0.9f * alpha)), 16);

    // Lock status text badge
    PushFont(font::small_font);
    dl->AddText(target_head + ImVec2(12.f, -8.f), ImGui::GetColorU32(ImVec4(1.f, 0.3f, 0.4f, alpha)), "[LOCKED: 18.4m]");
    PopFont();
}

// 6. Futuristic Cyber Hexagon Grid Canvas Background
inline void DrawCyberHexagonGrid(ImDrawList* dl, ImVec2 min, ImVec2 max, float alpha)
{
    float time = ImGui::GetTime();
    float hex_size = 28.f;
    float h = hex_size * 2.f;
    float w = sqrtf(3.f) * hex_size;

    ImU32 base_line_col = ImGui::GetColorU32(ImVec4(0.4f, 0.2f, 0.9f, 0.08f * alpha));
    ImU32 pulse_col = ImGui::GetColorU32(utils::GetColorWithAlpha(c::anim::active, 0.28f * alpha));

    for (float y = min.y - hex_size; y < max.y + hex_size; y += h * 0.75f) {
        int row = (int)((y - min.y) / (h * 0.75f));
        float x_offset = (row % 2 == 0) ? 0.f : w * 0.5f;

        for (float x = min.x - w + x_offset; x < max.x + w; x += w) {
            ImVec2 center(x, y);

            // Distance to time-wave center
            float wave = sinf(time * 2.f + (center.x * 0.005f) + (center.y * 0.005f));
            ImU32 line_col = (wave > 0.6f) ? pulse_col : base_line_col;

            ImVec2 pts[6];
            for (int i = 0; i < 6; i++) {
                float angle = ImDegToRad(60.f * i - 30.f);
                pts[i] = center + ImVec2(cosf(angle) * hex_size, sinf(angle) * hex_size);
            }
            dl->AddPolyline(pts, 6, line_col, ImDrawFlags_Closed, 1.f);
        }
    }
}

// 6. Interactive Live Crosshair Preview Studio Widget
inline void DrawAnimatedCrosshairPreview(ImDrawList* dl, ImVec2 center, float alpha,
    bool enable, int style, int size, int thick, int gap, bool dot, bool outline, bool recoil, float* col)
{
    // Draw 2D Game Viewport Canvas Background
    ImVec2 vp_min = center - ImVec2(130.f, 95.f);
    ImVec2 vp_max = center + ImVec2(130.f, 95.f);

    // Dark Tactical Viewport BG with Corner Borders
    dl->AddRectFilled(vp_min, vp_max, IM_COL32(10, 12, 18, (int)(230 * alpha)), 8.f);
    dl->AddRect(vp_min, vp_max, IM_COL32(255, 255, 255, (int)(25 * alpha)), 8.f, 0, 1.f);

    // Subtle Grid Pattern in Viewport
    for (float x = vp_min.x + 20.f; x < vp_max.x; x += 20.f)
        dl->AddLine(ImVec2(x, vp_min.y), ImVec2(x, vp_max.y), IM_COL32(255, 255, 255, (int)(8 * alpha)));
    for (float y = vp_min.y + 20.f; y < vp_max.y; y += 20.f)
        dl->AddLine(ImVec2(vp_min.x, y), ImVec2(vp_max.x, y), IM_COL32(255, 255, 255, (int)(8 * alpha)));



    if (!enable) {
        PushFont(font::small_font);
        dl->AddText(center - ImVec2(35.f, 8.f), IM_COL32(255, 255, 255, (int)(120 * alpha)), "DISABLED");
        PopFont();
        return;
    }

    // Dynamic Recoil Animation Expansion when hovering or firing
    float r_expand = 0.f;
    if (recoil) {
        r_expand = fabsf(sinf((float)ImGui::GetTime() * 4.f)) * 8.f;
    }

    ImU32 c_col = ImGui::GetColorU32(ImVec4(col[0], col[1], col[2], col[3] * alpha));
    ImU32 o_col = IM_COL32(0, 0, 0, (int)(220 * alpha));
    float total_gap = (float)gap + r_expand;
    float sz = (float)size;
    float th = (float)thick;

    // Center Dot
    if (dot || style == 1) {
        if (outline)
            dl->AddCircleFilled(center, th + 1.f, o_col);
        dl->AddCircleFilled(center, th * 0.75f, c_col);
    }

    if (style == 1) return; // Dot-only style

    // Crosshair Lines Rendering (Top, Bottom, Left, Right)
    if (style == 2) { // Circle style
        if (outline)
            dl->AddCircle(center, total_gap + sz, o_col, 32, th + 2.f);
        dl->AddCircle(center, total_gap + sz, c_col, 32, th);
        return;
    }

    // Line 1: Left
    ImVec2 l_start(center.x - total_gap - sz, center.y);
    ImVec2 l_end(center.x - total_gap, center.y);

    // Line 2: Right
    ImVec2 r_start(center.x + total_gap, center.y);
    ImVec2 r_end(center.x + total_gap + sz, center.y);

    // Line 3: Bottom
    ImVec2 b_start(center.x, center.y + total_gap);
    ImVec2 b_end(center.x, center.y + total_gap + sz);

    // Line 4: Top
    ImVec2 t_start(center.x, center.y - total_gap - sz);
    ImVec2 t_end(center.x, center.y - total_gap);

    if (outline) {
        dl->AddLine(l_start, l_end, o_col, th + 2.f);
        dl->AddLine(r_start, r_end, o_col, th + 2.f);
        dl->AddLine(b_start, b_end, o_col, th + 2.f);
        if (style != 3) dl->AddLine(t_start, t_end, o_col, th + 2.f);
    }

    dl->AddLine(l_start, l_end, c_col, th);
    dl->AddLine(r_start, r_end, c_col, th);
    dl->AddLine(b_start, b_end, c_col, th);
    if (style != 3) dl->AddLine(t_start, t_end, c_col, th);
}





