#pragma once
#include "imgui.h"
#include "imgui_internal.h"

namespace font
{
	inline ImFont* inter_regular = nullptr;
	inline ImFont* inter_medium = nullptr;
	inline ImFont* inter_semibold = nullptr;
	inline ImFont* inter_bold = nullptr;
	inline ImFont* logo_font = nullptr;
	inline ImFont* icon_font = nullptr;
	inline ImFont* small_font = nullptr;
	inline ImFont* big_font = nullptr;
	inline ImFont* regular_l = nullptr;
	inline ImFont* regular_m = nullptr;
	inline ImFont* regular_s = nullptr;
	inline ImFont* semibold_s = nullptr;
	inline ImFont* icomoon_logo = nullptr;
	inline ImFont* description_font = nullptr;
	inline ImFont* esp_font = nullptr;
	inline ImFont* default_r = nullptr;
	inline ImFont* default_m = nullptr;
	inline ImFont* default_s = nullptr;
	inline ImFont* icomoon_page = nullptr;
	inline ImFont* s_inter_semibold = nullptr;
	inline ImFont* icon_notify = nullptr;
}

inline static float current_scroll = 0.f;

namespace utils
{
	inline float CalculateTextWidthWithoutColorCodes(const ImFont* font, const char* text_begin, const char* text_end = nullptr) {
		if (!text_end)
			text_end = text_begin + strlen(text_begin);

		float text_width = 0.0f;
		const char* s = text_begin;

		while (s < text_end) {
			if (*s == '^' && (s + 1) < text_end && *(s + 1) >= '0' && *(s + 1) <= '9') {
				s += 2;
				continue;
			}

			unsigned int c = (unsigned int)*s;
			if (c < 0x80) {
				s += 1;
			}
			else {
				s += ImTextCharFromUtf8(&c, s, text_end);
				if (c == 0)
					break;
			}

			const ImFontGlyph* glyph = font ? font->FindGlyph((ImWchar)c) : nullptr;
			if (glyph) {
				text_width += glyph->AdvanceX;
			}
		}

		return text_width;
	}

	inline ImColor GetColorWithAlpha(const ImColor& color, float alpha)
	{
		return ImColor(color.Value.x, color.Value.y, color.Value.z, alpha);
	}

	inline ImVec4 GetColorWithAlpha(const ImVec4& color, float alpha)
	{
		return ImVec4(color.x, color.y, color.z, alpha);
	}

	inline ImVec2 center_text(ImVec2 min, ImVec2 max, const char* text)
	{
		ImVec2 sz = ImGui::CalcTextSize(text);
		return ImVec2(min.x + (max.x - min.x - sz.x) * 0.5f, min.y + (max.y - min.y - sz.y) * 0.5f);
	}

	inline ImColor GetDarkColor(const ImColor& color)
	{
		float r, g, b, a;
		r = color.Value.x;
		g = color.Value.y;
		b = color.Value.z;
		a = 255;

		float darkPercentage = 0.2f;
		float darkR = r * darkPercentage;
		float darkG = g * darkPercentage;
		float darkB = b * darkPercentage;

		return ImColor(darkR, darkG, darkB, a);
	}
	inline ImVec4 ImColorToImVec4(const ImColor& color)
	{
		return ImVec4(color.Value.x, color.Value.y, color.Value.z, color.Value.w);
	}
}

static ImColor ImLerpColor(const ImColor& a, const ImColor& b, float t)
{
	t = ImClamp(t, 0.0f, 1.0f);
	float inv = 1.0f - t;
	return ImColor(
		a.Value.x * inv + b.Value.x * t,
		a.Value.y * inv + b.Value.y * t,
		a.Value.z * inv + b.Value.z * t,
		a.Value.w * inv + b.Value.w * t
	);
}

inline static bool bTheme = false;

inline namespace c
{
	inline int selected_font = 0;
	inline int anim_offset_side = 0;
	inline static bool lang = false;

	inline ImColor accent_primary = ImColor(255, 255, 255, 255);
	inline ImColor accent_secondary = ImColor(0, 0, 0, 255);
	inline ImColor accent_teal = ImColor(200, 200, 200, 255);
	inline ImColor dark_color = ImColor(8, 10, 16, 255);
	inline ImColor second_color = ImColor(0, 0, 0, 255);
	inline ImColor background_color = ImColor(2, 3, 5, 255);
	inline ImColor stroke_color = ImColor(255, 255, 255, 18);
	inline ImColor window_bg_color = ImColor(5, 6, 10, 245);

	inline ImVec4 separator = ImColor(255, 255, 255, 18);

	inline namespace anim
	{
		inline float   speed = 1.0f;
		inline ImColor active = ImColor(255, 255, 255, 255);
		inline ImColor secondary = ImColor(0, 0, 0, 255);
		inline ImColor default_col = ImColor(18, 22, 32, 220);
		inline bool    gradient_anim = false;
		inline float   gradient_anim_speed = 0.08f;

		inline float GetGradientAnimPhase()
		{
			if (!gradient_anim)
				return 0.f;
			return (float)ImGui::GetTime() * gradient_anim_speed;
		}
	}

	inline namespace bg
	{
		inline ImVec4 background = ImColor(6, 8, 12, 255);
		inline ImVec2 window_size = ImVec2(890, 540);
		inline float   rounding = 16.f;
		inline ImRect menu_bb;
	}

	inline namespace child
	{
		inline ImVec4 top_bg = ImColor(255, 255, 255, 8);
		inline ImVec4 background = ImColor(12, 16, 24, 200);
		inline ImVec4 stroke = ImColor(255, 255, 255, 15);
		inline float   rounding = 12.f;
	}

	namespace page
	{
		inline ImVec4 background_active = ImColor(255, 255, 255, 18);
		inline ImVec4 background = ImColor(255, 255, 255, 6);
		inline ImVec4 text_hov = ImColor(255, 255, 255, 255);
		inline ImVec4 text = ImColor(200, 200, 210, 255);
		inline float   rounding = 10.f;
	}

	inline namespace elements
	{
		inline ImVec4 background_hovered = ImColor(255, 255, 255, 14);
		inline ImVec4 background = ImColor(14, 18, 26, 200);
		inline float   rounding = 8.f;
	}

	inline namespace checkbox
	{
		inline ImVec4 mark = ImColor(0, 240, 255, 255);
	}

	inline namespace text
	{
		inline namespace label
		{
			inline ImColor active = ImColor(255, 255, 255, 255);
			inline ImColor hovered = ImColor(220, 220, 230, 255);
			inline ImColor default_col = ImColor(160, 160, 175, 255);
		}
		inline namespace description
		{
			inline ImColor active = ImColor(180, 180, 195, 255);
			inline ImColor hovered = ImColor(150, 150, 165, 255);
			inline ImColor default_col = ImColor(110, 110, 125, 255);
		}
	}
}


inline void UpdateTheme(bool dark_theme, float t)
{
	c::accent_primary = ImLerpColor(
		c::accent_primary,
		dark_theme ? ImColor(0, 240, 255, 255) : ImColor(168, 85, 247, 255),
		t);

	c::second_color = ImLerpColor(
		c::second_color,
		dark_theme ? ImColor(18, 22, 32, 220) : ImColor(14, 18, 26, 220),
		t);

	c::anim::default_col = ImLerpColor(
		c::anim::default_col,
		dark_theme ? ImColor(18, 22, 32, 220) : ImColor(14, 18, 26, 220),
		t);

	c::background_color = ImLerpColor(
		c::background_color,
		dark_theme ? ImColor(8, 10, 16, 255) : ImColor(6, 8, 12, 255),
		t);

	c::stroke_color = ImLerpColor(
		c::stroke_color,
		dark_theme ? ImColor(255, 255, 255, 18) : ImColor(255, 255, 255, 12),
		t);

	c::window_bg_color = ImLerpColor(
		c::window_bg_color,
		dark_theme ? ImColor(255, 255, 255, 190) : ImColor(8, 8, 12, 200),
		t);

	c::separator = ImLerpColor(
		c::separator,
		dark_theme ? ImColor(0, 0, 0, 25) : ImColor(255, 255, 255, 20),
		t);

	c::bg::background = ImLerpColor(
		c::bg::background,
		dark_theme ? ImColor(248, 248, 252, 200) : ImColor(4, 4, 6, 255),
		t);

	c::child::background = ImLerpColor(
		c::child::background,
		dark_theme ? ImColor(0, 0, 0, 10) : ImColor(255, 255, 255, 8),
		t);

	c::child::stroke = ImLerpColor(
		c::child::stroke,
		dark_theme ? ImColor(0, 0, 0, 20) : ImColor(255, 255, 255, 22),
		t);

	c::page::background_active = ImLerpColor(
		c::page::background_active,
		dark_theme ? ImColor(0, 0, 0, 15) : ImColor(255, 255, 255, 18),
		t);

	c::page::background = ImLerpColor(
		c::page::background,
		dark_theme ? ImColor(0, 0, 0, 8) : ImColor(255, 255, 255, 6),
		t);

	c::page::text_hov = ImLerpColor(
		c::page::text_hov,
		dark_theme ? ImColor(20, 20, 30, 255) : ImColor(255, 255, 255, 255),
		t);
	c::page::text = ImLerpColor(
		c::page::text,
		dark_theme ? ImColor(40, 40, 50, 255) : ImColor(200, 200, 210, 255),
		t);

	c::elements::background_hovered = ImLerpColor(
		c::elements::background_hovered,
		dark_theme ? ImColor(0, 0, 0, 12) : ImColor(255, 255, 255, 14),
		t);

	c::elements::background = ImLerpColor(
		c::elements::background,
		dark_theme ? ImColor(0, 0, 0, 8) : ImColor(255, 255, 255, 8),
		t);

	c::checkbox::mark = ImLerpColor(
		c::checkbox::mark,
		dark_theme ? ImColor(220, 40, 40, 255) : ImColor(255, 55, 55, 255),
		t);

	c::text::label::active = ImLerpColor(
		c::text::label::active,
		dark_theme ? ImColor(15, 15, 20, 255) : ImColor(255, 255, 255, 255),
		t);
	c::text::label::hovered = ImLerpColor(
		c::text::label::hovered,
		dark_theme ? ImColor(40, 40, 50, 255) : ImColor(220, 220, 230, 255),
		t);
	c::text::label::default_col = ImLerpColor(
		c::text::label::default_col,
		dark_theme ? ImColor(80, 80, 95, 255) : ImColor(160, 160, 175, 255),
		t);

	c::text::description::active = ImLerpColor(
		c::text::description::active,
		dark_theme ? ImColor(60, 60, 75, 255) : ImColor(180, 180, 195, 255),
		t);
	c::text::description::hovered = ImLerpColor(
		c::text::description::hovered,
		dark_theme ? ImColor(80, 80, 95, 255) : ImColor(150, 150, 165, 255),
		t);
	c::text::description::default_col = ImLerpColor(
		c::text::description::default_col,
		dark_theme ? ImColor(100, 100, 115, 255) : ImColor(110, 110, 125, 255),
		t);
}
inline bool tab_want_to_change;

