#pragma once
#include <GLES3/gl3.h>
#include <GLES2/gl2.h>

GLuint GetMirageLogoTexture();
int GetMirageLogoWidth();
int GetMirageLogoHeight();
