#define IMGUI_DEFINE_MATH_OPERATORS   // enable ImVec2 +/- ops for vandal_widgets.hpp
#include "ESP.h"
#include "ActorPipeline.h"
#include "UE4Helper.h"
#include "SDK/SDK.hpp"
#include "Config.h"
#include "CrashLog.h"
#include "Memory/Tools.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_internal.h"
#include "UI/Lang.h"
#include "UI/vandal_widgets.hpp"   // DrawLetterWaveText: menu text shimmer (c::anim theme colour)
#include <cmath>
#include <string>
#include <algorithm>
#include <cinttypes>
#include <unordered_map>
#include <cstdio>
#include <ctime>
#include <sys/stat.h>

#ifndef CONST_PI
#define CONST_PI 3.14159265358979323846f
#endif

namespace ESP {

    // ── Centralised colour table ──────────────────────────────────────────────
    // Visibility-aware colours per entity type:
    //   PLAYER  — открытый(visible)=Red      за преградой(hidden)=Black
    //   BOT     — открытый=Green             за преградой=White
    //   ACTOR   — открытый=Yellow            за преградой=Blue
    //   TEAM    — Blue always
    namespace Colors {
        // TEAMMATE
        static constexpr ImU32 kTeammate     = IM_COL32(  0, 170, 255, 255);
        static constexpr ImU32 kTeammateFade = IM_COL32(  0, 170, 255, 240);
        // PLAYER
        static constexpr ImU32 kPlayerVis    = IM_COL32(255,  40,  40, 255); // red    — open
        static constexpr ImU32 kPlayerVisFade= IM_COL32(255,  40,  40, 240);
        static constexpr ImU32 kPlayerHid    = IM_COL32(180,  60, 240, 255); // purple — behind wall
        static constexpr ImU32 kPlayerHidFade= IM_COL32(180,  60, 240, 220);
        // BOT
        static constexpr ImU32 kBotVis       = IM_COL32( 60, 220,  60, 255); // green — open
        static constexpr ImU32 kBotVisFade   = IM_COL32( 60, 220,  60, 240);
        static constexpr ImU32 kBotHid       = IM_COL32(220, 220, 220, 255); // white — behind wall
        static constexpr ImU32 kBotHidFade   = IM_COL32(220, 220, 220, 200);
        // ACTOR / NPC
        static constexpr ImU32 kNPCVis       = IM_COL32(255, 215,  30, 255); // yellow — open
        static constexpr ImU32 kNPCVisFade   = IM_COL32(255, 215,  30, 240);
        static constexpr ImU32 kNPCHid       = IM_COL32( 50, 100, 255, 255); // blue   — behind wall
        static constexpr ImU32 kNPCHidFade   = IM_COL32( 50, 100, 255, 220);
        static constexpr ImU32 kNPCBar       = IM_COL32( 80, 220, 220, 255); // cyan HP bar (always)
        // Aliases used by counter and UpAlert label text
        static constexpr ImU32 kPlayerLabel  = kPlayerVis;
        static constexpr ImU32 kBotLabel     = kBotVis;
        static constexpr ImU32 kNPCLabel     = kNPCVis;
    }

    // Returns colour for boxes, skeleton lines, snap lines, radar dots, and arrows.
    // fade=true → slightly lower alpha for skeleton/arrow layers.
    static ImU32 GetEntityColor(const PlayerData& p, bool fade = false) {
        if (p.isTeammate)
            return fade ? Colors::kTeammateFade : Colors::kTeammate;
        if (p.isNPC)
            return p.isVisible
                ? (fade ? Colors::kNPCVisFade  : Colors::kNPCVis)
                : (fade ? Colors::kNPCHidFade  : Colors::kNPCHid);
        if (p.isBot)
            return p.isVisible
                ? (fade ? Colors::kBotVisFade  : Colors::kBotVis)
                : (fade ? Colors::kBotHidFade  : Colors::kBotHid);
        // PLAYER
        return p.isVisible
            ? (fade ? Colors::kPlayerVisFade : Colors::kPlayerVis)
            : (fade ? Colors::kPlayerHidFade : Colors::kPlayerHid);
    }

    // Localised "<n>m" in logical order (pass composed strings through Lang::Display).
    static std::string DistText(int meters) {
        return std::to_string(meters) + Lang::Raw("m", "м");
    }

    // Faction byte → name, mirroring the upstream project's EFactionType ordering.
    // Our build exposes ASGCharacter::FactionType (uint8_t @ 0x15E8) directly.
    static const char* FactionName(uint8_t id) {
        switch (id) {
            case 1:  return "PMC";
            case 2:  return "SCAV";
            case 3:  return "PlayerScav";
            case 4:  return "Rebel";
            case 5:  return "Lake";
            case 6:  return "Gangster";
            case 7:  return "Kurt";
            case 8:  return "Navy";
            case 9:  return "Blackgold";
            case 10: return "Gnesk";
            case 11: return "MadDog";
            default: return "";
        }
    }

    // Cleans up a player nickname: strips control characters and trims spaces
    static std::string CleanPlayerName(const std::string& str) {
        if (str.empty()) return str;
        std::string clean;
        clean.reserve(str.size());
        for (unsigned char c : str) {
            // Keep printable ASCII (0x20..0x7E) and UTF-8 multi-byte bytes (>= 0x80)
            if ((c >= 0x20 && c != 0x7F) || c >= 0x80) {
                clean.push_back(static_cast<char>(c));
            }
        }
        while (!clean.empty() && clean.front() == ' ') clean.erase(clean.begin());
        while (!clean.empty() && clean.back() == ' ') clean.pop_back();
        return clean.empty() ? str : clean;
    }

    // Colours are fixed defaults now (custom-colour UI removed):
    //   PLAYER open=red covered=purple   BOT open=green covered=white
    static bool UseCustomColors(const PlayerData&) {
        return false;
    }
    // Skeleton bones follow the entity's own visibility colours:
    //   PLAYER open=red  covered=purple   BOT open=green covered=white
    //   ACTOR  open=yellow covered=blue    TEAM blue always
    static ImU32 BoneOpenColor(const PlayerData& p) {
        if (p.isTeammate) return Colors::kTeammate;
        if (p.isNPC)      return Colors::kNPCVis;
        if (p.isBot)      return ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_bot_skel_vis);
        return ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_player_skel_vis);
    }
    static ImU32 BoneCoveredColor(const PlayerData& p) {
        if (p.isTeammate) return Colors::kTeammate;
        if (p.isNPC)      return Colors::kNPCHid;
        if (p.isBot)      return ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_bot_skel_hid);
        return ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_player_skel_hid);
    }

    // Health-bar style index:
    //   0 = ALL ENEMIES (PLAYER, BOT, NPC) — vertical gradient bar strip
    //   3 = TEAM                           — vertical solid blue bar strip
    static int GetHealthBarStyle(const PlayerData& p) {
        if (p.isTeammate) return 3;
        return 0; // All enemies (Player, Bot, NPC) use style 0
    }

    // ── Enemy counter (top-centre) ────────────────────────────────────────────
    // Shows live counts: PLAYER  BOT  ACTOR — each in its own open-state colour.
    static void DrawCounters(ImDrawList* drawList,
                             const std::vector<PlayerData>& enemies,
                             int screenWidth) {
        if (!drawList) return;
        int nPlayer = 0, nBot = 0;
        for (const auto& e : enemies) {
            if (e.isTeammate) continue;
            if (e.isBot || e.isNPC) ++nBot;
            else                    ++nPlayer;
        }

        const std::string sStr = Lang::Display(std::string(Lang::Raw("PLAYER", "ИГРОКИ")) + ": " + std::to_string(nPlayer) + "  ");
        const std::string bStr = Lang::Display(std::string(Lang::Raw("BOT", "БОТЫ")) + ": " + std::to_string(nBot));
        const char* sPart = sStr.c_str();
        const char* bPart = bStr.c_str();

        const float wS = ImGui::CalcTextSize(sPart).x;
        const float wB = ImGui::CalcTextSize(bPart).x;
        const float totalW = wS + wB;
        const float textH  = ImGui::CalcTextSize("A").y;

        (void)textH;
        const float cx = ((float)screenWidth - totalW) * 0.5f;
        const float cy = 12.0f;

        // No frame/pill. The counter has its OWN animated colour pair (independent
        // of the menu theme): it shimmers between col_counter_a and col_counter_b,
        // both editable in the menu's colour section.
        const ImU32 cA = ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_counter_a);
        const ImU32 cB = ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_counter_b);
        fade_text_smooth(drawList, sPart, ImVec2(cx,      cy), cA, cB);
        fade_text_smooth(drawList, bPart, ImVec2(cx + wS, cy), cA, cB);
    }
    // ─────────────────────────────────────────────────────────────────────────

    std::vector<PlayerData> g_Enemies;

    static constexpr int kSkeletonBoneCount = 16;

    // Cache real joint positions in the actor's root frame, never screen pixels.
    // This follows movement/rotation while the animation buffer is briefly empty.
    struct SkeletonFrame {
        SDK::FVector origin;
        SDK::FVector xAxis{1,0,0}, yAxis{0,1,0}, zAxis{0,0,1};
        SDK::FVector scale{1,1,1};

        bool IsValid() const {
            return std::isfinite(origin.SizeSquared()) && std::isfinite(xAxis.SizeSquared()) &&
                std::isfinite(yAxis.SizeSquared()) && std::isfinite(zAxis.SizeSquared()) &&
                std::abs(xAxis.SizeSquared() - 1.0f) < 0.05f &&
                std::abs(yAxis.SizeSquared() - 1.0f) < 0.05f &&
                std::abs(zAxis.SizeSquared() - 1.0f) < 0.05f &&
                std::abs(xAxis.Dot(yAxis)) < 0.05f && std::abs(xAxis.Dot(zAxis)) < 0.05f &&
                std::abs(yAxis.Dot(zAxis)) < 0.05f && std::isfinite(scale.SizeSquared()) &&
                std::abs(scale.X) > 0.0001f && std::abs(scale.X) <= 100.0f &&
                std::abs(scale.Y) > 0.0001f && std::abs(scale.Y) <= 100.0f &&
                std::abs(scale.Z) > 0.0001f && std::abs(scale.Z) <= 100.0f;
        }
        SDK::FVector ToLocal(const SDK::FVector& position) const {
            const auto delta = position - origin;
            return {delta.Dot(xAxis) / scale.X, delta.Dot(yAxis) / scale.Y, delta.Dot(zAxis) / scale.Z};
        }
        SDK::FVector ToWorld(const SDK::FVector& local) const {
            return origin + xAxis * (local.X * scale.X) + yAxis * (local.Y * scale.Y) + zAxis * (local.Z * scale.Z);
        }
    };

    struct SkeletonPose {
        SDK::FVector local[kSkeletonBoneCount]{};
        double sampledAt[kSkeletonBoneCount]{};
        bool valid[kSkeletonBoneCount]{};
        SDK::FVector lastRoot;
        bool hasRoot = false;

        bool Resolve(SDK::FVector* positions, bool fresh, const SkeletonFrame& frame, double now) {
            if (!frame.IsValid() || !std::isfinite(now)) {
                *this = {};
                for (int i = 0; i < kSkeletonBoneCount; ++i) positions[i] = {};
                return false;
            }
            // Teleports must not carry a pose from a different location/spawn.
            if (hasRoot && (frame.origin - lastRoot).SizeSquared() > 800.0f * 800.0f) *this = {};
            lastRoot = frame.origin;
            hasRoot = true;
            bool any = false;
            for (int i = 0; i < kSkeletonBoneCount; ++i) {
                const auto& p = positions[i];
                const bool measured = fresh && std::isfinite(p.SizeSquared()) && p.SizeSquared() > 0.001f &&
                    (p - frame.origin).SizeSquared() <= 600.0f * 600.0f;
                if (measured) {
                    local[i] = frame.ToLocal(p);
                    sampledAt[i] = now;
                    valid[i] = true;
                } else if (valid[i] && now >= sampledAt[i] && now - sampledAt[i] <= 0.7) {
                    // Smooth fallback allows pose to persist during temporary animation LOD hitches (max 0.7s)
                    positions[i] = frame.ToWorld(local[i]);
                    if (!std::isfinite(positions[i].SizeSquared()) ||
                        (positions[i] - frame.origin).SizeSquared() > 600.0f * 600.0f) valid[i] = false;
                } else {
                    valid[i] = false;
                }
                if (!valid[i]) positions[i] = {};
                any |= valid[i];
            }
            return any;
        }
    };

    struct SkeletonObjectId {
        const SDK::UObject* object = nullptr;
        int32_t index = -1;
        int32_t serial = 0;
        bool operator==(const SkeletonObjectId& other) const {
            return object == other.object && index == other.index && serial == other.serial;
        }
    };

    static bool GetSkeletonObjectId(const SDK::UObject* object, SkeletonObjectId& id) {
        if (!Tools::IsPtrValid(object) || !Tools::IsReadable(object, sizeof(SDK::UObject)) ||
            !Tools::IsPtrValid(SDK::UObject::GObjects)) return false;
        const auto item = SDK::UObject::GObjects->GetItemByIndex(object->InternalIndex);
        if (!item || item->Object != object || item->IsUnreachable() || item->IsPendingKill()) return false;
        id = {object, object->InternalIndex, item->SerialNumber};
        return true;
    }

    struct SkeletonCacheEntry {
        SkeletonObjectId actor, mesh, root;
        SkeletonPose pose;
    };
    static std::unordered_map<SDK::ASGCharacter*, SkeletonCacheEntry> s_SkeletonCache;

    // Clip a LINE, not individual endpoints: a joint outside the viewport or
    // behind the near plane must not remove the visible part of its limb.
    static bool ProjectSkeletonSegment(SDK::FVector a, SDK::FVector b,
                                       const UE4Helper::ScreenProjection& projection,
                                       SDK::FVector2D& start, SDK::FVector2D& end) {
        if (!projection.Valid || projection.Width <= 0 || projection.Height <= 0) return false;
        const float da = (a - projection.Location).Dot(projection.Forward);
        const float db = (b - projection.Location).Dot(projection.Forward);
        constexpr float nearDepth = 1.01f;
        if (!std::isfinite(da) || !std::isfinite(db) || (da < nearDepth && db < nearDepth)) return false;
        if (da < nearDepth) a = a + (b - a) * ((nearDepth - da) / (db - da));
        else if (db < nearDepth) b = b + (a - b) * ((nearDepth - db) / (da - db));
        if (!UE4Helper::WorldToScreen(a, start, projection) || !UE4Helper::WorldToScreen(b, end, projection)) return false;
        const auto delta = end - start;
        if (!std::isfinite(delta.X) || !std::isfinite(delta.Y)) return false;
        float t0 = 0.0f, t1 = 1.0f;
        const auto clip = [&](float p, float q) {
            if (std::abs(p) < 0.000001f) return q >= 0.0f;
            const float t = q / p;
            if (p < 0.0f) { if (t > t1) return false; t0 = std::max(t0, t); }
            else { if (t < t0) return false; t1 = std::min(t1, t); }
            return true;
        };
        if (!clip(-delta.X, start.X) || !clip(delta.X, projection.Width - start.X) ||
            !clip(-delta.Y, start.Y) || !clip(delta.Y, projection.Height - start.Y)) return false;
        end = start + delta * t1;
        start = start + delta * t0;
        return true;
    }

    static inline ImU32 LerpColor(ImU32 c1, ImU32 c2, float t) {
        t = std::clamp(t, 0.0f, 1.0f);
        const int r1 = (c1 >> IM_COL32_R_SHIFT) & 0xFF;
        const int g1 = (c1 >> IM_COL32_G_SHIFT) & 0xFF;
        const int b1 = (c1 >> IM_COL32_B_SHIFT) & 0xFF;
        const int a1 = (c1 >> IM_COL32_A_SHIFT) & 0xFF;

        const int r2 = (c2 >> IM_COL32_R_SHIFT) & 0xFF;
        const int g2 = (c2 >> IM_COL32_G_SHIFT) & 0xFF;
        const int b2 = (c2 >> IM_COL32_B_SHIFT) & 0xFF;
        const int a2 = (c2 >> IM_COL32_A_SHIFT) & 0xFF;

        const int r = r1 + (int)((r2 - r1) * t);
        const int g = g1 + (int)((g2 - g1) * t);
        const int b = b1 + (int)((b2 - b1) * t);
        const int a = a1 + (int)((a2 - a1) * t);

        return IM_COL32(r, g, b, a);
    }

    static inline ImU32 GetHealthGradientColor(float t) {
        t = std::clamp(t, 0.0f, 1.0f);
        static constexpr ImU32 kRed    = IM_COL32(235, 45, 45, 255);
        static constexpr ImU32 kYellow = IM_COL32(245, 205, 35, 255);
        static constexpr ImU32 kGreen  = IM_COL32(45, 230, 75, 255);
        if (t <= 0.5f) {
            return LerpColor(kRed, kYellow, t * 2.0f);
        } else {
            return LerpColor(kYellow, kGreen, (t - 0.5f) * 2.0f);
        }
    }

    static void DrawGradientBar(ImDrawList* drawList, float x, float y, float width, float height,
                                float pct, bool isVertical) {
        if (!drawList || pct <= 0.0f) return;
        pct = std::clamp(pct, 0.0f, 1.0f);

        static constexpr ImU32 kRed    = IM_COL32(235, 45, 45, 255);
        static constexpr ImU32 kYellow = IM_COL32(245, 205, 35, 255);

        if (isVertical) {
            const float y_bot  = y + height;
            const float y_mid  = y + height * 0.5f;
            const float y_fill = y + height - height * pct;

            if (pct > 0.5f) {
                drawList->AddRectFilledMultiColor(
                    ImVec2(x, y_mid), ImVec2(x + width, y_bot),
                    kYellow, kYellow, kRed, kRed
                );
                const ImU32 col_top = GetHealthGradientColor(pct);
                drawList->AddRectFilledMultiColor(
                    ImVec2(x, y_fill), ImVec2(x + width, y_mid),
                    col_top, col_top, kYellow, kYellow
                );
            } else {
                const ImU32 col_top = GetHealthGradientColor(pct);
                drawList->AddRectFilledMultiColor(
                    ImVec2(x, y_fill), ImVec2(x + width, y_bot),
                    col_top, col_top, kRed, kRed
                );
            }
        } else {
            const float x_left = x;
            const float x_mid  = x + width * 0.5f;
            const float x_fill = x + width * pct;

            if (pct > 0.5f) {
                drawList->AddRectFilledMultiColor(
                    ImVec2(x_left, y), ImVec2(x_mid, y + height),
                    kRed, kYellow, kYellow, kRed
                );
                const ImU32 col_right = GetHealthGradientColor(pct);
                drawList->AddRectFilledMultiColor(
                    ImVec2(x_mid, y), ImVec2(x_fill, y + height),
                    kYellow, col_right, col_right, kYellow
                );
            } else {
                const ImU32 col_right = GetHealthGradientColor(pct);
                drawList->AddRectFilledMultiColor(
                    ImVec2(x_left, y), ImVec2(x_fill, y + height),
                    kRed, col_right, col_right, kRed
                );
            }
        }
    }

    void DrawHealthBar(ImDrawList* drawList, float x, float y, float width, float height,
                       float health, float maxHealth, bool isVertical, int style) {
        if (!drawList || !std::isfinite(health) || !std::isfinite(maxHealth) ||
            health < 0.0f || maxHealth <= 0.0f) return;

        const float pct = std::clamp(health / maxHealth, 0.0f, 1.0f);

        // ── Style 0 / 1 / 2: ALL ENEMIES (Player, Bot, NPC) — gradient bar strip ─
        if (style != 3) {
            drawList->AddRectFilled(ImVec2(x-1, y-1), ImVec2(x+width+1, y+height+1), IM_COL32(10,10,10,190), 2.0f);
            drawList->AddRect(     ImVec2(x-1, y-1), ImVec2(x+width+1, y+height+1), IM_COL32(0,0,0,220),    2.0f);
            DrawGradientBar(drawList, x, y, width, height, pct, isVertical);

            const ImU32 textCol = GetHealthGradientColor(pct);
            char buf[16]; snprintf(buf, sizeof(buf), "%.0f", health);
            if (isVertical) {
                const float fillH = height * pct;
                if (pct < 0.999f) {
                    drawList->AddText(ImVec2(x - 22.0f, y + height - fillH - 6.0f), textCol, buf);
                }
            } else {
                drawList->AddText(ImVec2(x + width + 4.0f, y - 3.0f), textCol, buf);
            }
            return;
        }

        // ── Style 3: TEAM — solid blue (vertical or horizontal) ─────────────
        {
            static constexpr ImU32 kBlue = IM_COL32(0, 150, 255, 255);
            drawList->AddRectFilled(ImVec2(x-1, y-1), ImVec2(x+width+1, y+height+1), IM_COL32(10,10,10,170), 2.0f);
            drawList->AddRect(     ImVec2(x-1, y-1), ImVec2(x+width+1, y+height+1), IM_COL32(0,0,0,200),    2.0f);
            if (isVertical) {
                const float fillH = height * pct;
                drawList->AddRectFilled(ImVec2(x, y + height - fillH), ImVec2(x + width, y + height), kBlue, 1.0f);
            } else {
                const float fillW = width * pct;
                drawList->AddRectFilled(ImVec2(x, y), ImVec2(x + fillW, y + height), kBlue, 1.0f);
            }
        }
    }

    void DrawPlayerBox(ImDrawList* drawList, const PlayerData& player) {
        if (!drawList || !player.onScreen) return;
        const float x  = player.boxLeft;
        const float y  = player.boxTop;
        const float bw = player.boxWidth;
        const float bh = player.boxHeight;

        const bool  custom  = UseCustomColors(player);
        const ImU32 col     = custom ? (player.isVisible ? g_Config.col_box_vis : g_Config.col_box_hid)
                                     : GetEntityColor(player);
        const ImU32 lineCol = custom ? (player.isVisible ? g_Config.col_line_vis : g_Config.col_line_hid)
                                     : GetEntityColor(player);
        const int   hbStyle = GetHealthBarStyle(player);

        // ── Corner Box (Уголки для всех сущностей) ──────────────────────────
        if (g_Config.esp_box) {
            const float cLen = std::max(std::min(bw, bh) * 0.25f, 4.0f);
            const float t = g_Config.esp_box_thickness;
            const ImU32 shadowCol = IM_COL32(0, 0, 0, 180);

            // Black outline / shadow for contrast
            // TL
            drawList->AddLine(ImVec2(x,        y),        ImVec2(x + cLen, y),        shadowCol, t + 1.5f);
            drawList->AddLine(ImVec2(x,        y),        ImVec2(x,        y + cLen), shadowCol, t + 1.5f);
            // TR
            drawList->AddLine(ImVec2(x + bw,   y),        ImVec2(x + bw - cLen, y),   shadowCol, t + 1.5f);
            drawList->AddLine(ImVec2(x + bw,   y),        ImVec2(x + bw,   y + cLen), shadowCol, t + 1.5f);
            // BL
            drawList->AddLine(ImVec2(x,        y + bh),   ImVec2(x + cLen, y + bh),   shadowCol, t + 1.5f);
            drawList->AddLine(ImVec2(x,        y + bh),   ImVec2(x,        y + bh - cLen), shadowCol, t + 1.5f);
            // BR
            drawList->AddLine(ImVec2(x + bw,   y + bh),   ImVec2(x + bw - cLen, y + bh),   shadowCol, t + 1.5f);
            drawList->AddLine(ImVec2(x + bw,   y + bh),   ImVec2(x + bw,   y + bh - cLen), shadowCol, t + 1.5f);

            // Primary colored corner lines
            // TL
            drawList->AddLine(ImVec2(x,        y),        ImVec2(x + cLen, y),        col, t);
            drawList->AddLine(ImVec2(x,        y),        ImVec2(x,        y + cLen), col, t);
            // TR
            drawList->AddLine(ImVec2(x + bw,   y),        ImVec2(x + bw - cLen, y),   col, t);
            drawList->AddLine(ImVec2(x + bw,   y),        ImVec2(x + bw,   y + cLen), col, t);
            // BL
            drawList->AddLine(ImVec2(x,        y + bh),   ImVec2(x + cLen, y + bh),   col, t);
            drawList->AddLine(ImVec2(x,        y + bh),   ImVec2(x,        y + bh - cLen), col, t);
            // BR
            drawList->AddLine(ImVec2(x + bw,   y + bh),   ImVec2(x + bw - cLen, y + bh),   col, t);
            drawList->AddLine(ImVec2(x + bw,   y + bh),   ImVec2(x + bw,   y + bh - cLen), col, t);
        }

        // ── Health bar (Бар / Полоса для всех) ──────────────────────────────
        if (g_Config.esp_health) {
            const float barW = 4.0f;
            const float barX = x - 6.0f;
            const float barY = y;
            const float barH = bh;

            if (g_Config.esp_health_type == 0) {
                // Numeric ("Цифры")
                char buf[16]; snprintf(buf, sizeof(buf), "%.0f", player.health);
                const float maxH = player.maxHealth > 0.0f ? player.maxHealth : 100.0f;
                const float pct = std::clamp(player.health / maxH, 0.0f, 1.0f);
                const ImU32 hpCol = player.isTeammate ? IM_COL32(0, 150, 255, 255) : GetHealthGradientColor(pct);
                drawList->AddText(ImVec2(x - 24.0f, y - 2.0f), hpCol, buf);
            } else {
                // Bar ("Полоса"): unified vertical health bar strip for all entities
                DrawHealthBar(drawList, barX, barY, barW, barH,
                              player.health, player.maxHealth, true, hbStyle);
            }
        }

        // ── Head dot ─────────────────────────────────────────────────────────
        if (g_Config.esp_head_dot) {
            // Head dot: use the same visibility-aware entity color
            ImU32 dotCol;
            if (player.boneVisLive && !player.isTeammate)
                dotCol = (player.boneVisible & 1u) ? BoneOpenColor(player) : BoneCoveredColor(player);
            else if (custom)
                dotCol = player.isVisible ? g_Config.col_skel_vis : g_Config.col_skel_hid;
            else
                dotCol = GetEntityColor(player, true);
            drawList->AddCircleFilled(ImVec2(player.headScreen.X, player.headScreen.Y), 3.5f, dotCol);
            drawList->AddCircle(     ImVec2(player.headScreen.X, player.headScreen.Y), 3.5f, IM_COL32(0,0,0,200), 12, 1.0f);
        }

        // Snap line is drawn once per target by the main ESP loop, not here.

        // Name + distance are drawn once per target by the main ESP loop (just
        // the name, no [BOT]/[PLAYER] type tag), so no label is drawn here.
    }

    void DrawPlayerSkeleton(ImDrawList* drawList, SDK::ASGCharacter* actor, ImU32 color,
                            const UE4Helper::ScreenProjection& projection,
                            bool boneVisLive, uint16_t boneVisible,
                            ImU32 openColor, ImU32 coveredColor,
                            const SDK::FVector& originOverride) {
        if (!drawList || !actor || !g_Config.esp_skeleton || !projection.Valid) return;

        // Suppress skeleton rendering for actors beyond 38m.
        // The server does NOT replicate bone transforms beyond the replication bubble (~38-40m),
        // and UE4 optimization freezes the distant mesh. Drawing bones beyond 38m creates
        // flickering, laggy sliding mannequins, and stretching artifacts.
        const SDK::FVector testOrigin = originOverride.SizeSquared() > 0.001f ? originOverride : (actor->RootComponent ? actor->RootComponent->K2_GetComponentLocation() : SDK::FVector{0,0,0});
        if (testOrigin.SizeSquared() > 0.001f && UE4Helper::GetDistance(projection.Location, testOrigin) > 100.0f) {
            return;
        }

        SkeletonObjectId actorId, meshId, rootId;
        if (!GetSkeletonObjectId(actor, actorId) || actor->IsDead()) {
            s_SkeletonCache.erase(actor);
            return;
        }
        const auto mesh = actor->GetMeshComponent();
        const auto root = actor->RootComponent;
        SkeletonFrame frame;
        if (!root || !Tools::IsPtrValid(root) ||
            !Tools::IsReadable(root, sizeof(SDK::USceneComponent))) {
            return;
        }
        if (originOverride.SizeSquared() > 0.001f) {
            frame.origin = originOverride;
        } else if (!root->TryGetWorldLocation(frame.origin) || frame.origin.SizeSquared() < 0.001f) {
            return;
        }
        meshId = {mesh, 0, 0};
        rootId = {root, 0, 0};

        SDK::FVector rootLoc{0, 0, 0};
        SDK::FVector skelShift{0, 0, 0};
        if (root->TryGetWorldLocation(rootLoc) && originOverride.SizeSquared() > 0.001f) {
            skelShift = originOverride - rootLoc;
        }

        SDK::FRotator liveRot = actor->K2_GetActorRotation();
        if (std::isfinite(liveRot.Yaw) && (std::abs(liveRot.Pitch) > 0.001f || std::abs(liveRot.Yaw) > 0.001f || std::abs(liveRot.Roll) > 0.001f)) {
            frame.xAxis = liveRot.RotateVector({1,0,0});
            frame.yAxis = liveRot.RotateVector({0,1,0});
            frame.zAxis = liveRot.RotateVector({0,0,1});
            frame.scale = (root->ComponentToWorld.IsValid()) ? root->ComponentToWorld.Scale3D : SDK::FVector{1,1,1};
        } else if (root->ComponentToWorld.IsValid()) {
            const auto transform = root->ComponentToWorld;
            frame.xAxis = transform.Rotation.RotateVector({1,0,0});
            frame.yAxis = transform.Rotation.RotateVector({0,1,0});
            frame.zAxis = transform.Rotation.RotateVector({0,0,1});
            frame.scale = transform.Scale3D;
        } else {
            const auto rotation = root->RelativeRotation;
            frame.xAxis = rotation.RotateVector({1,0,0});
            frame.yAxis = rotation.RotateVector({0,1,0});
            frame.zAxis = rotation.RotateVector({0,0,1});
            frame.scale = root->RelativeScale3D;
        }
        if (frame.scale.SizeSquared() < 0.001f || !std::isfinite(frame.scale.SizeSquared())) {
            frame.scale = {1.0f, 1.0f, 1.0f};
        }
        if (!frame.IsValid()) {
            frame.xAxis = {1,0,0};
            frame.yAxis = {0,1,0};
            frame.zAxis = {0,0,1};
            frame.scale = {1,1,1};
        }
        enum EBoneId : int {
            B_HEAD = 0,
            B_NECK,
            B_SPINE,
            B_PELVIS,
            B_UPPERARM_L,
            B_LOWERARM_L,
            B_HAND_L,
            B_UPPERARM_R,
            B_LOWERARM_R,
            B_HAND_R,
            B_THIGH_L,
            B_CALF_L,
            B_FOOT_L,
            B_THIGH_R,
            B_CALF_R,
            B_FOOT_R,
            B_MAX
        };

        static_assert(B_MAX == kSkeletonBoneCount, "Skeleton cache and bone list must match");
        static const char* const s_BoneNames[B_MAX] = {
            "Head", "neck_01", "spine_03", "pelvis",
            "upperarm_l", "lowerarm_l", "hand_l",
            "upperarm_r", "lowerarm_r", "hand_r",
            "thigh_l", "calf_l", "foot_l", "thigh_r", "calf_r", "foot_r"
        };

        struct BoneConn {
            EBoneId from;
            EBoneId to;
        };

        static const BoneConn s_Connections[] = {
            {B_HEAD, B_NECK},
            {B_NECK, B_SPINE},
            {B_SPINE, B_PELVIS},
            {B_SPINE, B_UPPERARM_L},
            {B_UPPERARM_L, B_LOWERARM_L},
            {B_LOWERARM_L, B_HAND_L},
            {B_SPINE, B_UPPERARM_R},
            {B_UPPERARM_R, B_LOWERARM_R},
            {B_LOWERARM_R, B_HAND_R},
            {B_PELVIS, B_THIGH_L},
            {B_THIGH_L, B_CALF_L},
            {B_CALF_L, B_FOOT_L},
            {B_PELVIS, B_THIGH_R},
            {B_THIGH_R, B_CALF_R},
            {B_CALF_R, B_FOOT_R}
        };

        auto& cached = s_SkeletonCache[actor];
        if (!(cached.actor == actorId) || !(cached.mesh == meshId) || !(cached.root == rootId)) {
            cached = {};
            cached.actor = actorId;
            cached.mesh = meshId;
            cached.root = rootId;
        }
        SDK::FVector positions[B_MAX]{};
        // One snapshot for all joints, instead of copying the entire pose 16 times.
        const bool fresh = actor->GetBonePositions(s_BoneNames, B_MAX, positions);

        // Slide fresh bones onto the authoritative anchor (FastRep) so local pose and fallback are exact
        if (fresh && skelShift.SizeSquared() > 0.0001f) {
            for (int i = 0; i < B_MAX; ++i) {
                if (positions[i].SizeSquared() > 0.001f) {
                    positions[i] = positions[i] + skelShift;
                }
            }
        }

        if (!cached.pose.Resolve(positions, fresh, frame, ImGui::GetTime())) return;

        const float thick = g_Config.esp_skeleton_thickness;
        const ImU32 shadowCol = IM_COL32(0, 0, 0, 200);
        auto boneCol = [&](int bone) {
            return (boneVisible & (1u << bone)) ? openColor : coveredColor;
        };

        // 1. Draw connecting bones
        for (const auto& conn : s_Connections) {
            if (!cached.pose.valid[conn.from] || !cached.pose.valid[conn.to]) continue;
            SDK::FVector2D start, end;
            if (!ProjectSkeletonSegment(positions[conn.from], positions[conn.to], projection, start, end)) continue;
            const ImVec2 p1(start.X, start.Y), p2(end.X, end.Y);
            drawList->AddLine(p1, p2, shadowCol, thick + 1.2f);
            if (!boneVisLive) {
                drawList->AddLine(p1, p2, color, thick);
                continue;
            }
            // Each half takes the colour of the bone it touches.
            const ImVec2 mid((p1.x + p2.x) * 0.5f, (p1.y + p2.y) * 0.5f);
            drawList->AddLine(p1, mid, boneCol(conn.from), thick);
            drawList->AddLine(mid, p2, boneCol(conn.to), thick);
        }

        // 2. Draw articulation joints for smooth and solid skeleton junctions
        static const EBoneId s_Joints[] = {
            B_SPINE, B_PELVIS,
            B_UPPERARM_L, B_LOWERARM_L, B_HAND_L,
            B_UPPERARM_R, B_LOWERARM_R, B_HAND_R,
            B_THIGH_L, B_CALF_L, B_FOOT_L,
            B_THIGH_R, B_CALF_R, B_FOOT_R
        };
        const float dotR = std::max(1.8f, thick * 0.85f);
        for (EBoneId j : s_Joints) {
            if (!cached.pose.valid[j]) continue;
            SDK::FVector2D pt;
            if (UE4Helper::WorldToScreen(positions[j], pt, projection)) {
                const ImU32 jCol = boneVisLive ? boneCol(j) : color;
                drawList->AddCircleFilled(ImVec2(pt.X, pt.Y), dotR + 1.0f, shadowCol);
                drawList->AddCircleFilled(ImVec2(pt.X, pt.Y), dotR, jCol);
            }
        }

        // 3. Draw head with perspective-scaled adaptive radius (always rendered)
        if (cached.pose.valid[B_HEAD]) {
            SDK::FVector2D head;
            if (UE4Helper::WorldToScreen(positions[B_HEAD], head, projection)) {
                float headRadius = 4.5f + thick * 0.5f;
                if (cached.pose.valid[B_NECK]) {
                    SDK::FVector2D neck;
                    if (UE4Helper::WorldToScreen(positions[B_NECK], neck, projection)) {
                        float distHeadNeck = head.Distance(neck);
                        if (distHeadNeck >= 3.0f && distHeadNeck <= 35.0f) {
                            headRadius = std::clamp(distHeadNeck * 0.95f, 3.5f, 16.0f);
                        }
                    }
                }
                const ImU32 hCol = boneVisLive ? boneCol(B_HEAD) : color;
                drawList->AddCircle(ImVec2(head.X, head.Y), headRadius, shadowCol, 16, thick + 1.2f);
                drawList->AddCircle(ImVec2(head.X, head.Y), headRadius, hCol, 16, thick);
                drawList->AddCircleFilled(ImVec2(head.X, head.Y), std::max(2.0f, headRadius * 0.25f), hCol);
            }
        }
    }

    void DrawRadar(ImDrawList* drawList, const SDK::FVector& localPos, const SDK::FRotator& localRot, 
                   const std::vector<PlayerData>& enemies, int screenWidth, int screenHeight) {
        if (!drawList || !g_Config.esp_radar) return;
        float cx = static_cast<float>(g_Config.radar_center_x);
        float cy = static_cast<float>(g_Config.radar_center_y);
        float r = static_cast<float>(g_Config.radar_size);

        drawList->AddCircleFilled(ImVec2(cx, cy), r, IM_COL32(18, 22, 28, 190));
        drawList->AddCircle(ImVec2(cx, cy), r, IM_COL32(70, 85, 110, 220), 48, 1.5f);

        drawList->AddLine(ImVec2(cx - r, cy), ImVec2(cx + r, cy), IM_COL32(90, 105, 130, 100), 1.0f);
        drawList->AddLine(ImVec2(cx, cy - r), ImVec2(cx, cy + r), IM_COL32(90, 105, 130, 100), 1.0f);

        drawList->AddCircleFilled(ImVec2(cx, cy), 3.0f, IM_COL32(255, 255, 255, 255));

        float yawRad = localRot.Yaw * (CONST_PI / 180.0f);
        for (const auto& enemy : enemies) {
            float dx = (enemy.rootPos.X - localPos.X) / 100.0f;
            float dy = (enemy.rootPos.Y - localPos.Y) / 100.0f;
            
            float rx = dx * std::cos(-yawRad) - dy * std::sin(-yawRad);
            float ry = dx * std::sin(-yawRad) + dy * std::cos(-yawRad);

            float scale = r / static_cast<float>(g_Config.radar_distance > 0 ? g_Config.radar_distance : 150);
            float px = cx + rx * scale;
            float py = cy - ry * scale;

            float distSq = (px - cx) * (px - cx) + (py - cy) * (py - cy);
            if (distSq <= r * r) {
                const ImU32 dotColor = GetEntityColor(enemy);
                drawList->AddCircleFilled(ImVec2(px, py), 3.5f, dotColor);
                drawList->AddCircle(ImVec2(px, py), 3.5f, IM_COL32(0, 0, 0, 180), 8, 1.0f);
            }
        }
    }

    // ZOLO UpAlert (360° Off-Screen Directional Indicator)
    void DrawUpAlert(ImDrawList* drawList, const SDK::FVector& localPos, float camYaw, 
                     const std::vector<PlayerData>& enemies, int screenWidth, int screenHeight) {
        if (!drawList || !g_Config.esp_offscreen || enemies.empty()) return;

        float centerX = (float)screenWidth * 0.5f;
        float centerY = (float)screenHeight * 0.5f;
        float alertRadius = std::min(centerX, centerY) * 0.58f;

        for (const auto& enemy : enemies) {
            // Skip teammates in UpAlert — they are friendly
            if (enemy.isTeammate) continue;
            if (enemy.onScreen) continue;

            // Compute fresh distance from viewer to enemy
            float curDist = UE4Helper::GetDistance(localPos, enemy.rootPos);
            SDK::FVector dir = enemy.rootPos - localPos;
            float distMeters = curDist;
            if (distMeters <= 0.5f || distMeters > (float)g_Config.max_distance_offscreen) continue;

            float enemyYaw = atan2f(dir.Y, dir.X) * (180.0f / CONST_PI);
            float diffYaw = enemyYaw - camYaw;
            while (diffYaw > 180.0f) diffYaw -= 360.0f;
            while (diffYaw < -180.0f) diffYaw += 360.0f;

            float rad = diffYaw * (CONST_PI / 180.0f);

            // Position on circular radar arc around screen center
            float posX = centerX + alertRadius * sinf(rad);
            float posY = centerY - alertRadius * cosf(rad);

            // Directional Arrow Geometry (pointing outward in rad angle)
            float arrowW = 10.0f;
            float arrowH = 14.0f;
            float sinA = sinf(rad);
            float cosA = cosf(rad);

            ImVec2 tip(posX + arrowH * 0.5f * sinA, posY - arrowH * 0.5f * cosA);
            ImVec2 base1(posX - arrowH * 0.5f * sinA - arrowW * 0.5f * cosA, posY + arrowH * 0.5f * cosA - arrowW * 0.5f * sinA);
            ImVec2 base2(posX - arrowH * 0.5f * sinA + arrowW * 0.5f * cosA, posY + arrowH * 0.5f * cosA + arrowW * 0.5f * sinA);

            const ImU32 col = GetEntityColor(enemy, true);

            // Shadow outline
            drawList->AddTriangle(base1, tip, base2, IM_COL32(0, 0, 0, 200), 2.5f);
            drawList->AddTriangleFilled(base1, tip, base2, col);

            // Distance Badge
            const std::string distStr = Lang::Display(DistText((int)distMeters));
            const char* distBuf = distStr.c_str();
            ImVec2 textSz = ImGui::CalcTextSize(distBuf);
            float textX = posX - textSz.x * 0.5f;
            float textY = posY + (arrowH * 0.5f) + 3.0f;

            // Entity type badge: label + colour already comes from GetEntityColor (visibility-aware)
            const char* typeLbl = enemy.isNPC ? Lang::T("ACTOR", "НПС")
                                : (enemy.isBot ? Lang::T("BOT", "БОТ") : Lang::T("ENM", "ВРАГ"));
            ImVec2 typeSz = ImGui::CalcTextSize(typeLbl);
            float typeX = posX - typeSz.x * 0.5f;
            float typeY = posY - (arrowH * 0.5f) - typeSz.y - 3.0f;
            drawList->AddText(ImVec2(typeX + 1, typeY + 1), IM_COL32(0, 0, 0, 200), typeLbl);
            drawList->AddText(ImVec2(typeX, typeY), col, typeLbl);

            drawList->AddRectFilled(ImVec2(textX - 3.0f, textY - 1.0f), ImVec2(textX + textSz.x + 3.0f, textY + textSz.y + 1.0f), IM_COL32(15, 15, 15, 180), 2.0f);
            drawList->AddText(ImVec2(textX, textY), IM_COL32(255, 255, 255, 255), distBuf);
        }
    }

    // 3D world-space box around the capsule, projected corner-by-corner.
    // Used for enemy players. Returns true when it drew.
    static bool Draw3DBox(ImDrawList* drawList, const ActorPipeline::EntityData& e,
                          const UE4Helper::ScreenProjection& projection, ImU32 col) {
        if (!drawList || !projection.Valid) return false;
        const float r = (e.capsuleRadius > 1.0f) ? e.capsuleRadius : 34.0f;
        float topZ = e.headPos.Z, botZ = e.feetPos.Z;
        if (!(topZ > botZ)) {
            const float hh = (e.capsuleHalfHeight > 1.0f) ? e.capsuleHalfHeight : 88.0f;
            topZ = e.rootPos.Z + hh;
            botZ = e.rootPos.Z - hh;
        }
        const float cx = e.rootPos.X, cy = e.rootPos.Y;
        const SDK::FVector world[8] = {
            {cx - r, cy - r, botZ}, {cx + r, cy - r, botZ}, {cx + r, cy + r, botZ}, {cx - r, cy + r, botZ},
            {cx - r, cy - r, topZ}, {cx + r, cy - r, topZ}, {cx + r, cy + r, topZ}, {cx - r, cy + r, topZ},
        };
        ImVec2 s[8];
        for (int i = 0; i < 8; ++i) {
            SDK::FVector2D sp;
            if (!UE4Helper::WorldToScreen(world[i], sp, projection)) return false;
            s[i] = ImVec2(sp.X, sp.Y);
        }
        static const int edges[12][2] = {
            {0,1},{1,2},{2,3},{3,0},   // bottom
            {4,5},{5,6},{6,7},{7,4},   // top
            {0,4},{1,5},{2,6},{3,7},   // verticals
        };
        const ImU32 shadow = IM_COL32(0,0,0,170);
        for (auto& ed : edges) drawList->AddLine(s[ed[0]], s[ed[1]], shadow, 2.2f);
        for (auto& ed : edges) drawList->AddLine(s[ed[0]], s[ed[1]], col,    1.2f);
        return true;
    }

    // Small health bar above the head with smooth gradient: full=green, ~50%=yellow, ~0%=red.
    // Returns the Y of the bar's top, so the snapline can terminate there.
    static float DrawHeadHealth(ImDrawList* drawList, float hx, float hy,
                                float health, float maxHealth) {
        const float barTopDefault = hy - 14.0f;
        if (!drawList || !(maxHealth > 0.0f) || health < 0.0f) return barTopDefault;
        const float pct = std::clamp(health / maxHealth, 0.0f, 1.0f);
        const float w = 32.0f, h = 4.0f;
        const float x = hx - w * 0.5f;
        const float y = hy - 16.0f;

        drawList->AddRectFilled(ImVec2(x - 1, y - 1), ImVec2(x + w + 1, y + h + 1), IM_COL32(10,10,10,190), 1.5f);
        drawList->AddRect(      ImVec2(x - 1, y - 1), ImVec2(x + w + 1, y + h + 1), IM_COL32(0,0,0,220),    1.5f);
        DrawGradientBar(drawList, x, y, w, h, pct, false);
        return y;
    }

    void RenderImGuiESP(ImDrawList* drawList, int screenWidth, int screenHeight) {
        g_Enemies.clear();
        if ((!g_Config.esp_enabled && !g_Config.aimbot_enabled && !g_Config.ammo_hud_enabled) || !drawList) {
            ActorPipeline::Reset();
            s_SkeletonCache.clear();
            return;
        }
        if (!g_Config.esp_enabled || !g_Config.esp_skeleton) s_SkeletonCache.clear();

        auto world = UE4Helper::GetWorld();
        if (!world || !UE4Helper::IsWorldReady(world)) {
            s_SkeletonCache.clear();
            return;
        }

        auto localPlayer = UE4Helper::GetLocalPlayer();
        auto controller = UE4Helper::GetPlayerController();
        if (!localPlayer || !controller) {
            s_SkeletonCache.clear();
            return;
        }
        static SDK::UWorld* s_PrevWorld = nullptr;
        static SDK::ASGCharacter* s_PrevLocal = nullptr;
        if (world != s_PrevWorld || localPlayer != s_PrevLocal) {
            s_SkeletonCache.clear();
            s_PrevWorld = world;
            s_PrevLocal = localPlayer;
        }

        SDK::FVector localPos{0, 0, 0};
        SDK::FRotator localRot{0, 0, 0};
        if (localPlayer && Tools::IsPtrValid(localPlayer) &&
            localPlayer->RootComponent && Tools::IsPtrValid(localPlayer->RootComponent) &&
            Tools::IsReadable(localPlayer->RootComponent, sizeof(SDK::USceneComponent))) {
            localPos = localPlayer->RootComponent->K2_GetComponentLocation();
        }

        // Use one complete POV for this frame. A guessed head position / 90-degree
        // fallback projects plausible-looking boxes at the wrong world locations.
        SDK::FCameraView view;
        if (!controller || !Tools::IsPtrValid(controller) ||
            !controller->PlayerCameraManager || !Tools::IsPtrValid(controller->PlayerCameraManager) ||
            !controller->PlayerCameraManager->GetCameraView(view)) return;
        localRot = controller->ControlRotation;
        const SDK::FVector camLoc = view.Location;
        const SDK::FRotator camRot = view.Rotation;
        const float fov = view.FOV;
        UE4Helper::ScreenProjection projection;
        if (!UE4Helper::BuildProjection(view, screenWidth, screenHeight, projection)) return;

        // 1. All geometry in this frame uses the same complete camera projection.
        ActorPipeline::Update(world, localPlayer, controller, projection);

        static uint64_t s_EspFrames = 0;
        if (++s_EspFrames % 300 == 0 || s_EspFrames == 1) {
            LOG_FRAME("[ESP] Frame #%" PRIu64 " camLoc=(%.1f, %.1f, %.1f) camRot=(P:%.1f, Y:%.1f, R:%.1f) fov=%.1f mode=%u aspect=%.3f constrain=%u offset=(%.3f,%.3f) focal=%.1f enemies=%zu",
                 s_EspFrames, camLoc.X, camLoc.Y, camLoc.Z, camRot.Pitch, camRot.Yaw, camRot.Roll, fov,
                 static_cast<unsigned>(view.FOVMode), view.AspectRatio, static_cast<unsigned>(view.ProjectionFlags & 1),
                 view.OffCenterProjectionOffset.X, view.OffCenterProjectionOffset.Y, projection.FocalX,
                 ActorPipeline::GetEnemies().size());
        }

        // ── ESP render ─────────────────────────────────────────────────────────
        // Players : 3D box + skeleton + head HP bar + name
        // Bots/NPC: 2D box + head HP bar + name
        // Snapline: screen-centre → the head HP bar, coloured by visibility.
        const auto& enemies = ActorPipeline::GetEnemies();

        // ── ESP FULL diagnostics log ────────────────────────────────────────
        // When the toggle is ON: writes a complete per-tick snapshot (camera +
        // EVERY enemy's full state) to /sdcard/Download/Telegram/inferno_esp_log.txt.
        // Flushed every tick (always on disk) and closed the instant the toggle is
        // turned OFF, so the file is complete and ready to grab from Telegram.
        {
            static FILE* s_espLog = nullptr;
            static bool  s_espWasOn = false;
            static double s_espLast = 0.0;

            if (g_Config.esp_log) {
                if (!s_espWasOn) {
                    // Make sure the target directory exists, then open (append).
                    mkdir("/sdcard/Download", 0755);
                    mkdir("/sdcard/Download/Telegram", 0755);
                    s_espLog = fopen("/sdcard/Download/Telegram/inferno_esp_log.txt", "a");
                    if (!s_espLog) s_espLog = fopen("/sdcard/inferno_esp_log.txt", "a"); // fallback
                    s_espWasOn = true;
                    if (s_espLog) {
                        time_t t = time(nullptr);
                        char tb[64]; strftime(tb, sizeof(tb), "%Y-%m-%d %H:%M:%S", localtime(&t));
                        fprintf(s_espLog, "\n===== ESP LOG SESSION %s =====\n", tb);
                        fflush(s_espLog);
                    }
                }
                if (s_espLog) {
                    const double now = ImGui::GetTime();
                    if (now - s_espLast > 0.2) {   // 5 snapshots per second
                        s_espLast = now;
                        time_t t = time(nullptr);
                        char tb[32]; strftime(tb, sizeof(tb), "%H:%M:%S", localtime(&t));
                        fprintf(s_espLog,
                            "[%s] CAM loc=(%.1f,%.1f,%.1f) rot=(P%.1f Y%.1f R%.1f) fov=%.1f screen=%dx%d espOn=%d enemies=%zu\n",
                            tb, camLoc.X, camLoc.Y, camLoc.Z, camRot.Pitch, camRot.Yaw, camRot.Roll,
                            fov, screenWidth, screenHeight, (int)g_Config.esp_enabled, enemies.size());
                        for (const auto& en : enemies) {
                            fprintf(s_espLog,
                                "    %-16s dist=%6.1fm on=%d vis=%d stale=%d bot=%d npc=%d knock=%d hp=%.0f/%.0f box=%.0fx%.0f scr=(%.0f,%.0f) head=(%.0f,%.0f) root=(%.1f,%.1f,%.1f) boneBits=0x%04X\n",
                                en.name.empty() ? "?" : en.name.c_str(),
                                en.distance, (int)en.onScreen, (int)en.isVisible, (int)en.stale,
                                (int)en.isBot, (int)en.isNPC, (int)en.isKnocked,
                                en.health, en.maxHealth, en.boxWidth, en.boxHeight,
                                en.screenRoot.X, en.screenRoot.Y, en.screenHead.X, en.screenHead.Y,
                                en.rootPos.X, en.rootPos.Y, en.rootPos.Z, (unsigned)en.boneVisible);

                            // For PLAYERS: dump every raw position source (incl. zeros /
                            // off-screen) so a player with no on-screen letter can be
                            // diagnosed — which source, if any, actually holds a position.
                            auto* ch = en.character;
                            if (!en.isBot && !en.isNPC && ch && Tools::IsPtrValid(ch)) {
                                SDK::FVector Rv{}, Pv{}, Fv{}, Gv{}, Dv{}, Nv{}, Mv{}, Tv{}, Av{};
                                auto* prx = ch->CharacterFastRepProxy;
                                if (prx && Tools::IsPtrValid(prx) && Tools::IsReadable(prx, Offsets::FastRepProxy::Location + 12)) {
                                    const uintptr_t pb = reinterpret_cast<uintptr_t>(prx);
                                    Pv = *reinterpret_cast<SDK::FVector*>(pb + Offsets::FastRepProxy::PredictStopLocation);
                                    Rv = *reinterpret_cast<SDK::FVector*>(pb + Offsets::FastRepProxy::Location);
                                }
                                ch->GetFastRepLocation(Fv);
                                ch->GetProxyPosition(Gv);
                                const uintptr_t chb = reinterpret_cast<uintptr_t>(ch);
                                if (Tools::IsReadable(reinterpret_cast<void*>(chb + 0x84 + 0x18), 12))
                                    Dv = *reinterpret_cast<SDK::FVector*>(chb + 0x84 + 0x18);
                                if (Tools::IsReadable(reinterpret_cast<void*>(chb + 0x1D70 + 0x18), 12))
                                    Nv = *reinterpret_cast<SDK::FVector*>(chb + 0x1D70 + 0x18);
                                auto* mesh = ch->GetMeshComponent();
                                if (mesh && Tools::IsPtrValid(mesh) && Tools::IsReadable(mesh, sizeof(SDK::USkeletalMeshComponent)) && mesh->ComponentToWorld.IsValid())
                                    Mv = mesh->ComponentToWorld.Translation;
                                if (ch->RootComponent && Tools::IsPtrValid(ch->RootComponent))
                                    Tv = ch->RootComponent->K2_GetComponentLocation();
                                Av = ch->K2_GetActorLocation();
                                fprintf(s_espLog,
                                    "      SRC R=(%.0f,%.0f,%.0f) P=(%.0f,%.0f,%.0f) F=(%.0f,%.0f,%.0f) G=(%.0f,%.0f,%.0f) D=(%.0f,%.0f,%.0f) N=(%.0f,%.0f,%.0f) M=(%.0f,%.0f,%.0f) T=(%.0f,%.0f,%.0f) A=(%.0f,%.0f,%.0f)\n",
                                    Rv.X,Rv.Y,Rv.Z, Pv.X,Pv.Y,Pv.Z, Fv.X,Fv.Y,Fv.Z, Gv.X,Gv.Y,Gv.Z, Dv.X,Dv.Y,Dv.Z,
                                    Nv.X,Nv.Y,Nv.Z, Mv.X,Mv.Y,Mv.Z, Tv.X,Tv.Y,Tv.Z, Av.X,Av.Y,Av.Z);
                            }
                        }
                        fflush(s_espLog);   // durable immediately
                    }
                }
            } else if (s_espWasOn) {
                // Toggle turned OFF: finalize and save the file right now.
                if (s_espLog) {
                    fprintf(s_espLog, "===== ESP LOG STOPPED =====\n");
                    fflush(s_espLog);
                    fclose(s_espLog);
                    s_espLog = nullptr;
                }
                s_espWasOn = false;
            }
        }

        // Drop cached skeletons for actors no longer in the pipeline list.
        for (auto it = s_SkeletonCache.begin(); it != s_SkeletonCache.end();) {
            const bool present = std::any_of(enemies.begin(), enemies.end(),
                [&](const auto& en) { return en.character == it->first; });
            if (!present) it = s_SkeletonCache.erase(it);
            else ++it;
        }

        const float scX = screenWidth * 0.5f;
        const float scY = screenHeight * 0.5f;

        for (const auto& e : enemies) {
            PlayerData p;
            p.actor = e.character;
            p.rootPos = e.rootPos;
            p.headPos = e.headPos;
            p.feetPos = e.feetPos;
            p.rootScreen = e.screenRoot;
            p.headScreen = e.screenHead;
            p.feetScreen = e.screenFeet;
            p.boxLeft = e.boxLeft;
            p.boxTop = e.boxTop;
            p.boxWidth = e.boxWidth;
            p.boxHeight = e.boxHeight;
            p.distance = e.distance;
            p.health = e.health;
            p.maxHealth = e.maxHealth;
            p.teamId = e.teamId;
            p.isBot = e.isBot;
            p.isNPC = e.isNPC;
            p.isTeammate = e.isTeammate;
            p.isKnocked = e.isKnocked;
            p.isVisible = e.isVisible;
            p.onScreen = e.onScreen;
            p.stale = e.stale;
            p.proxyOnly = e.proxyOnly;
            p.boneVisible = e.boneVisible;
            p.boneVisLive = e.boneVisLive;
            p.name = e.name;
            g_Enemies.push_back(p);

            if (!g_Config.esp_enabled) continue;

            // Calibration overlay (PLAYERS only): only two markers now —
            //   R (cyan)   = the anchor position every player ESP uses
            //   O (orange) = a proxy-only player (emitted from a fast-rep proxy with
            //                no loaded character); this is the kind that used to show
            //                no ESP at all. If a missing player now shows an O, it's him.
            if (g_Config.esp_calibrate && !p.isBot && !p.isNPC) {
                SDK::FVector2D s;
                if (p.proxyOnly) {
                    if (UE4Helper::WorldToScreen(e.rootPos, s, projection))
                        drawList->AddText(ImVec2(s.X + 4.0f, s.Y), IM_COL32(255, 150, 40, 255), "O");
                } else if (UE4Helper::WorldToScreen(e.rootPos, s, projection)) {
                    drawList->AddText(ImVec2(s.X + 4.0f, s.Y), IM_COL32(120, 255, 255, 255), "R");
                }
            }

            const bool  isPlayer = !p.isBot && !p.isNPC;
            const ImU32 col      = GetEntityColor(p);          // visibility-aware
            const ImU32 lineCol  = GetEntityColor(p, true);

            // Skeleton for everyone (players and bots) — projects/clips itself.
            // Pass fast-rep rootPos: the pose SHAPE is kept in the stable mesh frame
            // (so network jitter can't wipe it), but the whole skeleton is shifted by
            // (fastRep - meshRoot) at projection time so it sits on the box even when
            // a far player's mesh lags behind the authoritative position.
            const ImU32 skelBaseCol = p.isTeammate ? Colors::kTeammate : (
                p.isBot ? (p.isVisible ? ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_bot_skel_vis)
                                       : ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_bot_skel_hid))
                        : (p.isVisible ? ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_player_skel_vis)
                                       : ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_player_skel_hid))
            );
            DrawPlayerSkeleton(drawList, p.actor, skelBaseCol, projection,
                               p.boneVisLive && !p.isTeammate, p.boneVisible,
                               BoneOpenColor(p), BoneCoveredColor(p), p.rootPos);

            if (!p.onScreen) continue;

            // Box and health bar (corners + health bar strip for all entities)
            DrawPlayerBox(drawList, p);

            // Anchor the head to the authoritative capsule top (same source as
            // the 3D box). The mesh-derived headScreen goes stale when a remote
            // player's mesh is dormant, which made the line/HP drop while the box
            // held; project rootPos+height instead so they stay pinned.
            SDK::FVector2D headAnchor = p.headScreen;
            {
                const float topZ = (e.headPos.Z > e.feetPos.Z)
                    ? e.headPos.Z
                    : e.rootPos.Z + ((e.capsuleHalfHeight > 1.0f) ? e.capsuleHalfHeight : 88.0f);
                SDK::FVector2D hs;
                if (UE4Helper::WorldToScreen(SDK::FVector{e.rootPos.X, e.rootPos.Y, topZ}, hs, projection))
                    headAnchor = hs;
            }

            // Snapline to the head; origin picked in the menu:
            //   0 = top-centre, 1 = screen centre, 2 = bottom-centre.
            if (g_Config.esp_line) {
                const float oy = (g_Config.esp_line_origin == 1) ? scY
                               : (g_Config.esp_line_origin == 2) ? (float)screenHeight
                                                                 : 0.0f;
                const ImU32 snaplineCol = p.isTeammate ? Colors::kTeammate : (
                    p.isBot ? (p.isVisible ? ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_bot_line_vis)
                                           : ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_bot_line_hid))
                            : (p.isVisible ? ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_player_line_vis)
                                           : ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_player_line_hid))
                );
                drawList->AddLine(ImVec2(scX, oy), ImVec2(headAnchor.X, headAnchor.Y), snaplineCol, 1.2f);
            }

            // Name tag above head / box: real player nickname, [BOT] for bots, [NPC] for NPCs
            if (g_Config.esp_name) {
                std::string tag;
                if (p.isTeammate) {
                    std::string cleanName = CleanPlayerName(p.name);
                    tag = !cleanName.empty() ? ("[" + cleanName + "]") : Lang::T("[TEAM]", "[ТИММЕЙТ]");
                } else if (p.isBot) {
                    tag = Lang::T("[BOT]", "[БОТ]");
                } else if (p.isNPC) {
                    tag = Lang::T("[NPC]", "[НПС]");
                } else {
                    // Real player: show their actual nickname!
                    std::string finalName = CleanPlayerName(p.name);
                    if (finalName.empty()) {
                        // Direct resolution safety net from actor PlayerState
                        SDK::ASGCharacter* c = e.character;
                        std::string foundName;
                        if (c && Tools::IsPtrValid(c)) {
                            SDK::APlayerState* ps = nullptr;
                            if (Tools::IsReadable(reinterpret_cast<uint8_t*>(c) + Offsets::Pawn::PlayerState, sizeof(void*))) {
                                ps = *reinterpret_cast<SDK::APlayerState**>(reinterpret_cast<uint8_t*>(c) + Offsets::Pawn::PlayerState);
                            }
                            if ((!ps || !Tools::IsPtrValid(ps)) && Tools::IsReadable(reinterpret_cast<uint8_t*>(c) + Offsets::SGCharacter::PlayerInfo_PlayerState, sizeof(void*))) {
                                ps = c->PlayerInfo.PlayerState;
                            }
                            if (ps && Tools::IsPtrValid(ps)) {
                                auto* sgPs = reinterpret_cast<SDK::ASGPlayerState*>(ps);
                                if (Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::ZonePlayerName, sizeof(SDK::FString))) {
                                    auto* zn = reinterpret_cast<SDK::FString*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::ZonePlayerName);
                                    foundName = zn->ToString();
                                }
                                if (foundName.empty() && Tools::IsReadable(&ps->PlayerNamePrivate, sizeof(SDK::FString))) {
                                    foundName = ps->PlayerNamePrivate.ToString();
                                }
                            }
                        }
                        if (!foundName.empty()) {
                            finalName = CleanPlayerName(foundName);
                        }
                    }

                    if (!finalName.empty()) {
                        tag = "[" + finalName + "]";
                    } else {
                        SDK::ASGCharacter* c = e.character;
                        if (c && Tools::IsReadable(&c->FactionType, 1)) {
                            const char* faction = FactionName(c->FactionType);
                            if (faction && *faction) tag = std::string("[") + faction + "]";
                            else tag = Lang::T("[PMC]", "[ЧВК]");
                        } else {
                            tag = Lang::T("[PMC]", "[ЧВК]");
                        }
                    }
                }

                if (!tag.empty()) {
                    const ImVec2 tsz = ImGui::CalcTextSize(tag.c_str());
                    const float topCenterX = (p.boxWidth > 0.0f) ? (p.boxLeft + p.boxWidth * 0.5f) : headAnchor.X;
                    const float topY = (p.boxHeight > 0.0f) ? (p.boxTop - tsz.y - 10.0f) : (headAnchor.Y - tsz.y - 10.0f);
                    const float tx = topCenterX - tsz.x * 0.5f;
                    const float ty = topY;
                    drawList->AddText(ImVec2(tx + 1, ty + 1), IM_COL32(0, 0, 0, 220), tag.c_str());
                    drawList->AddText(ImVec2(tx,     ty),     col,                 tag.c_str());
                }
            }

            // Distance below the box / feet
            if (g_Config.esp_distance) {
                float curDist = UE4Helper::GetDistance(camLoc, e.rootPos);
                int displayDist = static_cast<int>(curDist);
                char distBuf[32];
                snprintf(distBuf, sizeof(distBuf), "%dm", displayDist);
                const ImVec2 dsz = ImGui::CalcTextSize(distBuf);
                const float distCenterX = (p.boxWidth > 0.0f) ? (p.boxLeft + p.boxWidth * 0.5f) : headAnchor.X;
                const float distCenterY = (p.boxHeight > 0.0f) ? (p.boxTop + p.boxHeight + 2.0f) : (p.feetScreen.Y + 2.0f);
                const float dx = distCenterX - dsz.x * 0.5f;
                const float dy = distCenterY;
                drawList->AddText(ImVec2(dx + 1, dy + 1), IM_COL32(0, 0, 0, 220), distBuf);
                drawList->AddText(ImVec2(dx,     dy),     IM_COL32(255, 255, 255, 230), distBuf);
            }
        }

        if (!g_Config.esp_enabled) return;

        // World Items ESP (CATEGORY: ITEMS)
        if (g_Config.esp_items) {
            const auto& items = ActorPipeline::GetItems();
            for (const auto& item : items) {
                if (!item.onScreen || item.distance > (float)g_Config.item_esp_max_distance) continue;

                const ImVec2 pos(item.screenRoot.X, item.screenRoot.Y);

                // Small diamond marker in vibrant gold
                const float r = 3.5f;
                const ImU32 markerCol = IM_COL32(255, 205, 50, 240);
                drawList->AddQuadFilled(
                    ImVec2(pos.x, pos.y - r),
                    ImVec2(pos.x + r, pos.y),
                    ImVec2(pos.x, pos.y + r),
                    ImVec2(pos.x - r, pos.y),
                    markerCol
                );
                drawList->AddQuad(
                    ImVec2(pos.x, pos.y - r),
                    ImVec2(pos.x + r, pos.y),
                    ImVec2(pos.x, pos.y + r),
                    ImVec2(pos.x - r, pos.y),
                    IM_COL32(0, 0, 0, 200), 1.0f
                );

                // Item Name + Distance tag
                std::string label = item.name.empty() ? Lang::T("Item", "Предмет") : item.name;
                char distBuf[64];
                snprintf(distBuf, sizeof(distBuf), "%s [%dm]", label.c_str(), (int)item.distance);

                const ImVec2 tsz = ImGui::CalcTextSize(distBuf);
                const ImVec2 tpos(pos.x - tsz.x * 0.5f, pos.y - tsz.y - 4.0f);

                // Shadow & text
                drawList->AddText(ImVec2(tpos.x + 1, tpos.y + 1), IM_COL32(0, 0, 0, 220), distBuf);
                drawList->AddText(tpos, IM_COL32(255, 235, 120, 245), distBuf);
            }
        }

        // Loot Boxes / Containers / Crates ESP (CATEGORY: BOXES)
        if (g_Config.esp_lootbox) {
            const auto& boxes = ActorPipeline::GetLootBoxes();
            for (const auto& box : boxes) {
                if (!box.onScreen || box.distance > (float)g_Config.item_esp_max_distance) continue;

                const ImVec2 pos(box.screenRoot.X, box.screenRoot.Y);

                // Small square marker in vibrant cyan/teal
                const float r = 4.0f;
                const ImU32 boxCol = IM_COL32(0, 220, 255, 240);
                drawList->AddRectFilled(
                    ImVec2(pos.x - r, pos.y - r),
                    ImVec2(pos.x + r, pos.y + r),
                    boxCol, 2.0f
                );
                drawList->AddRect(
                    ImVec2(pos.x - r, pos.y - r),
                    ImVec2(pos.x + r, pos.y + r),
                    IM_COL32(0, 0, 0, 220), 2.0f, 0, 1.0f
                );

                std::string label = box.name.empty() ? Lang::T("Box", "Ящик") : box.name;
                char distBuf[64];
                snprintf(distBuf, sizeof(distBuf), "[%s] [%dm]", label.c_str(), (int)box.distance);

                const ImVec2 tsz = ImGui::CalcTextSize(distBuf);
                const ImVec2 tpos(pos.x - tsz.x * 0.5f, pos.y - tsz.y - 4.0f);

                drawList->AddText(ImVec2(tpos.x + 1, tpos.y + 1), IM_COL32(0, 0, 0, 220), distBuf);
                drawList->AddText(tpos, IM_COL32(100, 235, 255, 250), distBuf);
            }
        }

        // Dead Bodies / Corpses ESP (CATEGORY: CORPSES)
        if (g_Config.esp_dead_bodies) {
            const auto& corpses = ActorPipeline::GetDeadBodies();
            for (const auto& corpse : corpses) {
                if (!corpse.onScreen || corpse.distance > (float)g_Config.item_esp_max_distance) continue;

                const ImVec2 pos(corpse.screenRoot.X, corpse.screenRoot.Y);

                // Small cross marker in muted crimson
                const float r = 4.0f;
                const ImU32 corpseCol = IM_COL32(220, 70, 70, 240);
                drawList->AddLine(ImVec2(pos.x - r, pos.y), ImVec2(pos.x + r, pos.y), corpseCol, 1.8f);
                drawList->AddLine(ImVec2(pos.x, pos.y - r), ImVec2(pos.x, pos.y + r), corpseCol, 1.8f);

                std::string label = corpse.name.empty() ? Lang::T("Corpse", "Труп") : corpse.name;
                char distBuf[64];
                snprintf(distBuf, sizeof(distBuf), "%s [%dm]", label.c_str(), (int)corpse.distance);

                const ImVec2 tsz = ImGui::CalcTextSize(distBuf);
                const ImVec2 tpos(pos.x - tsz.x * 0.5f, pos.y - tsz.y - 4.0f);

                drawList->AddText(ImVec2(tpos.x + 1, tpos.y + 1), IM_COL32(0, 0, 0, 220), distBuf);
                drawList->AddText(tpos, IM_COL32(235, 120, 120, 245), distBuf);
            }
        }

        // Calibration legend (top-left) so a screenshot shows which letter is which.
        if (g_Config.esp_calibrate) {
            struct LG { const char* t; ImU32 c; };
            static const LG legend[] = {
                {"R=player anchor",   IM_COL32(120, 255, 255, 255)},
                {"O=proxy-only player", IM_COL32(255, 150, 40, 255)},
            };
            float ly = 90.0f;
            drawList->AddText(ImVec2(16.0f, ly - 18.0f), IM_COL32(255,255,255,255), "CALIBRATION:");
            for (auto& l : legend) { drawList->AddText(ImVec2(16.0f, ly), l.c, l.t); ly += 16.0f; }
        }

        // Enemy counter (top-centre pill): PLAYER / BOT counts.
        DrawCounters(drawList, g_Enemies, screenWidth);

        // Off-screen directional alerts (360°).
        DrawUpAlert(drawList, localPos, camRot.Yaw, g_Enemies, screenWidth, screenHeight);

        // Floating Draggable & Lockable Weapon Ammo Counter HUD
        DrawAmmoHUD(localPlayer, screenWidth, screenHeight);
    }

    void DrawAmmoHUD(SDK::ASGCharacter* localPlayer, int screenWidth, int screenHeight) {
        if (!g_Config.ammo_hud_enabled || !localPlayer || !Tools::IsPtrValid(localPlayer)) return;

        // 1. Fetch current weapon and ammo
        int32_t clipAmmo = -1;
        int32_t maxClipAmmo = -1;
        int32_t chamberAmmo = 0;
        bool isReloading = false;
        bool isMelee = false;
        bool isThrowable = false;
        std::string weaponName;

        // Method A: Check SGCharacterWeaponManager (+0x1838, +0x19A0, +0x1F68 or via component list)
        SDK::UActorComponent* wm = nullptr;
        for (uintptr_t off : Offsets::SGCharacter::WeaponManagerOffsets) {
            if (Tools::IsReadable(reinterpret_cast<const uint8_t*>(localPlayer) + off, sizeof(void*))) {
                auto* candidate = *reinterpret_cast<SDK::UActorComponent* const*>(reinterpret_cast<const uint8_t*>(localPlayer) + off);
                if (candidate && Tools::IsPtrValid(candidate) && SDK::IsLiveSDKObject(candidate) && SDK::HasSDKClass(candidate, "WeaponManager")) {
                    wm = candidate;
                    break;
                }
            }
        }
        if (!wm) {
            wm = localPlayer->FindComponentByClassName("SGCharacterWeaponManagerComponent");
        }

        SDK::AActor* currentWp = nullptr;
        if (wm && Tools::IsPtrValid(wm) && Tools::IsReadable(reinterpret_cast<const uint8_t*>(wm) + Offsets::Weapon::WeaponManager_CurrentWeapon, sizeof(void*))) {
            currentWp = *reinterpret_cast<SDK::AActor* const*>(reinterpret_cast<const uint8_t*>(wm) + Offsets::Weapon::WeaponManager_CurrentWeapon);
        }
        // Fallback A: Check LastUsedWeapon (wm + 0x470)
        if (!currentWp || !Tools::IsPtrValid(currentWp)) {
            if (wm && Tools::IsReadable(reinterpret_cast<const uint8_t*>(wm) + Offsets::Weapon::WeaponManager_LastUsedWeapon, sizeof(void*))) {
                currentWp = *reinterpret_cast<SDK::AActor* const*>(reinterpret_cast<const uint8_t*>(wm) + Offsets::Weapon::WeaponManager_LastUsedWeapon);
            }
        }
        // Fallback B: Check SGCharacterWeaponTraceComponent (+0x410)
        if (!currentWp || !Tools::IsPtrValid(currentWp)) {
            auto* wt = localPlayer->FindComponentByClassName("SGCharacterWeaponTraceComponent");
            if (wt && Tools::IsPtrValid(wt) && Tools::IsReadable(reinterpret_cast<const uint8_t*>(wt) + Offsets::Weapon::WeaponTrace_CurrentWeapon, sizeof(void*))) {
                currentWp = *reinterpret_cast<SDK::AActor* const*>(reinterpret_cast<const uint8_t*>(wt) + Offsets::Weapon::WeaponTrace_CurrentWeapon);
            }
        }

        if (currentWp && Tools::IsPtrValid(currentWp) && SDK::IsLiveSDKObject(currentWp)) {
            std::string rawWpName = currentWp->GetName();
            std::string rawCls = (currentWp->ClassPrivate && Tools::IsPtrValid(currentWp->ClassPrivate)) ? currentWp->ClassPrivate->GetName() : "";
            if (rawCls.find("Melee") != std::string::npos || rawWpName.find("Melee") != std::string::npos ||
                rawWpName.find("Bayonet") != std::string::npos || rawWpName.find("Knife") != std::string::npos) {
                isMelee = true;
            }
            if (rawCls.find("Throw") != std::string::npos || rawWpName.find("Throw") != std::string::npos ||
                rawWpName.find("Grenade") != std::string::npos) {
                isThrowable = true;
            }

            size_t cPos = rawWpName.rfind("_C");
            if (cPos != std::string::npos) rawWpName = rawWpName.substr(0, cPos);
            static const char* const wpPrefixes[] = {
                "Default__", "BP_SGWeapon_", "BP_Weapon_", "BP_", "SGWeapon_", "SG_", "Wp_", "UA_", "Loot_"
            };
            bool stripped = true;
            while (stripped && !rawWpName.empty()) {
                stripped = false;
                for (const char* pfx : wpPrefixes) {
                    size_t plen = strlen(pfx);
                    if (rawWpName.size() >= plen && rawWpName.compare(0, plen, pfx) == 0) {
                        rawWpName = rawWpName.substr(plen);
                        stripped = true;
                        break;
                    }
                }
            }
            while (!rawWpName.empty() && (rawWpName.front() == '_' || rawWpName.front() == ' ')) {
                rawWpName.erase(rawWpName.begin());
            }
            for (char& ch : rawWpName) { if (ch == '_') ch = ' '; }
            weaponName = rawWpName.empty() ? "WEAPON" : rawWpName;

            // Helper to find a component on an AActor by checking WeaponCmpCacheArray (+0xAF8) or FindComponentByClassName
            auto findComp = [](SDK::AActor* actor, const char* namePart) -> SDK::UActorComponent* {
                if (!actor || !Tools::IsPtrValid(actor)) return nullptr;
                // Check WeaponCmpCacheArray at +0xAF8 (19 elements)
                if (Tools::IsReadable(reinterpret_cast<const uint8_t*>(actor) + Offsets::Actor::WeaponCmpCacheArray, 19 * sizeof(void*))) {
                    for (int i = 0; i < 19; ++i) {
                        auto* c = *reinterpret_cast<SDK::UActorComponent* const*>(reinterpret_cast<const uint8_t*>(actor) + Offsets::Actor::WeaponCmpCacheArray + i * sizeof(void*));
                        if (c && Tools::IsPtrValid(c) && SDK::IsLiveSDKObject(c)) {
                            if (SDK::HasSDKClass(c, namePart)) return c;
                        }
                    }
                }
                return actor->FindComponentByClassName(namePart);
            };

            // Helper to get USGWeaponContainerComponent from an ASGInventory actor
            auto getContainerComp = [&](SDK::AActor* invActor) -> SDK::UActorComponent* {
                if (!invActor || !Tools::IsPtrValid(invActor)) return nullptr;
                // 1. Direct offset +0x810 on ASGInventory (Slot 12 of CmpCacheArray)
                if (Tools::IsReadable(reinterpret_cast<const uint8_t*>(invActor) + Offsets::Weapon::Inventory_WeaponContainer, sizeof(void*))) {
                    auto* c = *reinterpret_cast<SDK::UActorComponent* const*>(reinterpret_cast<const uint8_t*>(invActor) + Offsets::Weapon::Inventory_WeaponContainer);
                    if (c && Tools::IsPtrValid(c) && SDK::IsLiveSDKObject(c) && SDK::HasSDKClass(c, "Container")) {
                        return c;
                    }
                }
                return findComp(invActor, "WeaponContainerComponent");
            };

            // Helper to read ammo from a USGWeaponContainerComponent
            auto readContainerAmmo = [](SDK::UActorComponent* cont, int32_t& outCur, int32_t& outMax) -> bool {
                if (!cont || !Tools::IsPtrValid(cont)) return false;
                // +0x118: MaxStackCount
                if (Tools::IsReadable(reinterpret_cast<const uint8_t*>(cont) + Offsets::Weapon::Container_MaxStackCount, sizeof(int32_t))) {
                    int32_t maxVal = *reinterpret_cast<const int32_t*>(reinterpret_cast<const uint8_t*>(cont) + Offsets::Weapon::Container_MaxStackCount);
                    if (maxVal > 0 && maxVal < 500) outMax = maxVal;
                }
                // +0x1D0: ContainDataList (TArray<FBulletContainerInfo>)
                if (Tools::IsReadable(reinterpret_cast<const uint8_t*>(cont) + Offsets::Weapon::Container_ContainDataList, sizeof(SDK::TArray<uint8_t>))) {
                    const auto* list = reinterpret_cast<const SDK::TArray<uint8_t>*>(reinterpret_cast<const uint8_t*>(cont) + Offsets::Weapon::Container_ContainDataList);
                    int32_t num = list->Num();
                    const uint8_t* data = list->GetData();
                    // If empty, check ContainDataListForRep at +0x1E0
                    if (num <= 0 || !data) {
                        if (Tools::IsReadable(reinterpret_cast<const uint8_t*>(cont) + Offsets::Weapon::Container_ContainDataListForRep, sizeof(SDK::TArray<uint8_t>))) {
                            const auto* repList = reinterpret_cast<const SDK::TArray<uint8_t>*>(reinterpret_cast<const uint8_t*>(cont) + Offsets::Weapon::Container_ContainDataListForRep);
                            if (repList && repList->Num() > 0 && repList->GetData()) {
                                list = repList;
                                num = list->Num();
                                data = list->GetData();
                            }
                        }
                    }
                    if (num > 0 && num < 128 && data && Tools::IsReadable(data, num * 16)) {
                        int32_t sum = 0;
                        for (int i = 0; i < num; ++i) {
                            int32_t stack = *reinterpret_cast<const int32_t*>(data + i * 16 + 8);
                            if (stack > 0 && stack < 300) sum += stack;
                        }
                        outCur = sum;
                        return true;
                    } else if (num == 0) {
                        outCur = 0;
                        return true;
                    }
                }
                return false;
            };

            if (!isMelee && !isThrowable) {
                // Step A: Find Magazine via USGWeaponAssembleComponent
                SDK::AActor* magActor = nullptr;
                auto* assembleComp = findComp(currentWp, "Assemble");
                if (assembleComp && Tools::IsPtrValid(assembleComp)) {
                    // +0x0270: CachedMagazine
                    if (Tools::IsReadable(reinterpret_cast<const uint8_t*>(assembleComp) + Offsets::Weapon::Assemble_CachedMagazine, sizeof(void*))) {
                        magActor = *reinterpret_cast<SDK::AActor* const*>(reinterpret_cast<const uint8_t*>(assembleComp) + Offsets::Weapon::Assemble_CachedMagazine);
                    }
                    // +0x0278: ClientCachedMagazine
                    if (!magActor || !Tools::IsPtrValid(magActor)) {
                        if (Tools::IsReadable(reinterpret_cast<const uint8_t*>(assembleComp) + Offsets::Weapon::Assemble_ClientCachedMagazine, sizeof(void*))) {
                            magActor = *reinterpret_cast<SDK::AActor* const*>(reinterpret_cast<const uint8_t*>(assembleComp) + Offsets::Weapon::Assemble_ClientCachedMagazine);
                        }
                    }
                    // +0x01E8: AssembledInventoryList scan
                    if (!magActor || !Tools::IsPtrValid(magActor)) {
                        if (Tools::IsReadable(reinterpret_cast<const uint8_t*>(assembleComp) + Offsets::Weapon::Assemble_AssembledInventoryList, sizeof(SDK::TArray<SDK::AActor*>))) {
                            const auto* assemList = reinterpret_cast<const SDK::TArray<SDK::AActor*>*>(reinterpret_cast<const uint8_t*>(assembleComp) + Offsets::Weapon::Assemble_AssembledInventoryList);
                            int32_t aNum = assemList->Num();
                            SDK::AActor* const* aData = assemList->GetData();
                            if (aNum > 0 && aNum < 32 && aData && Tools::IsReadable(aData, aNum * sizeof(void*))) {
                                for (int k = 0; k < aNum; ++k) {
                                    auto* item = aData[k];
                                    if (item && Tools::IsPtrValid(item) && SDK::IsLiveSDKObject(item)) {
                                        std::string iName = item->GetName();
                                        if (iName.find("Mag") != std::string::npos || iName.find("Drum") != std::string::npos) {
                                            magActor = item;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Step B: Read ammo from Magazine container
                if (magActor && Tools::IsPtrValid(magActor)) {
                    auto* magCont = getContainerComp(magActor);
                    if (magCont) {
                        readContainerAmmo(magCont, clipAmmo, maxClipAmmo);
                    }
                }

                // Step C: Fallback to weapon's own container (shotguns, revolvers, internal mags)
                if (clipAmmo < 0) {
                    auto* wpCont = getContainerComp(currentWp);
                    if (wpCont) {
                        readContainerAmmo(wpCont, clipAmmo, maxClipAmmo);
                    }
                }

                // Step D: Check chambered bullet via USGWeaponBoreComponent
                auto* boreComp = findComp(currentWp, "Bore");
                if (boreComp && Tools::IsReadable(reinterpret_cast<const uint8_t*>(boreComp) + Offsets::Weapon::Bore_CurShotBullet, sizeof(void*))) {
                    const void* curShotBullet = *reinterpret_cast<const void* const*>(reinterpret_cast<const uint8_t*>(boreComp) + Offsets::Weapon::Bore_CurShotBullet);
                    if (curShotBullet && Tools::IsPtrValid(curShotBullet)) {
                        chamberAmmo = 1;
                    }
                }

                // Step E: Check USGWeaponAmmoComponent for reload flag and fallback clip ammo
                auto* ammoComp = findComp(currentWp, "Ammo");
                if (ammoComp && Tools::IsReadable(ammoComp, 0x120)) {
                    isReloading = *reinterpret_cast<const bool*>(reinterpret_cast<const uint8_t*>(ammoComp) + Offsets::Weapon::Ammo_IsReloading);
                    if (clipAmmo < 0) {
                        int32_t fallbackClip = *reinterpret_cast<const int32_t*>(reinterpret_cast<const uint8_t*>(ammoComp) + Offsets::Weapon::Ammo_FallbackClip);
                        int32_t fallbackMax = *reinterpret_cast<const int32_t*>(reinterpret_cast<const uint8_t*>(ammoComp) + Offsets::Weapon::Ammo_FallbackMax);
                        if (fallbackClip > 0 || fallbackMax > 0) {
                            clipAmmo = fallbackClip;
                            maxClipAmmo = fallbackMax;
                        }
                    }
                }
            }
        }

        // 2. Setup ImGui floating window
        ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration 
                               | ImGuiWindowFlags_AlwaysAutoResize 
                               | ImGuiWindowFlags_NoSavedSettings
                               | ImGuiWindowFlags_NoFocusOnAppearing
                               | ImGuiWindowFlags_NoNav;
        if (g_Config.ammo_hud_locked) {
            flags |= ImGuiWindowFlags_NoMove;
        }

        if (g_Config.ammo_hud_x <= 0.0f || g_Config.ammo_hud_x > (float)screenWidth) {
            g_Config.ammo_hud_x = (float)screenWidth * 0.15f;
        }
        if (g_Config.ammo_hud_y <= 0.0f || g_Config.ammo_hud_y > (float)screenHeight) {
            g_Config.ammo_hud_y = (float)screenHeight * 0.70f;
        }

        ImGui::SetNextWindowPos(ImVec2(g_Config.ammo_hud_x, g_Config.ammo_hud_y), ImGuiCond_Appearing);

        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 12.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12.0f, 8.0f));
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.08f, 0.09f, 0.14f, 0.85f));
        ImGui::PushStyleColor(ImGuiCol_Border, g_Config.ammo_hud_locked 
            ? ImVec4(0.35f, 0.40f, 0.60f, 0.45f) 
            : ImVec4(0.99f, 0.45f, 0.18f, 0.90f));

        if (ImGui::Begin("##MirageAmmoHUD", nullptr, flags)) {
            if (!g_Config.ammo_hud_locked) {
                ImVec2 curPos = ImGui::GetWindowPos();
                if (std::abs(curPos.x - g_Config.ammo_hud_x) > 1.0f || std::abs(curPos.y - g_Config.ammo_hud_y) > 1.0f) {
                    g_Config.ammo_hud_x = curPos.x;
                    g_Config.ammo_hud_y = curPos.y;
                    ConfigManager::RequestAutoSave();
                }
            }

            ImGui::BeginGroup();
            {
                if (!weaponName.empty()) {
                    ImGui::TextColored(ImVec4(0.65f, 0.72f, 0.85f, 1.0f), "%s", weaponName.c_str());
                } else {
                    ImGui::TextColored(ImVec4(0.50f, 0.55f, 0.65f, 0.8f), "HOLSTER");
                }
                if (isReloading) {
                    float pulse = 0.6f + 0.4f * std::sin((float)ImGui::GetTime() * 8.0f);
                    ImGui::TextColored(ImVec4(1.0f, 0.55f, 0.15f, pulse), "%s", Lang::T("RELOADING...", "ПЕРЕЗАРЯДКА..."));
                } else if (isMelee) {
                    ImGui::TextColored(ImVec4(0.55f, 0.65f, 0.80f, 0.9f), "%s", Lang::T("MELEE", "ХОЛОДНОЕ ОРУЖИЕ"));
                } else if (isThrowable) {
                    ImGui::TextColored(ImVec4(0.85f, 0.70f, 0.30f, 0.9f), "%s", Lang::T("THROWABLE", "МЕТАТЕЛЬНОЕ"));
                } else if (clipAmmo >= 0) {
                    ImVec4 ammoCol = ImVec4(0.20f, 0.95f, 0.55f, 1.0f);
                    if (maxClipAmmo > 0) {
                        float ratio = (float)clipAmmo / (float)maxClipAmmo;
                        if (ratio <= 0.25f) ammoCol = ImVec4(1.0f, 0.25f, 0.25f, 1.0f);
                        else if (ratio <= 0.50f) ammoCol = ImVec4(1.0f, 0.78f, 0.20f, 1.0f);
                    }
                    ImGui::TextColored(ammoCol, "%d", clipAmmo);
                    if (chamberAmmo > 0) {
                        ImGui::SameLine(0, 2.0f);
                        ImGui::TextColored(ImVec4(0.40f, 0.85f, 1.0f, 0.95f), "+%d", chamberAmmo);
                    }
                    if (maxClipAmmo > 0) {
                        ImGui::SameLine(0, 4.0f);
                        ImGui::TextColored(ImVec4(0.55f, 0.60f, 0.70f, 0.9f), "/ %d", maxClipAmmo);
                    }
                } else {
                    ImGui::TextColored(ImVec4(0.55f, 0.60f, 0.70f, 0.8f), "-- / --");
                }
            }
            ImGui::EndGroup();

            ImGui::SameLine(0, 10.0f);
            const char* lockLabel = g_Config.ammo_hud_locked 
                ? Lang::T("[LOCKED]", "[ФИКС]") 
                : Lang::T("[MOVE]", "[ДВИГАТЬ]");
            ImVec4 lockBtnCol = g_Config.ammo_hud_locked 
                ? ImVec4(0.20f, 0.25f, 0.38f, 0.85f) 
                : ImVec4(0.85f, 0.35f, 0.15f, 0.90f);
            ImGui::PushStyleColor(ImGuiCol_Button, lockBtnCol);
            if (ImGui::SmallButton(lockLabel)) {
                g_Config.ammo_hud_locked = !g_Config.ammo_hud_locked;
                ConfigManager::RequestAutoSave();
            }
            ImGui::PopStyleColor();
        }
        ImGui::End();
        ImGui::PopStyleColor(2);
        ImGui::PopStyleVar(2);
    }
}

