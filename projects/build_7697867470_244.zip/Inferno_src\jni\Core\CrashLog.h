#pragma once
#include <string>

namespace CrashLog {
    // Call once at startup from DllMain/JNI_OnLoad
    void Init(const char* logPath = nullptr);

    // Write a general log line (thread-safe)
    void Log(const char* fmt, ...);

    // Flush log to disk now
    void Flush();
}
