// CrashLog.cpp — signal-based crash logger for Android ARM64
// Writes to /sdcard/inferno_crash.log (falls back to /data/local/tmp/)
// Captures: timestamp, signal, fault address, full stack unwind, /proc/self/maps

#include "CrashLog.h"

#include <android/log.h>
#include <csignal>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <mutex>
#include <string>
#include <unistd.h>
#include <unwind.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <pthread.h>

#define TAG "InfernoLog"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)

namespace CrashLog {

// ─────────────────────────────────────────────────────────────────────────────
// State
// ─────────────────────────────────────────────────────────────────────────────

static char      s_logPath[256]  = {};
static FILE*     s_file          = nullptr;
static std::mutex s_mtx;
static struct sigaction s_oldHandlers[7] = {};

static const int kSignals[] = {
    SIGSEGV, SIGABRT, SIGBUS, SIGFPE, SIGILL, SIGTRAP, SIGTERM
};
static const int kSignalCount = 7;

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

static void WriteToFile(const char* msg) {
    if (!s_file) return;
    fputs(msg, s_file);
    fflush(s_file);
}

static void WriteLineFmt(const char* fmt, ...) {
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    WriteToFile(buf);
    LOGD("%s", buf);
}

static const char* SignalName(int sig) {
    switch (sig) {
        case SIGSEGV: return "SIGSEGV (segmentation fault)";
        case SIGABRT: return "SIGABRT (abort)";
        case SIGBUS:  return "SIGBUS  (bus error)";
        case SIGFPE:  return "SIGFPE  (floating point exception)";
        case SIGILL:  return "SIGILL  (illegal instruction)";
        case SIGTRAP: return "SIGTRAP (trace trap)";
        case SIGTERM: return "SIGTERM (termination)";
        default:      return "UNKNOWN";
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Stack unwind
// ─────────────────────────────────────────────────────────────────────────────

struct UnwindState {
    uintptr_t frames[64];
    int       count = 0;
};

static _Unwind_Reason_Code UnwindCallback(_Unwind_Context* ctx, void* arg) {
    auto* st = reinterpret_cast<UnwindState*>(arg);
    if (st->count >= 64) return _URC_END_OF_STACK;
    uintptr_t pc = _Unwind_GetIP(ctx);
    if (pc) st->frames[st->count++] = pc;
    return _URC_NO_REASON;
}

static void WriteStackTrace() {
    UnwindState st;
    _Unwind_Backtrace(UnwindCallback, &st);

    WriteToFile("--- Stack Trace ---\n");
    for (int i = 0; i < st.count; ++i) {
        uintptr_t pc = st.frames[i];
        Dl_info info = {};
        if (dladdr(reinterpret_cast<void*>(pc), &info) && info.dli_fname) {
            uintptr_t offset = pc - reinterpret_cast<uintptr_t>(info.dli_fbase);
            const char* sym = info.dli_sname ? info.dli_sname : "?";
            WriteLineFmt("  #%02d  %p  %s  (%s+0x%lx)\n",
                i, reinterpret_cast<void*>(pc),
                sym,
                info.dli_fname,
                (unsigned long)offset);
        } else {
            WriteLineFmt("  #%02d  %p  ??\n", i, reinterpret_cast<void*>(pc));
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// /proc/self/maps (module list)
// ─────────────────────────────────────────────────────────────────────────────

static void WriteMaps() {
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return;
    WriteToFile("--- /proc/self/maps ---\n");
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        // Only write lines with a file path (skip anonymous)
        if (strchr(line, '/')) WriteToFile(line);
    }
    fclose(f);
}

// ─────────────────────────────────────────────────────────────────────────────
// Signal handler
// ─────────────────────────────────────────────────────────────────────────────

static void CrashHandler(int sig, siginfo_t* info, void* /*ctx*/) {
    // Timestamp
    time_t now = time(nullptr);
    struct tm* t = localtime(&now);
    char timebuf[64];
    strftime(timebuf, sizeof(timebuf), "%Y-%m-%d %H:%M:%S", t);

    WriteToFile("\n");
    WriteToFile("════════════════════════════════════════\n");
    WriteLineFmt("  CRASH  %s\n", timebuf);
    WriteToFile("════════════════════════════════════════\n");
    WriteLineFmt("  Signal   : %s (%d)\n", SignalName(sig), sig);
    if (info) {
        WriteLineFmt("  Fault addr: %p\n", info->si_addr);
        WriteLineFmt("  si_code   : %d\n", info->si_code);
    }
    WriteLineFmt("  Thread   : %lu\n", (unsigned long)pthread_self());
    WriteLineFmt("  PID      : %d\n", getpid());
    WriteToFile("\n");

    WriteStackTrace();
    WriteToFile("\n");
    WriteMaps();
    WriteToFile("════════════════════════════════════════\n\n");
    fflush(s_file);

    // Re-raise to let the OS produce a tombstone as well
    struct sigaction& old = s_oldHandlers[0];
    for (int i = 0; i < kSignalCount; ++i) {
        if (kSignals[i] == sig) { old = s_oldHandlers[i]; break; }
    }
    sigaction(sig, &old, nullptr);
    raise(sig);
}

// ─────────────────────────────────────────────────────────────────────────────
// atexit — normal / SIGTERM close
// ─────────────────────────────────────────────────────────────────────────────

static void OnExit() {
    time_t now = time(nullptr);
    struct tm* t = localtime(&now);
    char timebuf[64];
    strftime(timebuf, sizeof(timebuf), "%Y-%m-%d %H:%M:%S", t);
    WriteLineFmt("[%s] --- Clean exit ---\n\n", timebuf);
    if (s_file) { fflush(s_file); fclose(s_file); s_file = nullptr; }
}

// ─────────────────────────────────────────────────────────────────────────────
// Public API
// ─────────────────────────────────────────────────────────────────────────────

void Init(const char* logPath) {
    // Determine log path
    if (logPath && *logPath) {
        snprintf(s_logPath, sizeof(s_logPath), "%s", logPath);
    } else {
        // Try /sdcard/ first; fall back to /data/local/tmp/
        const char* candidates[] = {
            "/sdcard/inferno_crash.log",
            "/data/local/tmp/inferno_crash.log",
            "/data/data/com.eu.mf.uamo/cache/inferno_crash.log",
        };
        for (const char* p : candidates) {
            FILE* test = fopen(p, "a");
            if (test) { fclose(test); snprintf(s_logPath, sizeof(s_logPath), "%s", p); break; }
        }
    }

    s_file = fopen(s_logPath, "a");
    if (!s_file) {
        LOGD("CrashLog: could not open %s", s_logPath);
        return;
    }
    LOGD("CrashLog: logging to %s", s_logPath);

    // Session header
    time_t now = time(nullptr);
    struct tm* tm_ = localtime(&now);
    char timebuf[64];
    strftime(timebuf, sizeof(timebuf), "%Y-%m-%d %H:%M:%S", tm_);
    WriteLineFmt("\n[%s] === SESSION START  pid=%d ===\n", timebuf, getpid());

    // Install signal handlers
    struct sigaction sa = {};
    sa.sa_sigaction = CrashHandler;
    sa.sa_flags     = SA_SIGINFO | SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    for (int i = 0; i < kSignalCount; ++i)
        sigaction(kSignals[i], &sa, &s_oldHandlers[i]);

    atexit(OnExit);
}

void Log(const char* fmt, ...) {
    if (!s_file) return;
    std::lock_guard<std::mutex> lock(s_mtx);

    time_t now = time(nullptr);
    struct tm* t = localtime(&now);
    char timebuf[32];
    strftime(timebuf, sizeof(timebuf), "%H:%M:%S", t);

    char msg[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    char line[1088];
    snprintf(line, sizeof(line), "[%s] %s\n", timebuf, msg);
    fputs(line, s_file);
    fflush(s_file);
    LOGD("%s", msg);
}

void Flush() {
    if (s_file) fflush(s_file);
}

} // namespace CrashLog
