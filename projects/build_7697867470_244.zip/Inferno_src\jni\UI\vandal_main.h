﻿#pragma once
#define IMGUI_DEFINE_MATH_OPERATORS

#if __has_include("imgui.h")
#include "imgui.h"
#include "imgui_internal.h"
#elif __has_include("imgui/imgui.h")
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"
#elif __has_include("Files/imgui/imgui.h")
#include "Files/imgui/imgui.h"
#include "Files/imgui/imgui_internal.h"
#else
#include "../imgui/imgui.h"
#include "../imgui/imgui_internal.h"
#endif

#include <vector>
#include <string>
#include <cmath>
#include <cstdlib>
#include <cstdint>
#include <algorithm>
#include <mutex>
#include <thread>

#include "font_defines.h"
#include "imgui_settings.h"

#ifdef __ANDROID__
#include <GLES3/gl3.h>
#include <GLES2/gl2.h>
typedef GLuint TextureHandle;
#define TO_IMGUI_TEX(x) ((ImTextureID)(intptr_t)(x))
#else
typedef void* TextureHandle;
#define TO_IMGUI_TEX(x) ((ImTextureID)(x))
#endif

namespace texture
{
    inline TextureHandle preview_slow = 0;
    inline TextureHandle window_bg = 0;
    inline TextureHandle esp_model_bg = 0;
    inline TextureHandle model_image = 0;
    inline TextureHandle menu_bg = 0;
    inline TextureHandle avatar_image = 0;
    inline TextureHandle logotype_image = 0;
    inline TextureHandle anim_logo = 0;
    inline TextureHandle aimbot_logo = 0;
}

struct c_white_fire_bg
{
private:
    struct FireParticle
    {
        ImVec2 pos;
        ImVec2 vel;
        float radius;
        float life;
        float max_life;
        float fade_in_time;
        float fade_out_time;
        float sway_phase;
        float sway_speed;
        float sway_amp;
    };

    static const int MAX_FIRE_PARTICLES = 45;
    std::vector<FireParticle> particles;
    bool initialized = false;

    float rand_f(float min, float max)
    {
        return min + static_cast<float>(rand()) / (static_cast<float>(RAND_MAX / (max - min)));
    }

    float get_particle_alpha(const FireParticle& p) const
    {
        float a = 1.0f;
        if (p.life < p.fade_in_time && p.fade_in_time > 0.001f)
        {
            float t = p.life / p.fade_in_time;
            a = sinf(t * (3.14159265f * 0.5f));
        }
        else if (p.life > (p.max_life - p.fade_out_time) && p.fade_out_time > 0.001f)
        {
            float t = (p.max_life - p.life) / p.fade_out_time;
            if (t < 0.f) t = 0.f;
            a = sinf(t * (3.14159265f * 0.5f));
        }
        return ImClamp(a, 0.0f, 1.0f);
    }

    void spawn_particle(FireParticle& p, const ImRect& rect, bool random_initial)
    {
        if (random_initial)
        {
            p.pos.x = rand_f(rect.Min.x, rect.Max.x);
            p.pos.y = rand_f(rect.Min.y, rect.Max.y);
        }
        else
        {
            if (rand_f(0.f, 1.f) < 0.5f)
            {
                p.pos.x = rect.Max.x + rand_f(2.f, 15.f);
                p.pos.y = rand_f(rect.Min.y, rect.Max.y);
            }
            else
            {
                p.pos.x = rand_f(rect.Min.x, rect.Max.x);
                p.pos.y = rect.Max.y + rand_f(2.f, 15.f);
            }
        }

        p.radius = rand_f(2.0f, 4.0f);
        p.vel.x = rand_f(-32.f, -15.f);
        p.vel.y = rand_f(-36.f, -16.f);

        p.max_life = rand_f(4.0f, 8.0f);
        p.fade_in_time = rand_f(0.8f, 1.5f);
        p.fade_out_time = rand_f(1.0f, 1.8f);

        p.sway_phase = rand_f(0.f, 6.2831853f);
        p.sway_speed = rand_f(1.0f, 2.0f);
        p.sway_amp = rand_f(4.0f, 10.0f);

        if (random_initial)
            p.life = rand_f(0.f, p.max_life * 0.85f);
        else
            p.life = 0.f;
    }

public:
    c_white_fire_bg()
    {
        particles.resize(MAX_FIRE_PARTICLES);
    }

    void render(ImDrawList* dl, const ImRect& rect, float dt, float master_alpha = 1.0f)
    {
        if (master_alpha <= 0.005f)
            return;

        if (!initialized)
        {
            for (int i = 0; i < MAX_FIRE_PARTICLES; i++)
                spawn_particle(particles[i], rect, true);
            initialized = true;
        }

        float time = static_cast<float>(ImGui::GetTime());
        ImVec2 mouse_pos = ImGui::GetMousePos();
        bool mouse_in_rect = rect.Contains(mouse_pos);

        dl->PushClipRect(rect.Min, rect.Max, true);

        for (int i = 0; i < MAX_FIRE_PARTICLES; i++)
        {
            FireParticle& p = particles[i];
            p.life += dt;

            if (p.life >= p.max_life || p.pos.x < (rect.Min.x - 20.f) || p.pos.y < (rect.Min.y - 20.f))
            {
                spawn_particle(p, rect, false);
            }

            p.pos.x += p.vel.x * dt;
            p.pos.y += p.vel.y * dt;

            p.pos.x += sinf(time * p.sway_speed + p.sway_phase) * p.sway_amp * dt;
            p.pos.y += cosf(time * p.sway_speed + p.sway_phase) * p.sway_amp * 0.5f * dt;

            if (mouse_in_rect)
            {
                float m_dx = p.pos.x - mouse_pos.x;
                float m_dy = p.pos.y - mouse_pos.y;
                float m_dist_sq = m_dx * m_dx + m_dy * m_dy;
                float influence_rad = 60.f;
                if (m_dist_sq < influence_rad * influence_rad && m_dist_sq > 1.f)
                {
                    float m_dist = sqrtf(m_dist_sq);
                    float push_factor = (1.0f - (m_dist / influence_rad));
                    p.pos.x += (m_dx / m_dist) * push_factor * 30.f * dt;
                    p.pos.y += (m_dy / m_dist) * push_factor * 30.f * dt;
                }
            }

            float cur_alpha = get_particle_alpha(p) * master_alpha;
            if (cur_alpha <= 0.002f)
                continue;

            dl->AddCircleFilled(p.pos, p.radius, ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, cur_alpha * 0.75f)), 10);
        }

        dl->PopClipRect();
    }
};

using c_animated_bg = c_white_fire_bg;
