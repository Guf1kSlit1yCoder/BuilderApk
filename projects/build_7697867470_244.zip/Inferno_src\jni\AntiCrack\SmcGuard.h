#pragma once
// ──────────────────────────────────────────────────────────────────────────────
//  SmcGuard.h — System 4: polymorphic self-modifying detector in the watchdog.
//
//  The frida-port check lives in its own aligned function. At rest its prologue
//  bytes are XOR-scrambled, so a static memory dump of our .text shows garbage
//  where the detector should be. The watchdog decrypts it immediately before the
//  call and re-encrypts right after, so the plaintext detector exists only for the
//  few microseconds of the check, on one thread.
//
//  SAFETY (Android is strict about W^X and self-modifying code):
//    * never W+X at once — mprotect R+W to patch, R+X to run.
//    * __builtin___clear_cache after every code edit (ARM needs an I-cache flush).
//    * only the single watchdog thread ever calls the protected function, so no
//      other thread can execute it while it is scrambled.
//    * FAIL-SAFE: if any mprotect fails (device blocks it), we leave the function
//      in plaintext + R+X and just call it — degraded (not polymorphic) but never
//      a crash, and the check still runs.
// ──────────────────────────────────────────────────────────────────────────────
#include <cstdint>
#include <cstddef>
#include <sys/mman.h>
#include <poll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include "Syscalls.h"

namespace AntiCrack {

// ── the protected detector ──────────────────────────────────────────────────────
// Aligned so its first page region is well-defined; noinline so it is a real,
// addressable function; padded with a tiny volatile loop so the scrambled region
// stays inside the body. Returns true if a frida server port is open.
inline __attribute__((noinline, aligned(64)))
bool SmcFridaCheck() {
    volatile int pad = 0;
    for (int i = 0; i < 3; ++i) pad += i;      // keep the body > scramble region
    const int ports[2] = { 27042, 27043 };
    bool open = false;
    for (int k = 0; k < 2 && !open; ++k) {
        int s = ::socket(AF_INET, SOCK_STREAM, 0);
        if (s < 0) continue;
        int fl = fcntl(s, F_GETFL, 0); fcntl(s, F_SETFL, fl | O_NONBLOCK);
        struct sockaddr_in a; __builtin_memset(&a, 0, sizeof(a));
        a.sin_family = AF_INET; a.sin_port = htons(ports[k]);
        ::inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
        if (::connect(s, (struct sockaddr*)&a, sizeof(a)) == 0) open = true;
        else {
            struct pollfd pfd;
            pfd.fd = s;
            pfd.events = POLLOUT;
            pfd.revents = 0;
            if (::poll(&pfd, 1, 60) > 0) {
                if ((pfd.revents & POLLOUT) && !(pfd.revents & (POLLERR | POLLHUP))) {
                    int err = 0; socklen_t el = sizeof(err);
                    ::getsockopt(s, SOL_SOCKET, SO_ERROR, &err, &el);
                    open = (err == 0);
                }
            }
        }
        ::close(s);
    }
    return open || (pad < 0);                  // pad use keeps it from being folded
}

class SmcGuard {
public:
    // Run the detector under the polymorphic cover. Returns true if frida detected.
    // Call ONLY from the single watchdog thread.
    static bool GuardedCheck() {
        if (m_disabled) return SmcFridaCheck();   // device blocked SMC earlier

        void* fn = reinterpret_cast<void*>(&SmcFridaCheck);
        void* page = PageAlign(fn);
        const size_t span = kPageSize * 2;        // cover the region across a boundary

        // One-time: scramble to the resting (encrypted) state so a dump taken
        // between watchdog ticks shows garbage.
        if (!m_everScrambled) {
            if (!Protect(page, span, PROT_READ | PROT_WRITE)) { m_disabled = true; return SmcFridaCheck(); }
            Xor(fn);                              // plaintext -> garbage
            Flush(fn);
            if (!Protect(page, span, PROT_READ | PROT_EXEC)) { Unscramble(fn, page, span); m_disabled = true; return SmcFridaCheck(); }
            m_everScrambled = true;
        }

        // Decrypt -> run -> re-encrypt. Any failure => leave plaintext+RX, disable.
        if (!Protect(page, span, PROT_READ | PROT_WRITE)) { m_disabled = true; return SmcFridaCheck(); }
        Xor(fn); Flush(fn);                       // garbage -> plaintext
        if (!Protect(page, span, PROT_READ | PROT_EXEC)) { m_disabled = true; return SmcFridaCheck(); }

        const bool detected = SmcFridaCheck();    // plaintext, executable

        if (!Protect(page, span, PROT_READ | PROT_WRITE)) { m_disabled = true; return detected; }
        Xor(fn); Flush(fn);                       // plaintext -> garbage (rest state)
        if (!Protect(page, span, PROT_READ | PROT_EXEC)) { Unscramble(fn, page, span); m_disabled = true; }
        return detected;
    }

private:
    static const size_t kPageSize = 4096;
    static const size_t kRegion   = 32;           // bytes scrambled from fn start
    static const uint8_t kKey     = 0x7F;

    static void* PageAlign(void* p) { return (void*)((uintptr_t)p & ~(kPageSize - 1)); }

    static bool Protect(void* p, size_t len, int prot) { return sc::sys_mprotect(p, len, prot) == 0; }

    static void Xor(void* fn) {
        volatile uint8_t* p = reinterpret_cast<volatile uint8_t*>(fn);
        for (size_t i = 0; i < kRegion; ++i) p[i] ^= kKey;
    }
    static void Flush(void* fn) {
        char* b = reinterpret_cast<char*>(fn);
        __builtin___clear_cache(b, b + kRegion);
    }
    // Emergency restore to plaintext + R+X so the function is never left callable-as-garbage.
    static void Unscramble(void* fn, void* page, size_t span) {
        if (Protect(page, span, PROT_READ | PROT_WRITE)) { Xor(fn); Flush(fn); Protect(page, span, PROT_READ | PROT_EXEC); }
    }

    static inline bool m_disabled = false;
    static inline bool m_everScrambled = false;
};

} // namespace AntiCrack
