"""Run the actual SDK math as a freestanding native regression executable.

Usage: python tests/test_skeleton_transform.py --compiler <clang++.exe>
The Android build separately checks all SDK and component layout assertions.
"""
import argparse
import pathlib
import re
import subprocess
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]


def extract_struct(source, name):
    start = source.index("struct " + name + "\n")
    brace = source.index("{", start)
    depth = 1
    end = brace + 1
    while depth:
        depth += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[start:end + 1]


def extract_definition(source, signature):
    start = source.index(signature)
    brace = source.index("{", start)
    depth, end = 1, brace + 1
    while depth:
        depth += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[start:end]


def spatial_regression(source, implementation):
    # Compile the actual production location/cache readers, with only platform
    # pointer checks stubbed. Android compilation verifies full object layouts.
    declarations = r'''
namespace std {
float sin(float);
float cos(float);
inline void* memcpy(void* dst, const void* src, unsigned long long n) {
    auto* d = static_cast<unsigned char*>(dst);
    auto* s = static_cast<const unsigned char*>(src);
    for (unsigned long long i = 0; i < n; ++i) d[i] = s[i];
    return dst;
}
}
namespace Tools {
inline bool IsPtrValid(const void* p) { return p != nullptr; }
inline bool IsReadable(const void* p, unsigned long long) { return p != nullptr; }
}
#define CONST_PI 3.14159265358979323846f
'''
    definitions = "\n".join(extract_struct(source, name) for name in ("FVector2D", "FRotator", "FCameraView", "FCameraCacheSample"))
    fixtures = r'''
struct USceneComponent {
    USceneComponent* AttachParent = nullptr;
    FVector RelativeLocation;
    unsigned char Pad_0x184[12] = {};
    FTransform ComponentToWorld;
    bool TryGetWorldLocation(FVector&) const;
};
struct APlayerCameraManager {
    unsigned char CameraCache[0x6C0] = {};
    unsigned char CameraCachePrivate[0x6C0] = {};
    bool GetCameraView(FCameraView&) const;
};
'''
    functions = "\n".join(extract_definition(implementation, signature) for signature in (
        "bool USceneComponent::TryGetWorldLocation",
        "bool APlayerCameraManager::GetCameraView",
    ))
    cases = r'''
int run_spatial_checks() {
    USceneComponent root, parent;
    root.RelativeLocation = {2928.7f,-601.9f,-7804.6f};
    root.ComponentToWorld.Translation = {100,200,300}; // stale but finite cache
    FVector position;
    if (!root.TryGetWorldLocation(position) || position.Z != -7804.6f) return 20;
    root.RelativeLocation = {0,0,0};
    if (!root.TryGetWorldLocation(position) || position.SizeSquared() != 0) return 21;
    root.AttachParent = &parent;
    root.RelativeLocation = {1,2,3};
    if (root.TryGetWorldLocation(position)) return 22; // unupdated attached cache
    root.Pad_0x184[0] = 0x02;
    if (!root.TryGetWorldLocation(position) || position.X != 100) return 23;
    root.ComponentToWorld.Rotation = {0,0,0,0};
    if (root.TryGetWorldLocation(position)) return 24; // invalid transform, no local fallback
    root.Pad_0x184[0] = 0x08;
    if (!root.TryGetWorldLocation(position) || position.X != 1) return 25; // absolute location
    root.RelativeLocation.X = __builtin_nanf("");
    if (root.TryGetWorldLocation(position) || position.SizeSquared() != 0) return 26;
    root.AttachParent = nullptr;
    root.RelativeLocation.X = __builtin_inff();
    if (root.TryGetWorldLocation(position)) return 27;

    APlayerCameraManager camera;
    FCameraView view;
    if (camera.GetCameraView(view)) return 28; // no guessed 90-degree camera
    FCameraCacheSample older, newer;
    older.Timestamp = 1;
    older.POV.Location = {100,200,300};
    older.POV.Rotation = {10,90,0};
    older.POV.FOV = 75;
    newer.Timestamp = 2;
    newer.POV.Location = {0,0,0}; // origin and zero rotation must both be accepted
    newer.POV.Rotation = {0,0,0};
    newer.POV.FOV = 5; // magnified scopes are not reset to 90 degrees
    std::memcpy(camera.CameraCache, &older, sizeof(older));
    std::memcpy(camera.CameraCachePrivate, &newer, sizeof(newer));
    if (!camera.GetCameraView(view) || view.Location.X != 0 || view.Rotation.Yaw != 0 || view.FOV != 5) return 29;
    older.Timestamp = 3;
    std::memcpy(camera.CameraCache, &older, sizeof(older));
    if (!camera.GetCameraView(view) || view.Location.X != 100 || view.Rotation.Yaw != 90 || view.FOV != 75) return 30;
    newer.Timestamp = 4;
    newer.POV.Rotation.Yaw = __builtin_nanf("");
    std::memcpy(camera.CameraCachePrivate, &newer, sizeof(newer));
    if (!camera.GetCameraView(view) || view.Location.X != 100 || view.FOV != 75) return 31;
    older.POV.FOV = __builtin_inff();
    std::memcpy(camera.CameraCache, &older, sizeof(older));
    if (camera.GetCameraView(view)) return 32; // never mix individually valid fields
    newer.POV.Rotation.Yaw = 0;
    newer.POV.FOV = 180;
    std::memcpy(camera.CameraCachePrivate, &newer, sizeof(newer));
    if (camera.GetCameraView(view)) return 33;
    newer.POV.FOV = 60;
    newer.Timestamp = -1;
    std::memcpy(camera.CameraCachePrivate, &newer, sizeof(newer));
    if (camera.GetCameraView(view)) return 34;
    newer.Timestamp = __builtin_nanf("");
    std::memcpy(camera.CameraCachePrivate, &newer, sizeof(newer));
    if (camera.GetCameraView(view)) return 35;
    newer.Timestamp = 0;
    std::memcpy(camera.CameraCachePrivate, &newer, sizeof(newer));
    if (!camera.GetCameraView(view) || view.FOV != 60) return 36;
    older.Timestamp = 0;
    older.POV.FOV = 75;
    std::memcpy(camera.CameraCache, &older, sizeof(older));
    if (!camera.GetCameraView(view) || view.FOV != 60) return 37; // private wins a tie
    return 0;
}
'''
    return declarations + definitions + fixtures + functions + cases


def actor_regression(implementation):
    # Small fixed-capacity std substitutes allow the real traversal to run as a
    # freestanding Windows executable without Android or MSVC runtime libraries.
    fixtures = r'''
using int32_t = int;
using size_t = unsigned long long;
namespace std {
template<class T> T min(T a, T b) { return a < b ? a : b; }
template<class T> T max(T a, T b) { return a > b ? a : b; }
template<class T> class unordered_set {
    T entries[128] = {};
    size_t count = 0;
public:
    struct Result { bool second; };
    void clear() { count = 0; }
    size_t bucket_count() const { return 4096; }
    void reserve(size_t) {}
    Result insert(T value) {
        for (size_t i = 0; i < count; ++i) if (entries[i] == value) return {false};
        entries[count++] = value;
        return {true};
    }
};
template<class T> class vector {
    T entries[128] = {};
    size_t count = 0;
public:
    void clear() { count = 0; }
    size_t size() const { return count; }
    T* begin() { return entries; }
    T* end() { return entries + count; }
    void push_back(T value) { entries[count++] = value; }
    void erase(T* first, T*) { count = first - entries; }
};
template<class T> T* find(T* first, T* last, T value) {
    for (; first != last && *first != value; ++first) {}
    return first;
}
template<class T> struct less {
    bool operator()(T a, T b) const { return a < b; }
};
template<class T, class Compare> void sort(T* first, T* last, Compare less) {
    for (T* i = first; i != last; ++i)
        for (T* j = i; j != last; ++j)
            if (less(*j,*i)) { T t = *i; *i = *j; *j = t; }
}
template<class T> T* unique(T* first, T* last) {
    if (first == last) return last;
    T* result = first;
    while (++first != last) if (*result != *first) *++result = *first;
    return result + 1;
}
}
template<class T> struct TArray {
    T* data = nullptr;
    int count = 0;
    int capacity = 0;
    int Num() const { return count; }
    int Max() const { return capacity; }
    T* GetData() const { return data; }
    T operator[](int i) const { return data[i]; }
};
struct AActor { int marker; };
struct UWorld;
struct ULevelActorContainer { TArray<AActor*> Actors; };
struct ULevel {
    TArray<AActor*> Actors;
    UWorld* OwningWorld = nullptr;
    ULevelActorContainer* ActorCluster = nullptr;
};
struct UWorld {
    ULevel* PersistentLevel = nullptr;
    TArray<ULevel*> Levels;
    void GetActors(std::vector<AActor*>&) const;
};
'''
    function = extract_definition(implementation, "void UWorld::GetActors")
    cases = r'''
int run_actor_checks() {
    UWorld world, otherWorld;
    ULevel persistent, streamed, foreign;
    persistent.OwningWorld = streamed.OwningWorld = &world;
    foreign.OwningWorld = &otherWorld;
    AActor entities[5];
    AActor* native[] = {&entities[0], &entities[1], nullptr};
    AActor* clustered[] = {&entities[1], &entities[2]};
    AActor* loaded[] = {&entities[3]};
    AActor* stale[] = {&entities[4]};
    persistent.Actors = {native,3,3};
    ULevelActorContainer cluster;
    cluster.Actors = {clustered,2,2};
    persistent.ActorCluster = &cluster;
    streamed.Actors = {loaded,1,1};
    foreign.Actors = {stale,1,1};
    ULevel* levels[] = {&persistent,&streamed,&streamed,nullptr,&foreign};
    world.PersistentLevel = &persistent;
    world.Levels = {levels,5,5};
    std::vector<AActor*> result;
    world.GetActors(result);
    if (result.size() != 4) return 40;
    for (int i = 0; i < 4; ++i) if (result.begin()[i] != &entities[i]) return 41;
    persistent.Actors.capacity = 0; // invalid native header must not hide cluster
    world.GetActors(result);
    if (result.size() != 3) return 42;
    cluster.Actors.count = 50001;
    world.GetActors(result);
    if (result.size() != 1 || result.begin()[0] != &entities[3]) return 43;
    world.Levels.count = 1025;
    world.GetActors(result);
    if (result.size() != 0) return 44;
    cluster.Actors = {nullptr,2,2};
    world.Levels = {};
    world.GetActors(result);
    if (result.size() != 0) return 45;
    world.PersistentLevel = nullptr;
    result.push_back(&entities[4]);
    world.GetActors(result);
    if (result.size() != 0) return 46; // no previous-frame ghosts
    return 0;
}
'''
    return fixtures + function + cases


def skeleton_regression(esp, helper, helper_header):
    # Execute the production cache and segment clipper (not a Python reimplementation).
    declarations = r'''
namespace std {
inline bool isfinite(double x) { return __builtin_isfinite(x); }
}
namespace SDK {
using FVector = ::FVector;
using FVector2D = ::FVector2D;
struct UObject {};
}
namespace UE4Helper {
'''
    projection = extract_definition(helper_header, "struct ScreenProjection") + ";\n"
    project = extract_definition(helper, "bool WorldToScreen(")
    frame = extract_definition(esp, "struct SkeletonFrame") + ";\n"
    pose = extract_definition(esp, "struct SkeletonPose") + ";\n"
    identity = extract_definition(esp, "struct SkeletonObjectId") + ";\n"
    clip = extract_definition(esp, "static bool ProjectSkeletonSegment(")
    cases = r'''
int run_skeleton_checks() {
    SkeletonFrame frame;
    frame.origin = {100,200,300};
    SkeletonPose pose, other;
    FVector positions[kSkeletonBoneCount]{};
    auto clear = [&]() { for (auto& p : positions) p = {}; };
    if (pose.Resolve(positions, false, frame, 1.0)) return 50; // no fabricated startup pose
    for (int i = 0; i < kSkeletonBoneCount; ++i) positions[i] = frame.origin + FVector{10,20,float(i+1)};
    if (!pose.Resolve(positions, true, frame, 1.0)) return 51;
    for (int i = 0; i < kSkeletonBoneCount; ++i) if (!pose.valid[i]) return 52;
    clear();
    frame.origin = {110,220,330};
    if (!pose.Resolve(positions, false, frame, 1.2) || positions[0].X != 120 || positions[0].Y != 240) return 53;
    if (pose.sampledAt[0] != 1.0) return 54; // fallback must not renew TTL
    clear();
    frame.xAxis = {0,1,0}; frame.yAxis = {-1,0,0};
    frame.scale = {2,3,1};
    if (!pose.Resolve(positions, false, frame, 1.3) || positions[0].X != 50 || positions[0].Y != 240) return 55;
    clear();
    positions[0] = {111,222,333}; // live sample replaces held pose immediately
    positions[1].X = __builtin_nanf(""); // a broken joint must not invalidate the others
    if (!pose.Resolve(positions, true, frame, 1.4) || positions[0].X != 111 || !pose.valid[1]) return 56;
    if (pose.sampledAt[0] != 1.4 || pose.sampledAt[1] != 1.0) return 57;
    clear();
    if (other.Resolve(positions, false, frame, 1.5)) return 58; // per-actor isolation
    clear();
    if (!pose.Resolve(positions, false, frame, 1.76) || !pose.valid[0] || pose.valid[1]) return 59;
    clear();
    if (pose.Resolve(positions, false, frame, 2.151)) return 60; // no indefinitely frozen skeleton
    clear();
    positions[0] = frame.origin + FVector{10,20,30};
    if (!pose.Resolve(positions, true, frame, 3.0)) return 61; // recover after expiry
    clear();
    frame.origin.X += 301;
    if (pose.Resolve(positions, false, frame, 3.1)) return 62; // teleport resets history
    positions[0] = frame.origin + FVector{1,2,3};
    if (!pose.Resolve(positions, true, frame, 4.0)) return 63;
    clear();
    if (pose.Resolve(positions, false, frame, 3.9)) return 64; // clock rollback
    positions[0] = frame.origin + FVector{1,2,3};
    pose.Resolve(positions, true, frame, 5.0);
    frame.scale.Z = 0;
    if (pose.Resolve(positions, false, frame, 5.1) || pose.hasRoot) return 65;
    frame.scale.Z = 1;
    positions[0] = frame.origin + FVector{1,2,3};
    pose.Resolve(positions, true, frame, 6.0);
    if (pose.Resolve(positions, false, frame, __builtin_nan(""))) return 66;
    frame.scale = {-2,3,4};
    const auto world = frame.ToWorld(frame.ToLocal({500,210,350}));
    if (std::abs(world.X - 500) > 0.001f || std::abs(world.Y - 210) > 0.001f || std::abs(world.Z - 350) > 0.001f) return 67;
    frame.yAxis = frame.xAxis;
    if (frame.IsValid()) return 68;

    SDK::UObject obj;
    SkeletonObjectId id{&obj,1,2}, same{&obj,1,2}, recycled{&obj,1,3};
    if (!(id == same) || id == recycled) return 69;

    UE4Helper::ScreenProjection projection;
    projection.Valid = true; projection.Width = projection.Height = 100;
    projection.CenterX = projection.CenterY = projection.FocalX = projection.FocalY = 50;
    projection.Forward = {1,0,0}; projection.Right = {0,1,0}; projection.Up = {0,0,1};
    FVector2D a, b;
    if (!ProjectSkeletonSegment({10,-100,0}, {10,100,0}, projection, a, b)) return 70;
    if (std::abs(a.X) > 0.001f || std::abs(b.X - 100) > 0.001f) return 71;
    if (ProjectSkeletonSegment({10,100,0}, {10,200,0}, projection, a, b)) return 72;
    if (ProjectSkeletonSegment({-10,0,0}, {-1,0,0}, projection, a, b)) return 73;
    if (!ProjectSkeletonSegment({-10,0,0}, {10,0,5}, projection, a, b)) return 74;
    if (a.Y < -0.001f || a.Y > 100.001f || b.Y < -0.001f || b.Y > 100.001f) return 75;
    if (!ProjectSkeletonSegment({10,0,5}, {-10,0,0}, projection, a, b)) return 76;
    if (!ProjectSkeletonSegment({10,0,-100}, {10,0,100}, projection, a, b)) return 77;
    if (std::abs(a.Y - 100) > 0.001f || std::abs(b.Y) > 0.001f) return 78;
    projection.Location.Y = 5; // the same held world point reprojects with the current camera
    if (!ProjectSkeletonSegment({10,0,0}, {10,0,5}, projection, a, b) || a.X != 25) return 79;
    if (ProjectSkeletonSegment({__builtin_nanf(""),0,0}, {10,0,5}, projection, a, b)) return 80;
    projection.Valid = false;
    if (ProjectSkeletonSegment({10,0,0}, {10,0,5}, projection, a, b)) return 81;
    return 0;
}
'''
    return declarations + projection + project + "\n}\nconstexpr int kSkeletonBoneCount = 16;\n" + frame + pose + identity + clip + cases


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--compiler", required=True)
    args = parser.parse_args()
    source = (ROOT / "jni/SDK/SDK.hpp").read_text(encoding="utf-8")
    implementation = (ROOT / "jni/SDK/SDK.cpp").read_text(encoding="utf-8")
    dump_path = ROOT.parent / "sdk/sdk/SDK/CoreUObject_structs.hpp"
    dump_transform = extract_struct(dump_path.read_text(encoding="utf-8"), "FTransform")
    assert re.search(r"Scale3D;\s*// 0x1C", dump_transform), "Dump layout changed"
    get_location = implementation.split("FVector USkeletalMeshComponent::GetBoneLocation(int boneId)", 1)[1].split("float UCapsuleComponent::", 1)[0]
    assert "meshPos +" not in get_location, "Component-relative coordinates must not be returned as world space"
    assert "boneTransform.IsValid() && meshWorld.IsValid()" in get_location
    pipeline = (ROOT / "jni/Core/ActorPipeline.cpp").read_text(encoding="utf-8")
    esp = (ROOT / "jni/Core/ESP.cpp").read_text(encoding="utf-8")
    assert "world->GetActors(actors)" in pipeline
    assert "rootPos.Z < -2000" not in pipeline and "rootPos.Z > 20000" not in pipeline
    assert "TryGetWorldLocation(rootPos)" in pipeline
    assert "GetCameraView(view)" in esp and "GetFOVAngle()" not in esp
    draw_skeleton = extract_definition(esp, "void DrawPlayerSkeleton(")
    assert draw_skeleton.count("actor->GetBonePositions(") == 1, "Read the pose once for all joints"
    assert "actor->GetBonePos(" not in draw_skeleton, "Do not resnapshot for each joint"
    assert "AddCircle" not in draw_skeleton, "Skeleton joint dots must stay removed"
    assert "GetBonePositions(s_BoneNames, B_MAX, positions)" in draw_skeleton
    assert "cached.mesh == meshId" in draw_skeleton and "cached.asset == assetId" in draw_skeleton
    assert "cached.actor == actorId" in draw_skeleton and "cached.root == rootId" in draw_skeleton
    assert "previousWorld == worldId" in esp and "previousPlayer == playerId" in esp
    assert "if (!present) it = s_SkeletonCache.erase(it)" in esp
    assert "if (g_Config.esp_enabled && p.onScreen)" not in esp, "Warm poses independently of capsule visibility"
    helper = (ROOT / "jni/Core/UE4Helper.cpp").read_text(encoding="utf-8")
    helper_header = (ROOT / "jni/Core/UE4Helper.h").read_text(encoding="utf-8")
    dump_classes = (ROOT.parent / "dump_Engine_classes.hpp").read_text(encoding="utf-8")
    for pattern in (r"ActorCluster; // 0xD8", r"Actors; // 0x28", r"Levels; // 0x138",
                    r"CameraCachePrivate; // 0x1EC0", r"AttachParent; // 0xF0",
                    r"RelativeLocation; // 0x154"):
        assert re.search(pattern, dump_classes), f"Dump layout changed: {pattern}"

    # Only std math needed by the extracted production structs. sqrt is unused
    # in these tests, but must be declared for FVector's inline methods.
    prefix = r'''
using uint8_t = unsigned char;
extern "C" {
int _fltused = 0;
// Freestanding test binary has no CRT. Clang emits these for aggregate copies.
void* memset(void* dst, int value, unsigned long long count) {
    auto* p = static_cast<volatile unsigned char*>(dst);
    for (unsigned long long i = 0; i < count; ++i) p[i] = static_cast<unsigned char>(value);
    return dst;
}
void* memcpy(void* dst, const void* src, unsigned long long count) {
    auto* d = static_cast<volatile unsigned char*>(dst);
    auto* s = static_cast<const volatile unsigned char*>(src);
    for (unsigned long long i = 0; i < count; ++i) d[i] = s[i];
    return dst;
}
}
namespace std {
inline bool isfinite(float x) { return __builtin_isfinite(x); }
inline float abs(float x) { return x < 0 ? -x : x; }
inline float sqrt(float x) { return __builtin_sqrtf(x); }
}
#define offsetof(T, member) __builtin_offsetof(T, member)
'''
    structs = "\n".join(extract_struct(source, name) for name in ("FVector", "FQuat", "FTransform"))
    tests = r'''
static_assert(sizeof(FTransform) == 0x30, "Array stride");
static_assert(offsetof(FTransform, Translation) == 0x10, "Translation layout");
static_assert(offsetof(FTransform, Scale3D) == 0x1C, "Scale layout");
bool near(float a, float b) { return std::abs(a - b) < 0.001f; }
bool equals(FVector a, FVector b) { return near(a.X,b.X) && near(a.Y,b.Y) && near(a.Z,b.Z); }
int main() {
    // Byte image in the dump's field order. Nonzero padding catches the old
    // incorrect 0x20 scale offset, including a falsely nonzero Scale3D.Z.
    const float raw[12] = {0,0,0,1, 100,200,300, 2,3,4, 77,88};
    FTransform transform;
    auto* dst = reinterpret_cast<unsigned char*>(&transform);
    auto* src = reinterpret_cast<const unsigned char*>(raw);
    for (unsigned i = 0; i < sizeof(transform); ++i) dst[i] = src[i];
    if (!transform.IsValid()) return 1;
    if (!equals(transform.Scale3D, {2,3,4})) return 2;
    if (!equals(transform.TransformPosition({1,2,3}), {102,206,312})) return 3;

    // Rotation must follow nonuniform scale, not precede it.
    transform.Rotation = {0,0,0.70710678118f,0.70710678118f};
    if (!equals(transform.TransformPosition({1,2,3}), {94,202,312})) return 4;
    transform.Scale3D = {1,1,0};
    if (transform.IsValid()) return 5;
    transform.Scale3D = {-2,3,4};
    if (!transform.IsValid()) return 6;
    transform.Rotation = {0,0,0,0};
    if (transform.IsValid()) return 7;
    transform.Rotation = {0,0,0,1};
    transform.Translation.X = __builtin_nanf("");
    if (transform.IsValid()) return 8;
    transform.Translation.X = 0;
    transform.Scale3D.X = __builtin_inff();
    if (transform.IsValid()) return 9;

    // Two records must retain the 0x30 stride and independent scales.
    FTransform pair[2];
    pair[0].Translation = {10,20,30};
    pair[1].Translation = {1000,2000,3000};
    pair[1].Scale3D = {2,3,4};
    if (!equals(pair[1].TransformPosition({1,1,1}), {1002,2003,3004})) return 10;
    if (reinterpret_cast<unsigned char*>(&pair[1]) - reinterpret_cast<unsigned char*>(&pair[0]) != 0x30) return 11;
    return 0;
}
'''
    tests = tests.replace("    return 0;\n}", "    int spatial = run_spatial_checks();\n    if (spatial) return spatial;\n    int actors = run_actor_checks();\n    if (actors) return actors;\n    return run_skeleton_checks();\n}")
    tests = (spatial_regression(source, implementation) + actor_regression(implementation) +
             skeleton_regression(esp, helper, helper_header) + tests)
    with tempfile.TemporaryDirectory(prefix="arena-skeleton-test-") as tmp:
        cpp = pathlib.Path(tmp) / "transform_regression.cpp"
        exe = pathlib.Path(tmp) / "transform_regression.dll"
        cpp.write_text(prefix + structs + tests, encoding="utf-8")
        obj = pathlib.Path(tmp) / "transform_regression.obj"
        linker = pathlib.Path(args.compiler).with_name("ld.lld.exe")
        subprocess.run([args.compiler, "--target=x86_64-pc-windows-msvc", "-O2", "-std=c++17", "-fno-stack-protector", "-mno-stack-arg-probe", "-c", str(cpp), "-o", str(obj)], check=True)
        # NDK ships ld.lld, not a separate lld-link executable.
        subprocess.run([str(linker), "-flavor", "link", "/entry:main", "/subsystem:console", "/nodefaultlib", f"/out:{exe}", str(obj)], check=True)
        print("Running native regression executable", flush=True)
        try:
            result = subprocess.run([str(exe)], timeout=10)
        except subprocess.TimeoutExpired:
            objdump = pathlib.Path(args.compiler).with_name("llvm-objdump.exe")
            diagnostic = ROOT / "build_cmake" / "regression_disassembly.txt"
            diagnostic.write_text(subprocess.check_output([str(objdump), "-d", str(exe)], text=True), encoding="utf-8")
            raise SystemExit(f"Regression timed out; disassembly: {diagnostic}")
        if result.returncode:
            raise SystemExit(f"C++ regression failed: test/exit code {result.returncode}")
    print("PASS: SDK transform math (11), world location/camera (18), actor traversal (7), skeleton cache/clipping (32), dump layouts and integration guards")


if __name__ == "__main__":
    main()
