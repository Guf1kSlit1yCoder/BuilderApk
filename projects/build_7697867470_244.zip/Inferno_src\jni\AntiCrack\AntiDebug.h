#pragma once
// ──────────────────────────────────────────────────────────────────────────────
//  AntiDebug.h — anti-debug / anti-instrumentation with a strike system.
//
//  Eight checks (ptrace/TracerPid, maps scan, Frida ports, inline-hook prologue,
//  frida-gadget dlopen, timing, ro.debuggable). Nothing crashes: on detection the
//  license is silently invalidated (AuthGate cleared) so the menu drops to the
//  login screen and features stop — no obvious "you were caught" moment.
//
//  Kill policy is tuned to avoid locking out legit devices:
//    * STRONG signals (TracerPid / Frida in maps / Frida ports / ro.debuggable):
//        - two at once          -> invalidate immediately (very likely real), or
//        - one persists >= 30 s -> invalidate (grace window).
//    * WEAK heuristics (inline-hook prologue, timing) only ADD strikes while a
//        strong signal is already present — never act on their own (ifunc stubs
//        and scheduler jitter make them false-positive-prone).
//    * EXTERNAL AddStrike (e.g. repeated forged-server logins) hard-kills at a
//        high threshold so a couple of mistyped keys never lock the device.
//
//  A detached watchdog thread (StartWatchdog, from JNI_OnLoad) runs the pass
//  periodically. IsCompromised() is cheap for a per-frame gate.
// ──────────────────────────────────────────────────────────────────────────────
#include <atomic>
#include <string>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <dlfcn.h>
#include <poll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/system_properties.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/prctl.h>
#include "ObfStr.h"
#include "AuthGate.h"
#include "Syscalls.h"
#include "SmcGuard.h"

namespace AntiCrack {

class AntiDebug {
public:
    static AntiDebug& I() { static AntiDebug d; return d; }

    // External strong signal (login forgery etc.). Hard-kills only when many pile up.
    void AddStrike(int n) { if (n > 0) m_extStrikes.fetch_add(n); }

    bool IsCompromised() const { return m_invalidated.load(); }

    void Tick() {
        const bool tracer = CheckTracerPid();   // 1. ptrace / TracerPid
        const bool maps   = CheckMaps();         // 2,3,6. frida/xposed/substrate/gadget
        // NOTE: SMC (SmcGuard) disabled — mprotect on the detector's 2-page span
        // momentarily removes X from ~8KB of code that OTHER threads execute, which
        // crashes on inject (page-perm race). Plain direct port check instead.
        const bool ports  = CheckFridaPorts();   // 4. frida-server ports
        const bool dbg    = CheckDebuggable();   // 8. ro.debuggable
        const int strong  = (tracer ? 1 : 0) + (maps ? 1 : 0) + (ports ? 1 : 0) + (dbg ? 1 : 0);
        const bool inlhk  = CheckInlineHook();   // 5
        const bool timg   = CheckTiming();       // 7

#ifdef ARENA_DIAG
        {
            // Diagnostic: record every check each tick + the current decision inputs,
            // so a false-positive lockout can be traced to the exact check.
            static int s_tracerPid = -2;
            if (s_tracerPid == -2) s_tracerPid = ReadTracerPidValue();
            FILE* df = fopen("/sdcard/Download/arena_ad_diag.txt", "a");
            if (df) {
                fprintf(df, "t=%llums tracer=%d(pid=%d) maps=%d ports=%d dbg=%d inlineHook=%d timing=%d | strong=%d ext=%d firstStrongAgo=%lldms invalidated=%d\n",
                        (unsigned long long)NowMs(), (int)tracer, ReadTracerPidValue(),
                        (int)maps, (int)ports, (int)dbg, (int)inlhk, (int)timg,
                        strong, m_extStrikes.load(),
                        m_firstStrongMs.load() ? (long long)(NowMs() - m_firstStrongMs.load()) : -1,
                        (int)m_invalidated.load());
                fclose(df);
            }
        }
#endif

        if (strong >= 2) { Invalidate(); return; }

        if (strong == 1) {
            uint64_t z = 0; m_firstStrongMs.compare_exchange_strong(z, NowMs());
            // weak heuristics only corroborate while a strong signal is live
            int weak = (inlhk ? 1 : 0) + (timg ? 1 : 0);   // 5,7
            if (weak >= 2) { Invalidate(); return; }
            if (NowMs() - m_firstStrongMs.load() >= kGraceMs) { Invalidate(); return; }
        } else {
            m_firstStrongMs.store(0);            // strong signal gone -> reset grace
        }

        if (m_extStrikes.load() >= kHardExtStrikes) Invalidate();
    }

    // Raw TracerPid integer (for diagnostics): the PID of a tracer, or 0 if none.
    static int ReadTracerPidValue() {
        int fd = sc::sys_open(OBFSTR("/proc/self/status"), O_RDONLY);
        if (fd < 0) return -1;
        char buf[4096]; ssize_t n = sc::sys_read(fd, buf, sizeof(buf) - 1); sc::sys_close(fd);
        if (n <= 0) return -1;
        buf[n] = 0;
        const char* p = strstr(buf, OBFSTR("TracerPid:"));
        if (!p) return -1;
        p += 10; while (*p == ' ' || *p == '\t') ++p;
        return atoi(p);
    }

    // Active anti-attach: fork a child that ptrace-ATTACHes to us. Only one tracer
    // is allowed per process, so once our child holds us, any debugger/gdbserver/
    // frida ptrace attach fails. yama stays strict (we whitelist only our child via
    // PR_SET_PTRACER — no PTRACER_ANY). FULLY fail-safe: fork/ptrace failure => no-op.
    // (In an injected lib this can be device-sensitive; kept guarded so it never
    //  harms the host — if it cannot engage, detection via TracerPid still stands.)
    static void StartPtraceGuard() {
        static std::atomic<bool> started{false};
        bool expected = false;
        if (!started.compare_exchange_strong(expected, true)) return;

        const pid_t parent = getpid();
        const pid_t child = fork();
        if (child < 0) return;                         // fork failed -> skip
        if (child == 0) {
            // CHILD: async-signal-safe calls only. Retry ATTACH until the parent has
            // whitelisted us (PR_SET_PTRACER), then keep it traced forever.
            pid_t pp = parent;
            bool attached = false;
            for (int i = 0; i < 100 && !attached; ++i) {
                if (ptrace(PTRACE_ATTACH, pp, nullptr, nullptr) == 0) attached = true;
                else usleep(2000);
            }
            if (attached) {
                int status;
                waitpid(pp, &status, 0);
                ptrace(PTRACE_CONT, pp, nullptr, nullptr);
                while (waitpid(pp, &status, 0) > 0) {
                    if (WIFEXITED(status) || WIFSIGNALED(status)) break;
                    int sig = WIFSTOPPED(status) ? WSTOPSIG(status) : 0;
                    if (sig == SIGTRAP || sig == SIGSTOP) sig = 0;   // swallow ptrace stops
                    ptrace(PTRACE_CONT, pp, nullptr, reinterpret_cast<void*>((long)sig));
                }
            }
            _exit(0);
        } else {
            // PARENT: allow ONLY this child to trace us (keeps yama strict).
            prctl(PR_SET_PTRACER, child, 0, 0, 0);
        }
    }

    static void StartWatchdog() {
        bool expected = false;
        if (!I().m_watchdogStarted.compare_exchange_strong(expected, true)) return;
        pthread_t t; pthread_attr_t a;
        pthread_attr_init(&a);
        pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
        pthread_create(&t, &a, WatchdogMain, nullptr);
        pthread_attr_destroy(&a);
    }

private:
    AntiDebug() : m_extStrikes(0), m_firstStrongMs(0), m_invalidated(false), m_watchdogStarted(false) {}

    static uint64_t NowMs() {
        struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
        return (uint64_t)ts.tv_sec * 1000ull + ts.tv_nsec / 1000000ull;
    }

    void Invalidate() {
        if (m_invalidated.exchange(true)) return;
        AuthGate::I().Clear();   // silent: Authorized() now false -> login screen, features off
    }

    static void* WatchdogMain(void*) {
        usleep(1500000);
        for (;;) {
            I().Tick();
            usleep(I().m_invalidated.load() ? 5000000 : 2500000);
        }
        return nullptr;
    }

    static bool CheckTracerPid() {
        int fd = sc::sys_open(OBFSTR("/proc/self/status"), O_RDONLY);
        if (fd < 0) return false;
        char buf[4096]; ssize_t n = sc::sys_read(fd, buf, sizeof(buf) - 1); sc::sys_close(fd);
        if (n <= 0) return false;
        buf[n] = 0;
        const char* p = strstr(buf, OBFSTR("TracerPid:"));
        if (!p) return false;
        p += 10; while (*p == ' ' || *p == '\t') ++p;
        return (*p != '0' && *p != '\n' && *p != 0);
    }

    static bool CheckMaps() {
        int fd = sc::sys_open(OBFSTR("/proc/self/maps"), O_RDONLY);
        if (fd < 0) return false;
        char buf[8192]; std::string acc; ssize_t n;
        while ((n = sc::sys_read(fd, buf, sizeof(buf) - 1)) > 0) {
            buf[n] = 0; acc += buf;
            if (acc.size() > 131072) acc.erase(0, acc.size() - 131072);
        }
        sc::sys_close(fd);
        // Frida-specific only. Deliberately NOT matching magisk/zygisk/xposed/
        // substrate — the user injects on a rooted device and those would flag the
        // legit environment. Frida is the actual reverse-engineering tool.
        const char* needles[] = {
            OBFSTR("frida"), OBFSTR("gum-js-loop"), OBFSTR("gadget"), OBFSTR("linjector")
        };
        for (auto s : needles) if (strstr(acc.c_str(), s)) return true;
        return false;
    }

    static bool CheckFridaPorts() {
        const int ports[2] = { 27042, 27043 };
        for (int k = 0; k < 2; ++k) {
            int s = socket(AF_INET, SOCK_STREAM, 0);
            if (s < 0) continue;
            int fl = fcntl(s, F_GETFL, 0); fcntl(s, F_SETFL, fl | O_NONBLOCK);
            struct sockaddr_in a; memset(&a, 0, sizeof(a));
            a.sin_family = AF_INET; a.sin_port = htons(ports[k]);
            inet_pton(AF_INET, OBFSTR("127.0.0.1"), &a.sin_addr);
            bool opened = false;
            if (connect(s, (struct sockaddr*)&a, sizeof(a)) == 0) opened = true;
            else {
                struct pollfd pfd;
                pfd.fd = s;
                pfd.events = POLLOUT;
                pfd.revents = 0;
                if (poll(&pfd, 1, 80) > 0) {
                    if ((pfd.revents & POLLOUT) && !(pfd.revents & (POLLERR | POLLHUP))) {
                        int err = 0; socklen_t el = sizeof(err);
                        getsockopt(s, SOL_SOCKET, SO_ERROR, &err, &el);
                        opened = (err == 0);
                    }
                }
            }
            close(s);
            if (opened) return true;
        }
        return false;
    }

    static bool CheckInlineHook() {
        static void* fns[2] = { nullptr, nullptr };
        if (!fns[0]) { fns[0] = dlsym(RTLD_DEFAULT, OBFSTR("connect"));
                       fns[1] = dlsym(RTLD_DEFAULT, OBFSTR("recvfrom")); }
        int hits = 0;
        for (int i = 0; i < 2; ++i) {
            if (!fns[i]) continue;
            uint32_t instr; memcpy(&instr, fns[i], 4);
            if ((instr >> 26) == 0x05) hits++;                    // B imm
            else if ((instr & 0xFFFFFC1Fu) == 0xD61F0000u) hits++; // BR Xn
        }
        return hits >= 2;   // both looking trampolined -> suspicious (reduces false positives)
    }

    static bool CheckTiming() {
        struct timespec a, b;
        clock_gettime(CLOCK_MONOTONIC, &a);
        volatile int acc = 0;
        for (int i = 0; i < 300; ++i) acc += (int)getpid();
        clock_gettime(CLOCK_MONOTONIC, &b);
        uint64_t ns = (uint64_t)(b.tv_sec - a.tv_sec) * 1000000000ull + (b.tv_nsec - a.tv_nsec);
        (void)acc;
        return ns > 80000000ull;   // >80ms for 300 getpid() == being single-stepped
    }

    static bool CheckDebuggable() {
        char v[PROP_VALUE_MAX] = {0};
        if (__system_property_get(OBFSTR("ro.debuggable"), v) > 0) return v[0] == '1';
        return false;
    }

    std::atomic<int>      m_extStrikes;
    std::atomic<uint64_t> m_firstStrongMs;
    std::atomic<bool>     m_invalidated;
    std::atomic<bool>     m_watchdogStarted;

    static const int      kHardExtStrikes = 12;    // ~4 forged logins
    static const uint64_t kGraceMs        = 30000; // persistent strong signal -> 30 s
};

} // namespace AntiCrack
