#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/uio.h>
#include <dirent.h>
#include <string.h>
#include <string>

static pid_t g_Pid = 2323;
static uintptr_t g_LibBase = 0x6cac853000;
static uintptr_t g_GNames = 0x6cac853000 + 0x0F36BEC0;

static bool ReadMem(uintptr_t addr, void* buf, size_t size) {
    if (addr < 0x10000ULL || addr > 0x00007FFFFFFFFFFFULL) return false;
    struct iovec local = { buf, size };
    struct iovec remote = { (void*)addr, size };
    return process_vm_readv(g_Pid, &local, 1, &remote, 1, 0) == (ssize_t)size;
}
template<typename T> static T ReadVal(uintptr_t a) { T v{}; ReadMem(a, &v, sizeof(T)); return v; }
static uintptr_t ReadPtr(uintptr_t a) { return ReadVal<uintptr_t>(a); }
static int32_t ReadI32(uintptr_t a) { return ReadVal<int32_t>(a); }
static uint16_t ReadU16(uintptr_t a) { return ReadVal<uint16_t>(a); }

static std::string GetName(int32_t id) {
    if (id <= 0 || !g_GNames) return "None";
    uint32_t block = static_cast<uint32_t>(id) >> 16;
    uint32_t offset = (static_cast<uint32_t>(id) & 0xFFFF) * 2;
    if (block >= 8192) return "None";
    uintptr_t blockPtrAddr = g_GNames + 0x48 + block * sizeof(uint8_t*);
    uintptr_t chunk = ReadPtr(blockPtrAddr);
    if (!chunk) return "None";
    uintptr_t entry = chunk + offset;
    uint16_t header = ReadU16(entry);
    size_t len = header >> 6;
    if (len == 0 || len > 512) return "None";
    char buf[512] = {};
    ReadMem(entry + 2, buf, len);
    return std::string(buf, len);
}

static std::string GetObjClass(uintptr_t obj) {
    if (!obj) return "null";
    uintptr_t cls = ReadPtr(obj + 0x10);
    if (!cls) return "no_class";
    return GetName(ReadI32(cls + 0x18));
}

int main() {
    uintptr_t pc = 0x6725c62000;
    for (int off = 0x280; off < 0xB00; off += 8) {
        uintptr_t ptr = ReadPtr(pc + off);
        if (ptr >= 0x1000000000 && ptr <= 0x7FFFFFFFFFFF) {
            uintptr_t cls = ReadPtr(ptr + 0x10);
            if (cls >= 0x1000000000 && cls <= 0x7FFFFFFFFFFF) {
                std::string cName = GetObjClass(ptr);
                printf("  pc + 0x%03X: 0x%lx (Class: %s)\n", off, ptr, cName.c_str());
            }
        }
    }
    return 0;
}
