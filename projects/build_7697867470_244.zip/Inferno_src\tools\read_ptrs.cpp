#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/uio.h>
#include <dirent.h>

static pid_t g_Pid = -1;
static uintptr_t g_LibBase = 0;

static bool ReadMem(uintptr_t addr, void* buf, size_t size) {
    if (addr < 0x10000ULL || addr > 0x00007FFFFFFFFFFFULL) return false;
    struct iovec local = { buf, size };
    struct iovec remote = { (void*)addr, size };
    ssize_t n = process_vm_readv(g_Pid, &local, 1, &remote, 1, 0);
    return (n == (ssize_t)size);
}

static void PrintMapping(uintptr_t target) {
    char mapsPath[64];
    snprintf(mapsPath, sizeof(mapsPath), "/proc/%d/maps", g_Pid);
    FILE* f = fopen(mapsPath, "r");
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        uintptr_t start, end;
        if (sscanf(line, "%lx-%lx", &start, &end) == 2) {
            if (target >= start && target < end) {
                printf("  [MAP] 0x%lx is in: %s", target, line);
                break;
            }
        }
    }
    fclose(f);
}

int main() {
    DIR* dir = opendir("/proc");
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type != DT_DIR) continue;
        int pid = atoi(entry->d_name);
        if (pid <= 0) continue;
        char cmdlinePath[64];
        snprintf(cmdlinePath, sizeof(cmdlinePath), "/proc/%d/cmdline", pid);
        FILE* fp = fopen(cmdlinePath, "r");
        if (fp) {
            char cmdline[256] = {};
            fread(cmdline, 1, sizeof(cmdline) - 1, fp);
            fclose(fp);
            if (strstr(cmdline, "com.eu.mf.uamo")) {
                g_Pid = pid;
                break;
            }
        }
    }
    closedir(dir);
    if (g_Pid <= 0) { printf("PID not found\n"); return 1; }

    char mapsPath[64];
    snprintf(mapsPath, sizeof(mapsPath), "/proc/%d/maps", g_Pid);
    FILE* f = fopen(mapsPath, "r");
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, "libUE4.so") && strstr(line, "r--p") && !strstr(line, "anon")) {
            sscanf(line, "%lx-", &g_LibBase);
            break;
        }
    }
    fclose(f);
    printf("libUE4.so text base: 0x%lx\n", g_LibBase);

    uintptr_t t1 = g_LibBase + 0xEDA8C10;
    uintptr_t t2 = g_LibBase + 0xEDAD740;

    uintptr_t curCap = 0, maxCap = 0, bore = 0, inMag = 0, maxMag = 0;
    ReadMem(t1 + 0x8E8, &curCap, 8);
    ReadMem(t1 + 0x8F8, &maxCap, 8);
    ReadMem(t1 + 0x790, &bore, 8);
    ReadMem(t2 + 0x898, &inMag, 8);
    ReadMem(t2 + 0x8A0, &maxMag, 8);

    printf("GetMagazineCurrentCapacity: 0x%lx\n", curCap);
    PrintMapping(curCap);
    printf("GetMagazineMaxCapacity: 0x%lx\n", maxCap);
    PrintMapping(maxCap);
    printf("GetAmmoCountInBore: 0x%lx\n", bore);
    PrintMapping(bore);
    printf("GetAmmoCountInMag: 0x%lx\n", inMag);
    PrintMapping(inMag);
    printf("GetMaxAmmoCount: 0x%lx\n", maxMag);
    PrintMapping(maxMag);

    uint32_t insts[16] = {};
    if (ReadMem(curCap, insts, sizeof(insts))) {
        printf("Insts at GetMagazineCurrentCapacity (0x%lx):\n", curCap);
        for (int i = 0; i < 16; i++) {
            printf("  +%02x: 0x%08X\n", i * 4, insts[i]);
        }
    }

    if (ReadMem(inMag, insts, sizeof(insts))) {
        printf("Insts at GetAmmoCountInMag (0x%lx):\n", inMag);
        for (int i = 0; i < 16; i++) {
            printf("  +%02x: 0x%08X\n", i * 4, insts[i]);
        }
    }

    return 0;
}
