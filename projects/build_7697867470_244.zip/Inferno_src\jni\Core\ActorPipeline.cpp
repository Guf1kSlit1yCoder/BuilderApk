#include "ActorPipeline.h"
#include "VisCheck.h"
#include "UE4Helper.h"
#include "Config.h"
#include "../UI/Lang.h"
#include <chrono>
#include <cmath>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#include <string>

namespace ActorPipeline {

    static std::vector<EntityData> s_Enemies;
    static std::vector<EntityData> s_DeadBodies;
    static std::vector<EntityData> s_Items;
    static std::vector<EntityData> s_LootBoxes;

    static SDK::UClass* s_SGCharClass = nullptr;
    static SDK::UClass* s_BaseCharClass = nullptr;
    static SDK::UClass* s_CharClass = nullptr;
    static SDK::UClass* s_AICharClass = nullptr;
    static SDK::UClass* s_PickupClass = nullptr;
    static std::unordered_map<SDK::UClass*, bool> s_ClassCharCache;
    static std::unordered_map<SDK::UClass*, bool> s_ClassItemCache;
    struct BoxClassOffsets {
        int32_t offOpened = -1;
        int32_t offIsOpen = -1;
        int32_t offHasBeenOpened = -1;
        int32_t offSearched = -1;
        int32_t offCurFSMState = -1;
        bool checked = false;
    };
    static std::unordered_map<SDK::UClass*, BoxClassOffsets> s_BoxClassOffsets;
    static uint64_t s_ResetGeneration = 0;
    struct LivePositionTracker {
        SDK::FVector lastLivePos{0, 0, 0};
        std::chrono::steady_clock::time_point lastProxyTime{};
        bool hasHadProxy = false;
        // Anti-ghost: when the proxy position stops advancing (player left relevancy
        // and the server no longer streams them), freeze is detected here.
        SDK::FVector lastMovedPos{0, 0, 0};
        std::chrono::steady_clock::time_point lastMovedTime{};
        bool stale = false;
    };
    static std::unordered_map<SDK::ASGCharacter*, LivePositionTracker> s_CharLiveTrack;
    static std::unordered_map<SDK::ASGCharacter*, SDK::ASGCharacterFastRepProxy*> s_CharToProxy;
    static std::unordered_map<SDK::ASGCharacterFastRepProxy*, SDK::ASGCharacter*> s_ProxyToChar;

    SDK::ASGCharacterFastRepProxy* GetFastRepForChar(SDK::ASGCharacter* character) {
        if (!character) return nullptr;
        auto it = s_CharToProxy.find(character);
        if (it != s_CharToProxy.end()) {
            auto* proxy = it->second;
            if (proxy && Tools::IsPtrValid(proxy) && Tools::IsReadable(proxy, sizeof(SDK::ASGCharacterFastRepProxy))) {
                return proxy;
            }
        }
        return nullptr;
    }

    static inline std::string NormalizeForMatch(const std::string& str) {
        std::string res;
        res.reserve(str.size());
        for (char c : str) {
            if (c >= 'A' && c <= 'Z') {
                res.push_back((char)(c + 32));
            } else if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
                res.push_back(c);
            }
        }
        return res;
    }

    static bool StartsWithSMPrefix(const std::string& s) {
        if (s.size() >= 3) {
            if ((s[0] == 'S' || s[0] == 's') && (s[1] == 'M' || s[1] == 'm')) {
                char c2 = s[2];
                if (c2 == '_' || c2 == ' ' || c2 == '-') return true;
            }
        }
        if (s.size() >= 12 && s.compare(0, 9, "Default__") == 0) {
            if ((s[9] == 'S' || s[9] == 's') && (s[10] == 'M' || s[10] == 'm')) {
                char c11 = s[11];
                if (c11 == '_' || c11 == ' ' || c11 == '-') return true;
            }
        }
        return false;
    }

    static bool HasSMPrefix(const std::string& s) {
        if (StartsWithSMPrefix(s)) return true;
        static const char* const kSMPatterns[] = {
            "_SM_", "_sm_", "/SM_", "/sm_", " SM ", " sm ",
            "_SM ", "_sm ", " SM_", " sm_",
            "SM_Env", "sm_env", "SM Env", "sm env",
            "SM_Prop", "sm_prop", "SM Prop", "sm prop"
        };
        for (const char* p : kSMPatterns) {
            if (s.find(p) != std::string::npos) return true;
        }
        return false;
    }

    static bool IsBlacklistedActor(const std::string& actName, const std::string& clsName) {
        // Any actor with SM prefix (Static Mesh decor/prop in UE4)
        if (HasSMPrefix(actName) || HasSMPrefix(clsName)) {
            return true;
        }
        if (clsName.find("StaticMesh") != std::string::npos || actName.find("StaticMesh") != std::string::npos) {
            return true;
        }

        std::string nAct = NormalizeForMatch(actName);
        std::string nCls = NormalizeForMatch(clsName);

        static const char* const kBlacklistKeywords[] = {
            "metalbox01",
            "smenvmetalbox",
            "metalbox",
            "bearoil",
            "capacitor",
            "containetruck",
            "vehicleglass",
            "bcpu"
        };

        for (const char* kw : kBlacklistKeywords) {
            if (nAct.find(kw) != std::string::npos || nCls.find(kw) != std::string::npos) {
                return true;
            }
        }
        return false;
    }

    // ---- Phantom-pawn rejection ------------------------------------------
    // Device evidence (2026-09-20, com.eu.mf.uamo): the client's object list
    // contains a pool of BP_UamCharacter_C instances that are NOT players. All of
    // them sat 40..42 m from the viewer, all had a live PlayerState and
    // Controller==0x0, and they were drawn as real enemies. Two properties
    // separate them from a genuine replicated player:
    //
    //   1. Two DIFFERENT pawns shared one identical PlayerState pointer
    //      (0x6ffad39000 / gid=660551333 / name='jykn'). Two live players can
    //      never share a PlayerState object.
    //   2. Their PlayerNamePrivate decoded to byte noise ('TTxx|D', 'Mris6',
    //      '"B@=3') instead of printable text.
    //
    // The identity of a pawn is only decided once per frame per actor pointer,
    // after all characters are known, so the duplicate test sees the whole set.
    struct PawnIdentity {
        bool        hasName = false;   // name decoded to plausible printable text
        bool        duplicatePState = false; // another pawn used the same PlayerState
        bool        isPhantom = false; // confirmed duplicate/dormant pawn
        uint64_t    gid = 0;
        int32_t     teamId = -1;
        std::string name;
    };
    static std::unordered_map<SDK::ASGCharacter*, PawnIdentity> s_PawnIdentity;
    static std::unordered_set<SDK::APlayerState*> s_SeenPStates;
    static uint64_t s_IdentityGeneration = ~0ull;
    // Tracks phantoms already logged; reset per-session so map changes re-log them.
    static std::unordered_set<SDK::ASGCharacter*> s_PhantomDumped;
    static std::unordered_set<SDK::ASGCharacter*> s_AnchorLogged;


    // A real nickname is short printable text. A FString read through a stale or
    // wrong pointer yields arbitrary bytes, which this rejects. Non-ASCII is
    // allowed (Cyrillic/Chinese nicknames exist) but control bytes and the
    // high-bit garbage seen on device are not.
    static bool LooksLikePlayerName(const std::string& n)
    {
        if (n.empty() || n.size() > 40) return false;
        int good = 0;
        for (unsigned char c : n) {
            if (c >= 0x20 && c < 0x7F) { ++good; continue; }
            if (c >= 0x80) { ++good; continue; }  // Valid UTF-8 multibyte (Cyrillic, CJK, etc.)
        }
        return good * 10 >= (int)n.size() * 8; // >=80% plausible bytes
    }

    static SDK::APlayerState* GetPawnPlayerState(SDK::ASGCharacter* c)
    {
        if (!c) return nullptr;
        // APawn::PlayerState at 0x330 is the standard UE4 replicated field.
        // On Android clients it is authoritative and unique per player — try first.
        // Using this as the primary dedup key prevents false duplicatePState hits
        // that occur when PlayerInfo.PlayerState (game-specific, 0x1610) is not
        // yet replicated for remote characters and multiple pawns read the same
        // stale pointer.
        if (Tools::IsReadable(reinterpret_cast<uint8_t*>(c) + Offsets::Pawn::PlayerState, sizeof(void*))) {
            auto* ps = *reinterpret_cast<SDK::APlayerState**>(reinterpret_cast<uint8_t*>(c) + Offsets::Pawn::PlayerState);
            if (Tools::IsPtrValid(ps)) return ps;
        }
        // Fallback: FSGPlayerInfo.PlayerState at +0x1610 (game-specific field).
        // May not be replicated yet on mobile client for remote pawns.
        if (Tools::IsReadable(reinterpret_cast<uint8_t*>(c) + Offsets::SGCharacter::PlayerInfo_PlayerState, sizeof(void*))) {
            auto* ps = c->PlayerInfo.PlayerState; // +0x1610
            if (Tools::IsPtrValid(ps)) return ps;
        }
        return nullptr;
    }

    static std::string ExtractPlayerName(SDK::ASGCharacter* c)
    {
        if (!c || !Tools::IsPtrValid(c)) return "";
        auto* psRaw = GetPawnPlayerState(c);
        if (psRaw && Tools::IsPtrValid(psRaw)) {
            auto* sgPs = reinterpret_cast<SDK::ASGPlayerState*>(psRaw);
            if (Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::ZonePlayerName, sizeof(SDK::FString))) {
                auto* zoneNamePtr = reinterpret_cast<SDK::FString*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::ZonePlayerName);
                const std::string zn = zoneNamePtr->ToString();
                if (LooksLikePlayerName(zn)) return zn;
            }
            if (Tools::IsReadable(&psRaw->PlayerNamePrivate, sizeof(SDK::FString))) {
                const std::string pn = psRaw->PlayerNamePrivate.ToString();
                if (LooksLikePlayerName(pn)) return pn;
            }
            if (Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::TeamName, sizeof(SDK::FString))) {
                auto* teamNamePtr = reinterpret_cast<SDK::FString*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::TeamName);
                const std::string tn = teamNamePtr->ToString();
                if (LooksLikePlayerName(tn)) return tn;
            }
        }
        return "";
    }

    // Helper to read current Client World Time Seconds
    static float GetWorldTimeSeconds(SDK::UWorld* world, SDK::ASGCharacter* localPlayer) {
        // 1. Direct UWorld client TimeSeconds (+0x1AC, +0x1A8, +0x1B0)
        if (world && Tools::IsPtrValid(world)) {
            uint8_t* worldPtr = reinterpret_cast<uint8_t*>(world);
            for (uintptr_t off : Offsets::World::TimeSecondsOffsets) {
                if (Tools::IsReadable(worldPtr + off, sizeof(float))) {
                    float val = *reinterpret_cast<const float*>(worldPtr + off);
                    if (std::isfinite(val) && val > 2.0f && val < 2000000.0f) {
                        return val;
                    }
                }
            }
        }

        // 2. LocalPlayer mesh render timestamp (+0x67C, +0x678)
        if (localPlayer && Tools::IsPtrValid(localPlayer)) {
            auto localMesh = localPlayer->GetMeshComponent();
            if (localMesh && Tools::IsPtrValid(localMesh)) {
                uint8_t* lmPtr = reinterpret_cast<uint8_t*>(localMesh);
                for (uintptr_t off : Offsets::SkeletalMeshComponent::RenderTimestampOffsets) {
                    if (Tools::IsReadable(lmPtr + off, sizeof(float))) {
                        float val = *reinterpret_cast<const float*>(lmPtr + off);
                        if (std::isfinite(val) && val > 2.0f && val < 2000000.0f) {
                            return val;
                        }
                    }
                }
            }
        }

        return -1.0f;
    }

    static bool IsMeshVisible(SDK::USkeletalMeshComponent* mesh, float worldTime, SDK::ASGCharacter* charActor) {
        if (!mesh || !Tools::IsPtrValid(mesh)) return false;

        uint8_t* meshPtr = reinterpret_cast<uint8_t*>(mesh);

        // 1. Actor-level bHidden check (+0x68, mask 0x20)
        if (charActor && Tools::IsReadable(reinterpret_cast<uint8_t*>(charActor) + Offsets::Actor::NetFlags, 1)) {
            uint8_t actorFlags68 = *reinterpret_cast<const uint8_t*>(reinterpret_cast<uint8_t*>(charActor) + Offsets::Actor::NetFlags);
            if (actorFlags68 & 0x20) { // bHidden is true
                return false;
            }
        }

        // 2. SceneComponent::bHiddenInGame (+0x185, bit 0x8)
        if (Tools::IsReadable(meshPtr + Offsets::SceneComponent::Flags185, 1)) {
            uint8_t flags185 = *reinterpret_cast<const uint8_t*>(meshPtr + Offsets::SceneComponent::Flags185);
            if (flags185 & 0x8) { // bHiddenInGame is true
                return false;
            }
        }

        // 3. Direct reflected engine flag in USkinnedMeshComponent:
        // +0x0858 [0x0001] uint8_t bRecentlyRendered : 1 (Mask(0x1))
        if (Tools::IsReadable(meshPtr + Offsets::SkeletalMeshComponent::Flags858, 1)) {
            uint8_t flags858 = *reinterpret_cast<const uint8_t*>(meshPtr + Offsets::SkeletalMeshComponent::Flags858);
            if ((flags858 & 0x01) == 0) {
                // If not marked as recently rendered by engine, mesh is definitely occluded.
                return false;
            }
        }

        // 4. Timestamp verification if client worldTime is active
        // +0x67C = LastRenderTimeOnScreen, +0x678 = LastSubmitTime
        if (worldTime > 2.0f) {
            for (uintptr_t off : Offsets::SkeletalMeshComponent::RenderTimestampOffsets) {
                if (Tools::IsReadable(meshPtr + off, sizeof(float))) {
                    float lrt = *reinterpret_cast<const float*>(meshPtr + off);
                    if (std::isfinite(lrt) && lrt > 2.0f) {
                        float diff = worldTime - lrt;
                        if (diff >= -0.05f && diff <= 0.25f) {
                            return true;
                        }
                    }
                }
            }
            // If worldTime is active and timestamps exist but are stale (>0.25s), occluded!
            return false;
        }

        return true;
    }

    // Checks if a character pawn is an actively simulated / moving live soldier,
    // rather than a stationary spawn dummy left at the match staging location.
    static int GetPawnLivenessScore(SDK::ASGCharacter* c, const SDK::FVector& viewerPos)
    {
        if (!c || !Tools::IsPtrValid(c)) return -1000;

        if (c->RootComponent && Tools::IsReadable(c->RootComponent, sizeof(SDK::USceneComponent))) {
            if (c->RootComponent->AttachParent != nullptr) {
                return -1000;
            }
        }

        SDK::FVector rootPos{0,0,0};
        if (c->RootComponent && Tools::IsPtrValid(c->RootComponent)) {
            c->RootComponent->TryGetWorldLocation(rootPos);
        }
        if (rootPos.SizeSquared() < 0.001f && c->CapsuleComponent && Tools::IsPtrValid(c->CapsuleComponent)) {
            c->CapsuleComponent->TryGetWorldLocation(rootPos);
        }

        if (rootPos.SizeSquared() < 0.001f ||
            (std::abs(rootPos.X) < 1.0f && std::abs(rootPos.Y) < 1.0f) ||
            rootPos.Z < -50000.0f || rootPos.Z > 200000.0f) {
            return -500;
        }

        int score = 100;
        SDK::FVector proxyPos;
        if (c->GetFastRepLocation(proxyPos)) {
            if (proxyPos.SizeSquared() > 0.001f &&
                (std::abs(proxyPos.X) >= 1.0f || std::abs(proxyPos.Y) >= 1.0f)) {
                score += 50;
            }
        }
        auto* mesh = c->GetMeshComponent();
        if (mesh && Tools::IsPtrValid(mesh) && Tools::IsReadable(mesh, sizeof(SDK::USkinnedMeshComponent))) {
            score += 50;
            const int bones = mesh->CachedComponentSpaceTransforms.Num() >= 5 ?
                              mesh->CachedComponentSpaceTransforms.Num() :
                              mesh->CachedComponentSpaceTransforms.Max();
            if (bones >= 5 && bones <= 300) {
                score += 150;
            }
        }
        return score;
    }

    // Fill s_PawnIdentity for this frame. Runs once per actor-list refresh.
    static void BuildPawnIdentities(const std::vector<SDK::ASGCharacter*>& chars,
                                   const std::vector<SDK::ASGCharacterFastRepProxy*>& proxies,
                                   const SDK::FVector& viewerPos)
    {
        s_PawnIdentity.clear();
        s_SeenPStates.clear();

        // Prune destroyed or stale objects from persistent proxy map instead of wiping it
        for (auto it = s_CharToProxy.begin(); it != s_CharToProxy.end(); ) {
            if (!IsObjectValid(it->first) || !IsObjectValid(it->second)) {
                s_ProxyToChar.erase(it->second);
                it = s_CharToProxy.erase(it);
            } else {
                ++it;
            }
        }

        // 0. Update authoritative map of ASGCharacter -> ASGCharacterFastRepProxy from level proxy actors
        for (auto* proxy : proxies) {
            if (!proxy || !Tools::IsPtrValid(proxy) || !Tools::IsReadable(proxy, sizeof(SDK::ASGCharacterFastRepProxy))) continue;
            auto* bound = proxy->BindingCharacter;
            if (bound && Tools::IsPtrValid(bound) && Tools::IsReadable(bound, sizeof(SDK::ASGCharacterBase))) {
                s_CharToProxy[bound] = proxy;
                s_ProxyToChar[proxy] = bound;
                if (!bound->CharacterFastRepProxy) {
                    bound->CharacterFastRepProxy = proxy;
                }
            }
        }
        for (auto* c : chars) {
            if (c->CharacterFastRepProxy && Tools::IsPtrValid(c->CharacterFastRepProxy) &&
                Tools::IsReadable(c->CharacterFastRepProxy, sizeof(SDK::ASGCharacterFastRepProxy))) {
                s_CharToProxy[c] = c->CharacterFastRepProxy;
                s_ProxyToChar[c->CharacterFastRepProxy] = c;
            }
        }

        // 1. Group pawns by PlayerState
        std::unordered_map<SDK::APlayerState*, std::vector<SDK::ASGCharacter*>> pstateToPawns;
        for (auto* c : chars) {
            auto* psRaw = GetPawnPlayerState(c);
            if (psRaw) pstateToPawns[psRaw].push_back(c);
        }

        // 2. Classify each pawn
        for (auto* c : chars) {
            PawnIdentity id;
            id.gid = c->PlayerInfo.gid; // +0x1600
            id.teamId = c->PlayerInfo.TeamIndex;
            if (id.teamId < 0) id.teamId = c->GetTeamID();
            auto* psRaw = GetPawnPlayerState(c);
            if (psRaw) {
                auto* sgPs = reinterpret_cast<SDK::ASGPlayerState*>(psRaw);
                uint64_t psGid = 0;
                if (Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::gid, sizeof(uint64_t)))
                    psGid = *reinterpret_cast<const uint64_t*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::gid);

                if (id.teamId < 0 && Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::TeamIndex, sizeof(int32_t))) {
                    int32_t tid = *reinterpret_cast<const int32_t*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::TeamIndex);
                    if (tid >= 0 && tid < 1000) id.teamId = tid;
                }
                if (id.teamId < 0 && Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::AltTeamIndex, sizeof(int32_t))) {
                    int32_t tid = *reinterpret_cast<const int32_t*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::AltTeamIndex);
                    if (tid >= 0 && tid < 1000) id.teamId = tid;
                }

                if (Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::ZonePlayerName, sizeof(SDK::FString))) {
                    auto* zoneNamePtr = reinterpret_cast<SDK::FString*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::ZonePlayerName);
                    const std::string zn = zoneNamePtr->ToString();
                    if (LooksLikePlayerName(zn)) {
                        id.hasName = true;
                        id.name = zn;
                    }
                }
                if (!id.hasName && Tools::IsReadable(&psRaw->PlayerNamePrivate, sizeof(SDK::FString))) {
                    const std::string n = psRaw->PlayerNamePrivate.ToString();
                    if (LooksLikePlayerName(n)) {
                        id.hasName = true;
                        id.name = n;
                    }
                }
                if (!id.hasName && Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::TeamName, sizeof(SDK::FString))) {
                    auto* teamNamePtr = reinterpret_cast<SDK::FString*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::TeamName);
                    const std::string tn = teamNamePtr->ToString();
                    if (LooksLikePlayerName(tn)) {
                        id.hasName = true;
                        id.name = tn;
                    }
                }
                if (id.gid == 0 && psGid != 0) id.gid = psGid;
                s_SeenPStates.insert(psRaw);
            } else if (id.gid != 0) {
                id.hasName = true;
            }
            s_PawnIdentity[c] = id;
        }

        // 3. Resolve duplicate PlayerState groups: exactly ONE is the real active player,
        // chosen by highest liveness score (active simulated moving pawn with skeletal mesh).
        for (auto& entry : pstateToPawns) {
            auto* psRaw = entry.first;
            auto& pawnList = entry.second;
            if (pawnList.size() <= 1) continue;

            SDK::APawn* activePawn = nullptr;
            if (Tools::IsReadable(reinterpret_cast<uint8_t*>(psRaw) + Offsets::PlayerState::ActivePawn, sizeof(void*))) {
                activePawn = *reinterpret_cast<SDK::APawn**>(reinterpret_cast<uint8_t*>(psRaw) + Offsets::PlayerState::ActivePawn);
            }

            SDK::ASGCharacter* realPawn = nullptr;
            int bestScore = -9999;
            for (auto* p : pawnList) {
                int sc = GetPawnLivenessScore(p, viewerPos);
                if (activePawn && p == reinterpret_cast<SDK::ASGCharacter*>(activePawn)) sc += 200;
                if (sc > bestScore) {
                    bestScore = sc;
                    realPawn = p;
                }
            }

            if (!realPawn) {
                for (auto* p : pawnList) {
                    if (Tools::IsReadable(reinterpret_cast<uint8_t*>(p) + Offsets::SGCharacter::PlayerInfo_Character, sizeof(void*))) {
                        auto* charRef = *reinterpret_cast<SDK::ASGCharacter**>(reinterpret_cast<uint8_t*>(p) + Offsets::SGCharacter::PlayerInfo_Character);
                        if (charRef == p) { realPawn = p; break; }
                    }
                }
            }
            if (!realPawn) realPawn = pawnList[0];

            for (auto* p : pawnList) {
                if (p == realPawn) {
                    s_PawnIdentity[p].duplicatePState = false;
                    s_PawnIdentity[p].isPhantom = false;
                } else {
                    s_PawnIdentity[p].duplicatePState = true;
                    s_PawnIdentity[p].isPhantom = true;
                }
            }
        }

        // Diagnostic summary
        int accepted = 0, phantoms = 0;
        for (const auto& kv : s_PawnIdentity) {
            if (!kv.second.isPhantom) ++accepted;
            else ++phantoms;
        }
        LOGI("[PawnId] total=%d accepted=%d phantoms=%d",
             (int)s_PawnIdentity.size(), accepted, phantoms);
    }

    void Reset() {
        ++s_ResetGeneration;
        s_Enemies.clear();
        s_DeadBodies.clear();
        s_Items.clear();
        s_LootBoxes.clear();
        s_ClassCharCache.clear();
        s_ClassItemCache.clear();
        s_PawnIdentity.clear();
        s_SeenPStates.clear();
        s_CharToProxy.clear();
        s_ProxyToChar.clear();
        s_CharLiveTrack.clear();
        s_PhantomDumped.clear();
        s_AnchorLogged.clear();
        VisCheck::Reset();
        s_IdentityGeneration = ~0ull;
        s_SGCharClass = s_BaseCharClass = s_CharClass = s_AICharClass = s_PickupClass = nullptr;
    }

    // Cache discovery/classification, never moving geometry or health. Both
    // discovery deadlines use the same interval to avoid stacked 50+100 ms waits.
    static constexpr auto kEntityRefreshInterval = std::chrono::milliseconds(50);
    static constexpr auto kActorListRefreshInterval = kEntityRefreshInterval;

    // Remote players: anchor ESP on the rendered mesh ONLY when close and actively animating
    static void ResolveVisualRoot(SDK::ASGCharacter* charActor, SDK::FVector& rootPos, const SDK::FVector& viewerPos) {
        // If enemy is far (>38m), proxy is strictly authoritative; do not let culled mesh drag position back!
        if (UE4Helper::GetDistance(viewerPos, rootPos) > 38.0f) return;

        const auto m = charActor->GetMeshComponent();
        if (!m || !Tools::IsPtrValid(m) || !Tools::IsReadable(m, sizeof(SDK::USkeletalMeshComponent)) ||
            !(m->Pad_0x184[0] & 0x02) || !m->ComponentToWorld.IsValid()) return;
        float hh = 88.0f;
        if (charActor->CapsuleComponent && Tools::IsPtrValid(charActor->CapsuleComponent)) {
            const float c = charActor->CapsuleComponent->GetScaledCapsuleHalfHeight();
            if (c >= 30.0f && c <= 140.0f) hh = c;
        }
        const SDK::FVector meshFeet = m->ComponentToWorld.Translation;
        const SDK::FVector visual = meshFeet + SDK::FVector{0.0f, 0.0f, hh};
        const SDK::FVector d = visual - rootPos;
        const bool finite = std::isfinite(visual.X) && std::isfinite(visual.Y) && std::isfinite(visual.Z);
        // Only snap to visual mesh if it's very close to root (< 1.5m), proving the mesh is locally active
        if (finite && d.SizeSquared() < 150.0f * 150.0f &&
            !(std::abs(meshFeet.X) < 1.0f && std::abs(meshFeet.Y) < 1.0f)) {
            rootPos = visual;
        }
    }    // Returns the authoritative live world position for a remote (non-bot) player.
    // Includes position persistence/hysteresis to lock onto the live proxy stream and
    // prevent snaps back to the dormant 40m RootComponent during network packet intervals.
    static SDK::FVector ChooseLivePosition(SDK::ASGCharacter* c, const SDK::FVector& root,
                                           const SDK::FVector& viewer) {
        if (!c) return root;

        const auto now = std::chrono::steady_clock::now();
        auto& track = s_CharLiveTrack[c];

        SDK::FVector proxy{0, 0, 0};
        bool gotProxy = false;
        // Anchor to R = replicated proxy Location (0x348). Calibration showed this
        // is the true position; GetProxyPosition mixed in PredictStopLocation's X/Y
        // which drifted (player stood in front but the marker sat 40m to the side).
        if (c->GetFastRepLocation(proxy)) {
            if (std::isfinite(proxy.X) && std::isfinite(proxy.Y) && std::isfinite(proxy.Z) &&
                proxy.SizeSquared() > 0.001f &&
                (std::abs(proxy.X) >= 1.0f || std::abs(proxy.Y) >= 1.0f) &&
                proxy.Z >= -50000.0f && proxy.Z <= 200000.0f) {
                gotProxy = true;
            }
        }

        if (gotProxy) {
            // Anti-ghost freeze detection with hysteresis so sub-tick jitter can't
            // flip the flag every frame (that made the ESP blink the ghost on/off).
            // Only REAL movement (> 30 cm) refreshes the anchor and clears stale;
            // once frozen longer than the threshold, stale latches until the target
            // actually moves again.
            const float moved = (proxy - track.lastMovedPos).Size();
            if (track.lastMovedTime.time_since_epoch().count() == 0) {
                track.lastMovedPos = proxy;
                track.lastMovedTime = now;
            } else if (moved > 30.0f) {
                track.lastMovedPos = proxy;
                track.lastMovedTime = now;
                track.stale = false;               // moved for real → alive
            }
            const auto frozenMs = std::chrono::duration_cast<std::chrono::milliseconds>(now - track.lastMovedTime).count();
            const long ghostMs = (long)(g_Config.esp_ghost_seconds > 0.2f ? g_Config.esp_ghost_seconds * 1000.0f : 2000.0f);
            if (track.hasHadProxy && frozenMs > ghostMs) track.stale = true;   // latch

            track.lastLivePos = proxy;
            track.lastProxyTime = now;
            track.hasHadProxy = true;

            // Always use R (replicated proxy Location) — authoritative at any range,
            // including point-blank. Do NOT fall back to the RootComponent for close
            // players: that root sits at the dormancy boundary and put the marker in
            // the wrong place even when the player was right in front.
            return proxy;
        }

        // 3. FastRep packet missed on this tick (packet interval / network latency):
        // If this character was already recognized as remote/proxy-tracked (hasHadProxy) and
        // the last known live position is recent (< 5 seconds), HOLD THE LIVE POSITION!
        // NEVER SNAP BACK TO ROOT (which is frozen at the 40m dormancy boundary)!
        if (track.hasHadProxy && track.lastLivePos.SizeSquared() > 0.001f) {
            const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - track.lastProxyTime).count();
            if (elapsed < 5000) {
                return track.lastLivePos;
            }
        }

        // 4. Fallback for players without proxy (e.g. bots or nearby players before first proxy)
        return root;
    }

    // Publish trace targets for the game thread and apply its latest results.
    static void UpdateVisibility(const SDK::FVector& camera, SDK::ASGCharacter* localPlayer,
                                 SDK::ASGPlayerController* controller) {
        // Must match ESP's skeleton bone order: bit i == skeleton bone i.
        static const char* const kBones[VisCheck::kMaxPoints] = {
            "Head", "neck_01", "spine_03", "pelvis",
            "upperarm_l", "lowerarm_l", "hand_l",
            "upperarm_r", "lowerarm_r", "hand_r",
            "thigh_l", "calf_l", "foot_l", "thigh_r", "calf_r", "foot_r"
        };
        // Overall "visible" uses head/torso/shoulders only: a lone hand or foot past a
        // cover edge colours that limb green but does not mark the whole enemy open.
        constexpr uint16_t kCoreMask = (1u << 0) | (1u << 1) | (1u << 2) | (1u << 3) | (1u << 4) | (1u << 7);

        std::vector<VisCheck::Target> targets;
        targets.reserve(s_Enemies.size());
        for (auto& ed : s_Enemies) {
            ed.boneVisLive = false;
            if (ed.distance > 300.0f) continue;
            if (!ed.character || !Tools::IsPtrValid(ed.character)) continue;
            VisCheck::Target t;
            t.actor = ed.character;
            ed.character->GetBonePositions(kBones, VisCheck::kMaxPoints, t.points);
            for (int i = 0; i < VisCheck::kMaxPoints; ++i)
                if (t.points[i].SizeSquared() > 0.001f) t.valid |= (uint16_t)(1u << i);
            if (!t.valid) {
                t.points[0] = ed.headPos;
                t.points[3] = ed.rootPos;
                t.valid = (1u << 0) | (1u << 3);
            }
            targets.push_back(t);

            uint16_t visible = 0, known = 0;
            if (VisCheck::QueryBones(ed.character, visible, known)) {
                if (known != 0) {
                    ed.boneVisible = visible;
                    ed.boneVisLive = true;
                    ed.isVisible = (visible & kCoreMask) != 0;
                }
            }
        }
        VisCheck::EnsureHooked(reinterpret_cast<SDK::APlayerController*>(controller), localPlayer, targets);
        VisCheck::Publish(camera, localPlayer, targets);
    }

    static void RefreshProjection(const UE4Helper::ScreenProjection& projection,
                                  const SDK::FVector& viewerPos) {
        if (!projection.Valid) return;

        s_Enemies.erase(std::remove_if(s_Enemies.begin(), s_Enemies.end(), [](const EntityData& ed) {
            if (ed.character) return !IsObjectValid(ed.character) || ed.character->IsDead();
            if (ed.rawActor) return !IsObjectValid(ed.rawActor);
            return true;
        }), s_Enemies.end());
        for (auto& ed : s_Enemies) {
            ed.onScreen = false;
            auto actor = ed.character;
            SDK::FVector rootPos = ed.rootPos;
            if (actor && Tools::IsPtrValid(actor)) {
                SDK::FVector rawRoot{0,0,0};
                bool located = actor->RootComponent && Tools::IsPtrValid(actor->RootComponent) &&
                    actor->RootComponent->TryGetWorldLocation(rawRoot);
                if (!located && actor->CapsuleComponent && Tools::IsPtrValid(actor->CapsuleComponent))
                    located = actor->CapsuleComponent->TryGetWorldLocation(rawRoot);
                if (!located || !std::isfinite(rawRoot.SizeSquared()) || rawRoot.SizeSquared() < 0.001f) {
                    rawRoot = ed.rootPos;
                }
                if (!ed.isBot) {
                    rootPos = ChooseLivePosition(actor, rawRoot, viewerPos);
                    ed.stale = s_CharLiveTrack[actor].stale;
                } else {
                    rootPos = rawRoot;
                }
            } else if (ed.rawActor && Tools::IsPtrValid(ed.rawActor)) {
                auto* prx = reinterpret_cast<SDK::ASGCharacterFastRepProxy*>(ed.rawActor);
                if (Tools::IsReadable(reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(prx) + Offsets::FastRepProxy::Location), sizeof(SDK::FVector))) {
                    const SDK::FVector loc = prx->Location;
                    if (std::isfinite(loc.X) && std::isfinite(loc.Y) && std::isfinite(loc.Z) && loc.SizeSquared() > 0.001f) {
                        rootPos = loc;
                    }
                }
            }
            ResolveVisualRoot(actor, rootPos, viewerPos);
            ed.rootPos = rootPos;
            if (actor && Tools::IsPtrValid(actor)) {
                if (actor->CapsuleComponent && Tools::IsPtrValid(actor->CapsuleComponent)) {
                    const float hh = actor->CapsuleComponent->GetScaledCapsuleHalfHeight();
                    const float radius = actor->CapsuleComponent->GetScaledCapsuleRadius();
                    if (hh >= 30.0f && hh <= 140.0f) ed.capsuleHalfHeight = hh;
                    if (radius >= 10.0f && radius <= 70.0f) ed.capsuleRadius = radius;
                }
                if (ed.distance <= 38.0f) {
                    ed.headPos = actor->GetBonePos("Head");
                } else {
                    ed.headPos = {0,0,0};
                }
                if (g_Config.esp_enabled && g_Config.esp_health) {
                    actor->TryGetHealth(ed.health, ed.maxHealth);
                }
            }
            ed.distance = UE4Helper::GetDistance(viewerPos, ed.rootPos);
            if (ed.headPos.SizeSquared() < 0.001f || std::abs(ed.headPos.Z - rootPos.Z) < 15.0f || (ed.headPos - rootPos).SizeSquared() > 100.0f * 100.0f)
                ed.headPos = rootPos + SDK::FVector{0,0,ed.capsuleHalfHeight * 0.82f};
            ed.feetPos = rootPos - SDK::FVector{0,0,ed.capsuleHalfHeight};

            const bool rootOk = UE4Helper::WorldToScreen(ed.rootPos, ed.screenRoot, projection);
            const bool headOk = UE4Helper::WorldToScreen(ed.headPos, ed.screenHead, projection);
            const bool feetOk = UE4Helper::WorldToScreen(ed.feetPos, ed.screenFeet, projection);

            SDK::FVector2D boxMin{}, boxMax{};
            const bool boxOk = UE4Helper::WorldBoundsToScreen(
                ed.rootPos,
                {ed.capsuleRadius, ed.capsuleRadius, ed.capsuleHalfHeight},
                boxMin, boxMax, projection);
            if (boxOk) {
                ed.boxLeft = boxMin.X;
                ed.boxTop = boxMin.Y;
                ed.boxWidth = boxMax.X - boxMin.X;
                ed.boxHeight = boxMax.Y - boxMin.Y;
                ed.onScreen = ed.boxWidth > 0.0f && ed.boxHeight > 0.0f &&
                    boxMax.X >= -150.0f && boxMin.X <= projection.Width + 150.0f &&
                    boxMax.Y >= -150.0f && boxMin.Y <= projection.Height + 150.0f;
            }
            if (!headOk) ed.screenHead = ed.screenRoot;
            if (!feetOk) ed.screenFeet = ed.screenRoot;

            // Near-plane robustness. When a target gets point-blank, its capsule
            // corners cross the camera near-plane and WorldBoundsToScreen explodes
            // (box in the hundreds of thousands, flung off the top of the screen),
            // so the overlap test flips onScreen to false and ESP/skeleton vanish
            // exactly when the enemy is next to you. Detect the blow-up and rebuild
            // a sane box from the body points, forcing onScreen when any body point
            // is in front of the camera and within the viewport.
            {
                const float W = (float)projection.Width, H = (float)projection.Height;
                const float margin = 300.0f;
                auto inView = [&](const SDK::FVector2D& s) {
                    return std::isfinite(s.X) && std::isfinite(s.Y) &&
                           s.X >= -margin && s.X <= W + margin && s.Y >= -margin && s.Y <= H + margin;
                };
                const bool rootIn = rootOk && inView(ed.screenRoot);
                const bool headIn = headOk && inView(ed.screenHead);
                const bool feetIn = feetOk && inView(ed.screenFeet);

                const bool boxInsane = !boxOk ||
                    ed.boxWidth  > W * 2.5f || ed.boxHeight > H * 2.5f ||
                    ed.boxWidth  <= 0.0f    || ed.boxHeight <= 0.0f    ||
                    ed.boxLeft < -W * 2.0f  || ed.boxTop < -H * 2.0f;

                if (boxInsane && (headIn || feetIn || rootIn)) {
                    float topY = headIn ? ed.screenHead.Y : (rootIn ? ed.screenRoot.Y - 120.0f : ed.screenFeet.Y - 240.0f);
                    float botY = feetIn ? ed.screenFeet.Y : (rootIn ? ed.screenRoot.Y + 120.0f : ed.screenHead.Y + 240.0f);
                    float cxp  = rootIn ? ed.screenRoot.X : (feetIn ? ed.screenFeet.X : ed.screenHead.X);
                    if (botY < topY) { const float t = topY; topY = botY; botY = t; }
                    const float bh = std::clamp(botY - topY, 24.0f, H * 1.5f);
                    const float bw = std::clamp(bh * 0.45f, 14.0f, W * 0.8f);
                    ed.boxLeft   = cxp - bw * 0.5f;
                    ed.boxTop    = topY;
                    ed.boxWidth  = bw;
                    ed.boxHeight = bh;
                    ed.onScreen  = true;
                }
            }
        }

        for (auto& ed : s_DeadBodies) {
            ed.distance = UE4Helper::GetDistance(viewerPos, ed.rootPos);
            ed.onScreen = UE4Helper::WorldToScreen(ed.rootPos, ed.screenRoot, projection);
        }

        for (auto& ed : s_Items) {
            ed.distance = UE4Helper::GetDistance(viewerPos, ed.rootPos);
            ed.onScreen = UE4Helper::WorldToScreen(ed.rootPos, ed.screenRoot, projection);
        }

        for (auto& ed : s_LootBoxes) {
            ed.distance = UE4Helper::GetDistance(viewerPos, ed.rootPos);
            ed.onScreen = UE4Helper::WorldToScreen(ed.rootPos, ed.screenRoot, projection);
        }
    }

    void Init() {
        // Class identification is resolved on-demand and cached per UClass* pointer
    }

    static std::string CleanItemName(std::string rawName, const std::string& clsName) {
        if (rawName.empty() || rawName == "None") rawName = clsName;

        // 1. Strip trailing _C_0, _C_1, or _C
        size_t cPos = rawName.rfind("_C");
        if (cPos != std::string::npos && (cPos + 2 == rawName.size() || rawName[cPos + 2] == '_')) {
            rawName = rawName.substr(0, cPos);
        }

        // 2. Strip trailing instance number (e.g. _0, _1, _2)
        if (rawName.size() >= 2 && rawName[rawName.size() - 2] == '_' && isdigit(rawName.back())) {
            rawName.erase(rawName.size() - 2);
        }

        // 3. Strip known prefixes repeatedly
        static const char* const kPrefixes[] = {
            "Default__", "BP_SGPickup_Loot_", "BP_SGPickup_Item_", "BP_SGPickup_Weapon_", "BP_SGPickup_",
            "BP_Pickup_Loot_", "BP_Pickup_Item_", "BP_Pickup_", "BP_PickUp_",
            "BP_Item_Loot_", "BP_Item_", "BP_SGWeapon_", "BP_Weapon_",
            "BP_Box_", "BP_Crate_", "BP_Container_", "BP_Safe_", "BP_Loot_", "BP_",
            "SGPickup_Loot_", "SGPickup_", "Pickup_Loot_", "Pickup_", "PickUp_",
            "Item_Loot_", "Item_", "SGWeapon_", "SG_", "Wp_", "UA_", "UALoot_",
            "Loot_", "loot_", "LOOT_", "Loot", "loot", "LOOT"
        };

        bool stripped = true;
        while (stripped && !rawName.empty()) {
            stripped = false;
            for (const char* pfx : kPrefixes) {
                size_t plen = strlen(pfx);
                if (rawName.size() >= plen && rawName.compare(0, plen, pfx) == 0) {
                    rawName = rawName.substr(plen);
                    stripped = true;
                    break;
                }
            }
        }

        // 4. Strip any leading underscores or spaces
        while (!rawName.empty() && (rawName.front() == '_' || rawName.front() == ' ')) {
            rawName.erase(rawName.begin());
        }

        // 5. Strip leading technical numbers (e.g. "10012_M4A1" -> "M4A1", "5012_AK74N" -> "AK74N")
        if (!rawName.empty() && isdigit(rawName.front())) {
            size_t di = 0;
            while (di < rawName.size() && isdigit(rawName[di])) di++;
            if (di < rawName.size() && (rawName[di] == '_' || rawName[di] == ' ')) {
                if (di + 1 < rawName.size()) {
                    rawName = rawName.substr(di + 1);
                }
            }
        }

        // 6. Again strip any leading prefixes / underscores in case of nested names
        while (!rawName.empty() && (rawName.front() == '_' || rawName.front() == ' ')) {
            rawName.erase(rawName.begin());
        }
        if (rawName.size() >= 5 && (rawName.compare(0, 5, "Loot_") == 0 || rawName.compare(0, 5, "loot_") == 0)) {
            rawName = rawName.substr(5);
        }

        // 7. Replace all remaining underscores with spaces
        for (char& ch : rawName) {
            if (ch == '_') ch = ' ';
        }

        // 8. Collapse consecutive spaces and trim
        std::string clean;
        clean.reserve(rawName.size());
        bool inSpace = false;
        for (char ch : rawName) {
            if (ch == ' ') {
                if (!inSpace && !clean.empty()) {
                    clean.push_back(' ');
                    inSpace = true;
                }
            } else {
                clean.push_back(ch);
                inSpace = false;
            }
        }
        while (!clean.empty() && clean.back() == ' ') clean.pop_back();

        // 9. Remove duplicate consecutive words (e.g., "M4A1 M4A1" -> "M4A1")
        std::vector<std::string> tokens;
        {
            std::string tok;
            for (char ch : clean) {
                if (ch == ' ') {
                    if (!tok.empty()) { tokens.push_back(tok); tok.clear(); }
                } else {
                    tok.push_back(ch);
                }
            }
            if (!tok.empty()) tokens.push_back(tok);
        }
        if (tokens.size() > 1) {
            std::vector<std::string> uniqueTokens;
            for (const auto& t : tokens) {
                if (uniqueTokens.empty() || uniqueTokens.back() != t) {
                    uniqueTokens.push_back(t);
                }
            }
            std::string rebuilt;
            for (size_t ti = 0; ti < uniqueTokens.size(); ti++) {
                if (ti > 0) rebuilt.push_back(' ');
                rebuilt += uniqueTokens[ti];
            }
            clean = rebuilt;
        }

        bool onlyDigits = true;
        for (char c : clean) {
            if (!isdigit(c) && c != ' ') { onlyDigits = false; break; }
        }
        if (clean.empty() || onlyDigits) {
            clean = "Item";
        }

        return clean;
    }

    static std::string CleanBoxName(std::string rawName, const std::string& clsName) {
        std::string nRaw = NormalizeForMatch(rawName);
        std::string nCls = NormalizeForMatch(clsName);

        if (nRaw.find("longweaponcase12") != std::string::npos || nCls.find("longweaponcase12") != std::string::npos) {
            return Lang::T("Long Weapon Case 12", "Длинный оружейный кейс 12");
        }
        if (nRaw.find("longweaponcase") != std::string::npos || nCls.find("longweaponcase") != std::string::npos) {
            return Lang::T("Long Weapon Case", "Длинный оружейный кейс");
        }
        if (nRaw.find("rouble") != std::string::npos || nCls.find("rouble") != std::string::npos ||
            nRaw.find("ruble") != std::string::npos || nCls.find("ruble") != std::string::npos) {
            return Lang::T("Roubles", "Рубли");
        }

        std::string clean = CleanItemName(rawName, clsName);
        if (clean.empty() || clean == "Item") {
            if (clsName.find("Safe") != std::string::npos || rawName.find("Safe") != std::string::npos) return Lang::T("Safe", "Сейф");
            if (clsName.find("WeaponBox") != std::string::npos || rawName.find("WeaponBox") != std::string::npos) return Lang::T("Weapon Box", "Оружейный ящик");
            if (clsName.find("Med") != std::string::npos || rawName.find("Med") != std::string::npos) return Lang::T("Med Box", "Аптечка");
            if (clsName.find("Ammo") != std::string::npos || rawName.find("Ammo") != std::string::npos) return Lang::T("Ammo Box", "Патронный ящик");
            if (clsName.find("Chest") != std::string::npos) return Lang::T("Chest", "Сундук");
            if (clsName.find("Crate") != std::string::npos) return Lang::T("Crate", "Контейнер");
            return Lang::T("Box", "Ящик");
        }
        return clean;
    }

    static bool IsBoxOpenedOrEmpty(SDK::AActor* a, SDK::UClass* actorClass) {
        if (!a || !Tools::IsPtrValid(a)) return false;

        // 1. Check actor name or class name for "Opened", "Empty", "Looted"
        const std::string actorName = a->GetName();
        if (!actorName.empty()) {
            if (actorName.find("Opened") != std::string::npos ||
                actorName.find("opened") != std::string::npos ||
                actorName.find("Empty") != std::string::npos ||
                actorName.find("empty") != std::string::npos ||
                actorName.find("Looted") != std::string::npos ||
                actorName.find("looted") != std::string::npos) {
                return true;
            }
        }

        // 2. Direct check of CurFSMState on AUALockLootContainer (offset 0x0988)
        if (Tools::IsReadable(reinterpret_cast<const uint8_t*>(a) + Offsets::LootBox::CurFSMState, sizeof(SDK::FString))) {
            const auto* fsm = reinterpret_cast<const SDK::FString*>(reinterpret_cast<const uint8_t*>(a) + Offsets::LootBox::CurFSMState);
            std::string s = fsm->ToString();
            if (s.find("UnLock") != std::string::npos || s.find("Open") != std::string::npos) return true;
        }

        // 3. Direct check of SpendUseProgress (offset 0x08B8)
        if (Tools::IsReadable(reinterpret_cast<const uint8_t*>(a) + Offsets::LootBox::SpendUseProgress, sizeof(float))) {
            float progress = *reinterpret_cast<const float*>(reinterpret_cast<const uint8_t*>(a) + Offsets::LootBox::SpendUseProgress);
            if (progress >= 1.0f) return true;
        }

        // 2. Reflected properties on the Actor (cached per class for 0 runtime cost)
        if (actorClass && Tools::IsPtrValid(actorClass)) {
            BoxClassOffsets& po = s_BoxClassOffsets[actorClass];
            if (!po.checked) {
                po.offOpened = actorClass->FindPropertyOffset("bOpened");
                if (po.offOpened < 0) po.offOpened = actorClass->FindPropertyOffset("bOpen");
                if (po.offOpened < 0) po.offOpened = actorClass->FindPropertyOffset("IsOpened");
                if (po.offOpened < 0) po.offOpened = actorClass->FindPropertyOffset("WeaponBoxIsOpened");
                po.offIsOpen = actorClass->FindPropertyOffset("bIsOpen");
                po.offHasBeenOpened = actorClass->FindPropertyOffset("bHasBeenOpened");
                po.offSearched = actorClass->FindPropertyOffset("bSearched");
                if (po.offSearched < 0) po.offSearched = actorClass->FindPropertyOffset("IsSearched");
                po.offCurFSMState = actorClass->FindPropertyOffset("CurFSMState");
                po.checked = true;
            }

            if (po.offOpened > 0 && Tools::IsReadable(reinterpret_cast<const uint8_t*>(a) + po.offOpened, 1)) {
                if (*reinterpret_cast<const bool*>(reinterpret_cast<const uint8_t*>(a) + po.offOpened)) return true;
            }
            if (po.offIsOpen > 0 && Tools::IsReadable(reinterpret_cast<const uint8_t*>(a) + po.offIsOpen, 1)) {
                if (*reinterpret_cast<const bool*>(reinterpret_cast<const uint8_t*>(a) + po.offIsOpen)) return true;
            }
            if (po.offHasBeenOpened > 0 && Tools::IsReadable(reinterpret_cast<const uint8_t*>(a) + po.offHasBeenOpened, 1)) {
                if (*reinterpret_cast<const bool*>(reinterpret_cast<const uint8_t*>(a) + po.offHasBeenOpened)) return true;
            }
            if (po.offSearched > 0 && Tools::IsReadable(reinterpret_cast<const uint8_t*>(a) + po.offSearched, 1)) {
                if (*reinterpret_cast<const bool*>(reinterpret_cast<const uint8_t*>(a) + po.offSearched)) return true;
            }
            if (po.offCurFSMState > 0 && Tools::IsReadable(reinterpret_cast<const uint8_t*>(a) + po.offCurFSMState, sizeof(SDK::FString))) {
                const auto* fsm = reinterpret_cast<const SDK::FString*>(reinterpret_cast<const uint8_t*>(a) + po.offCurFSMState);
                std::string s = fsm->ToString();
                if (s.find("UnLock") != std::string::npos || s.find("Open") != std::string::npos) return true;
            }
        }

        // 3. Performance Component: SGInventoryContainerInteractPerformanceComponent
        // RotateAnimState (+0x170), TranslateAnimState (+0x1BC)
        // Enum EContainerIteractAnimState: Closed = 0, Opening = 1, Opened = 2, Closing = 3
        auto* perfComp = a->FindComponentByClassName("SGInventoryContainerInteractPerformanceComponent");
        if (perfComp && Tools::IsPtrValid(perfComp) && Tools::IsReadable(perfComp, 0x1C0)) {
            uint8_t rotState = *reinterpret_cast<const uint8_t*>(reinterpret_cast<const uint8_t*>(perfComp) + Offsets::LootBox::Perf_RotateAnimState);
            uint8_t transState = *reinterpret_cast<const uint8_t*>(reinterpret_cast<const uint8_t*>(perfComp) + Offsets::LootBox::Perf_TranslateAnimState);
            uint8_t isBySearch = *reinterpret_cast<const uint8_t*>(reinterpret_cast<const uint8_t*>(perfComp) + Offsets::LootBox::Perf_IsBySearch);
            if (rotState == 1 || rotState == 2 || transState == 1 || transState == 2 || isBySearch != 0) {
                return true;
            }
        }

        // 4. Searching Component: SGInventoryContainerSearchingComponent
        // IsLootOpenStartSearching (+0x128), RoughSearchedFinishedCharacterList (+0x108), RoughSearchedFinishedActorList (+0x118)
        auto* searchComp = a->FindComponentByClassName("SGInventoryContainerSearchingComponent");
        if (searchComp && Tools::IsPtrValid(searchComp) && Tools::IsReadable(searchComp, 0x130)) {
            bool isSearching = *reinterpret_cast<const bool*>(reinterpret_cast<const uint8_t*>(searchComp) + Offsets::LootBox::Search_IsSearching);
            if (isSearching) return true;

            const auto* chars = reinterpret_cast<const SDK::TArray<int64_t>*>(reinterpret_cast<const uint8_t*>(searchComp) + Offsets::LootBox::Search_SearchChars);
            if (chars && chars->Num() > 0 && chars->Num() <= 256 && chars->Max() >= chars->Num()) return true;

            const auto* actors = reinterpret_cast<const SDK::TArray<SDK::AActor*>*>(reinterpret_cast<const uint8_t*>(searchComp) + Offsets::LootBox::Search_SearchActors);
            if (actors && actors->Num() > 0 && actors->Num() <= 256 && actors->Max() >= actors->Num()) return true;
        }

        // 5. Manager Component: SGInventoryContainerMgrComponent
        // ContainerOccupyState (+0x0153): Empty = 3
        auto* mgrComp = a->FindComponentByClassName("SGInventoryContainerMgrComponent");
        if (mgrComp && Tools::IsPtrValid(mgrComp) && Tools::IsReadable(mgrComp, 0x155)) {
            uint8_t occState = *reinterpret_cast<const uint8_t*>(reinterpret_cast<const uint8_t*>(mgrComp) + Offsets::LootBox::Mgr_ContainerOccupyState);
            if (occState == 3) return true;
        }

        // 6. Common Data Component: SGInventoryCommonDataComponent
        // IsSearched_LocalClient (+0x0478)
        auto* commonComp = a->FindComponentByClassName("SGInventoryCommonDataComponent");
        if (commonComp && Tools::IsPtrValid(commonComp) && Tools::IsReadable(commonComp, 0x480)) {
            bool isSearched = *reinterpret_cast<const bool*>(reinterpret_cast<const uint8_t*>(commonComp) + Offsets::LootBox::Common_IsSearched);
            if (isSearched) return true;
        }

        return false;
    }

    void Update(SDK::UWorld* world, SDK::ASGCharacter* localPlayer, SDK::ASGPlayerController* controller,
                const UE4Helper::ScreenProjection& projection) {
        const auto& camLoc = projection.Location;
        const int screenWidth = projection.Width, screenHeight = projection.Height;

        if (!projection.Valid || !world || !localPlayer || !controller) {
            Reset();
            return;
        }

        // Fast path: keep the expensive actor/UObject scan cached for a few frames.
        // Invalidate even when a map is re-entered at the same address or possession
        // changes without changing UWorld.
        static SDK::UWorld* s_DataWorld = nullptr;
        static SDK::ASGCharacter* s_DataPlayer = nullptr;
        static uint64_t s_DataGeneration = 0;
        static auto s_NextEntityRefresh = std::chrono::steady_clock::time_point::min();
        const auto now = std::chrono::steady_clock::now();
        const bool resetData = world != s_DataWorld || localPlayer != s_DataPlayer ||
            s_DataGeneration != s_ResetGeneration;
        if (resetData) {
            Reset();
            s_DataGeneration = s_ResetGeneration;
            s_DataWorld = world;
            s_DataPlayer = localPlayer;
            s_NextEntityRefresh = std::chrono::steady_clock::time_point::min();
        }

        SDK::FVector viewerPos = camLoc;
        if (viewerPos.SizeSquared() <= 1.0f && localPlayer->RootComponent && Tools::IsPtrValid(localPlayer->RootComponent)) {
            viewerPos = localPlayer->RootComponent->K2_GetComponentLocation();
        }

        if (now < s_NextEntityRefresh) {
            RefreshProjection(projection, viewerPos);
            UpdateVisibility(camLoc, localPlayer, controller);
            return;
        }

        s_NextEntityRefresh = now + kEntityRefreshInterval;
        s_Enemies.clear();
        s_DeadBodies.clear();
        s_Items.clear();
        s_LootBoxes.clear();
        if (s_Enemies.capacity() < 32) s_Enemies.reserve(32);
        if (s_DeadBodies.capacity() < 16) s_DeadBodies.reserve(16);
        if (s_Items.capacity() < 64) s_Items.reserve(64);
        if (s_LootBoxes.capacity() < 32) s_LootBoxes.reserve(32);

        Init();

        static SDK::UWorld* s_LastWorld = nullptr;
        if (world != s_LastWorld) {
            s_LastWorld = world;
            s_SGCharClass = nullptr;
            s_BaseCharClass = nullptr;
            s_CharClass = nullptr;
            s_AICharClass = nullptr;
            s_PickupClass = nullptr;
            s_ClassCharCache.clear();
            s_ClassItemCache.clear();
            s_BoxClassOffsets.clear();
        }

        if (!s_SGCharClass) {
            if (localPlayer && Tools::IsPtrValid(localPlayer) &&
                localPlayer->ClassPrivate && Tools::IsPtrValid(localPlayer->ClassPrivate) &&
                Tools::IsReadable(localPlayer->ClassPrivate, sizeof(SDK::UClass))) {
                s_SGCharClass = localPlayer->ClassPrivate;
            } else {
                s_SGCharClass = SDK::ASGCharacter::StaticClass();
            }
            if (s_SGCharClass && Tools::IsPtrValid(s_SGCharClass)) {
                LOGI("[ActorPipeline] Resolved s_SGCharClass: %p ('%s')", s_SGCharClass, s_SGCharClass->GetName().c_str());
                for (SDK::UStruct* s = s_SGCharClass; s && Tools::IsPtrValid(s) && Tools::IsReadable(s, sizeof(SDK::UStruct)); s = s->SuperStruct) {
                    std::string sName = s->GetName();
                    if (sName == "Character" || sName == "ACharacter") {
                        s_CharClass = static_cast<SDK::UClass*>(s);
                        LOGI("[ActorPipeline] Resolved s_CharClass: %p ('%s')", s_CharClass, sName.c_str());
                        break;
                    }
                    if (!s_BaseCharClass && (sName == "SGCharacterBase" || sName == "ASGCharacterBase")) {
                        s_BaseCharClass = static_cast<SDK::UClass*>(s);
                        LOGI("[ActorPipeline] Resolved s_BaseCharClass: %p ('%s')", s_BaseCharClass, sName.c_str());
                    }
                }
            }
            // Fallback: if SuperStruct walk failed to resolve the base class (e.g. the
            // local player's hierarchy didn't include SGCharacterBase in this session),
            // try the GObjects scan path. This catches both bots and enemy players when
            // s_SGCharClass is the concrete BP class and the base wasn't in the chain.
            if (!s_BaseCharClass) {
                s_BaseCharClass = SDK::ASGCharacterBase::StaticClass();
                if (s_BaseCharClass)
                    LOGI("[ActorPipeline] s_BaseCharClass via StaticClass: %p", s_BaseCharClass);
            }
            if (!s_SGCharClass) {
                s_SGCharClass = SDK::ASGCharacter::StaticClass();
                if (s_SGCharClass)
                    LOGI("[ActorPipeline] s_SGCharClass via StaticClass: %p", s_SGCharClass);
            }
        }
        // AI derives from SGCharacterBase; do not scan all GObjects every time
        // an AI class is absent. ASGCharacter::IsAI classifies encountered classes.

        // Try to get localTeamId from PlayerInfo.TeamIndex first.
        // If that returns -1, fall back to ASGPlayerState.TeamIndex (offset 0x5A0 or 0x518).
        static int32_t s_LastKnownLocalTeamId = -1;
        int32_t localTeamId = -1;
        if (localPlayer && Tools::IsPtrValid(localPlayer)) {
            localTeamId = localPlayer->GetTeamID();
            if (localTeamId < 0) {
                // fallback: read ASGPlayerState.TeamIndex directly
                auto* psRaw = GetPawnPlayerState(localPlayer);
                if (psRaw) {
                    auto* sgPs = reinterpret_cast<SDK::ASGPlayerState*>(psRaw);
                    if (Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::TeamIndex, sizeof(int32_t))) {
                        int32_t psTid = *reinterpret_cast<const int32_t*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::TeamIndex);
                        if (psTid >= 0 && psTid < 1000) localTeamId = psTid;
                    }
                    if (localTeamId < 0 && Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::AltTeamIndex, sizeof(int32_t))) {
                        int32_t psTid = *reinterpret_cast<const int32_t*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::AltTeamIndex);
                        if (psTid >= 0 && psTid < 1000) localTeamId = psTid;
                    }
                }
            }
            if (localTeamId >= 0) {
                s_LastKnownLocalTeamId = localTeamId;
            } else if (s_LastKnownLocalTeamId >= 0) {
                localTeamId = s_LastKnownLocalTeamId;
            }
        }
        int charCount = 0;
        static int32_t s_LoggedTeamId = -99;
        if (localTeamId != s_LoggedTeamId) {
            LOGI("[ActorPipeline] localTeamId resolved: %d (ptr=%p)", localTeamId, localPlayer);
            s_LoggedTeamId = localTeamId;
        }

        // Discovery/classification is throttled; RefreshProjection reads live
        // character geometry and HP on the intervening frames.
        static std::vector<SDK::AActor*> actors;
        static SDK::UWorld* s_ActorsWorld = nullptr;
        static auto s_NextActorRefresh = std::chrono::steady_clock::time_point::min();
        static std::vector<SDK::ASGCharacterFastRepProxy*> s_CachedProxies;

        if (resetData || world != s_ActorsWorld || now >= s_NextActorRefresh) {
            world->GetActors(actors);
            s_ActorsWorld = world;
            s_NextActorRefresh = now + kActorListRefreshInterval;

            // Rebuild phantom-pawn evidence once per actor refresh, so the
            // duplicate-PlayerState test compares the complete set.
            std::vector<SDK::ASGCharacter*> charList;
            s_CachedProxies.clear();
            charList.reserve(actors.size() / 4);
            s_CachedProxies.reserve(32);
            static SDK::UClass* s_ProxyClass = nullptr;
            if (!s_ProxyClass) s_ProxyClass = SDK::ASGCharacterFastRepProxy::StaticClass();

            for (SDK::AActor* a : actors) {
                if (!a || !Tools::IsPtrValid(a) || !IsObjectValid(a)) continue;
                SDK::UClass* c = a->ClassPrivate;
                if (!Tools::IsReadable(c, sizeof(SDK::UClass))) continue;
                const std::string cn = c->GetName();
                if (cn.empty() || cn == "None") continue;

                // Collect proxy actors from the level
                if ((s_ProxyClass && a->IsA(s_ProxyClass)) || cn.find("FastRepProxy") != std::string::npos) {
                    s_CachedProxies.push_back(reinterpret_cast<SDK::ASGCharacterFastRepProxy*>(a));
                    continue;
                }

                if (cn.find("Preview") != std::string::npos ||
                    cn.find("Capture") != std::string::npos ||
                    cn.find("Dummy") != std::string::npos ||
                    cn.find("Lobby") != std::string::npos) continue;
                if (c->PropertiesSize < sizeof(SDK::ASGCharacterBase)) continue;
                if ((s_BaseCharClass && a->IsA(s_BaseCharClass)) ||
                    (s_SGCharClass && a->IsA(s_SGCharClass))) {
                    charList.push_back(reinterpret_cast<SDK::ASGCharacter*>(a));
                }
            }
            BuildPawnIdentities(charList, s_CachedProxies, viewerPos);
            s_IdentityGeneration = s_ResetGeneration;
        }

        // Safety guard: if s_PawnIdentity was never built (empty after Reset on first
        // frame), skip processing until the actor refresh below populates it.
        const bool identityReady = !s_PawnIdentity.empty() || s_IdentityGeneration == s_ResetGeneration;

        const float currentWorldTime = GetWorldTimeSeconds(world, localPlayer);

        for (SDK::AActor* a : actors) {
            if (!identityReady) break; // wait for the next refresh cycle
            if (!a || !Tools::IsPtrValid(a)) continue;
            if (!IsObjectValid(a)) continue;

            SDK::UClass* actorClass = a->ClassPrivate;

            // Classify once per class. Preview exclusions take precedence over
            // IsA, otherwise capture actors derived from Character leak through.
            bool isChar = false;
            auto cacheIt = s_ClassCharCache.find(actorClass);
            if (cacheIt != s_ClassCharCache.end()) {
                isChar = cacheIt->second;
            } else if (Tools::IsReadable(actorClass, sizeof(SDK::UClass))) {
                const std::string clsName = actorClass->GetName();
                if (clsName.empty() || clsName == "None") continue;
                const bool excluded = clsName.find("Preview") != std::string::npos ||
                    clsName.find("Capture") != std::string::npos ||
                    clsName.find("Dummy") != std::string::npos ||
                    clsName.find("Lobby") != std::string::npos;
                // Base Character/Pawn/Player names alone do not prove SG layout.
                isChar = !excluded && actorClass->PropertiesSize >= sizeof(SDK::ASGCharacterBase) &&
                    ((s_BaseCharClass && a->IsA(s_BaseCharClass)) ||
                     (s_SGCharClass && a->IsA(s_SGCharClass)));
                s_ClassCharCache[actorClass] = isChar;
            }

            if (isChar) {
                auto charActor = reinterpret_cast<SDK::ASGCharacter*>(a);
                if (charActor == localPlayer || charActor == controller->ControlledCharacter ||
                    charActor == controller->Pawn || charActor == controller->AcknowledgedPawn ||
                    charActor->Controller == controller) continue;

                // Absolute sanity check: real characters MUST have RootComponent
                if (!charActor->RootComponent || !Tools::IsPtrValid(charActor->RootComponent)) continue;

                if (localPlayer && localPlayer->RootComponent && Tools::IsPtrValid(localPlayer->RootComponent) && 
                    charActor->RootComponent == localPlayer->RootComponent) continue;

                SDK::FVector rootPos;
                bool hasWorldPosition = charActor->RootComponent->TryGetWorldLocation(rootPos);
                if (!hasWorldPosition && charActor->CapsuleComponent && Tools::IsPtrValid(charActor->CapsuleComponent)) {
                    hasWorldPosition = charActor->CapsuleComponent->TryGetWorldLocation(rootPos);
                }

                // Preserve the dormant-origin filter, but never assume map altitude:
                // arena_now.txt contains active AI at Z=-7804.6 and Z=-8365.7.
                if (!hasWorldPosition || !std::isfinite(rootPos.SizeSquared())) continue;
                if (rootPos.SizeSquared() < 0.001f) continue;
                if (std::abs(rootPos.X) < 1.0f && std::abs(rootPos.Y) < 1.0f) continue;

                charCount++;

                bool isBot = charActor->IsAI();
                // Ghost/phantom rejection via the fast-rep proxy: for a real,
                // actively-replicated player the proxy's server location agrees with
                // RootComponent (within a few metres). A dormant/pooled pawn has a
                // STALE RootComponent that diverges hugely from the live proxy — that
                // is the ghost whose skeleton the player could run up to and find
                // nobody. Drop those; keep RootComponent for real players (smooth).
                // Remote players: use the authoritative networked position from the
                // fast-rep proxy (PredictStopLocation + FastReplicatedMovement),
                // instead of the stale/dormant RootComponent. Bots have no proxy.
                if (!isBot) {
                    const SDK::FVector rawRoot = rootPos;
                    rootPos = ChooseLivePosition(charActor, rawRoot, viewerPos);
#ifdef ARENA_DIAG
                    SDK::FVector proxyPos;
                    const bool okp = charActor->GetFastRepLocation(proxyPos);
                    {
                        static uint64_t s_c = 0;
                        if (s_c++ % 60 < 6) {
                            const uintptr_t self = reinterpret_cast<uintptr_t>(charActor);
                            const uintptr_t proxy = Tools::ReadMemory<uintptr_t>(self + Offsets::SGCharacter::CharacterFastRepProxy);
                            const SDK::FVector loc  = proxy ? Tools::ReadMemory<SDK::FVector>(proxy + Offsets::FastRepProxy::Location) : SDK::FVector{0,0,0};
                            const SDK::FVector stop = proxy ? Tools::ReadMemory<SDK::FVector>(proxy + Offsets::FastRepProxy::PredictStopLocation) : SDK::FVector{0,0,0};
                            FILE* df = fopen("/sdcard/Download/arena_esp_diag.txt", "a");
                            if (df) {
                                fprintf(df, "char=%p root=(%.0f,%.0f,%.0f) loc348=(%.0f,%.0f,%.0f) stop314=(%.0f,%.0f,%.0f) final=(%.0f,%.0f,%.0f) okp=%d\n",
                                    charActor, rawRoot.X,rawRoot.Y,rawRoot.Z, loc.X,loc.Y,loc.Z,
                                    stop.X,stop.Y,stop.Z, rootPos.X,rootPos.Y,rootPos.Z, (int)okp);
                                fclose(df);
                            }
                        }
                    }
#endif
                }
                ResolveVisualRoot(charActor, rootPos, viewerPos);

                float dist = UE4Helper::GetDistance(viewerPos, rootPos);
                bool isDead = charActor->IsDead();
                // NPC = MFNPCAI package actor (subset of isBot). Shown as "ACTOR" on screen.
                // IsNPC() short-circuits at SGAICharacter so regular bots stay as BOT.
                bool isNPC = isBot && charActor->IsNPC();
                int32_t teamId = charActor->GetTeamID();
                if (teamId < 0) {
                    auto idIt = s_PawnIdentity.find(charActor);
                    if (idIt != s_PawnIdentity.end() && idIt->second.teamId >= 0) {
                        teamId = idIt->second.teamId;
                    }
                    if (teamId < 0) {
                        auto* psRaw = GetPawnPlayerState(charActor);
                        if (psRaw) {
                            auto* sgPs = reinterpret_cast<SDK::ASGPlayerState*>(psRaw);
                            if (Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::TeamIndex, sizeof(int32_t))) {
                                int32_t psTid = *reinterpret_cast<const int32_t*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::TeamIndex);
                                if (psTid >= 0 && psTid < 1000) teamId = psTid;
                            }
                            if (teamId < 0 && Tools::IsReadable(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::AltTeamIndex, sizeof(int32_t))) {
                                int32_t psTid = *reinterpret_cast<const int32_t*>(reinterpret_cast<uint8_t*>(sgPs) + Offsets::SGPlayerState::AltTeamIndex);
                                if (psTid >= 0 && psTid < 1000) teamId = psTid;
                            }
                        }
                    }
                }

                // Reject confirmed client-side phantom pawns. Real pawns with valid GID are never dropped.
                if (!isBot) {
                    auto idIt = s_PawnIdentity.find(charActor);
                    if (idIt != s_PawnIdentity.end()) {
                        const PawnIdentity& pid = idIt->second;
                        if (pid.isPhantom && (pid.gid == 0 || !pid.hasName)) {
                            if (s_PhantomDumped.insert(charActor).second) {
                                LOGI("[PHANTOM] drop duplicate/dormant pawn cls='%s' ptr=%p dist=%.1f team=%d gid=%llu",
                                     actorClass ? actorClass->GetName().c_str() : "null", charActor,
                                     dist, teamId, (unsigned long long)pid.gid);
                            }
                            continue;
                        }
                    }
                }

                static uint64_t s_CharLogCounter = 0;
                if (++s_CharLogCounter % 300 < 5) {
                    LOG_FRAME("[ActorPipeline] Char #%d: cls='%s' ptr=%p rootPos=(%.1f, %.1f, %.1f) dist=%.1fm dead=%d bot=%d team=%d locTeam=%d",
                         charCount, actorClass ? actorClass->GetName().c_str() : "null", charActor, rootPos.X, rootPos.Y, rootPos.Z, dist, (int)isDead, (int)isBot, teamId, localTeamId);
                }

                if (dist > (float)std::max(g_Config.max_distance_offscreen, 600)) continue;

                if (isDead) {
                    if (g_Config.esp_dead_bodies) {
                        EntityData ed;
                        ed.rawActor = a;
                        ed.character = charActor;
                        ed.rootPos = rootPos;
                        ed.distance = dist;
                        ed.isDead = true;
                        ed.isBot = isBot;
                        ed.isNPC = isNPC;
                        ed.type = EntityType::DeadBody;
                        ed.name = isBot ? "Dead Bot" : (ed.name.empty() ? "Dead Player" : ed.name);
                        SDK::FVector2D screenPos;
                        if (UE4Helper::WorldToScreen(rootPos, screenPos, projection)) {
                            ed.screenRoot = screenPos;
                            ed.onScreen = true;
                        }
                        s_DeadBodies.push_back(ed);
                    }
                    continue;
                }

                // If user disabled bots ESP, skip bots
                if (isBot && !g_Config.esp_bots) {
                    continue;
                }

                // Teammate detection: both team IDs are >= 0 (known) and equal.
                // Note: localTeamId or teamId == -1 means unknown — skip teammate check.
                const bool isTeammate = !isBot
                    && localTeamId >= 0 && teamId >= 0
                    && teamId == localTeamId;

                // If user disabled teammate ESP, skip them
                if (isTeammate && !g_Config.esp_teammates) {
                    continue;
                }

                EntityData ed;
                ed.rawActor = a;
                ed.character = charActor;
                ed.rootPos = rootPos;
                ed.distance = dist;
                ed.isDead = false;
                ed.isTeammate = isTeammate;
                ed.isBot = isBot;
                ed.isNPC = isNPC;
                ed.type = isTeammate ? EntityType::Teammate
                        : (isNPC   ? EntityType::NPC
                        : (isBot   ? EntityType::Bot
                                   : EntityType::EnemyPlayer));
                ed.teamId = teamId;
                if (g_Config.esp_enabled && g_Config.esp_health) {
                    charActor->TryGetHealth(ed.health, ed.maxHealth);
                }
                ed.isKnocked = charActor->IsKnocked();

                // Player name extraction (real players & teammates)
                if (!isBot && !isNPC) {
                    auto idIt = s_PawnIdentity.find(charActor);
                    if (idIt != s_PawnIdentity.end() && !idIt->second.name.empty()) {
                        ed.name = idIt->second.name;
                    }
                    if (ed.name.empty()) {
                        ed.name = ExtractPlayerName(charActor);
                    }
                }

                // Visibility: mesh LastRenderTime vs client worldTime
                {
                    bool vis = false;
                    const auto m = charActor->GetMeshComponent();
                    if (m && Tools::IsPtrValid(m)) {
                        vis = IsMeshVisible(m, currentWorldTime, charActor);
                    }
                    ed.isVisible = vis;
                }

                // Capsule & Head/Feet calculation
                float halfHeight = 88.0f;
                float radius = 34.0f;
                if (charActor->CapsuleComponent && Tools::IsPtrValid(charActor->CapsuleComponent)) {
                    float hh = charActor->CapsuleComponent->GetScaledCapsuleHalfHeight();
                    float r = charActor->CapsuleComponent->GetScaledCapsuleRadius();
                    if (hh >= 30.0f && hh <= 140.0f) halfHeight = hh;
                    if (r >= 10.0f && r <= 70.0f) radius = r;
                }
                ed.capsuleHalfHeight = halfHeight;
                ed.capsuleRadius = radius;

                SDK::FVector headPos;
                if (dist <= 38.0f) {
                    headPos = charActor->GetBonePos("Head");
                }
                if (headPos.SizeSquared() < 0.001f || std::abs(headPos.Z - rootPos.Z) < 15.0f || (headPos - rootPos).SizeSquared() > 100.0f * 100.0f) {
                    headPos = rootPos + SDK::FVector{0.0f, 0.0f, halfHeight * 0.82f};
                }
                SDK::FVector feetPos = rootPos - SDK::FVector{0.0f, 0.0f, halfHeight};
                if (feetPos.SizeSquared() < 0.001f || std::abs(feetPos.Z - rootPos.Z) < 20.0f) {
                    feetPos = rootPos - SDK::FVector{0.0f, 0.0f, halfHeight};
                }
                ed.headPos = headPos;
                ed.feetPos = feetPos;

                // Screen Bounding Box Projection
                SDK::FVector topWorld = rootPos + SDK::FVector{0.0f, 0.0f, halfHeight};
                SDK::FVector botWorld = rootPos - SDK::FVector{0.0f, 0.0f, halfHeight};

                SDK::FVector2D topScreen{0, 0};
                SDK::FVector2D botScreen{0, 0};
                SDK::FVector2D headScreen{0, 0};
                SDK::FVector2D feetScreen{0, 0};
                SDK::FVector2D rootScreen{0, 0};

                bool topW2S = UE4Helper::WorldToScreen(topWorld, topScreen, projection);
                bool botW2S = UE4Helper::WorldToScreen(botWorld, botScreen, projection);
                bool headW2S = UE4Helper::WorldToScreen(headPos, headScreen, projection);
                bool feetW2S = UE4Helper::WorldToScreen(feetPos, feetScreen, projection);
                bool rootW2S = UE4Helper::WorldToScreen(rootPos, rootScreen, projection);

                ed.screenRoot = rootScreen;
                ed.screenHead = headW2S ? headScreen : topScreen;
                ed.screenFeet = feetW2S ? feetScreen : botScreen;

                // Project the capsule's world bounds, not a screen-aligned height
                // approximation. Roll/pitch and perspective affect every corner.
                SDK::FVector2D boxMin, boxMax;
                ed.onScreen = UE4Helper::WorldBoundsToScreen(rootPos, {radius, radius, halfHeight},
                                                            boxMin, boxMax, projection);
                if (ed.onScreen) {
                    ed.boxLeft = boxMin.X;
                    ed.boxTop = boxMin.Y;
                    ed.boxWidth = boxMax.X - boxMin.X;
                    ed.boxHeight = boxMax.Y - boxMin.Y;
                    // Do not enlarge distant boxes or guess another focal length.
                    ed.onScreen = ed.boxWidth > 0.0f && ed.boxHeight > 0.0f &&
                        boxMax.X >= -150.0f && boxMin.X <= screenWidth + 150.0f &&
                        boxMax.Y >= -150.0f && boxMin.Y <= screenHeight + 150.0f;
                }

                s_Enemies.push_back(ed);
                continue;
            }

            // 1. Strict Dead Body / Corpse Check (checked via IsDead system or corpse actor classes)
            std::string clsName = actorClass->GetName();
            std::string actName = a->GetName();

            // Blacklist check: reject unwanted static meshes, environmental props, and junk items
            if (IsBlacklistedActor(actName, clsName)) {
                continue;
            }

            bool isCorpse = false;
            if (clsName.find("Corpse") != std::string::npos ||
                clsName.find("DeadBody") != std::string::npos ||
                clsName.find("Ragdoll") != std::string::npos ||
                clsName.find("DeathDrop") != std::string::npos ||
                clsName.find("DeathBox") != std::string::npos ||
                actName.find("Corpse") != std::string::npos ||
                actName.find("DeadBody") != std::string::npos ||
                actName.find("DeathBox") != std::string::npos) {
                isCorpse = true;
            }

            if (isCorpse) {
                if (g_Config.esp_dead_bodies) {
                    SDK::FVector pos = (a->RootComponent && Tools::IsPtrValid(a->RootComponent))
                        ? a->RootComponent->K2_GetComponentLocation() : SDK::FVector{0,0,0};
                    if (pos.SizeSquared() > 0.001f) {
                        float dist = UE4Helper::GetDistance(viewerPos, pos);
                        if (dist <= (float)g_Config.item_esp_max_distance) {
                            EntityData ed;
                            ed.rawActor = a;
                            ed.type = EntityType::DeadBody;
                            ed.rootPos = pos;
                            ed.distance = dist;
                            ed.isDead = true;
                            ed.name = "Corpse";
                            SDK::FVector2D screenPos;
                            if (UE4Helper::WorldToScreen(pos, screenPos, projection)) {
                                ed.screenRoot = screenPos;
                                ed.onScreen = true;
                            }
                            s_DeadBodies.push_back(ed);
                        }
                    }
                }
                continue; // CRITICAL: Stop here, NEVER consider as item or box!
            }

            // 2. Reject any Character/Pawn that somehow bypassed isChar (e.g. dead ragdoll pawns or dummy pawns)
            if ((s_BaseCharClass && a->IsA(s_BaseCharClass)) ||
                (s_SGCharClass && a->IsA(s_SGCharClass)) ||
                (s_CharClass && a->IsA(s_CharClass))) {
                continue; // NEVER consider a character as item or box!
            }

            // 3. Lootbox / Container / Crate / Safe / Case / Roubles Check (CATEGORY: BOXES)
            bool isBox = false;
            std::string nCls = NormalizeForMatch(clsName);
            std::string nAct = NormalizeForMatch(actName);

            if (nCls.find("box") != std::string::npos ||
                nCls.find("crate") != std::string::npos ||
                nCls.find("container") != std::string::npos ||
                nCls.find("safe") != std::string::npos ||
                nCls.find("chest") != std::string::npos ||
                nCls.find("cabinet") != std::string::npos ||
                nCls.find("drawer") != std::string::npos ||
                nCls.find("locker") != std::string::npos ||
                nCls.find("case") != std::string::npos ||
                nCls.find("rouble") != std::string::npos ||
                nCls.find("ruble") != std::string::npos ||
                nAct.find("box") != std::string::npos ||
                nAct.find("crate") != std::string::npos ||
                nAct.find("container") != std::string::npos ||
                nAct.find("safe") != std::string::npos ||
                nAct.find("case") != std::string::npos ||
                nAct.find("rouble") != std::string::npos ||
                nAct.find("ruble") != std::string::npos) {
                if (nCls.find("volume") == std::string::npos &&
                    nCls.find("trigger") == std::string::npos &&
                    nCls.find("widget") == std::string::npos &&
                    nCls.find("capture") == std::string::npos &&
                    nCls.find("component") == std::string::npos &&
                    nCls.find("service") == std::string::npos &&
                    nCls.find("staticmesh") == std::string::npos &&
                    !HasSMPrefix(actName) &&
                    !HasSMPrefix(clsName)) {
                    isBox = true;
                }
            }

            if (isBox) {
                if (g_Config.esp_lootbox) {
                    // Check opened / looted / empty filter!
                    if (g_Config.esp_filter_opened_boxes && IsBoxOpenedOrEmpty(a, actorClass)) {
                        continue;
                    }

                    SDK::FVector boxPos = (a->RootComponent && Tools::IsPtrValid(a->RootComponent))
                        ? a->RootComponent->K2_GetComponentLocation() : SDK::FVector{0,0,0};
                    if (boxPos.SizeSquared() > 0.001f) {
                        float dist = UE4Helper::GetDistance(viewerPos, boxPos);
                        if (dist <= (float)g_Config.item_esp_max_distance) {
                            EntityData ed;
                            ed.rawActor = a;
                            ed.type = EntityType::LootBox;
                            ed.rootPos = boxPos;
                            ed.distance = dist;
                            ed.name = CleanBoxName(actName, clsName);
                            SDK::FVector2D screenPos;
                            if (UE4Helper::WorldToScreen(boxPos, screenPos, projection)) {
                                ed.screenRoot = screenPos;
                                ed.onScreen = true;
                            }
                            if (!ed.name.empty() && !IsBlacklistedActor(ed.name, actName)) {
                                s_LootBoxes.push_back(ed);
                            }
                        }
                    }
                }
                continue; // CRITICAL: Stop here, NEVER consider box as loose item!
            }

            // 4. Loose World Item / Pickup / Weapon / Ammo Check (CATEGORY: ITEMS)
            if (g_Config.esp_items) {
                bool isItem = false;
                auto itemIt = s_ClassItemCache.find(actorClass);
                if (itemIt != s_ClassItemCache.end()) {
                    isItem = itemIt->second;
                } else {
                    if (clsName.find("Pickup") != std::string::npos ||
                        clsName.find("PickUp") != std::string::npos ||
                        clsName.find("Item") != std::string::npos ||
                        clsName.find("SGPickup") != std::string::npos ||
                        clsName.find("Drop") != std::string::npos ||
                        clsName.find("Loot") != std::string::npos ||
                        clsName.find("Weapon") != std::string::npos ||
                        clsName.find("Ammo") != std::string::npos ||
                        clsName.find("Armor") != std::string::npos ||
                        clsName.find("Helmet") != std::string::npos ||
                        clsName.find("Vest") != std::string::npos ||
                        clsName.find("Backpack") != std::string::npos) {
                        if (clsName.find("Volume") == std::string::npos &&
                            clsName.find("Trigger") == std::string::npos &&
                            clsName.find("Capture") == std::string::npos &&
                            clsName.find("Service") == std::string::npos &&
                            clsName.find("Widget") == std::string::npos &&
                            clsName.find("Component") == std::string::npos &&
                            clsName.find("Preview") == std::string::npos &&
                            clsName.find("FrontEnd") == std::string::npos &&
                            clsName.find("Lobby") == std::string::npos &&
                            clsName.find("StaticMesh") == std::string::npos &&
                            !HasSMPrefix(actName) &&
                            !HasSMPrefix(clsName)) {
                            isItem = true;
                        }
                    }
                    s_ClassItemCache[actorClass] = isItem;
                }

                if (isItem) {
                    SDK::FVector itemPos = (a->RootComponent && Tools::IsPtrValid(a->RootComponent))
                        ? a->RootComponent->K2_GetComponentLocation() : SDK::FVector{0,0,0};
                    if (itemPos.SizeSquared() > 0.001f) {
                        float dist = UE4Helper::GetDistance(viewerPos, itemPos);
                        if (dist <= (float)g_Config.item_esp_max_distance) {
                            EntityData ed;
                            ed.rawActor = a;
                            ed.type = EntityType::Item;
                            ed.rootPos = itemPos;
                            ed.distance = dist;
                            ed.name = CleanItemName(actName, clsName);
                            SDK::FVector2D screenPos;
                            if (UE4Helper::WorldToScreen(itemPos, screenPos, projection)) {
                                ed.screenRoot = screenPos;
                                ed.onScreen = true;
                            }
                            if (!IsBlacklistedActor(ed.name, actName)) {
                                s_Items.push_back(ed);
                            }
                        }
                    }
                }
            }
        } // end actors loop

        // Ensure standalone/unlinked FastRep proxies are also rendered across the entire map
        for (auto* proxy : s_CachedProxies) {
            if (!proxy || !Tools::IsPtrValid(proxy) || !IsObjectValid(proxy)) continue;
            auto* bound = proxy->BindingCharacter;
            if (bound && (!Tools::IsPtrValid(bound) || !IsObjectValid(bound))) {
                bound = nullptr;
            }
            bool alreadyInEnemies = false;
            for (const auto& ed : s_Enemies) {
                if (ed.rawActor == proxy || (bound && ed.character == bound)) {
                    alreadyInEnemies = true;
                    break;
                }
            }
            if (alreadyInEnemies) continue;

            if (!Tools::IsReadable(reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(proxy) + Offsets::FastRepProxy::Location), sizeof(SDK::FVector))) continue;
            const SDK::FVector loc = proxy->Location;
            if (!std::isfinite(loc.X) || !std::isfinite(loc.Y) || !std::isfinite(loc.Z)) continue;
            if (loc.SizeSquared() < 0.001f || (std::abs(loc.X) < 1.0f && std::abs(loc.Y) < 1.0f)) continue;
            if (loc.Z < -50000.0f || loc.Z > 200000.0f) continue;

            float dist = UE4Helper::GetDistance(viewerPos, loc);
            if (dist > (float)std::max(g_Config.max_distance_offscreen, 600)) continue;

            int32_t tid = -1;
            bool isKnocked = false;
            float hp = -1.0f, maxHp = -1.0f;
            if (bound) {
                tid = bound->GetTeamID();
                isKnocked = bound->IsKnocked();
                bound->TryGetHealth(hp, maxHp);
            }
            const bool isTeammate = (localTeamId >= 0 && tid >= 0 && tid == localTeamId);
            if (isTeammate && !g_Config.esp_teammates) continue;

            EntityData ed;
            ed.rawActor = proxy;
            ed.character = bound;
            ed.rootPos = loc;
            ed.distance = dist;
            ed.isDead = false;
            ed.isBot = false;
            ed.isTeammate = isTeammate;
            ed.type = isTeammate ? EntityType::Teammate : EntityType::EnemyPlayer;
            ed.proxyOnly = true;   // emitted from a proxy with no loaded character
            ed.name = "Player";
            ed.teamId = tid;
            ed.isKnocked = isKnocked;
            ed.health = hp;
            ed.maxHealth = maxHp;
            ed.capsuleHalfHeight = 88.0f;
            ed.capsuleRadius = 34.0f;
            ed.headPos = loc + SDK::FVector{0.0f, 0.0f, 72.0f};
            ed.feetPos = loc - SDK::FVector{0.0f, 0.0f, 88.0f};

            SDK::FVector2D boxMin, boxMax;
            ed.onScreen = UE4Helper::WorldBoundsToScreen(loc, {34.0f, 34.0f, 88.0f}, boxMin, boxMax, projection);
            if (ed.onScreen) {
                ed.boxLeft = boxMin.X;
                ed.boxTop = boxMin.Y;
                ed.boxWidth = boxMax.X - boxMin.X;
                ed.boxHeight = boxMax.Y - boxMin.Y;
                ed.onScreen = ed.boxWidth > 0.0f && ed.boxHeight > 0.0f &&
                    boxMax.X >= -150.0f && boxMin.X <= screenWidth + 150.0f &&
                    boxMax.Y >= -150.0f && boxMin.Y <= screenHeight + 150.0f;
            }
            UE4Helper::WorldToScreen(loc, ed.screenRoot, projection);
            UE4Helper::WorldToScreen(ed.headPos, ed.screenHead, projection);
            UE4Helper::WorldToScreen(ed.feetPos, ed.screenFeet, projection);

            s_Enemies.push_back(ed);
        }
        if (s_Items.size() > 1) {
            std::vector<EntityData> uniqueItems;
            uniqueItems.reserve(s_Items.size());
            for (const auto& item : s_Items) {
                bool duplicate = false;
                for (auto& existing : uniqueItems) {
                    float distSq = (item.rootPos - existing.rootPos).SizeSquared();
                    if (distSq < 40.0f * 40.0f) { // within 40 cm
                        if (existing.name == "Item" && item.name != "Item") {
                            existing = item;
                        }
                        duplicate = true;
                        break;
                    }
                }
                if (!duplicate) {
                    uniqueItems.push_back(item);
                }
            }
            s_Items.swap(uniqueItems);
        }

        // Spatial deduplication for loot boxes (< 50 cm)
        if (s_LootBoxes.size() > 1) {
            std::vector<EntityData> uniqueBoxes;
            uniqueBoxes.reserve(s_LootBoxes.size());
            for (const auto& box : s_LootBoxes) {
                bool duplicate = false;
                for (auto& existing : uniqueBoxes) {
                    float distSq = (box.rootPos - existing.rootPos).SizeSquared();
                    if (distSq < 50.0f * 50.0f) {
                        duplicate = true;
                        break;
                    }
                }
                if (!duplicate) {
                    uniqueBoxes.push_back(box);
                }
            }
            s_LootBoxes.swap(uniqueBoxes);
        }

        UpdateVisibility(camLoc, localPlayer, controller);

        static uint64_t s_PipelineUpdateFrames = 0;
        if (++s_PipelineUpdateFrames % 300 == 0 || s_PipelineUpdateFrames == 1 || s_PipelineUpdateFrames == 10) {
            LOGI("[ActorPipeline] Frame #%" PRIu64 ": TotalActors=%zu, Characters=%d, Enemies=%zu, Dead=%zu, Boxes=%zu, Items=%zu, LocalPlayer=%p",
                 s_PipelineUpdateFrames, actors.size(), charCount, s_Enemies.size(), s_DeadBodies.size(), s_LootBoxes.size(), s_Items.size(), localPlayer);
        }
    }

    const std::vector<EntityData>& GetEnemies() {
        return s_Enemies;
    }

    const std::vector<EntityData>& GetDeadBodies() {
        return s_DeadBodies;
    }

    const std::vector<EntityData>& GetItems() {
        return s_Items;
    }

    const std::vector<EntityData>& GetLootBoxes() {
        return s_LootBoxes;
    }
}
