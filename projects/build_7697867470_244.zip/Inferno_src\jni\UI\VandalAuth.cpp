#define IMGUI_DEFINE_MATH_OPERATORS
#include "VandalAuth.h"
#include "imgui.h"
#include "imgui_internal.h"
#include "vandal_icons.h"
#include "mirage_banner.h"
#include "stb_image.h"
#include "Config.h"
#include "Login.h"
#include "Core/UE4Helper.h"

#include <GLES3/gl3.h>
#include <GLES2/gl2.h>
#include <cmath>
#include <string>
#include <vector>
#include <thread>
#include <atomic>
#include <map>
#include <algorithm>

namespace VandalAuth {

enum class AuthState {
    STATE_INPUT,
    STATE_CHECKING,
    STATE_SUCCESS,
    STATE_ERROR
};

struct AuthManager {
    bool is_authenticated = false;
    AuthState state = AuthState::STATE_INPUT;

    char key_buffer[128] = "";
    bool auto_login = true;
    bool show_password = false;

    float progress = 0.f;
    float timer = 0.f;
    float alpha = 1.f;
    float spin_angle = 0.f;

    std::string status_text = "";
    std::string error_text = "";

    std::atomic<bool> thread_running{false};
    std::atomic<bool> auth_success{false};
    std::string async_err_msg = "";

    void StartAuth(bool is_ru) {
        if (key_buffer[0] == '\0') {
            state = AuthState::STATE_ERROR;
            error_text = is_ru ? "Введите ключ активации!" : "Please enter an activation key!";
            return;
        }
        if (thread_running.load()) return;

        state = AuthState::STATE_CHECKING;
        timer = 0.f;
        progress = 0.05f;
        status_text = is_ru ? "Подключение к серверу..." : "Connecting to server...";
        error_text = "";
        async_err_msg = "";

        thread_running = true;
        auth_success = false;

        std::string key_to_check(key_buffer);
        bool save_on_success = auto_login;
        std::thread([this, key_to_check, save_on_success]() {
            bool ok = Login::DoLogin(key_to_check);
            if (ok) {
                if (save_on_success) {
                    Login::SaveKey(key_to_check);
                }
                g_Config.is_logged_in = true;
                g_Config.login_expiry = Login::g_Expiry;
                UE4Helper::ApplyOffsetUnlock(Login::g_UnlockKey.load());
                auth_success = true;
            } else {
                auth_success = false;
                async_err_msg = Login::g_ErrMsg.empty() ? "Invalid license key!" : Login::g_ErrMsg;
            }
            thread_running = false;
        }).detach();
    }

    void Update(float dt, bool is_ru) {
        if (state == AuthState::STATE_CHECKING) {
            timer += dt;
            spin_angle += dt * 7.f;

            if (thread_running.load()) {
                float target_p = 0.95f;
                progress = ImLerp(progress, target_p, dt * 1.8f);
                if (progress < 0.08f + timer * 0.40f) {
                    progress = ImMin(0.08f + timer * 0.40f, 0.95f);
                }
                status_text = is_ru ? "Проверка лицензии..." : "Verifying license key...";
            } else {
                if (auth_success.load()) {
                    progress = ImLerp(progress, 1.0f, dt * 7.0f);
                    if (progress >= 0.985f) progress = 1.0f;
                    status_text = is_ru ? "Доступ разрешен! Загрузка..." : "Access Granted! Welcome";

                    if (progress >= 1.0f) {
                        state = AuthState::STATE_SUCCESS;
                        timer = 0.f;
                    }
                } else {
                    state = AuthState::STATE_ERROR;
                    error_text = async_err_msg.empty() ? (is_ru ? "Неверный ключ активации!" : "Invalid license key!") : async_err_msg;
                }
            }
        } else if (state == AuthState::STATE_SUCCESS) {
            timer += dt;
            alpha = ImClamp(ImLerp(alpha, 0.f, dt * 5.f), 0.f, 1.f);
            if (alpha < 0.02f) {
                is_authenticated = true;
            }
        }
    }
};

static AuthManager g_auth;

static GLuint s_BannerTex = 0;
static int    s_BannerW   = 0;
static int    s_BannerH   = 0;

static GLuint GetBannerTexture(int* out_w, int* out_h) {
    if (!s_BannerTex) {
        int w = 0, h = 0, channels = 0;
        unsigned char* pixels = stbi_load_from_memory(mirage_banner_data, (int)sizeof(mirage_banner_data), &w, &h, &channels, 4);
        if (pixels) {
            glGenTextures(1, &s_BannerTex);
            glBindTexture(GL_TEXTURE_2D, s_BannerTex);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
            glBindTexture(GL_TEXTURE_2D, 0);
            stbi_image_free(pixels);
            s_BannerW = w;
            s_BannerH = h;
        }
    }
    if (out_w) *out_w = s_BannerW;
    if (out_h) *out_h = s_BannerH;
    return s_BannerTex;
}

void InitFonts(ImGuiIO& io) {
    static const ImWchar icomoon_ranges[] = { 0xe000, 0xf8ff, 0 };
    ImFontConfig icomoon_config;
    icomoon_config.MergeMode = true;
    icomoon_config.PixelSnapH = true;
    icomoon_config.FontDataOwnedByAtlas = false;
    io.Fonts->AddFontFromMemoryCompressedBase85TTF(icomoon_compressed_data_base85, 24.0f, &icomoon_config, icomoon_ranges);
}

static inline ImColor ImLerpColor(const ImColor& a, const ImColor& b, float t) {
    t = ImClamp(t, 0.0f, 1.0f);
    float inv = 1.0f - t;
    return ImColor(
        a.Value.x * inv + b.Value.x * t,
        a.Value.y * inv + b.Value.y * t,
        a.Value.z * inv + b.Value.z * t,
        a.Value.w * inv + b.Value.w * t
    );
}

static inline void SetLinearColor(ImDrawList* draw_list, int vert_start_idx, int vert_end_idx,
                                  ImVec2 gradient_p0, ImVec2 gradient_p1, ImU32 col0, ImU32 col1, float angle = 0.f)
{
    ImVec2 gradient_extent = gradient_p1 - gradient_p0;
    float cos_angle = cosf(angle);
    float sin_angle = sinf(angle);
    float rotated_x = cos_angle * gradient_extent.x - sin_angle * gradient_extent.y;
    float rotated_y = sin_angle * gradient_extent.x + cos_angle * gradient_extent.y;
    ImVec2 rotated_p1 = gradient_p0 + ImVec2(rotated_x, rotated_y);

    float len2 = ImLengthSqr(rotated_p1 - gradient_p0);
    if (len2 <= 0.0001f) return;
    float gradient_inv_length2 = 1.0f / len2;

    ImDrawVert* vert_start = draw_list->VtxBuffer.Data + vert_start_idx;
    ImDrawVert* vert_end = draw_list->VtxBuffer.Data + vert_end_idx;
    const int col0_r = (int)(col0 >> IM_COL32_R_SHIFT) & 0xFF;
    const int col0_g = (int)(col0 >> IM_COL32_G_SHIFT) & 0xFF;
    const int col0_b = (int)(col0 >> IM_COL32_B_SHIFT) & 0xFF;
    const int col_delta_r = ((int)(col1 >> IM_COL32_R_SHIFT) & 0xFF) - col0_r;
    const int col_delta_g = ((int)(col1 >> IM_COL32_G_SHIFT) & 0xFF) - col0_g;
    const int col_delta_b = ((int)(col1 >> IM_COL32_B_SHIFT) & 0xFF) - col0_b;

    for (ImDrawVert* vert = vert_start; vert < vert_end; vert++) {
        float d = ImDot(vert->pos - gradient_p0, rotated_p1 - gradient_p0);
        float t = ImClamp(d * gradient_inv_length2, 0.0f, 1.0f);
        int r = (int)(col0_r + col_delta_r * t);
        int g = (int)(col0_g + col_delta_g * t);
        int b = (int)(col0_b + col_delta_b * t);
        vert->col = (r << IM_COL32_R_SHIFT) | (g << IM_COL32_G_SHIFT) | (b << IM_COL32_B_SHIFT) | (vert->col & IM_COL32_A_MASK);
    }
}

// Procedural vector icon drawing (crisp backup & complementary to font glyphs)
static void DrawVectorKey(ImDrawList* dl, ImVec2 center, ImU32 col, float sz) {
    float r = sz * 0.28f;
    ImVec2 head_c = center - ImVec2(sz * 0.22f, 0.f);
    dl->AddCircle(head_c, r, col, 16, 1.8f);
    dl->AddCircle(head_c, r * 0.40f, col, 12, 1.2f);
    ImVec2 shaft_start = head_c + ImVec2(r, 0.f);
    ImVec2 shaft_end = center + ImVec2(sz * 0.45f, 0.f);
    dl->AddLine(shaft_start, shaft_end, col, 2.0f);
    dl->AddLine(shaft_end - ImVec2(sz * 0.16f, 0.f), shaft_end - ImVec2(sz * 0.16f, -sz * 0.25f), col, 1.8f);
    dl->AddLine(shaft_end, shaft_end + ImVec2(0.f, sz * 0.32f), col, 1.8f);
}

static void DrawVectorEye(ImDrawList* dl, ImVec2 center, ImU32 col, float sz, bool open) {
    float hw = sz * 0.45f;
    float hh = sz * 0.26f;
    ImVec2 p_left(center.x - hw, center.y);
    ImVec2 p_right(center.x + hw, center.y);
    ImVec2 c_top(center.x, center.y - hh * 1.5f);
    ImVec2 c_bot(center.x, center.y + hh * 1.5f);

    dl->AddBezierQuadratic(p_left, c_top, p_right, col, 1.8f);
    dl->AddBezierQuadratic(p_left, c_bot, p_right, col, 1.8f);
    if (open) {
        dl->AddCircleFilled(center, hh * 0.65f, col);
    } else {
        dl->AddCircle(center, hh * 0.50f, col, 12, 1.4f);
        dl->AddLine(center - ImVec2(hw * 0.85f, hh * 1.1f), center + ImVec2(hw * 0.85f, hh * 1.1f), col, 1.8f);
    }
}

static void DrawVectorShield(ImDrawList* dl, ImVec2 center, ImU32 col, float sz) {
    float w = sz * 0.42f;
    float h = sz * 0.50f;
    ImVec2 pts[5] = {
        center + ImVec2(-w, -h * 0.7f),
        center + ImVec2(w, -h * 0.7f),
        center + ImVec2(w, h * 0.2f),
        center + ImVec2(0.f, h),
        center + ImVec2(-w, h * 0.2f)
    };
    dl->AddPolyline(pts, 5, col, ImDrawFlags_Closed, 1.8f);
    dl->AddLine(center + ImVec2(0.f, -h * 0.45f), center + ImVec2(0.f, h * 0.65f), col, 1.4f);
}

static void DrawVectorClose(ImDrawList* dl, ImVec2 center, ImU32 col, float sz) {
    float d = sz * 0.35f;
    dl->AddLine(center - ImVec2(d, d), center + ImVec2(d, d), col, 2.0f);
    dl->AddLine(center + ImVec2(-d, d), center + ImVec2(d, -d), col, 2.0f);
}

struct VandalBtnAnim {
    float hover = 0.f;
    float press = 0.f;
    float grad_alpha = 0.f;
};

static bool VandalButton(const char* label, const ImVec2& size_arg, float alpha) {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiID id = window->GetID(label);

    static std::map<ImGuiID, VandalBtnAnim> anims;
    auto& state = anims[id];

    const ImVec2 pos = window->DC.CursorPos;
    ImVec2 size = size_arg;
    if (size.x <= 0.0f) size.x = ImGui::GetContentRegionAvail().x;
    if (size.y <= 0.0f) size.y = 36.0f;

    const ImRect bb(pos, pos + size);
    ImGui::ItemSize(size, 0.f);
    if (!ImGui::ItemAdd(bb, id)) return false;

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);

    float dt = g.IO.DeltaTime;
    state.hover = ImLerp(state.hover, (hovered || held) ? 1.f : 0.f, dt * 14.f);
    state.press = ImLerp(state.press, held ? 1.f : 0.f, dt * 25.f);
    state.grad_alpha = ImLerp(state.grad_alpha, hovered ? 1.f : 0.f, dt * 10.f);

    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 center = bb.GetCenter();

    float scale = 1.f - state.press * 0.03f;
    ImVec2 anim_size = size * scale;
    ImVec2 box_min = center - anim_size * 0.5f;
    ImVec2 box_max = center + anim_size * 0.5f;

    // Background
    draw->AddRectFilled(box_min, box_max, ImGui::GetColorU32(ImVec4(0.05f, 0.06f, 0.10f, 0.85f * alpha)), 8.f);

    // Border
    ImVec4 b_norm(1.f, 1.f, 1.f, 0.12f * alpha);
    ImVec4 b_hov(0.92f, 0.95f, 1.0f, 0.80f * alpha);
    ImVec4 b_cur = ImLerp(b_norm, b_hov, state.hover);
    draw->AddRect(box_min, box_max, ImGui::GetColorU32(b_cur), 8.f, 0, 1.f);

    // Rotating animated gradient on hover (silver / chrome monochrome shimmer)
    if (state.grad_alpha > 0.01f) {
        int vtx_start = draw->VtxBuffer.Size;
        draw->AddRectFilled(box_min, box_max, IM_COL32_WHITE, 8.f);
        int vtx_end = draw->VtxBuffer.Size;

        float time = (float)ImGui::GetTime();
        float angle = time * 0.4f * (2.0f * IM_PI);
        SetLinearColor(draw, vtx_start, vtx_end, box_min, box_max,
                       IM_COL32(255, 255, 255, 255), IM_COL32(75, 80, 92, 255), angle);

        for (int v = vtx_start; v < vtx_end; v++) {
            ImU32& col = draw->VtxBuffer[v].col;
            int a = (col >> 24) & 0xFF;
            a = (int)(a * state.grad_alpha * 0.4f * alpha);
            col = (col & 0x00FFFFFF) | (a << 24);
        }
    }

    ImVec4 t_norm(0.70f, 0.74f, 0.82f, 0.90f * alpha);
    ImVec4 t_hov(1.0f, 1.0f, 1.0f, 1.0f * alpha);
    ImVec4 t_col = ImLerp(t_norm, t_hov, state.hover);

    ImVec2 text_size = ImGui::CalcTextSize(label);
    ImVec2 text_pos = center - text_size * 0.5f;
    draw->AddText(text_pos, ImGui::GetColorU32(t_col), label);

    return pressed;
}

static bool VandalCheckbox(const char* label, bool* v, float alpha) {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiID id = window->GetID(label);

    const float box = 22.0f;
    const float gap = 14.0f;
    const ImVec2 label_size = ImGui::CalcTextSize(label);
    const ImVec2 pos = window->DC.CursorPos;

    struct ChkAnim {
        float t = 0.f;
        float hover = 0.f;
    };
    static std::map<ImGuiID, ChkAnim> anims;
    auto& state = anims[id];

    const ImVec2 total_size(box + gap + label_size.x, box + 8.f);
    const ImRect total_bb(pos, pos + total_size);
    ImGui::ItemSize(total_bb, 0.0f);
    if (!ImGui::ItemAdd(total_bb, id)) return false;

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(total_bb, id, &hovered, &held);
    if (pressed) {
        *v = !(*v);
    }

    float dt = g.IO.DeltaTime;
    float time = (float)ImGui::GetTime();

    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 center(total_bb.Min.x + box * 0.5f + 2.f, total_bb.Min.y + total_size.y * 0.5f);
    float r = box * 0.5f;
    float rounding = 5.f;

    state.t = ImClamp(state.t + ((*v ? 1.f : 0.f) - state.t) * dt * 10.f, 0.f, 1.f);
    state.hover = ImLerp(state.hover, hovered ? 1.f : 0.f, dt * 14.f);

    float scale = 1.f + state.hover * 0.05f;
    float sr = r * scale;

    ImVec2 box_min(center.x - sr, center.y - sr);
    ImVec2 box_max(center.x + sr, center.y + sr);

    // Hover glow (silver chrome)
    if (state.hover > 0.01f && !*v) {
        draw->AddShadowRect(box_min - ImVec2(3, 3), box_max + ImVec2(3, 3),
            ImGui::GetColorU32(ImVec4(0.92f, 0.95f, 1.0f, state.hover * 0.20f * alpha)),
            8.f, ImVec2(0, 0), ImDrawFlags_RoundCornersAll, rounding);
    }

    // Box base
    draw->AddRectFilled(box_min, box_max, ImGui::GetColorU32(ImVec4(0.07f, 0.09f, 0.13f, 0.85f * alpha)), rounding);
    draw->AddRect(box_min, box_max, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.14f * alpha)), rounding, 0, 1.f);

    // Checked fill & glow (silver chrome)
    if (state.t > 0.01f) {
        int vtx_start = draw->VtxBuffer.Size;
        draw->AddRectFilled(box_min, box_max, IM_COL32_WHITE, rounding);
        int vtx_end = draw->VtxBuffer.Size;

        float angle = time * 0.4f * (2.0f * IM_PI);
        SetLinearColor(draw, vtx_start, vtx_end, box_min, box_max,
                       IM_COL32(240, 242, 250, 255), IM_COL32(55, 60, 72, 255), angle);

        for (int vi = vtx_start; vi < vtx_end; vi++) {
            ImU32& col = draw->VtxBuffer[vi].col;
            int a = (col >> 24) & 0xFF;
            a = (int)(a * state.t * alpha);
            col = (col & 0x00FFFFFF) | (a << 24);
        }

        float glow = sinf(time * 2.5f) * 0.05f + 0.12f;
        draw->AddShadowRect(box_min - ImVec2(2, 2), box_max + ImVec2(2, 2),
            ImGui::GetColorU32(ImVec4(0.95f, 0.97f, 1.0f, glow * state.t * alpha)),
            8.f, ImVec2(0, 0), ImDrawFlags_RoundCornersAll, rounding);
    }

    // Checkmark mark line (crisp silver white)
    if (state.t > 0.01f) {
        float p_val = ImClamp(state.t, 0.f, 1.f);
        float cr = sr * 0.4f;

        float cx1 = center.x - cr * 0.55f;
        float cy1 = center.y + cr * 0.05f;
        float cx2 = center.x - cr * 0.05f;
        float cy2 = center.y + cr * 0.5f;
        float cx3 = center.x + cr * 0.65f;
        float cy3 = center.y - cr * 0.4f;

        float dx1 = cx1 + (center.x - cx1) * (1.f - p_val);
        float dy1 = cy1 + (center.y - cy1) * (1.f - p_val);

        ImVec2 da(dx1, dy1);
        ImVec2 db(cx2, cy2);
        ImVec2 dc(cx2 + (cx3 - cx2) * p_val, cy2 + (cy3 - cy2) * p_val);

        ImU32 cc = IM_COL32(255, 255, 255, (int)(p_val * 255.f * alpha));
        draw->AddLine(da, db, cc, 2.5f);
        draw->AddLine(db, dc, cc, 2.5f);
    }

    // Label
    float text_x = total_bb.Min.x + box + gap;
    float text_y = center.y - label_size.y * 0.5f;
    ImVec4 t_col = hovered ? ImVec4(1.f, 1.f, 1.f, 0.95f * alpha) : ImVec4(0.65f, 0.70f, 0.80f, 0.85f * alpha);
    draw->AddText(ImVec2(text_x, text_y), ImGui::GetColorU32(t_col), label);

    return pressed;
}

static bool VandalAuthKeyInput(const char* label, char* buf, size_t buf_size, const ImVec2& sz, bool* show_pass, float alpha, bool is_ru) {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    ImGuiID id = window->GetID(label);
    ImVec2 pos = window->DC.CursorPos;
    ImRect bb(pos, pos + sz);

    ImGui::ItemSize(sz);
    if (!ImGui::ItemAdd(bb, id)) return false;

    bool hovered = ImGui::ItemHoverable(bb, id, g.LastItemData.InFlags);
    bool focused = ImGui::IsItemActive();

    struct InAnim { float f = 0.f; };
    static std::map<ImGuiID, InAnim> anims;
    auto& sa = anims[id];
    sa.f = ImLerp(sa.f, (focused || hovered || buf[0] != '\0') ? 1.f : 0.f, g.IO.DeltaTime * 12.f);

    ImDrawList* dl = window->DrawList;

    // Dark Frosted Glass Input Box
    dl->AddRectFilled(bb.Min, bb.Max, ImGui::GetColorU32(ImVec4(0.02f, 0.025f, 0.04f, 0.85f * alpha)), 8.f);
    ImVec4 border_col = ImLerp(ImVec4(1.f, 1.f, 1.f, 0.12f * alpha), ImVec4(0.92f, 0.95f, 1.0f, 0.85f * alpha), sa.f);
    dl->AddRect(bb.Min, bb.Max, ImGui::GetColorU32(border_col), 8.f, 0, 1.2f);

    // Left Key Icon (silver monochrome)
    ImVec2 key_center = bb.Min + ImVec2(24.f, sz.y * 0.5f);
    ImU32 key_col = ImGui::GetColorU32(ImLerp(ImVec4(0.50f, 0.55f, 0.65f, 0.8f * alpha), ImVec4(1.0f, 1.0f, 1.0f, 1.0f * alpha), sa.f));
    const ImFontGlyph* key_glyph = ImGui::GetFont()->FindGlyph((ImWchar)0xeed5);
    if (key_glyph) {
        dl->AddText(bb.Min + ImVec2(14.f, (sz.y - ImGui::CalcTextSize(ICON_KEY_FILL).y) * 0.5f), key_col, ICON_KEY_FILL);
    } else {
        DrawVectorKey(dl, key_center, key_col, 20.f);
    }

    float eye_w = 40.f;
    float left_pad = 46.f;
    float right_pad = eye_w + 6.f;

    // Show/Hide Password Toggle Eye Icon
    ImRect eye_bb(ImVec2(bb.Max.x - eye_w, bb.Min.y + 4.f), ImVec2(bb.Max.x - 4.f, bb.Max.y - 4.f));
    bool eye_hov = eye_bb.Contains(ImGui::GetMousePos());
    if (eye_hov && ImGui::IsMouseClicked(0)) {
        *show_pass = !(*show_pass);
    }
    ImVec2 eye_center = eye_bb.GetCenter();
    ImU32 eye_col = ImGui::GetColorU32(eye_hov ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f * alpha) : ImVec4(0.65f, 0.70f, 0.78f, 0.85f * alpha));
    const ImFontGlyph* eye_glyph = ImGui::GetFont()->FindGlyph((ImWchar)0xeced);
    if (eye_glyph) {
        const char* eye_icon = *show_pass ? ICON_EYE_FILL : ICON_EYE_OFF_FILL;
        ImVec2 eye_sz = ImGui::CalcTextSize(eye_icon);
        dl->AddText(eye_bb.Min + (eye_bb.GetSize() - eye_sz) * 0.5f, eye_col, eye_icon);
    } else {
        DrawVectorEye(dl, eye_center, eye_col, 22.f, *show_pass);
    }

    // Direct Text Drawing on DrawList
    if (buf[0] != '\0') {
        std::string display_str = (*show_pass) ? std::string(buf) : std::string(strlen(buf), '*');
        ImVec2 text_pos = bb.Min + ImVec2(left_pad, (sz.y - ImGui::GetTextLineHeight()) * 0.5f);
        dl->AddText(text_pos, ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 1.0f * alpha)), display_str.c_str());
    } else {
        const char* hint = is_ru ? "Введите ключ активации..." : "Enter activation key...";
        ImVec2 text_pos = bb.Min + ImVec2(left_pad, (sz.y - ImGui::GetTextLineHeight()) * 0.5f);
        dl->AddText(text_pos, ImGui::GetColorU32(ImVec4(0.50f, 0.55f, 0.65f, 0.65f * alpha)), hint);
    }

    // Tap anywhere on the input box to auto-paste from clipboard if empty (never start auth on click)
    bool box_clicked = hovered && ImGui::IsMouseClicked(0) && !eye_hov;
    if (box_clicked && buf[0] == '\0') {
        std::string clip = Login::GetClipboardText();
        if (!clip.empty()) {
            strncpy(buf, clip.c_str(), buf_size - 1);
            buf[buf_size - 1] = '\0';
            strncpy(g_auth.key_buffer, clip.c_str(), sizeof(g_auth.key_buffer) - 1);
            g_auth.key_buffer[sizeof(g_auth.key_buffer) - 1] = '\0';
        }
    }

    return false;
}

void Render(int screenWidth, int screenHeight) {
    if (g_auth.is_authenticated) {
        return;
    }

    float dt = ImGui::GetIO().DeltaTime;
    bool is_ru = g_Config.russian_language;
    g_auth.Update(dt, is_ru);

    if (g_auth.alpha <= 0.001f) return;

    // Load saved key on first render if empty
    static bool s_InitKey = false;
    if (!s_InitKey) {
        s_InitKey = true;
        std::string saved = Login::LoadKey();
        if (!saved.empty() && g_auth.key_buffer[0] == '\0') {
            strncpy(g_auth.key_buffer, saved.c_str(), sizeof(g_auth.key_buffer) - 1);
            g_auth.key_buffer[sizeof(g_auth.key_buffer) - 1] = '\0';
        }
    }

    // Auto-fill clipboard key if still empty
    if (g_auth.key_buffer[0] == '\0') {
        static float clip_poll_timer = 0.f;
        clip_poll_timer += dt;
        if (clip_poll_timer >= 0.4f) {
            clip_poll_timer = 0.f;
            std::string auto_clip = Login::GetClipboardText();
            if (!auto_clip.empty() && auto_clip.length() >= 4) {
                strncpy(g_auth.key_buffer, auto_clip.c_str(), sizeof(g_auth.key_buffer) - 1);
                g_auth.key_buffer[sizeof(g_auth.key_buffer) - 1] = '\0';
            }
        }
    }

    ImVec2 screen_sz = ImGui::GetIO().DisplaySize;
    if (screen_sz.x < 100.f || screen_sz.y < 100.f) {
        screen_sz = ImVec2((float)screenWidth, (float)screenHeight);
    }

    // Modal size: VANDAL MOD expanded with wider banner frame (980x580)
    ImVec2 modal_sz(980.f, 580.f);
    float left_w = 410.f;
    static ImVec2 s_ModalPos(-1.0f, -1.0f);
    static bool   s_DraggingAuth = false;
    static ImVec2 s_DragOffset(0.0f, 0.0f);

    if (s_ModalPos.x < 0.0f || s_ModalPos.y < 0.0f) {
        s_ModalPos = ImVec2((screen_sz.x - modal_sz.x) * 0.5f, (screen_sz.y - modal_sz.y) * 0.5f);
    }

    // Process drag BEFORE SetNextWindowPos and Begin to avoid any clip rect lag or wall drifting
    if (ImGui::IsMouseClicked(0)) {
        ImVec2 mp = ImGui::GetIO().MouseClickedPos[0];
        ImRect banner_rect(s_ModalPos, s_ModalPos + ImVec2(left_w, modal_sz.y));
        ImRect header_rect(s_ModalPos + ImVec2(left_w, 0.f), s_ModalPos + ImVec2(modal_sz.x - 70.f, 65.f));
        if (banner_rect.Contains(mp) || header_rect.Contains(mp)) {
            s_DraggingAuth = true;
            s_DragOffset = mp - s_ModalPos;
        }
    }

    if (s_DraggingAuth) {
        if (ImGui::IsMouseDown(0)) {
            s_ModalPos = ImGui::GetIO().MousePos - s_DragOffset;
            s_ModalPos.x = std::clamp(s_ModalPos.x, 0.0f, std::max(0.0f, screen_sz.x - modal_sz.x));
            s_ModalPos.y = std::clamp(s_ModalPos.y, 0.0f, std::max(0.0f, screen_sz.y - modal_sz.y));
        } else {
            s_DraggingAuth = false;
        }
    }

    ImGui::SetNextWindowPos(s_ModalPos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(modal_sz, ImGuiCond_Always);

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
                             ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings |
                             ImGuiWindowFlags_NoBackground;

    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, g_auth.alpha);
    if (ImGui::Begin("##VANDAL_AUTH_MODAL", nullptr, flags)) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetWindowPos();

        // 1. Deep solid black card body with crisp silver border (zero blur bleeding)
        dl->AddRectFilled(p, p + modal_sz, ImGui::GetColorU32(ImVec4(0.010f, 0.012f, 0.018f, 1.0f)), 18.f);
        dl->AddRect(p, p + modal_sz, ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.12f * g_auth.alpha)), 18.f, 0, 1.2f);

        // =========================================================
        // LEFT BRAND & IMAGE PANEL (~410px Width - Full Artwork Frame)
        // =========================================================
        ImVec2 left_min = p;
        ImVec2 left_max = p + ImVec2(left_w, modal_sz.y);

        int img_w = 0, img_h = 0;
        GLuint banner_tex = GetBannerTexture(&img_w, &img_h);

        if (banner_tex) {
            // Dark backing
            dl->AddRectFilled(left_min, left_max, ImGui::GetColorU32(ImVec4(0.01f, 0.012f, 0.022f, 0.75f * g_auth.alpha)), 18.f, ImDrawFlags_RoundCornersLeft);

            // Compute exact UV coordinates - preserve full width & top text (zero MIRAGE crop)
            ImVec2 uv0(0.f, 0.f);
            ImVec2 uv1(1.f, 1.f);

            if (img_w > 0 && img_h > 0) {
                float img_ratio = (float)img_w / (float)img_h;
                float card_ratio = left_w / modal_sz.y;

                if (img_ratio > card_ratio) {
                    float s = card_ratio / img_ratio;
                    float crop_u = (1.f - s) * 0.5f;
                    uv0 = ImVec2(crop_u, 0.f);
                    uv1 = ImVec2(1.f - crop_u, 1.f);
                } else {
                    float s = img_ratio / card_ratio;
                    float crop_v = (1.f - s);
                    // Keep top 100% visible so top MIRAGE lettering is never cropped vertically
                    uv0 = ImVec2(0.f, 0.f);
                    uv1 = ImVec2(1.f, 1.f - crop_v);
                }
            }

            // Render Login Artwork with crisp, fully visible aspect ratio
            dl->AddImageRounded((ImTextureID)(intptr_t)banner_tex, left_min + ImVec2(1.f, 1.f), left_max - ImVec2(1.f, 1.f),
                uv0, uv1, ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.92f * g_auth.alpha)), 17.f, ImDrawFlags_RoundCornersLeft);

            // Subtle vertical separation divider
            dl->AddLine(ImVec2(left_max.x, left_min.y + 12.f), ImVec2(left_max.x, left_max.y - 12.f), ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.08f * g_auth.alpha)), 1.0f);
        } else {
            // Darker translucent fill for left side
            dl->AddRectFilled(left_min, left_max, ImGui::GetColorU32(ImVec4(0.01f, 0.012f, 0.022f, 0.75f * g_auth.alpha)), 18.f, ImDrawFlags_RoundCornersLeft);

            ImVec2 emblem_center = left_min + ImVec2(left_w * 0.5f, modal_sz.y * 0.38f);

            static float orbit_angle = 0.f;
            orbit_angle += dt * 2.f;
            dl->AddCircle(emblem_center, 52.f, ImGui::GetColorU32(ImVec4(0.80f, 0.85f, 0.92f, 0.35f * g_auth.alpha)), 36, 1.5f);

            static float pulse = 0.f;
            pulse += dt * 3.f;
            float p_val = (sinf(pulse) + 1.f) * 0.5f;
            dl->AddCircleFilled(emblem_center, 44.f + 2.f * p_val, ImGui::GetColorU32(ImVec4(0.92f, 0.95f, 1.0f, (0.08f + 0.06f * p_val) * g_auth.alpha)));
            dl->AddCircleFilled(emblem_center, 38.f, ImGui::GetColorU32(ImVec4(0.04f, 0.05f, 0.07f, 0.90f * g_auth.alpha)));
            dl->AddCircle(emblem_center, 38.f, ImGui::GetColorU32(ImVec4(0.92f, 0.95f, 1.0f, 0.85f * g_auth.alpha)), 36, 1.5f);

            // Shield Icon inside center (silver chrome)
            const ImFontGlyph* shield_glyph = ImGui::GetFont()->FindGlyph((ImWchar)0xefa9);
            if (shield_glyph) {
                ImVec2 ic_sz = ImGui::CalcTextSize(ICON_SHIELD_FILL);
                dl->AddText(emblem_center - ic_sz * 0.5f, ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.95f * g_auth.alpha)), ICON_SHIELD_FILL);
            } else {
                DrawVectorShield(dl, emblem_center, ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.95f * g_auth.alpha)), 24.f);
            }

            ImVec2 t_sz = ImGui::CalcTextSize("MIRAGE");
            dl->AddText(emblem_center + ImVec2(-t_sz.x * 0.5f, 56.f), ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.95f * g_auth.alpha)), "MIRAGE");

            ImVec2 sub_sz = ImGui::CalcTextSize("CLIENT v3.0");
            dl->AddText(emblem_center + ImVec2(-sub_sz.x * 0.5f, 86.f), ImGui::GetColorU32(ImVec4(0.85f, 0.88f, 0.95f, 0.85f * g_auth.alpha)), "CLIENT v3.0");
        }

        // =========================================================
        // RIGHT FORM PANEL (~500px Width)
        // =========================================================
        float right_x = left_w + 35.f;
        float right_w = modal_sz.x - right_x - 35.f;

        // Top-Right Header (Language Switch RU / EN, no cross icon)
        ImGui::SetCursorPos(ImVec2(modal_sz.x - 58.f, 22.f));
        if (VandalButton(is_ru ? "RU" : "EN", ImVec2(38, 30), g_auth.alpha)) {
            g_Config.russian_language = !g_Config.russian_language;
        }

        // Form Title: M I R A G E (Liquid Silver / Chrome wave gradient letter-by-letter)
        const char title_str[] = "M I R A G E";
        const int t_len = (int)strlen(title_str);
        float spacing = 3.2f;

        float letter_widths[32];
        float total_w = 0.f;
        for (int i = 0; i < t_len; i++) {
            char tmp[2] = { title_str[i], 0 };
            letter_widths[i] = ImGui::CalcTextSize(tmp).x;
            total_w += letter_widths[i] + (i < t_len - 1 ? spacing : 0.f);
        }
        float font_h = ImGui::CalcTextSize("M").y;
        float start_x = right_x;
        float base_y = 26.f;
        float cursor_x = start_x;

        for (int i = 0; i < t_len; i++) {
            char tmp[2] = { title_str[i], 0 };
            if (title_str[i] != ' ') {
                ImVec2 lp(p.x + cursor_x, p.y + base_y);
                dl->AddText(ImVec2(lp.x + 1.5f, lp.y + 1.5f), ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, 0.90f * g_auth.alpha)), tmp);
                float t = (float)i / (float)(t_len - 1);
                float wave_t = (sinf((float)ImGui::GetTime() * 2.8f + t * 3.14159f) + 1.0f) * 0.5f;
                float chrome_t = powf(wave_t, 1.35f);
                ImColor lc = ImLerpColor(ImColor(105, 114, 128, 255), ImColor(255, 255, 255, 255), chrome_t);
                lc.Value.w *= g_auth.alpha;
                dl->AddText(lp, ImGui::GetColorU32(lc), tmp);
            }
            cursor_x += letter_widths[i] + spacing;
        }

        dl->AddText(p + ImVec2(right_x, base_y + font_h + 8.f), ImGui::GetColorU32(ImVec4(0.6f, 0.65f, 0.75f, 0.80f * g_auth.alpha)),
            is_ru ? "Введите ваш ключ активации" : "Enter your activation key below");

        float form_y = base_y + font_h + 46.f;

        if (g_auth.state == AuthState::STATE_INPUT || g_auth.state == AuthState::STATE_ERROR) {
            ImGui::SetCursorPos(ImVec2(right_x, form_y));
            VandalAuthKeyInput("auth_key_in", g_auth.key_buffer, sizeof(g_auth.key_buffer), ImVec2(right_w, 54.f), &g_auth.show_password, g_auth.alpha, is_ru);

            if (g_auth.state == AuthState::STATE_ERROR && !g_auth.error_text.empty()) {
                ImVec2 err_p = p + ImVec2(right_x, form_y + 68.f);
                ImVec2 err_sz(right_w, 36.f);
                dl->AddRectFilled(err_p, err_p + err_sz, ImGui::GetColorU32(ImVec4(0.85f, 0.15f, 0.2f, 0.20f * g_auth.alpha)), 8.f);
                dl->AddRect(err_p, err_p + err_sz, ImGui::GetColorU32(ImVec4(1.f, 0.25f, 0.3f, 0.45f * g_auth.alpha)), 8.f);
                dl->AddText(err_p + ImVec2(14.f, 8.f), ImGui::GetColorU32(ImVec4(1.f, 0.45f, 0.5f, 0.95f * g_auth.alpha)), g_auth.error_text.c_str());
            }

            float opt_y = form_y + (g_auth.state == AuthState::STATE_ERROR ? 116.f : 76.f);
            ImGui::SetCursorPos(ImVec2(right_x, opt_y));
            VandalCheckbox(is_ru ? "Автовход при запуске" : "Auto-login on startup", &g_auth.auto_login, g_auth.alpha);

            float paste_w = is_ru ? 195.f : 156.f;
            ImGui::SetCursorPos(ImVec2(right_x + right_w - paste_w, opt_y - 4.f));
            if (VandalButton(is_ru ? "ВСТАВИТЬ КЛЮЧ" : "PASTE KEY", ImVec2(paste_w, 36.f), g_auth.alpha)) {
                std::string clip = Login::GetClipboardText();
                if (!clip.empty()) {
                    strncpy(g_auth.key_buffer, clip.c_str(), sizeof(g_auth.key_buffer) - 1);
                    g_auth.key_buffer[sizeof(g_auth.key_buffer) - 1] = '\0';
                    g_auth.error_text.clear();
                    if (g_auth.state == AuthState::STATE_ERROR) g_auth.state = AuthState::STATE_INPUT;
                }
            }

            float btn_y = modal_sz.y - 84.f;
            ImGui::SetCursorPos(ImVec2(right_x, btn_y));
            if (VandalButton(is_ru ? "АКТИВИРОВАТЬ И ВОЙТИ" : "ACTIVATE & LOGIN", ImVec2(right_w, 56.f), g_auth.alpha)) {
                g_auth.StartAuth(is_ru);
            }
        } else if (g_auth.state == AuthState::STATE_CHECKING || g_auth.state == AuthState::STATE_SUCCESS) {
            // =========================================================
            // ULTRA-SMOOTH CHASING DOTS WITH CENTER PERCENTAGE (SILVER CHROME)
            // =========================================================
            ImVec2 sp_c = p + ImVec2(right_x + right_w * 0.5f, form_y + 130.f);
            float rad = 52.f;
            int num_dots = 16;

            float cur_t = (float)ImGui::GetTime();
            float rot_phase = fmodf(cur_t * 0.55f, 1.0f);
            float head_idx = rot_phase * (float)num_dots;

            for (int i = 0; i < num_dots; i++) {
                float d = (float)i - head_idx;
                while (d < -(float)num_dots * 0.5f) d += (float)num_dots;
                while (d > (float)num_dots * 0.5f)  d -= (float)num_dots;

                float brightness = 0.f;
                if (d >= 0.f && d <= 1.8f) {
                    float u = d / 1.8f;
                    brightness = 0.5f * (1.0f + cosf(u * IM_PI));
                } else if (d < 0.f && d >= -3.5f) {
                    float v = -d / 3.5f;
                    float cos_val = 0.5f * (1.0f + cosf(v * IM_PI));
                    brightness = powf(cos_val, 1.6f);
                }

                if (brightness <= 0.01f) continue;

                float angle = -IM_PI * 0.5f + (float)i * (2.0f * IM_PI / (float)num_dots);
                ImVec2 dot_pos = sp_c + ImVec2(cosf(angle), sinf(angle)) * rad;
                float dot_r = 2.4f + 1.4f * brightness;

                ImVec4 col = ImLerp(ImVec4(0.52f, 0.56f, 0.64f, 1.0f), ImVec4(1.f, 1.f, 1.f, 1.f), brightness * 0.75f);
                col.w = brightness * g_auth.alpha;

                dl->AddCircleFilled(dot_pos, dot_r, ImGui::GetColorU32(col), 20);
            }

            // Center percentage
            float progress_clamped = ImClamp(g_auth.progress, 0.0f, 1.0f);
            char pct_str[16];
            snprintf(pct_str, sizeof(pct_str), "%d%%", (int)(progress_clamped * 100.f));
            ImVec2 pct_sz = ImGui::CalcTextSize(pct_str);
            dl->AddText(sp_c + ImVec2(-pct_sz.x * 0.5f, -pct_sz.y * 0.5f),
                ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, 0.98f * g_auth.alpha)), pct_str);

            // Minimalist Status Message with Pulsing Dot underneath (Silver Chrome)
            float dot_pulse = (sinf(cur_t * 5.f) + 1.f) * 0.5f;
            ImVec2 st_sz = ImGui::CalcTextSize(g_auth.status_text.c_str());
            float dot_offset_x = (st_sz.x + 20.f) * 0.5f;
            ImVec2 dot_c = sp_c + ImVec2(-dot_offset_x + 4.f, rad + 36.f + st_sz.y * 0.5f);

            dl->AddCircleFilled(dot_c, 3.8f + 1.4f * dot_pulse, ImGui::GetColorU32(ImVec4(0.92f, 0.95f, 1.0f, (0.25f + 0.50f * dot_pulse) * g_auth.alpha)));
            dl->AddCircleFilled(dot_c, 2.8f, ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 0.95f * g_auth.alpha)));

            dl->AddText(sp_c + ImVec2(-dot_offset_x + 18.f, rad + 36.f),
                ImGui::GetColorU32(ImVec4(0.85f, 0.88f, 0.95f, 0.92f * g_auth.alpha)), g_auth.status_text.c_str());
        }
    }
    ImGui::End();
    ImGui::PopStyleVar();
}

bool IsDone() {
    return g_auth.is_authenticated;
}

} // namespace VandalAuth
