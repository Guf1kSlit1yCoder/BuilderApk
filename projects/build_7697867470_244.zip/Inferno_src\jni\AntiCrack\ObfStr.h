#pragma once
// ──────────────────────────────────────────────────────────────────────────────
//  OBFSTR — compile-time XOR string obfuscation (single entry point).
//
//  OBFSTR("x") yields a const char* that is decrypted at runtime into a local
//  buffer, so the plaintext never sits in .rodata. Backed by the project's
//  ADVobfuscator (OBFUSCATE). Use it for every sensitive literal: server URL,
//  license/error messages, file paths, library names, JNI field names.
// ──────────────────────────────────────────────────────────────────────────────
#include "SDK/obfuscate.h"

#ifndef OBFSTR
#define OBFSTR(s) OBFUSCATE(s)
#endif
