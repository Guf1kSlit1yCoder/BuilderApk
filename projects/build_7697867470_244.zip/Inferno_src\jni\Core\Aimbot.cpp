#include "Aimbot.h"
#include "ESP.h"
#include "ActorPipeline.h"
#include "UI/Menu.h"
#include "UI/TouchHelper.h"
#include "CrashLog.h"
#include "../Login.h"
#include <cmath>
#include <algorithm>
#include <chrono>

namespace Aimbot {
    SDK::ASGCharacter* g_TargetPlayer = nullptr;

    // Bone priority array: Head is top priority, followed by torso and limbs.
    // Index corresponds to VisCheck bit position (matching kBones order in ActorPipeline/ESP).
    struct AimBonePrio {
        int index;
        const char* name;
    };

    static const AimBonePrio kAimBonePriority[] = {
        { 0,  "Head" },        // 1. Голова (Head) - ТОП ПРИОРИТЕТ
        { 1,  "neck_01" },     // 2. Шея (Neck)
        { 2,  "spine_03" },    // 3. Грудь / Верх торса (Chest)
        { 3,  "pelvis" },      // 4. Таз / Живот (Pelvis)
        { 7,  "upperarm_r" },  // 5. Правое плечо
        { 4,  "upperarm_l" },  // 6. Левое плечо
        { 8,  "lowerarm_r" },  // 7. Правое предплечье
        { 5,  "lowerarm_l" },  // 8. Левое предплечье
        { 9,  "hand_r" },      // 9. Правая кисть
        { 6,  "hand_l" },      // 10. Левая кисть
        { 13, "thigh_r" },     // 11. Правое бедро
        { 10, "thigh_l" },     // 12. Левое бедро
        { 14, "calf_r" },      // 13. Правая голень
        { 11, "calf_l" },      // 14. Левая голень
        { 15, "foot_r" },      // 15. Правая ступня
        { 12, "foot_l" }       // 16. Левая ступня
    };
    static const int kAimBoneCount = sizeof(kAimBonePriority) / sizeof(kAimBonePriority[0]);

    SDK::FVector GetTargetAimLocation(SDK::ASGCharacter* target) {
        if (!ActorPipeline::IsObjectValid(target)) return {0,0,0};

        // Auto bones is active if aimbot_bone == 0 (Auto option in Combo)
        const bool autoBones = (g_Config.aimbot_bone == 0);

        if (autoBones) {
            uint16_t boneVis = 0;
            bool boneVisLive = false;
            // Check ActorPipeline enemies for up-to-date raycast & visibility
            for (const auto& ed : ActorPipeline::GetEnemies()) {
                if (ed.character == target) {
                    boneVis = ed.boneVisible;
                    boneVisLive = ed.boneVisLive;
                    break;
                }
            }
            if (boneVis == 0) {
                // Also check ESP enemy cache
                for (const auto& e : ESP::g_Enemies) {
                    if (e.actor == target) {
                        boneVis = e.boneVisible;
                        boneVisLive = e.boneVisLive;
                        break;
                    }
                }
            }

            // 1. Ray-traced open bones check:
            // Iterate in priority order (Head is top priority!):
            if (boneVis != 0) {
                for (int i = 0; i < kAimBoneCount; ++i) {
                    const auto& bp = kAimBonePriority[i];
                    if (boneVis & (1u << bp.index)) {
                        SDK::FVector pos = target->GetBonePos(bp.name);
                        if (pos.SizeSquared() > 0.001f) {
                            return pos;
                        }
                    }
                }
            }

            // 2. Fallback for Auto Bones: iterate bone priority starting from Head (0) -> Neck (1) -> Chest (2) -> Pelvis (3)
            for (int i = 0; i < kAimBoneCount; ++i) {
                const auto& bp = kAimBonePriority[i];
                SDK::FVector pos = target->GetBonePos(bp.name);
                if (pos.SizeSquared() > 0.001f) {
                    return pos;
                }
            }
        }

        // Fixed bone selection:
        // Combo mapping: 0: Auto, 1: Head, 2: Neck, 3: Chest, 4: Pelvis
        const char* boneName = "Head";
        if (g_Config.aimbot_bone == 2) boneName = "neck_01";
        else if (g_Config.aimbot_bone == 3) boneName = "spine_03";
        else if (g_Config.aimbot_bone == 4) boneName = "pelvis";

        SDK::FVector bonePos = target->GetBonePos(boneName);
        if (bonePos.SizeSquared() < 0.001f) {
            for (const auto& ed : ActorPipeline::GetEnemies()) {
                if (ed.character == target && ed.rootPos.SizeSquared() > 0.001f) {
                    bonePos = ed.rootPos;
                    bonePos.Z += 60.0f;
                    break;
                }
            }
            if (bonePos.SizeSquared() < 0.001f && target->RootComponent && Tools::IsPtrValid(target->RootComponent)) {
                bonePos = target->RootComponent->K2_GetComponentLocation();
                bonePos.Z += 60.0f;
            }
        }
        return bonePos;
    }

    SDK::FRotator CalculateAimRotation(const SDK::FVector& start, const SDK::FVector& target) {
        SDK::FVector diff{target.X - start.X, target.Y - start.Y, target.Z - start.Z};
        float distance2D = std::sqrt(diff.X * diff.X + diff.Y * diff.Y);
        
        float pitch = std::atan2(diff.Z, distance2D) * (180.0f / CONST_PI);
        float yaw = std::atan2(diff.Y, diff.X) * (180.0f / CONST_PI);
        
        return SDK::FRotator{pitch, yaw, 0.0f};
    }

    SDK::ASGCharacter* FindBestTarget(int screenWidth, int screenHeight) {
        if (!g_Config.aimbot_enabled) return nullptr;

        const SDK::FVector2D screenCenter{screenWidth / 2.0f, screenHeight / 2.0f};
        SDK::ASGCharacter* bestActor = nullptr;
        float bestMetric = 999999.0f;

        // Hard FOV clamp: even when visual FOV circle is toggled off, clamp targeting to a sensible cone
        // so enemies 90 degrees to the side or behind never snatch the camera.
        const float maxAllowedRadius = g_Config.aimbot_fov
            ? g_Config.aimbot_fov_radius
            : std::min((float)screenWidth, (float)screenHeight) * 0.35f;

        for (const auto& enemy : ESP::g_Enemies) {
            if (!enemy.actor || !Tools::IsPtrValid(enemy.actor)) continue;
            if (enemy.isTeammate) continue;
            if (g_Config.aimbot_ignore_knocked && enemy.isKnocked) continue;
            if (g_Config.aimbot_ignore_bots && enemy.isBot) continue;
            if (g_Config.aimbot_visible_only && !enemy.isVisible) continue;
            if (enemy.distance < 0.0f) continue;
            if (!enemy.onScreen) continue;

            float distToCrosshair = 99999.0f;

            // 1. Check if screen center is directly inside the enemy's 2D bounding box
            const bool insideBox = (enemy.boxWidth > 0.0f && enemy.boxHeight > 0.0f &&
                                    screenCenter.X >= enemy.boxLeft &&
                                    screenCenter.X <= enemy.boxLeft + enemy.boxWidth &&
                                    screenCenter.Y >= enemy.boxTop &&
                                    screenCenter.Y <= enemy.boxTop + enemy.boxHeight);

            if (insideBox) {
                distToCrosshair = 0.0f;
            } else {
                if (enemy.boxWidth > 0.0f && enemy.boxHeight > 0.0f) {
                    const float dx = std::max({enemy.boxLeft - screenCenter.X, 0.0f, screenCenter.X - (enemy.boxLeft + enemy.boxWidth)});
                    const float dy = std::max({enemy.boxTop - screenCenter.Y, 0.0f, screenCenter.Y - (enemy.boxTop + enemy.boxHeight)});
                    distToCrosshair = std::sqrt(dx * dx + dy * dy);
                }

                if (enemy.headScreen.X != 0.0f || enemy.headScreen.Y != 0.0f) {
                    distToCrosshair = std::min(distToCrosshair, enemy.headScreen.Distance(screenCenter));
                }
                if (enemy.rootScreen.X != 0.0f || enemy.rootScreen.Y != 0.0f) {
                    distToCrosshair = std::min(distToCrosshair, enemy.rootScreen.Distance(screenCenter));
                }
            }

            // Must be within effective FOV radius
            if (distToCrosshair > maxAllowedRadius) {
                continue;
            }

            // Selection metric:
            // 0: Distance (Closest enemy in meters, weighted towards crosshair direction)
            // 1: Crosshair (Closest to crosshair on screen)
            float metric = 0.0f;
            if (g_Config.aimbot_priority == 0) {
                const float fovNormalized = distToCrosshair / maxAllowedRadius; // 0.0 to 1.0
                const float anglePenalty = 1.0f + (fovNormalized * fovNormalized) * 3.0f;
                metric = enemy.distance * anglePenalty;
            } else {
                metric = distToCrosshair;
            }

            if (metric < bestMetric) {
                bestMetric = metric;
                bestActor = enemy.actor;
            }
        }

        return bestActor;
    }

    void ApplyAim(const SDK::FRotator& targetRot) {
        if (Menu::g_ShowMenu || !g_Config.aimbot_enabled) return;
        auto controller = UE4Helper::GetPlayerController();
        auto player = UE4Helper::GetLocalPlayer();
        if (!ActorPipeline::IsObjectValid(controller) || !ActorPipeline::IsObjectValid(player) ||
            player->Controller != controller || player->IsDead()) return;

        const SDK::FRotator currentRot = controller->ControlRotation;
        if (!std::isfinite(targetRot.Pitch) || !std::isfinite(targetRot.Yaw) ||
            !std::isfinite(currentRot.Pitch) || !std::isfinite(currentRot.Yaw) ||
            !std::isfinite(g_Config.aimbot_smooth)) return;
        const float dt = ImGui::GetIO().DeltaTime;
        if (!std::isfinite(dt) || dt <= 0.0f || dt > 0.1f) return;

        // Breakaway / Swipe Override Detection:
        // If the player deliberately swipes to turn away, yield camera control immediately
        // so the aimbot never causes sticky lock ("прилипание к врагу").
        static SDK::FRotator s_LastAppliedRot{0, 0, 0};
        static uint64_t s_BreakawayUntilMs = 0;
        static int s_LastAimFrame = 0;
        const uint64_t nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();

        if (nowMs < s_BreakawayUntilMs) {
            return;
        }

        const int currentFrame = ImGui::GetFrameCount();
        if (s_LastAimFrame > 0 && (currentFrame - s_LastAimFrame) <= 2) {
            const float manualPitchDiff = std::abs(std::remainder(currentRot.Pitch - s_LastAppliedRot.Pitch, 360.0f));
            const float manualYawDiff = std::abs(std::remainder(currentRot.Yaw - s_LastAppliedRot.Yaw, 360.0f));
            if (manualPitchDiff > 2.8f || manualYawDiff > 2.8f) {
                s_BreakawayUntilMs = nowMs + 280; // 280ms breakaway window
                s_LastAimFrame = 0;
                return;
            }
        }

        const float smooth = std::clamp(g_Config.aimbot_smooth, 1.0f, 30.0f);
        const float pitch = std::remainder(targetRot.Pitch - currentRot.Pitch, 360.0f);
        const float yaw = std::remainder(targetRot.Yaw - currentRot.Yaw, 360.0f);
        if (!std::isfinite(pitch) || !std::isfinite(yaw)) return;

        // Deadzone: skip micro adjustments (< 0.05 deg) to eliminate jitter
        if (std::abs(pitch) < 0.05f && std::abs(yaw) < 0.05f) {
            return;
        }

        SDK::FRotator smoothedRot;
        if (smooth <= 1.05f) {
            smoothedRot = {currentRot.Pitch + pitch, currentRot.Yaw + yaw, currentRot.Roll};
        } else {
            const float alpha = 1.0f - std::pow(1.0f - 1.0f / smooth, dt * 60.0f);
            const float maxStep = 720.0f * dt;
            smoothedRot = {
                currentRot.Pitch + std::clamp(pitch * alpha, -maxStep, maxStep),
                currentRot.Yaw + std::clamp(yaw * alpha, -maxStep, maxStep),
                currentRot.Roll
            };
        }
        smoothedRot.Clamp();
        controller->ControlRotation = smoothedRot;
        s_LastAppliedRot = smoothedRot;
        s_LastAimFrame = currentFrame;
    }

    bool IsTriggerActive(int screenWidth, int screenHeight) {
        if (!g_Config.aimbot_enabled) return false;

        // If neither "aim on shoot" nor "touch zone" is selected, aim continuously
        if (!g_Config.aimbot_on_fire && !g_Config.aimbot_touch_zone) {
            return true;
        }

        // 1. In-game weapon shooting trigger
        if (g_Config.aimbot_on_fire && UE4Helper::IsLocalPlayerFiring()) {
            return true;
        }

        // 2. Separate Touch Zone (Scope / ADS trigger button)
        if (g_Config.aimbot_touch_zone) {
            const float cx = screenWidth  * g_Config.aimbot_fire_zone_x;
            const float cy = screenHeight * g_Config.aimbot_fire_zone_y;
            if (TouchHelper::IsPointerDownInCircle(cx, cy, g_Config.aimbot_fire_zone_r)) {
                return true;
            }
        }

        return false;
    }

    void Update(int screenWidth, int screenHeight) {
        g_TargetPlayer = nullptr;
        if (!Login::SessionValid()) return;
        if (!g_Config.aimbot_enabled || !UE4Helper::GetLocalPlayer() ||
            !UE4Helper::GetPlayerController()) return;

        // Trigger condition check (only aim when active: shooting in-game or touch zone held)
        if (!IsTriggerActive(screenWidth, screenHeight)) return;

        g_TargetPlayer = FindBestTarget(screenWidth, screenHeight);
        if (!g_TargetPlayer) return;

        auto localPlayer = UE4Helper::GetLocalPlayer();
        auto controller = UE4Helper::GetPlayerController();
        SDK::FVector camLoc;
        if (controller && controller->PlayerCameraManager && Tools::IsPtrValid(controller->PlayerCameraManager)) {
            camLoc = controller->PlayerCameraManager->GetCameraLocation();
        } else if (localPlayer) {
            camLoc = localPlayer->GetBonePos("Head");
        } else {
            return;
        }
        // Aim at R (replicated proxy Location) + a height offset per selected bone,
        // NOT at the mesh bones. The mesh/bones sit at a drifted position, so bone
        // aim swung the camera away from the player even though ESP (on R) was right.
        SDK::FVector targetLoc{0, 0, 0};
        {
            SDK::FVector R;
            if (g_TargetPlayer->GetFastRepLocation(R) && R.SizeSquared() > 0.001f) {
                float hh = 88.0f;
                if (g_TargetPlayer->CapsuleComponent && Tools::IsPtrValid(g_TargetPlayer->CapsuleComponent))
                    hh = g_TargetPlayer->CapsuleComponent->GetScaledCapsuleHalfHeight();
                // R is the capsule centre. Offset up toward the chosen hitbox.
                //   bone: 0 Auto, 1 Head, 2 Neck, 3 Chest, 4 Pelvis
                float up;
                switch (g_Config.aimbot_bone) {
                    case 1:  up = hh * 0.90f; break;  // head
                    case 2:  up = hh * 0.75f; break;  // neck
                    case 3:  up = hh * 0.45f; break;  // chest
                    case 4:  up = 0.0f;       break;  // pelvis (capsule centre)
                    default: up = hh * 0.80f; break;  // auto → upper chest/neck
                }
                targetLoc = { R.X, R.Y, R.Z + up };
            } else {
                targetLoc = GetTargetAimLocation(g_TargetPlayer); // fallback (no proxy)
            }
        }
        if (targetLoc.SizeSquared() < 0.001f) return;

        // Vertical aim adjust: raise/lower the aim point along world Z.
        // Negative lowers it (fixes "aim hits above the head"), positive raises it.
        const SDK::FVector rawTargetLoc = targetLoc;
        if (g_Config.aimbot_vertical) {
            targetLoc.Z += g_Config.aimbot_vertical_offset;
        }

        // Bullet-lead prediction + gravity drop over the projectile's time of flight.
        if (g_Config.aimbot_prediction) {
            SDK::FVector vel;
            if (g_TargetPlayer->GetProxyVelocity(vel)) {
                float speed = g_Config.aimbot_bullet_speed;
                if (!std::isfinite(speed) || speed < 1000.0f) speed = 80000.0f;
                const float dx = targetLoc.X - camLoc.X, dy = targetLoc.Y - camLoc.Y, dz = targetLoc.Z - camLoc.Z;
                float t = std::sqrt(dx*dx + dy*dy + dz*dz) / speed;
                if (!std::isfinite(t) || t < 0.0f) t = 0.0f;
                if (t > 1.5f) t = 1.5f;
                targetLoc.X += vel.X * t;
                targetLoc.Y += vel.Y * t;
                targetLoc.Z += vel.Z * t;
                targetLoc.Z += 0.5f * 980.0f * t * t;   // bullet drop (UE gravity ~980 cm/s^2)
            }
        }

        SDK::FRotator aimRot = CalculateAimRotation(camLoc, targetLoc);

        // Aim analysis log (throttled ~4/sec). Records camera, raw/adjusted target,
        // distance and the pitch/yaw delta vs current control rotation — so the
        // "hits above head" offset can be measured and tuned.
        if (g_Config.aimbot_log) {
            static double s_LastLog = 0.0;
            const double now = ImGui::GetTime();
            if (now - s_LastLog > 0.25) {
                s_LastLog = now;
                auto ctrl = UE4Helper::GetPlayerController();
                SDK::FRotator cur = ctrl ? ctrl->ControlRotation : SDK::FRotator{0,0,0};
                const float ddx = targetLoc.X - camLoc.X, ddy = targetLoc.Y - camLoc.Y, ddz = targetLoc.Z - camLoc.Z;
                const float dist = std::sqrt(ddx*ddx + ddy*ddy + ddz*ddz) / 100.0f;
                CrashLog::Log("[AIM] bone=%d vOff=%.1f dist=%.1fm raw.Z=%.1f aim.Z=%.1f tgtPitch=%.2f curPitch=%.2f dPitch=%.2f dYaw=%.2f",
                    g_Config.aimbot_bone,
                    g_Config.aimbot_vertical ? g_Config.aimbot_vertical_offset : 0.0f,
                    dist, rawTargetLoc.Z, targetLoc.Z,
                    aimRot.Pitch, cur.Pitch,
                    (float)std::remainder(aimRot.Pitch - cur.Pitch, 360.0f),
                    (float)std::remainder(aimRot.Yaw - cur.Yaw, 360.0f));
            }
        }

        ApplyAim(aimRot);
    }

    void DrawOverlay(ImDrawList* drawList, int screenWidth, int screenHeight) {
        if (!drawList) return;
        float cx = screenWidth * 0.5f;
        float cy = screenHeight * 0.5f;

        // FOV Circle
        if (g_Config.aimbot_enabled && g_Config.aimbot_fov) {
            const bool active = IsTriggerActive(screenWidth, screenHeight);
            ImU32 fov_col = ImGui::ColorConvertFloat4ToU32(*(const ImVec4*)g_Config.col_aimbot_fov);
            if (active) {
                // Highlight when actively aiming/firing
                fov_col = IM_COL32(255, 60, 60, 220);
            }
            drawList->AddCircle(ImVec2(cx, cy), g_Config.aimbot_fov_radius, fov_col, 64, active ? 1.8f : 1.2f);
        }

        // Touch trigger zone indicator (e.g. for Scope / ADS button):
        // Shown while menu is open or when unlocked so user can see and position it.
        if (g_Config.aimbot_enabled && g_Config.aimbot_touch_zone &&
            (Menu::g_ShowMenu || !g_Config.aimbot_fire_zone_locked)) {
            const float fx = screenWidth  * g_Config.aimbot_fire_zone_x;
            const float fy = screenHeight * g_Config.aimbot_fire_zone_y;
            const bool held = TouchHelper::IsPointerDownInCircle(fx, fy, g_Config.aimbot_fire_zone_r);
            const ImU32 zcol = held ? IM_COL32(0, 255, 90, 220) : IM_COL32(0, 200, 255, 180);
            drawList->AddCircle(ImVec2(fx, fy), g_Config.aimbot_fire_zone_r, zcol, 48, 2.0f);
            drawList->AddText(ImVec2(fx - 24, fy - 8), zcol, "SCOPE");
        }

        // Screen Crosshair
        if (g_Config.mem_crosshair) {
            float len = 10.0f;
            float gap = 3.0f;
            ImU32 col = IM_COL32(0, 255, 60, 220);
            drawList->AddLine(ImVec2(cx - len - gap, cy), ImVec2(cx - gap, cy), col, 1.5f);
            drawList->AddLine(ImVec2(cx + gap, cy), ImVec2(cx + len + gap, cy), col, 1.5f);
            drawList->AddLine(ImVec2(cx, cy - len - gap), ImVec2(cx, cy - gap), col, 1.5f);
            drawList->AddLine(ImVec2(cx, cy + gap), ImVec2(cx, cy + len + gap), col, 1.5f);
            drawList->AddCircleFilled(ImVec2(cx, cy), 1.5f, col);
        }
    }
}
