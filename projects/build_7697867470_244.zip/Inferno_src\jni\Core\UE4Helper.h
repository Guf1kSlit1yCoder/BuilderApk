#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "Memory/Tools.h"
#include "SDK/SDK.hpp"

namespace UE4Helper {
    extern uintptr_t g_UE4Base;
    extern SDK::UWorld* g_World;
    extern SDK::ASGCharacter* g_LocalPlayer;
    extern SDK::ASGPlayerController* g_PlayerController;
    extern SDK::UCanvas* g_Canvas;
    extern SDK::UObject* g_Font;
    extern SDK::UObject* g_WhiteTexture;

    bool InitUE4();
    // Э4: apply the server-authenticated offset-unlock key and recompute offsets.
    // Call once after a successful login; before this, offsets stay scrambled.
    void ApplyOffsetUnlock(uint32_t key);
    SDK::UWorld* GetWorld();
    bool IsWorldReady(SDK::UWorld* world);
    void ResetWorldState();
    SDK::ASGCharacter* GetLocalPlayer();
    SDK::ASGPlayerController* GetPlayerController();
    // Render-thread-only snapshot. Nested feature calls share one binding per frame.
    class ScopedFrame {
    public:
        ScopedFrame();
        ~ScopedFrame();
        ScopedFrame(const ScopedFrame&) = delete;
        ScopedFrame& operator=(const ScopedFrame&) = delete;
    private:
        bool ownsSnapshot = false;
    };
    SDK::UObject* GetDefaultFont();
    SDK::UObject* GetWhiteTexture();
    
    // Immutable for the entire overlay frame: boxes, joints and items share it.
    struct ScreenProjection {
        SDK::FVector Location, Forward, Right, Up;
        float CenterX = 0, CenterY = 0;
        float FocalX = 0, FocalY = 0;
        int Width = 0, Height = 0;
        bool Valid = false;
    };
    bool BuildProjection(const SDK::FCameraView& view, int screenWidth, int screenHeight, ScreenProjection& out);
    bool WorldToScreen(const SDK::FVector& worldPos, SDK::FVector2D& screenPos, const ScreenProjection& projection);
    bool WorldBoundsToScreen(const SDK::FVector& origin, const SDK::FVector& extent,
                             SDK::FVector2D& minimum, SDK::FVector2D& maximum, const ScreenProjection& projection);
    bool ProjectWorldToScreen(SDK::UCanvas* canvas, const SDK::FVector& worldPos, SDK::FVector2D& screenPos);
    
    SDK::FVector GetBoneLocation(SDK::ASGCharacter* actor, int boneId);
    SDK::FVector GetBoneLocationByName(SDK::ASGCharacter* actor, const char* boneName);
    
    float GetDistance(const SDK::FVector& a, const SDK::FVector& b);
    bool IsPlayerAlive(SDK::ASGCharacter* actor);
    bool IsPlayerVisible(SDK::ASGPlayerController* controller, SDK::ASGCharacter* actor);

    bool IsLocalPlayerInScope();
    bool IsLocalPlayerFiring();
}
