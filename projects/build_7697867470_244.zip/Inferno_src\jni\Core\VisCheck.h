#pragma once
#include <cstdint>
#include <vector>
#include "SDK/SDK.hpp"

// Ray-traced per-bone visibility. Targets are published from the render thread;
// the traces run on the game thread (inside a HUD/PlayerController/character
// ProcessEvent vtable hook), where UFunction calls and physics queries are safe.
namespace VisCheck {
    // Same order as ESP's skeleton bone list; bit i of a mask is bone i.
    constexpr int kMaxPoints = 16;

    struct Target {
        SDK::ASGCharacter* actor = nullptr;
        SDK::FVector points[kMaxPoints]{};
        uint16_t valid = 0;
    };

    // Render thread.
    void EnsureHooked(SDK::APlayerController* pc, SDK::ASGCharacter* local, const std::vector<Target>& targets);
    void Publish(const SDK::FVector& camera, SDK::ASGCharacter* local, std::vector<Target>& targets);
    // -1 = check not running, 0 = fully occluded, 1 = at least one bone visible.
    int Query(SDK::ASGCharacter* actor);
    // Returns false when the check is not running. `known` marks bones with a fresh result.
    bool QueryBones(SDK::ASGCharacter* actor, uint16_t& visible, uint16_t& known);
    void Reset();
}
