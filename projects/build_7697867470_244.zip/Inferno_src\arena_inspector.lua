-- ============================================================================
-- Arena Breakout (com.eu.mf.uamo) - UE4 Memory & Offset Inspector
-- GameGuardian Lua Script (ARM64)
-- ============================================================================

gg.clearResults()

local LIB_NAME = "libUE4.so"

-- Real Verified Offsets
local OFF_ENGINE        = 0x0F5D3138 -- UEngine* global in libUE4.so
local OFF_ENGINE_VP     = 0x788      -- GameViewportClient* in UEngine
local OFF_VP_WORLD      = 0x70       -- UWorld* in UGameViewportClient
local OFF_GNAMES        = 0x0F36BEC0 -- FNamePool in libUE4.so
local OFF_GUOBJECTS     = 0x0F38BDB0 -- GUObjectArray in libUE4.so

-- World & Actor Offsets
local OFF_WORLD_LEVEL   = 0x30       -- PersistentLevel in UWorld
local OFF_WORLD_GI      = 0x180      -- OwningGameInstance in UWorld
local OFF_GI_PLAYERS    = 0x38       -- LocalPlayers array in UGameInstance
local OFF_LP_PC         = 0x30       -- PlayerController in ULocalPlayer
local OFF_PC_PAWN       = 0x2A0      -- Character / Pawn in APlayerController
local OFF_LEVEL_ACTORS  = 0x98       -- Actors.Data in ULevel (TArray<AActor*>)
local OFF_LEVEL_COUNT   = 0xA0       -- Actors.Num in ULevel

-- Actor / Character Offsets
local OFF_ACTOR_ROOT    = 0x158      -- RootComponent in AActor
local OFF_SCENE_C2W     = 0x190      -- ComponentToWorld (FTransform) in USceneComponent
local OFF_CHAR_MESH     = 0x370      -- SkeletalMeshComponent in ACharacter
local OFF_CHAR_HEALTH_PL= 0x1FD8     -- SGCharacterHealth in BP_CharacterBase
local OFF_CHAR_HEALTH_AI= 0x2308     -- SGCharacterHealth in BP_UamAICharacterTemplate
local OFF_CHAR_ASC      = 0x1698     -- AbilitySystemComponent in ASGCharacter
local OFF_ASC_ATTRS     = 0x170      -- SpawnedAttributes in UAbilitySystemComponent
local OFF_HEALTH_ATTR   = 0xE0       -- AttributeSetClass in USGActorHealthComponent
local OFF_ATTR_HP       = 0x44       -- Health in USGActorHealthAttributeSet
local OFF_ATTR_MAXHP    = 0x48       -- HealthMax in USGActorHealthAttributeSet

local libBase = 0

-- Safe 64-bit Hex formatting for all Lua versions
local function toHex(val)
    if not val or val == 0 then return "0x0" end
    if type(val) == "string" then return val end
    local hi = math.floor(val / 0x100000000)
    local lo = math.floor(val % 0x100000000)
    if hi > 0 then
        return string.format("0x%X%08X", hi, lo)
    else
        return string.format("0x%X", lo)
    end
end

local function isValidPtr(addr)
    if not addr or addr == 0 then return false end
    return addr >= 0x1000000000 and addr <= 0x7FFFFFFFFFFF
end

local function findLibUE4()
    local ranges = gg.getRangesList(LIB_NAME)
    if not ranges or #ranges == 0 then
        ranges = gg.getRangesList('^/.*libUE4\\.so$')
    end
    if ranges and #ranges > 0 then
        local minStart = nil
        for _, r in ipairs(ranges) do
            if not minStart or r.start < minStart then
                minStart = r.start
            end
        end
        libBase = minStart
        return true
    end
    return false
end

local function readQword(addr)
    if not addr or addr == 0 then return 0 end
    local t = {{address = addr, flags = gg.TYPE_QWORD}}
    local res = gg.getValues(t)
    if res and #res > 0 and res[1].value then
        local v = res[1].value
        if v < 0 then
            v = v + 0x10000000000000000
        end
        return v
    end
    return 0
end

local function readDword(addr)
    if not addr or addr == 0 then return 0 end
    local t = {{address = addr, flags = gg.TYPE_DWORD}}
    local res = gg.getValues(t)
    if res and #res > 0 and res[1].value then
        local v = res[1].value
        if v < 0 then v = v + 0x100000000 end
        return v
    end
    return 0
end

local function readFloat(addr)
    if not addr or addr == 0 then return 0.0 end
    local t = {{address = addr, flags = gg.TYPE_FLOAT}}
    local res = gg.getValues(t)
    if res and #res > 0 and res[1].value then
        return res[1].value
    end
    return 0.0
end

local function readVec3(addr)
    if not isValidPtr(addr) then return {x=0, y=0, z=0} end
    local t = {
        {address = addr + 0x0, flags = gg.TYPE_FLOAT},
        {address = addr + 0x4, flags = gg.TYPE_FLOAT},
        {address = addr + 0x8, flags = gg.TYPE_FLOAT}
    }
    local res = gg.getValues(t)
    if res and #res == 3 then
        return {x = res[1].value or 0, y = res[2].value or 0, z = res[3].value or 0}
    end
    return {x=0, y=0, z=0}
end

-- Chain: libUE4 + 0x0F5D3138 -> Engine -> Viewport (+0x788) -> World (+0x70)
local function getGWorld()
    if libBase == 0 then return 0 end
    local enginePtr = readQword(libBase + OFF_ENGINE)
    if not isValidPtr(enginePtr) then return 0 end
    
    local vpPtr = readQword(enginePtr + OFF_ENGINE_VP)
    if not isValidPtr(vpPtr) then return 0 end
    
    local worldPtr = readQword(vpPtr + OFF_VP_WORLD)
    if isValidPtr(worldPtr) then return worldPtr end
    
    -- Fallback: try alternate viewport offsets
    for _, vpOff in ipairs({0x788, 0x770, 0x7A0, 0x798, 0x760}) do
        local vp = readQword(enginePtr + vpOff)
        if isValidPtr(vp) then
            for _, wOff in ipairs({0x70, 0x78, 0x68, 0x80, 0x60}) do
                local w = readQword(vp + wOff)
                if isValidPtr(w) then
                    local lvl = readQword(w + OFF_WORLD_LEVEL)
                    if isValidPtr(lvl) then return w end
                end
            end
        end
    end
    return 0
end

local function getLocalPlayer(world)
    if not isValidPtr(world) then return 0, 0 end
    local gi = readQword(world + OFF_WORLD_GI)
    if not isValidPtr(gi) then return 0, 0 end
    
    local lpArray = readQword(gi + OFF_GI_PLAYERS)
    if not isValidPtr(lpArray) then return 0, 0 end
    
    local lp = readQword(lpArray)
    if not isValidPtr(lp) then return 0, 0 end
    
    local pc = readQword(lp + OFF_LP_PC)
    if not isValidPtr(pc) then return 0, 0 end
    
    local pawn = readQword(pc + OFF_PC_PAWN)
    if not isValidPtr(pawn) then
        pawn = readQword(pc + 0x298) -- alternate Pawn offset
    end
    return pc, pawn
end

local function inspectActorHealth(actor)
    local report = {}
    table.insert(report, "Actor: " .. toHex(actor))
    
    -- 1. Check Player HealthComponent at +0x1FD8
    local compPlayer = readQword(actor + OFF_CHAR_HEALTH_PL)
    table.insert(report, "Comp Player (+0x1FD8): " .. toHex(compPlayer))
    if isValidPtr(compPlayer) then
        local attr = readQword(compPlayer + OFF_HEALTH_ATTR)
        table.insert(report, "  -> Attr (+0xE0): " .. toHex(attr))
        if isValidPtr(attr) then
            local hp = readFloat(attr + OFF_ATTR_HP)
            local maxHp = readFloat(attr + OFF_ATTR_MAXHP)
            table.insert(report, string.format("  -> HP(+0x44)=%.1f, MaxHP(+0x48)=%.1f", hp, maxHp))
        end
    end

    -- 2. Check AI HealthComponent at +0x2308
    local compAI = readQword(actor + OFF_CHAR_HEALTH_AI)
    table.insert(report, "Comp AI (+0x2308): " .. toHex(compAI))
    if isValidPtr(compAI) then
        local attr = readQword(compAI + OFF_HEALTH_ATTR)
        table.insert(report, "  -> Attr (+0xE0): " .. toHex(attr))
        if isValidPtr(attr) then
            local hp = readFloat(attr + OFF_ATTR_HP)
            local maxHp = readFloat(attr + OFF_ATTR_MAXHP)
            table.insert(report, string.format("  -> HP(+0x44)=%.1f, MaxHP(+0x48)=%.1f", hp, maxHp))
        end
    end

    -- 3. Check AbilitySystemComponent at +0x1698
    local asc = readQword(actor + OFF_CHAR_ASC)
    table.insert(report, "ASC (+0x1698): " .. toHex(asc))
    if isValidPtr(asc) then
        local attrsData = readQword(asc + OFF_ASC_ATTRS)
        local attrsNum = readDword(asc + OFF_ASC_ATTRS + 0x8)
        table.insert(report, string.format("  -> SpawnedAttributes: Data=%s, Count=%d", toHex(attrsData), attrsNum))
        if isValidPtr(attrsData) and attrsNum > 0 and attrsNum < 20 then
            for i = 0, attrsNum - 1 do
                local attrObj = readQword(attrsData + i * 8)
                if isValidPtr(attrObj) then
                    local f1 = readFloat(attrObj + 0x44)
                    local f2 = readFloat(attrObj + 0x48)
                    table.insert(report, string.format("     [%d] Attr %s: +0x44=%.1f, +0x48=%.1f", i, toHex(attrObj), f1, f2))
                end
            end
        end
    end

    return table.concat(report, "\n")
end

local function actionInspectLocalPlayer()
    local world = getGWorld()
    if not isValidPtr(world) then
        gg.alert("❌ GWorld not found! Make sure you are in a match or training area.")
        return
    end

    local pc, pawn = getLocalPlayer(world)
    if not isValidPtr(pawn) then
        gg.alert("World: " .. toHex(world) .. "\nPC: " .. toHex(pc) .. "\nPawn: NOT FOUND (not in match?)")
        return
    end

    local rootComp = readQword(pawn + OFF_ACTOR_ROOT)
    local pos = {x=0, y=0, z=0}
    if isValidPtr(rootComp) then
        pos = readVec3(rootComp + OFF_SCENE_C2W + 0x10)
    end

    local healthInfo = inspectActorHealth(pawn)
    local info = "✅ LOCAL PLAYER FOUND!\n" ..
        "World: " .. toHex(world) .. "\n" ..
        "PC: " .. toHex(pc) .. "\n" ..
        "Pawn: " .. toHex(pawn) .. "\n" ..
        string.format("Pos: (%.1f, %.1f, %.1f)\n\n", pos.x, pos.y, pos.z) ..
        "--- Health Details ---\n" .. healthInfo
    
    gg.alert(info)
    print(info)
end

local function actionDumpActors()
    local world = getGWorld()
    if not isValidPtr(world) then
        gg.alert("❌ GWorld not found! Are you in a match?")
        return
    end

    local level = readQword(world + OFF_WORLD_LEVEL)
    if not isValidPtr(level) then
        gg.alert("❌ PersistentLevel not found! World: " .. toHex(world))
        return
    end

    local actorsData = readQword(level + OFF_LEVEL_ACTORS)
    local actorsCount = readDword(level + OFF_LEVEL_COUNT)
    if not isValidPtr(actorsData) or actorsCount <= 0 then
        gg.alert(string.format("Level: %s\nActors: Data=%s, Count=%d", toHex(level), toHex(actorsData), actorsCount))
        return
    end

    local _, localPawn = getLocalPlayer(world)
    local localPos = {x=0, y=0, z=0}
    if isValidPtr(localPawn) then
        local rc = readQword(localPawn + OFF_ACTOR_ROOT)
        if isValidPtr(rc) then localPos = readVec3(rc + OFF_SCENE_C2W + 0x10) end
    end

    local found = 0
    local logLines = {}
    table.insert(logLines, string.format("=== Total Actors: %d ===", actorsCount))

    for i = 0, math.min(actorsCount - 1, 1500) do
        local actor = readQword(actorsData + i * 8)
        if isValidPtr(actor) and actor ~= localPawn then
            local root = readQword(actor + OFF_ACTOR_ROOT)
            if isValidPtr(root) then
                local mesh = readQword(actor + OFF_CHAR_MESH)
                if isValidPtr(mesh) then
                    found = found + 1
                    local p = readVec3(root + OFF_SCENE_C2W + 0x10)
                    local dist = math.sqrt((p.x - localPos.x)^2 + (p.y - localPos.y)^2 + (p.z - localPos.z)^2) / 100.0
                    
                    local hp1 = 0.0
                    local compPl = readQword(actor + OFF_CHAR_HEALTH_PL)
                    if isValidPtr(compPl) then
                        local at = readQword(compPl + OFF_HEALTH_ATTR)
                        if isValidPtr(at) then hp1 = readFloat(at + OFF_ATTR_HP) end
                    end
                    local hp2 = 0.0
                    local compAI = readQword(actor + OFF_CHAR_HEALTH_AI)
                    if isValidPtr(compAI) then
                        local at = readQword(compAI + OFF_HEALTH_ATTR)
                        if isValidPtr(at) then hp2 = readFloat(at + OFF_ATTR_HP) end
                    end

                    local line = string.format("#%d [%s] Dist=%.1fm Mesh=%s HP(Pl:0x1FD8)=%.1f HP(AI:0x2308)=%.1f Pos=(%.1f,%.1f,%.1f)",
                        found, toHex(actor), dist, toHex(mesh), hp1, hp2, p.x, p.y, p.z)
                    table.insert(logLines, line)
                    if found <= 10 then print(line) end
                end
            end
        end
    end

    table.insert(logLines, string.format("=== Characters with Mesh: %d ===", found))
    local fullText = table.concat(logLines, "\n")
    print(fullText)
    gg.alert(string.format("Found %d characters!\nCheck GG log for details.", found))
end

local function actionLiveMonitor()
    local world = getGWorld()
    if not isValidPtr(world) then
        gg.toast("GWorld not ready")
        return
    end

    local _, localPawn = getLocalPlayer(world)
    if not isValidPtr(localPawn) then
        gg.toast("Not in match (no local pawn)")
        return
    end

    gg.toast("Live Monitor Running... Click GG icon to stop.")
    while true do
        if gg.isClickedUi() then break end
        
        local info = inspectActorHealth(localPawn)
        local lines = {}
        for s in info:gmatch("[^\r\n]+") do
            if s:find("HP") or s:find("Comp") or s:find("Attr") then
                table.insert(lines, s)
            end
        end
        gg.toast("Local HP:\n" .. table.concat(lines, "\n"))
        gg.sleep(500)
    end
end

local function actionCheckPointers()
    local engine = readQword(libBase + OFF_ENGINE)
    local vp = isValidPtr(engine) and readQword(engine + OFF_ENGINE_VP) or 0
    local world = isValidPtr(vp) and readQword(vp + OFF_VP_WORLD) or 0
    local level = isValidPtr(world) and readQword(world + OFF_WORLD_LEVEL) or 0
    local actors = isValidPtr(level) and readQword(level + OFF_LEVEL_ACTORS) or 0
    local count = isValidPtr(level) and readDword(level + OFF_LEVEL_COUNT) or 0

    local info = "libUE4 Base: " .. toHex(libBase) .. "\n" ..
        "Engine: " .. toHex(engine) .. "\n" ..
        "Viewport: " .. toHex(vp) .. "\n" ..
        "World: " .. toHex(world) .. "\n" ..
        "Level: " .. toHex(level) .. "\n" ..
        "Actors.Data: " .. toHex(actors) .. "\n" ..
        "Actors.Count: " .. tostring(count)

    gg.alert(info)
    print(info)
end

local function actionInspectSkeleton()
    local world = getGWorld()
    if not isValidPtr(world) then
        gg.alert("❌ GWorld not found! Are you in a match?")
        return
    end

    local level = readQword(world + OFF_WORLD_LEVEL)
    local actorsData = isValidPtr(level) and readQword(level + OFF_LEVEL_ACTORS) or 0
    local actorsCount = isValidPtr(level) and readDword(level + OFF_LEVEL_COUNT) or 0
    if not isValidPtr(actorsData) or actorsCount <= 0 then
        gg.alert("❌ No actors found!")
        return
    end

    local _, localPawn = getLocalPlayer(world)
    local targetPawn = localPawn
    local targetName = "LocalPlayer"

    if not isValidPtr(targetPawn) then
        for i = 0, math.min(actorsCount - 1, 1000) do
            local a = readQword(actorsData + i * 8)
            if isValidPtr(a) then
                local m = readQword(a + OFF_CHAR_MESH)
                if isValidPtr(m) then
                    targetPawn = a
                    targetName = "Enemy #" .. i
                    break
                end
            end
        end
    end

    if not isValidPtr(targetPawn) then
        gg.alert("❌ No pawn with Mesh found!")
        return
    end

    local mesh = readQword(targetPawn + OFF_CHAR_MESH)
    if not isValidPtr(mesh) then
        gg.alert("❌ Target has no Mesh!")
        return
    end

    local cstData = readQword(mesh + 0x9B8)
    local cstNum = readDword(mesh + 0x9B8 + 8)
    local cstMax = readDword(mesh + 0x9B8 + 12)

    local bstData = readQword(mesh + 0x9A8)
    local bstNum = readDword(mesh + 0x9A8 + 8)

    local skelMesh = readQword(mesh + 0x6D0)
    local skeleton = isValidPtr(skelMesh) and readQword(skelMesh + 0x88) or 0
    local boneTreeNum = isValidPtr(skeleton) and readDword(skeleton + 0x38 + 8) or 0

    local info = string.format(
        "=== 🦴 Skeleton & Bone Inspector ===\n" ..
        "Target: %s (%s)\n" ..
        "Mesh: %s\n\n" ..
        "CachedComponentSpaceTransforms (+0x9B8):\n" ..
        "  Data: %s\n" ..
        "  Count: %d (Max: %d)\n\n" ..
        "CachedBoneSpaceTransforms (+0x9A8):\n" ..
        "  Data: %s\n" ..
        "  Count: %d\n\n" ..
        "USkeleton (+0x6D0 -> +0x88):\n" ..
        "  Skeleton: %s\n" ..
        "  BoneTree Count: %d\n",
        targetName, toHex(targetPawn), toHex(mesh),
        toHex(cstData), cstNum, cstMax,
        toHex(bstData), bstNum,
        toHex(skeleton), boneTreeNum
    )

    if isValidPtr(cstData) and cstNum >= 7 then
        local function readBonePos(idx)
            local addr = cstData + idx * 0x30 + 0x10
            local v = readVec3(addr)
            return string.format("Bone #%d: (%.1f, %.1f, %.1f)", idx, v.x, v.y, v.z)
        end
        info = info .. "\nSample Bone Translations (CompSpace):\n" ..
            readBonePos(0) .. "\n" ..
            readBonePos(1) .. "\n" ..
            readBonePos(4) .. "\n" ..
            readBonePos(6)
    end

    gg.alert(info)
    print(info)
end

local function main()
    if not findLibUE4() then
        gg.alert("❌ libUE4.so not found! Make sure Arena Breakout is running.")
        return
    end

    print(string.format("[Init] libUE4.so base: %s", toHex(libBase)))

    while true do
        local menu = gg.choice({
            "🎯 [1] Inspect Local Player (Coords & Health)",
            "👥 [2] Dump All Enemies / Bots (Mesh & Health Offsets)",
            "📊 [3] Live HP & Offset Monitor (Real-time toast)",
            "🔍 [4] Check UE4 Base & Global Pointers",
            "🦴 [5] Inspect Skeleton & Bone Transforms (+0x9B8)",
            "❌ [6] Exit"
        }, nil, "Arena UE4 Inspector (" .. toHex(libBase) .. ")")

        if not menu or menu == 6 then break end

        if menu == 1 then
            actionInspectLocalPlayer()
        elseif menu == 2 then
            actionDumpActors()
        elseif menu == 3 then
            actionLiveMonitor()
        elseif menu == 4 then
            actionCheckPointers()
        elseif menu == 5 then
            actionInspectSkeleton()
        end
    end
end

main()
