#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/uio.h>
#include <dirent.h>
#include <string.h>

static pid_t g_Pid = -1;
static uintptr_t g_LibBase = 0;
static bool ReadMem(uintptr_t addr, void* buf, size_t size) {
    if (addr < 0x10000ULL || addr > 0x00007FFFFFFFFFFFULL) return false;
    struct iovec local = { buf, size };
    struct iovec remote = { (void*)addr, size };
    return process_vm_readv(g_Pid, &local, 1, &remote, 1, 0) == (ssize_t)size;
}
template<typename T> static T ReadVal(uintptr_t a) { T v{}; ReadMem(a, &v, sizeof(T)); return v; }
static uintptr_t ReadPtr(uintptr_t a) { return ReadVal<uintptr_t>(a); }

int main() {
    DIR* dir = opendir("/proc");
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type != DT_DIR) continue;
        int pid = atoi(entry->d_name);
        if (pid <= 0) continue;
        char cmdlinePath[64];
        snprintf(cmdlinePath, sizeof(cmdlinePath), "/proc/%d/cmdline", pid);
        FILE* fp = fopen(cmdlinePath, "r");
        if (fp) {
            char cmdline[256] = {};
            fread(cmdline, 1, sizeof(cmdline) - 1, fp);
            fclose(fp);
            if (strstr(cmdline, "com.eu.mf.uamo")) { g_Pid = pid; break; }
        }
    }
    closedir(dir);
    char mapsPath[64];
    snprintf(mapsPath, sizeof(mapsPath), "/proc/%d/maps", g_Pid);
    FILE* f = fopen(mapsPath, "r");
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, "libUE4.so") && strstr(line, "r--p") && !strstr(line, "anon")) {
            sscanf(line, "%lx-", &g_LibBase);
            break;
        }
    }
    fclose(f);
    printf("PID: %d, LibBase: 0x%lx\n", g_Pid, g_LibBase);
    uintptr_t gEngine = ReadPtr(g_LibBase + 0x0F5D3138);
    uintptr_t vp = ReadPtr(gEngine + 0x788);
    uintptr_t world = ReadPtr(vp + 0x70);
    uintptr_t gi = ReadPtr(world + 0x180);
    uintptr_t lpArray = ReadPtr(gi + 0x38);
    uintptr_t lp = ReadPtr(lpArray);
    uintptr_t pc = ReadPtr(lp + 0x30);
    printf("gEngine: 0x%lx, vp: 0x%lx, world: 0x%lx, gi: 0x%lx, lp: 0x%lx, pc: 0x%lx\n",
           gEngine, vp, world, gi, lp, pc);
    return 0;
}
