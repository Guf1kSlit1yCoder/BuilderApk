#pragma once

namespace BgTexture
{
    bool Init();       // call once after GL context is ready
    void Shutdown();
    void Draw(int screenW, int screenH);  // draw fullscreen before ImGui
    unsigned int GetTex();
}
