#include "Config.h"
#include <fstream>
#include <sstream>
#include <iterator>
#include "Memory/Tools.h"
#include "../Login.h"
#include "AntiCrack/Crypto.h"

#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <algorithm>
#include <cstring>

ConfigState g_Config;

namespace ConfigManager {
    bool g_AutoSaveMode = true;
    char g_ActiveConfigName[64] = "Default";
    char g_NewConfigName[64] = "";

    static void ParseConfigStream(std::istream& file) {
        std::string line;
        while (std::getline(file, line)) {
            // Trim CR if present
            if (!line.empty() && line.back() == '\r') line.pop_back();
            if (line.empty() || line[0] == '#' || line[0] == '[') continue;

            size_t pos = line.find('=');
            if (pos == std::string::npos) continue;
            std::string key = line.substr(0, pos);
            std::string val = line.substr(pos + 1);

            if (key == (const char*)OBFSTR("esp_enabled")) g_Config.esp_enabled = (val == "1");
            else if (key == (const char*)OBFSTR("esp_box")) g_Config.esp_box = (val == "1");
            else if (key == (const char*)OBFSTR("esp_box_type")) g_Config.esp_box_type = std::stoi(val);
            else if (key == (const char*)OBFSTR("esp_skeleton")) g_Config.esp_skeleton = (val == "1");
            else if (key == (const char*)OBFSTR("esp_name")) g_Config.esp_name = (val == "1");
            else if (key == (const char*)OBFSTR("esp_distance")) g_Config.esp_distance = (val == "1");
            else if (key == (const char*)OBFSTR("esp_health")) g_Config.esp_health = (val == "1");
            else if (key == (const char*)OBFSTR("esp_health_type")) g_Config.esp_health_type = std::stoi(val);
            else if (key == (const char*)OBFSTR("esp_weapon")) g_Config.esp_weapon = (val == "1");
            else if (key == (const char*)OBFSTR("esp_team_id")) g_Config.esp_team_id = (val == "1");
            else if (key == (const char*)OBFSTR("esp_line")) g_Config.esp_line = (val == "1");
            else if (key == (const char*)OBFSTR("esp_line_origin")) g_Config.esp_line_origin = atoi(val.c_str());
            else if (key == (const char*)OBFSTR("esp_head_dot")) g_Config.esp_head_dot = (val == "1");
            else if (key == (const char*)OBFSTR("esp_bots")) g_Config.esp_bots = (val == "1");
            else if (key == (const char*)OBFSTR("esp_teammates")) g_Config.esp_teammates = (val == "1");
            else if (key == (const char*)OBFSTR("esp_radar")) g_Config.esp_radar = (val == "1");
            else if (key == (const char*)OBFSTR("esp_vehicles")) g_Config.esp_vehicles = (val == "1");
            else if (key == (const char*)OBFSTR("esp_airdrop")) g_Config.esp_airdrop = (val == "1");
            else if (key == (const char*)OBFSTR("esp_lootbox")) g_Config.esp_lootbox = (val == "1");
            else if (key == (const char*)OBFSTR("esp_dead_bodies")) g_Config.esp_dead_bodies = (val == "1");
            else if (key == (const char*)OBFSTR("esp_filter_opened_boxes")) g_Config.esp_filter_opened_boxes = (val == "1");
            else if (key == (const char*)OBFSTR("esp_items")) g_Config.esp_items = (val == "1");
            else if (key == (const char*)OBFSTR("ammo_hud_enabled")) g_Config.ammo_hud_enabled = (val == "1");
            else if (key == (const char*)OBFSTR("ammo_hud_locked")) g_Config.ammo_hud_locked = (val == "1");
            else if (key == (const char*)OBFSTR("ammo_hud_x")) g_Config.ammo_hud_x = std::stof(val);
            else if (key == (const char*)OBFSTR("ammo_hud_y")) g_Config.ammo_hud_y = std::stof(val);
            else if (key == (const char*)OBFSTR("item_esp_max_distance")) g_Config.item_esp_max_distance = std::stoi(val);
            else if (key == (const char*)OBFSTR("esp_grenade_warning")) g_Config.esp_grenade_warning = (val == "1");
            else if (key == (const char*)OBFSTR("esp_box_thickness")) g_Config.esp_box_thickness = std::stof(val);
            else if (key == (const char*)OBFSTR("esp_skeleton_thickness")) g_Config.esp_skeleton_thickness = std::stof(val);
            else if (key == (const char*)OBFSTR("esp_text_size")) g_Config.esp_text_size = std::stoi(val);
            else if (key == (const char*)OBFSTR("esp_log")) g_Config.esp_log = (val == "1");
            else if (key == (const char*)OBFSTR("esp_anti_ghost")) g_Config.esp_anti_ghost = (val == "1");
            else if (key == (const char*)OBFSTR("esp_ghost_seconds")) g_Config.esp_ghost_seconds = std::stof(val);
            else if (key == (const char*)OBFSTR("esp_calibrate")) g_Config.esp_calibrate = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_enabled")) g_Config.aimbot_enabled = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_fov")) g_Config.aimbot_fov = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_fov_radius")) g_Config.aimbot_fov_radius = std::stof(val);
            else if (key == (const char*)OBFSTR("aimbot_smooth")) g_Config.aimbot_smooth = std::stof(val);
            else if (key == (const char*)OBFSTR("aimbot_bone")) g_Config.aimbot_bone = std::stoi(val);
            else if (key == (const char*)OBFSTR("aimbot_priority")) g_Config.aimbot_priority = std::stoi(val);
            else if (key == (const char*)OBFSTR("aimbot_open_bones_first")) g_Config.aimbot_open_bones_first = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_visible_only")) g_Config.aimbot_visible_only = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_ignore_bots")) g_Config.aimbot_ignore_bots = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_ignore_knocked")) g_Config.aimbot_ignore_knocked = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_prediction")) g_Config.aimbot_prediction = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_bullet_speed")) g_Config.aimbot_bullet_speed = std::stof(val);
            else if (key == (const char*)OBFSTR("aimbot_auto_fire")) g_Config.aimbot_auto_fire = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_auto_fire_interval")) g_Config.aimbot_auto_fire_interval = std::stoi(val);
            else if (key == (const char*)OBFSTR("aimbot_silent")) g_Config.aimbot_silent = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_trigger")) g_Config.aimbot_trigger = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_on_fire")) g_Config.aimbot_on_fire = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_touch_zone")) g_Config.aimbot_touch_zone = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_fire_zone_x")) g_Config.aimbot_fire_zone_x = std::stof(val);
            else if (key == (const char*)OBFSTR("aimbot_fire_zone_y")) g_Config.aimbot_fire_zone_y = std::stof(val);
            else if (key == (const char*)OBFSTR("aimbot_fire_zone_r")) g_Config.aimbot_fire_zone_r = std::stof(val);
            else if (key == (const char*)OBFSTR("aimbot_fire_zone_locked")) g_Config.aimbot_fire_zone_locked = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_vertical")) g_Config.aimbot_vertical = (val == "1");
            else if (key == (const char*)OBFSTR("aimbot_vertical_offset")) g_Config.aimbot_vertical_offset = std::stof(val);
            else if (key == (const char*)OBFSTR("aimbot_log")) g_Config.aimbot_log = (val == "1");
            else if (key == (const char*)OBFSTR("mem_no_recoil")) g_Config.mem_no_recoil = (val == "1");
            else if (key == (const char*)OBFSTR("mem_wide_view")) g_Config.mem_wide_view = (val == "1");
            else if (key == (const char*)OBFSTR("mem_wide_view_fov")) g_Config.mem_wide_view_fov = std::stof(val);
            else if (key == (const char*)OBFSTR("mem_no_camera_shake")) g_Config.mem_no_camera_shake = (val == "1");
            else if (key == (const char*)OBFSTR("mem_crosshair")) g_Config.mem_crosshair = (val == "1");
            else if (key == (const char*)OBFSTR("esp_custom_colors")) g_Config.esp_custom_colors = (val == "1");
            else if (key == (const char*)OBFSTR("col_box_vis"))  g_Config.col_box_vis  = (uint32_t)std::stoul(val);
            else if (key == (const char*)OBFSTR("col_box_hid"))  g_Config.col_box_hid  = (uint32_t)std::stoul(val);
            else if (key == (const char*)OBFSTR("col_line_vis")) g_Config.col_line_vis = (uint32_t)std::stoul(val);
            else if (key == (const char*)OBFSTR("col_line_hid")) g_Config.col_line_hid = (uint32_t)std::stoul(val);
            else if (key == (const char*)OBFSTR("col_skel_vis")) g_Config.col_skel_vis = (uint32_t)std::stoul(val);
            else if (key == (const char*)OBFSTR("col_skel_hid")) g_Config.col_skel_hid = (uint32_t)std::stoul(val);
            else if (key == (const char*)OBFSTR("col_player_skel_vis")) sscanf(val.c_str(), "%f,%f,%f,%f", &g_Config.col_player_skel_vis[0], &g_Config.col_player_skel_vis[1], &g_Config.col_player_skel_vis[2], &g_Config.col_player_skel_vis[3]);
            else if (key == (const char*)OBFSTR("col_player_skel_hid")) sscanf(val.c_str(), "%f,%f,%f,%f", &g_Config.col_player_skel_hid[0], &g_Config.col_player_skel_hid[1], &g_Config.col_player_skel_hid[2], &g_Config.col_player_skel_hid[3]);
            else if (key == (const char*)OBFSTR("col_player_line_vis")) sscanf(val.c_str(), "%f,%f,%f,%f", &g_Config.col_player_line_vis[0], &g_Config.col_player_line_vis[1], &g_Config.col_player_line_vis[2], &g_Config.col_player_line_vis[3]);
            else if (key == (const char*)OBFSTR("col_player_line_hid")) sscanf(val.c_str(), "%f,%f,%f,%f", &g_Config.col_player_line_hid[0], &g_Config.col_player_line_hid[1], &g_Config.col_player_line_hid[2], &g_Config.col_player_line_hid[3]);
            else if (key == (const char*)OBFSTR("col_bot_skel_vis")) sscanf(val.c_str(), "%f,%f,%f,%f", &g_Config.col_bot_skel_vis[0], &g_Config.col_bot_skel_vis[1], &g_Config.col_bot_skel_vis[2], &g_Config.col_bot_skel_vis[3]);
            else if (key == (const char*)OBFSTR("col_counter_a")) sscanf(val.c_str(), "%f,%f,%f,%f", &g_Config.col_counter_a[0], &g_Config.col_counter_a[1], &g_Config.col_counter_a[2], &g_Config.col_counter_a[3]);
            else if (key == (const char*)OBFSTR("col_counter_b")) sscanf(val.c_str(), "%f,%f,%f,%f", &g_Config.col_counter_b[0], &g_Config.col_counter_b[1], &g_Config.col_counter_b[2], &g_Config.col_counter_b[3]);
            else if (key == (const char*)OBFSTR("col_bot_skel_hid")) sscanf(val.c_str(), "%f,%f,%f,%f", &g_Config.col_bot_skel_hid[0], &g_Config.col_bot_skel_hid[1], &g_Config.col_bot_skel_hid[2], &g_Config.col_bot_skel_hid[3]);
            else if (key == (const char*)OBFSTR("col_bot_line_vis")) sscanf(val.c_str(), "%f,%f,%f,%f", &g_Config.col_bot_line_vis[0], &g_Config.col_bot_line_vis[1], &g_Config.col_bot_line_vis[2], &g_Config.col_bot_line_vis[3]);
            else if (key == (const char*)OBFSTR("col_bot_line_hid")) sscanf(val.c_str(), "%f,%f,%f,%f", &g_Config.col_bot_line_hid[0], &g_Config.col_bot_line_hid[1], &g_Config.col_bot_line_hid[2], &g_Config.col_bot_line_hid[3]);
            else if (key == (const char*)OBFSTR("col_aimbot_fov")) sscanf(val.c_str(), "%f,%f,%f,%f", &g_Config.col_aimbot_fov[0], &g_Config.col_aimbot_fov[1], &g_Config.col_aimbot_fov[2], &g_Config.col_aimbot_fov[3]);
            else if (key == (const char*)OBFSTR("russian_language")) g_Config.russian_language = (val == "1");
            else if (key == (const char*)OBFSTR("arabic_language")) g_Config.arabic_language = (val == "1");
        }
    }

    static void SerializeConfigStream(std::ostream& file) {
        file << "# Mirage Shareable Configuration File\n";
        file << "esp_enabled=" << (g_Config.esp_enabled ? "1" : "0") << "\n";
        file << "esp_box=" << (g_Config.esp_box ? "1" : "0") << "\n";
        file << "esp_box_type=" << g_Config.esp_box_type << "\n";
        file << "esp_skeleton=" << (g_Config.esp_skeleton ? "1" : "0") << "\n";
        file << "esp_name=" << (g_Config.esp_name ? "1" : "0") << "\n";
        file << "esp_distance=" << (g_Config.esp_distance ? "1" : "0") << "\n";
        file << "esp_health=" << (g_Config.esp_health ? "1" : "0") << "\n";
        file << "esp_health_type=" << g_Config.esp_health_type << "\n";
        file << "esp_weapon=" << (g_Config.esp_weapon ? "1" : "0") << "\n";
        file << "esp_team_id=" << (g_Config.esp_team_id ? "1" : "0") << "\n";
        file << "esp_line=" << (g_Config.esp_line ? "1" : "0") << "\n";
        file << "esp_line_origin=" << g_Config.esp_line_origin << "\n";
        file << "esp_head_dot=" << (g_Config.esp_head_dot ? "1" : "0") << "\n";
        file << "esp_bots=" << (g_Config.esp_bots ? "1" : "0") << "\n";
        file << "esp_teammates=" << (g_Config.esp_teammates ? "1" : "0") << "\n";
        file << "esp_radar=" << (g_Config.esp_radar ? "1" : "0") << "\n";
        file << "esp_vehicles=" << (g_Config.esp_vehicles ? "1" : "0") << "\n";
        file << "esp_airdrop=" << (g_Config.esp_airdrop ? "1" : "0") << "\n";
        file << "esp_lootbox=" << (g_Config.esp_lootbox ? "1" : "0") << "\n";
        file << "esp_dead_bodies=" << (g_Config.esp_dead_bodies ? "1" : "0") << "\n";
        file << "esp_filter_opened_boxes=" << (g_Config.esp_filter_opened_boxes ? "1" : "0") << "\n";
        file << "esp_items=" << (g_Config.esp_items ? "1" : "0") << "\n";
        file << "ammo_hud_enabled=" << (g_Config.ammo_hud_enabled ? "1" : "0") << "\n";
        file << "ammo_hud_locked=" << (g_Config.ammo_hud_locked ? "1" : "0") << "\n";
        file << "ammo_hud_x=" << g_Config.ammo_hud_x << "\n";
        file << "ammo_hud_y=" << g_Config.ammo_hud_y << "\n";
        file << "item_esp_max_distance=" << g_Config.item_esp_max_distance << "\n";
        file << "esp_grenade_warning=" << (g_Config.esp_grenade_warning ? "1" : "0") << "\n";
        file << "esp_box_thickness=" << g_Config.esp_box_thickness << "\n";
        file << "esp_skeleton_thickness=" << g_Config.esp_skeleton_thickness << "\n";
        file << "esp_text_size=" << g_Config.esp_text_size << "\n";
        file << "esp_log=" << (g_Config.esp_log ? "1" : "0") << "\n";
        file << "esp_anti_ghost=" << (g_Config.esp_anti_ghost ? "1" : "0") << "\n";
        file << "esp_ghost_seconds=" << g_Config.esp_ghost_seconds << "\n";
        file << "esp_calibrate=" << (g_Config.esp_calibrate ? "1" : "0") << "\n";
        file << "aimbot_enabled=" << (g_Config.aimbot_enabled ? "1" : "0") << "\n";
        file << "aimbot_fov=" << (g_Config.aimbot_fov ? "1" : "0") << "\n";
        file << "aimbot_fov_radius=" << g_Config.aimbot_fov_radius << "\n";
        file << "col_aimbot_fov=" << g_Config.col_aimbot_fov[0] << "," << g_Config.col_aimbot_fov[1] << "," << g_Config.col_aimbot_fov[2] << "," << g_Config.col_aimbot_fov[3] << "\n";
        file << "russian_language=" << (g_Config.russian_language ? "1" : "0") << "\n";
        file << "arabic_language=" << (g_Config.arabic_language ? "1" : "0") << "\n";
        file << "aimbot_smooth=" << g_Config.aimbot_smooth << "\n";
        file << "aimbot_bone=" << g_Config.aimbot_bone << "\n";
        file << "aimbot_priority=" << g_Config.aimbot_priority << "\n";
        file << "aimbot_open_bones_first=" << (g_Config.aimbot_open_bones_first ? "1" : "0") << "\n";
        file << "aimbot_visible_only=" << (g_Config.aimbot_visible_only ? "1" : "0") << "\n";
        file << "aimbot_ignore_bots=" << (g_Config.aimbot_ignore_bots ? "1" : "0") << "\n";
        file << "aimbot_ignore_knocked=" << (g_Config.aimbot_ignore_knocked ? "1" : "0") << "\n";
        file << "aimbot_prediction=" << (g_Config.aimbot_prediction ? "1" : "0") << "\n";
        file << "aimbot_bullet_speed=" << g_Config.aimbot_bullet_speed << "\n";
        file << "aimbot_auto_fire=" << (g_Config.aimbot_auto_fire ? "1" : "0") << "\n";
        file << "aimbot_auto_fire_interval=" << g_Config.aimbot_auto_fire_interval << "\n";
        file << "aimbot_silent=" << (g_Config.aimbot_silent ? "1" : "0") << "\n";
        file << "aimbot_trigger=" << (g_Config.aimbot_trigger ? "1" : "0") << "\n";
        file << "aimbot_on_fire=" << (g_Config.aimbot_on_fire ? "1" : "0") << "\n";
        file << "aimbot_touch_zone=" << (g_Config.aimbot_touch_zone ? "1" : "0") << "\n";
        file << "aimbot_fire_zone_x=" << g_Config.aimbot_fire_zone_x << "\n";
        file << "aimbot_fire_zone_y=" << g_Config.aimbot_fire_zone_y << "\n";
        file << "aimbot_fire_zone_r=" << g_Config.aimbot_fire_zone_r << "\n";
        file << "aimbot_fire_zone_locked=" << (g_Config.aimbot_fire_zone_locked ? "1" : "0") << "\n";
        file << "aimbot_vertical=" << (g_Config.aimbot_vertical ? "1" : "0") << "\n";
        file << "aimbot_vertical_offset=" << g_Config.aimbot_vertical_offset << "\n";
        file << "aimbot_log=" << (g_Config.aimbot_log ? "1" : "0") << "\n";
        file << "mem_no_recoil=" << (g_Config.mem_no_recoil ? "1" : "0") << "\n";
        file << "mem_wide_view=" << (g_Config.mem_wide_view ? "1" : "0") << "\n";
        file << "mem_wide_view_fov=" << g_Config.mem_wide_view_fov << "\n";
        file << "mem_no_camera_shake=" << (g_Config.mem_no_camera_shake ? "1" : "0") << "\n";
        file << "mem_crosshair=" << (g_Config.mem_crosshair ? "1" : "0") << "\n";
        file << "esp_custom_colors=" << (g_Config.esp_custom_colors ? "1" : "0") << "\n";
        file << "col_box_vis="  << g_Config.col_box_vis  << "\n";
        file << "col_box_hid="  << g_Config.col_box_hid  << "\n";
        file << "col_line_vis=" << g_Config.col_line_vis << "\n";
        file << "col_line_hid=" << g_Config.col_line_hid << "\n";
        file << "col_skel_vis=" << g_Config.col_skel_vis << "\n";
        file << "col_skel_hid=" << g_Config.col_skel_hid << "\n";
        file << "col_player_skel_vis=" << g_Config.col_player_skel_vis[0] << "," << g_Config.col_player_skel_vis[1] << "," << g_Config.col_player_skel_vis[2] << "," << g_Config.col_player_skel_vis[3] << "\n";
        file << "col_player_skel_hid=" << g_Config.col_player_skel_hid[0] << "," << g_Config.col_player_skel_hid[1] << "," << g_Config.col_player_skel_hid[2] << "," << g_Config.col_player_skel_hid[3] << "\n";
        file << "col_player_line_vis=" << g_Config.col_player_line_vis[0] << "," << g_Config.col_player_line_vis[1] << "," << g_Config.col_player_line_vis[2] << "," << g_Config.col_player_line_vis[3] << "\n";
        file << "col_player_line_hid=" << g_Config.col_player_line_hid[0] << "," << g_Config.col_player_line_hid[1] << "," << g_Config.col_player_line_hid[2] << "," << g_Config.col_player_line_hid[3] << "\n";
        file << "col_bot_skel_vis=" << g_Config.col_bot_skel_vis[0] << "," << g_Config.col_bot_skel_vis[1] << "," << g_Config.col_bot_skel_vis[2] << "," << g_Config.col_bot_skel_vis[3] << "\n";
        file << "col_counter_a=" << g_Config.col_counter_a[0] << "," << g_Config.col_counter_a[1] << "," << g_Config.col_counter_a[2] << "," << g_Config.col_counter_a[3] << "\n";
        file << "col_counter_b=" << g_Config.col_counter_b[0] << "," << g_Config.col_counter_b[1] << "," << g_Config.col_counter_b[2] << "," << g_Config.col_counter_b[3] << "\n";
        file << "col_bot_skel_hid=" << g_Config.col_bot_skel_hid[0] << "," << g_Config.col_bot_skel_hid[1] << "," << g_Config.col_bot_skel_hid[2] << "," << g_Config.col_bot_skel_hid[3] << "\n";
        file << "col_bot_line_vis=" << g_Config.col_bot_line_vis[0] << "," << g_Config.col_bot_line_vis[1] << "," << g_Config.col_bot_line_vis[2] << "," << g_Config.col_bot_line_vis[3] << "\n";
        file << "col_bot_line_hid=" << g_Config.col_bot_line_hid[0] << "," << g_Config.col_bot_line_hid[1] << "," << g_Config.col_bot_line_hid[2] << "," << g_Config.col_bot_line_hid[3] << "\n";
    }

    void LoadConfig(const std::string& path) {
        std::string target = path.empty() ? g_Config.config_path : path;
        std::ifstream fin(target, std::ios::binary);
        if (!fin.is_open()) {
            LOGI("Config not found, using defaults.");
            return;
        }
        std::string blob((std::istreambuf_iterator<char>(fin)), std::istreambuf_iterator<char>());
        fin.close();

        // Check if plain text
        if (blob.find("esp_enabled=") != std::string::npos || blob.find("#") == 0) {
            std::istringstream iss(blob);
            ParseConfigStream(iss);
            LOGI("Plaintext config loaded successfully from %s", target.c_str());
            return;
        }

        uint8_t ckey[32];
        Login::GetDeviceConfigKey(ckey);
        std::string text;
        if (!AntiCrack::OpenConfig(blob, ckey, text)) {
            LOGW("Config decrypt/verify failed (tampered or different device), using defaults.");
            return;
        }
        std::istringstream file(text);
        ParseConfigStream(file);
        LOGI("Encrypted config loaded from %s", target.c_str());
    }

    void SaveConfig(const std::string& path) {
        std::string target = path.empty() ? g_Config.config_path : path;
        std::ostringstream file;
        SerializeConfigStream(file);

        std::ofstream fout(target, std::ios::out | std::ios::trunc);
        if (!fout.is_open()) { LOGE("Failed to open config for write"); return; }
        fout << file.str();
        fout.close();
        LOGI("Config saved successfully to %s", target.c_str());
    }

    static bool s_ConfigDirty = false;
    static float s_DirtyTimer = 0.0f;

    void RequestAutoSave() {
        s_ConfigDirty = true;
    }

    void UpdateAutoSave(float dt) {
        if (s_ConfigDirty) {
            s_DirtyTimer += dt;
            if (s_DirtyTimer >= 1.5f) {
                s_DirtyTimer = 0.0f;
                s_ConfigDirty = false;
                SaveConfig();
            }
        }
    }

    void ResetToDefaults() {
        g_Config = ConfigState();
    }

    std::string GetConfigDirectory() {
        struct stat st;
        std::string sd_down = "/sdcard/Download";
        if (stat(sd_down.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
            std::string dir = "/sdcard/Download/MirageConfigs";
            mkdir(dir.c_str(), 0777);
            return dir;
        }
        std::string sd = "/sdcard";
        if (stat(sd.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
            std::string dir = "/sdcard/MirageConfigs";
            mkdir(dir.c_str(), 0777);
            return dir;
        }
        std::string dir = "/data/local/tmp/MirageConfigs";
        mkdir(dir.c_str(), 0777);
        return dir;
    }

    std::vector<std::string> GetConfigList() {
        std::vector<std::string> list;
        std::string dir = GetConfigDirectory();
        DIR* dp = opendir(dir.c_str());
        if (dp) {
            struct dirent* ep;
            while ((ep = readdir(dp)) != nullptr) {
                std::string fname = ep->d_name;
                if (fname.size() > 4 && fname.substr(fname.size() - 4) == ".cfg") {
                    std::string cname = fname.substr(0, fname.size() - 4);
                    list.push_back(cname);
                }
            }
            closedir(dp);
        }
        if (list.empty()) {
            list.push_back("Default");
            SaveNamedConfig("Default");
        }
        std::sort(list.begin(), list.end());
        return list;
    }

    bool SaveNamedConfig(const std::string& name) {
        if (name.empty()) return false;
        std::string clean = name;
        clean.erase(std::remove_if(clean.begin(), clean.end(), [](char c) {
            return c == '/' || c == '\\' || c == ':' || c == '*' || c == '?' || c == '"' || c == '<' || c == '>' || c == '|';
        }), clean.end());
        if (clean.empty()) clean = "Config";

        std::string dir = GetConfigDirectory();
        std::string filepath = dir + "/" + clean + ".cfg";
        std::ofstream fout(filepath, std::ios::out | std::ios::trunc);
        if (!fout.is_open()) return false;

        std::ostringstream ss;
        SerializeConfigStream(ss);
        fout << ss.str();
        fout.close();

        strncpy(g_ActiveConfigName, clean.c_str(), sizeof(g_ActiveConfigName) - 1);
        g_ActiveConfigName[sizeof(g_ActiveConfigName) - 1] = '\0';
        return true;
    }

    bool LoadNamedConfig(const std::string& name) {
        if (name.empty()) return false;
        std::string dir = GetConfigDirectory();
        std::string filepath = dir + "/" + name + ".cfg";
        std::ifstream fin(filepath, std::ios::binary);
        if (!fin.is_open()) return false;

        std::string blob((std::istreambuf_iterator<char>(fin)), std::istreambuf_iterator<char>());
        fin.close();

        std::istringstream iss(blob);
        ParseConfigStream(iss);

        strncpy(g_ActiveConfigName, name.c_str(), sizeof(g_ActiveConfigName) - 1);
        g_ActiveConfigName[sizeof(g_ActiveConfigName) - 1] = '\0';
        return true;
    }

    bool DeleteNamedConfig(const std::string& name) {
        if (name.empty()) return false;
        std::string dir = GetConfigDirectory();
        std::string filepath = dir + "/" + name + ".cfg";
        int res = std::remove(filepath.c_str());
        if (res != 0) {
            unlink(filepath.c_str());
        }
        if (name == g_ActiveConfigName) {
            strncpy(g_ActiveConfigName, "Default", sizeof(g_ActiveConfigName) - 1);
            g_ActiveConfigName[sizeof(g_ActiveConfigName) - 1] = '\0';
        }
        return true;
    }
}
