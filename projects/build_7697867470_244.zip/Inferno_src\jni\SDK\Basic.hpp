#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <cstring>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <iostream>
#include <chrono>
#include "Offsets.hpp"
#include "../Memory/Tools.h"

namespace SDK
{

template <typename Fn>
inline Fn GetVFunction(const void *instance, size_t index)
{
    if (!instance) return nullptr;
    auto vtable = *reinterpret_cast<void ***>(const_cast<void *>(instance));
    if (!vtable) return nullptr;
    return reinterpret_cast<Fn>(vtable[index]);
}

class UObject;
class UClass;
class UFunction;
class UStruct;
class UField;

class FUObjectItem
{
public:
    UObject *Object;        // 0x00(0x8)
    int32_t Flags;          // 0x08(0x4)
    int32_t ClusterIndex;   // 0x0C(0x4)
    int32_t SerialNumber;   // 0x10(0x4)
    int32_t Pad;            // 0x14(0x4) -> total 0x18

    inline bool IsUnreachable() const { return (Flags & (1 << 28)) != 0; }
    inline bool IsPendingKill() const { return (Flags & (1 << 29)) != 0; }
};
static_assert(sizeof(FUObjectItem) == 0x18, "FUObjectItem size must be 0x18");

class TUObjectArray
{
public:
    FUObjectItem** Objects;             // 0x00(0x8)
    FUObjectItem* PreAllocatedObjects;  // 0x08(0x8)
    int32_t MaxElements;                // 0x10(0x4)
    int32_t NumElements;                // 0x14(0x4)
    int32_t MaxChunks;                  // 0x18(0x4)
    int32_t NumChunks;                  // 0x1C(0x4)

    static constexpr int32_t NumElementsPerChunk = 64 * 1024; // 0x10000

    inline int32_t Num() const { return NumElements; }

    inline UObject *GetByIndex(int32_t index) const
    {
        if (index < 0 || index >= NumElements || !Objects) return nullptr;
        if (!Tools::IsReadable(const_cast<FUObjectItem**>(Objects), sizeof(void*))) return nullptr;

        int32_t chunkIndex = index / NumElementsPerChunk;
        int32_t withinChunkIndex = index % NumElementsPerChunk;
        if (chunkIndex < 0 || (NumChunks > 0 && chunkIndex >= NumChunks)) return nullptr;

        if (!Tools::IsReadable(const_cast<FUObjectItem**>(Objects + chunkIndex), sizeof(void*))) return nullptr;
        FUObjectItem* chunk = Objects[chunkIndex];
        if (!chunk || !Tools::IsPtrValid(chunk)) return nullptr;

        FUObjectItem* item = &chunk[withinChunkIndex];
        if (!Tools::IsReadable(item, sizeof(FUObjectItem))) return nullptr;
        if (item->IsUnreachable() || item->IsPendingKill()) return nullptr;

        UObject* obj = item->Object;
        if (!obj || !Tools::IsPtrValid(obj)) return nullptr;
        return obj;
    }

    inline FUObjectItem *GetItemByIndex(int32_t index) const
    {
        if (index < 0 || index >= NumElements || !Objects) return nullptr;
        if (!Tools::IsReadable(const_cast<FUObjectItem**>(Objects), sizeof(void*))) return nullptr;

        int32_t chunkIndex = index / NumElementsPerChunk;
        int32_t withinChunkIndex = index % NumElementsPerChunk;
        if (chunkIndex < 0 || (NumChunks > 0 && chunkIndex >= NumChunks)) return nullptr;

        if (!Tools::IsReadable(const_cast<FUObjectItem**>(Objects + chunkIndex), sizeof(void*))) return nullptr;
        FUObjectItem* chunk = Objects[chunkIndex];
        if (!chunk || !Tools::IsPtrValid(chunk)) return nullptr;

        FUObjectItem* item = &chunk[withinChunkIndex];
        if (!Tools::IsReadable(item, sizeof(FUObjectItem))) return nullptr;
        return item;
    }
};
static_assert(offsetof(TUObjectArray, NumElements) == 0x14, "TUObjectArray::NumElements must be at 0x14");

class FUObjectArray
{
public:
    uint8_t Pad_0x00[0x40];
    TUObjectArray ObjObjects; // 0x40
};

template <class T>
class TArray
{
protected:
    T *Data;
    int32_t NumElements;
    int32_t MaxElements;

public:
    inline TArray() : Data(nullptr), NumElements(0), MaxElements(0) {}
    inline TArray(int size) : NumElements(0), MaxElements(size), Data(reinterpret_cast<T *>(calloc(1, sizeof(T) * size))) {}

    inline T &operator[](int i) { return Data[i]; }
    inline const T &operator[](int i) const { return Data[i]; }
    inline bool IsValidIndex(int index) const { return index >= 0 && index < NumElements; }
    inline int Num() const { return NumElements; }
    inline int Max() const { return MaxElements; }
    inline T *GetData() const { return Data; }

    inline bool Add(const T &element)
    {
        if (NumElements >= MaxElements) return false;
        Data[NumElements++] = element;
        return true;
    }
};

class FString : public TArray<wchar_t>
{
public:
    FString() = default;
    inline FString(const wchar_t *wstr)
    {
        MaxElements = NumElements = (wstr && *wstr) ? int32_t(std::wcslen(wstr)) + 1 : 0;
        if (NumElements) Data = const_cast<wchar_t *>(wstr);
    }
    inline std::wstring ToWString() const { return Data ? Data : L""; }
    std::string ToString() const;
};

class FName
{
public:
    int32_t ComparisonIndex;
    int32_t Number;

    inline FName() : ComparisonIndex(0), Number(0) {}
    inline FName(int32_t index) : ComparisonIndex(index), Number(0) {}
    FName(const char *name);

    std::string GetName() const;

    inline bool operator==(const FName &other) const
    {
        return ComparisonIndex == other.ComparisonIndex && Number == other.Number;
    }
    inline bool operator!=(const FName &other) const
    {
        return !(*this == other);
    }
};

struct FText
{
    uint8_t Pad[0x18];
};

struct FScriptDelegate
{
    uint8_t Pad[0x10];
};

struct FScriptMulticastDelegate
{
    uint8_t Pad[0x10];
};

template <typename Key, typename Value>
class TMap
{
    uint8_t Pad[0x50];
};

template <typename Element>
class TSet
{
    uint8_t Pad[0x50];
};

template <typename KeyType, typename ValueType>
class TPair
{
public:
    KeyType Key;
    ValueType Value;
};

template <class TEnum>
class TEnumAsByte
{
public:
    uint8_t Value;
    inline TEnumAsByte() : Value(0) {}
    inline TEnumAsByte(TEnum val) : Value(static_cast<uint8_t>(val)) {}
    inline operator TEnum() const { return static_cast<TEnum>(Value); }
    inline TEnum GetValue() const { return static_cast<TEnum>(Value); }
};

struct FWeakObjectPtr
{
    int32_t ObjectIndex;
    int32_t ObjectSerialNumber;
    UObject *Get() const;
    bool IsValid() const;
};

template <typename T>
struct TWeakObjectPtr : public FWeakObjectPtr
{
    inline T *Get() const { return reinterpret_cast<T *>(FWeakObjectPtr::Get()); }
    inline T *operator->() const { return Get(); }
    inline T &operator*() const { return *Get(); }
};

class FScriptInterface
{
public:
    UObject *ObjectPointer;
    void *InterfacePointer;
};

template <class InterfaceType>
class TScriptInterface : public FScriptInterface
{
public:
    inline InterfaceType *operator->() const { return reinterpret_cast<InterfaceType *>(InterfacePointer); }
    inline InterfaceType &operator*() const { return *reinterpret_cast<InterfaceType *>(InterfacePointer); }
};

class UObject
{
public:
    void *VTable;
    int32_t ObjectFlags;
    int32_t InternalIndex;
    UClass *ClassPrivate;
    FName NamePrivate;
    UObject *OuterPrivate;

    static class TUObjectArray *GObjects;
    static void *GNames;
    static uintptr_t ProcessEventAddr;
    static int32_t ProcessEventIndex;
    static uintptr_t GLibBase;

    static void Init(uintptr_t libBase);
    // Э4: set the server-authenticated unlock secret (from `uk`), then call Init
    // again to recompute GNames/GObjects/ProcessEventAddr with the real offsets.
    static void SetOffsetKey(uint32_t key);
    static uintptr_t UnmaskPtr(uintptr_t masked);

    std::string GetName() const;
    std::string GetFullName() const;
    // Outer (owner) object, or nullptr if the pointer is missing/unreadable.
    // Used to qualify name-only function matches (e.g. the many "GetHealth"s).
    UObject *GetOuter() const
    {
        if (!Tools::IsPtrValid(OuterPrivate)) return nullptr;
        if (!Tools::IsReadable(OuterPrivate, sizeof(UObject))) return nullptr;
        return OuterPrivate;
    }
    std::string GetCppName() const;
    bool IsA(UClass *cmp) const;

    void ProcessEvent(UFunction *function, void *parms);

    template <typename T = UObject>
    static T *FindObject(const std::string &fullName)
    {
        if (!GObjects || !Tools::IsPtrValid(GObjects)) return nullptr;

        struct CacheEntry {
            UObject* obj = nullptr;
            int64_t lastSearchMs = 0;
        };
        static std::unordered_map<std::string, CacheEntry> s_Cache;
        auto now = std::chrono::steady_clock::now();
        int64_t nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count();

        auto it = s_Cache.find(fullName);
        if (it != s_Cache.end()) {
            if (it->second.obj != nullptr) {
                return reinterpret_cast<T *>(it->second.obj);
            }
            // Throttled: do not re-scan for at least 5000ms if failed
            if (nowMs - it->second.lastSearchMs < 5000) {
                return nullptr;
            }
        }

        int32_t count = GObjects->Num();
        if (count <= 0 || count > 2000000) return nullptr;

        for (int32_t i = 0; i < count; i++)
        {
            UObject *obj = GObjects->GetByIndex(i);
            if (!obj || !Tools::IsPtrValid(obj)) continue;
            if (obj->GetFullName() == fullName)
            {
                s_Cache[fullName] = {obj, nowMs};
                return reinterpret_cast<T *>(obj);
            }
        }

        s_Cache[fullName] = {nullptr, nowMs};
        return nullptr;
    }

    template <typename T = UObject>
    static T *FindObjectFast(const std::string &name)
    {
        if (!GObjects || !Tools::IsPtrValid(GObjects)) return nullptr;

        struct CacheEntry {
            UObject* obj = nullptr;
            int64_t lastSearchMs = 0;
        };
        static std::unordered_map<std::string, CacheEntry> s_Cache;
        auto now = std::chrono::steady_clock::now();
        int64_t nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count();

        auto it = s_Cache.find(name);
        if (it != s_Cache.end()) {
            if (it->second.obj != nullptr && Tools::IsPtrValid(it->second.obj)) {
                return reinterpret_cast<T *>(it->second.obj);
            }
            if (nowMs - it->second.lastSearchMs < 3000) {
                return nullptr;
            }
        }

        int32_t count = GObjects->Num();
        if (count <= 0 || count > 2000000) return nullptr;

        // 1. Exact match pass
        for (int32_t i = 0; i < count; i++)
        {
            UObject *obj = GObjects->GetByIndex(i);
            if (!obj || !Tools::IsPtrValid(obj)) continue;
            std::string objName = obj->GetName();
            if (objName == name)
            {
                s_Cache[name] = {obj, nowMs};
                return reinterpret_cast<T *>(obj);
            }
        }

        auto isClassObj = [](UObject* o) -> bool {
            if (!o || !Tools::IsPtrValid(o)) return false;
            std::string fullName = o->GetFullName();
            return (fullName.rfind("Class ", 0) == 0 ||
                    fullName.rfind("BlueprintGeneratedClass ", 0) == 0 ||
                    fullName.rfind("WidgetBlueprintGeneratedClass ", 0) == 0 ||
                    fullName.rfind("DynamicClass ", 0) == 0);
        };

        bool queryIsClass = std::is_same<T, UClass>::value || (name.find("Class") != std::string::npos);

        // 2. Substring match pass (prioritize UClass if looking for a class)
        for (int32_t i = 0; i < count; i++)
        {
            UObject *obj = GObjects->GetByIndex(i);
            if (!obj || !Tools::IsPtrValid(obj)) continue;
            if (queryIsClass && !isClassObj(obj)) continue;

            std::string objName = obj->GetName();
            if (objName.find(name) != std::string::npos)
            {
                s_Cache[name] = {obj, nowMs};
                return reinterpret_cast<T *>(obj);
            }
        }

        s_Cache[name] = {nullptr, nowMs};
        return nullptr;
    }

    static UClass *StaticClass();
};

class UField : public UObject
{
public:
    UField *Next; // 0x28
    static UClass *StaticClass();
};
static_assert(sizeof(UField) == 0x30, "UField size must be 0x30");

class UStruct : public UField
{
public:
    uint8_t Pad_0x30[0x10]; // 0x30 - 0x40: FStructBaseChain (StructBaseChainArray + NumStructBases)
    UStruct *SuperStruct;   // 0x40
    UField *Children;       // 0x48
    void *ChildProperties;  // 0x50
    int32_t PropertiesSize; // 0x58
    int32_t MinAlignment;   // 0x5C
    uint8_t Pad_0x60[0x50]; // 0x60 - 0xB0
    int32_t FindPropertyOffset(const char* propName) const;
    static UClass *StaticClass();
};
static_assert(sizeof(UStruct) == 0xB0, "UStruct size must be 0xB0");
static_assert(offsetof(UStruct, SuperStruct) == 0x40, "SuperStruct must be at 0x40");

class UClass : public UStruct
{
public:
    uint8_t Pad_Class[0x1B0]; // 0xB0 - 0x260
    static UClass *StaticClass();
};
static_assert(sizeof(UClass) == 0x260, "UClass size must be 0x260");

class UFunction : public UStruct
{
public:
    int32_t FunctionFlags;  // 0xB0
    uint8_t NumParms;       // 0xB4
    uint8_t ParmsSize;      // 0xB5
    uint8_t Pad_Func[0x2A]; // 0xB6 - 0xE0
    static UClass *StaticClass();
};
static_assert(sizeof(UFunction) == 0xE0, "UFunction size must be 0xE0");

} // namespace SDK
