#pragma once
#include "ImGui/imgui.h"

namespace LiquidGlass
{
    struct Params
    {
        float exponent     = 8.0f;
        float lensBand     = 0.25f;
        float lensStrength = 1.5f;
        float blur         = 3.5f;
        float aberration   = 5.0f;
        float tint         = 0.55f;
        float rim          = 0.18f;
        float edgeSoftness = 1.5f;
        float shape        = 0.0f;  // 0 = hyperellipse, 1 = capsule
    };

    bool Init();
    void Shutdown();
    // Call once per frame before ImGui::NewFrame(), captures current framebuffer
    void CaptureSnapshot(int width, int height);
    void Draw(ImDrawList* dl, ImVec2 center, ImVec2 halfSize, const Params& p,
              ImU32 tint = IM_COL32_WHITE);
}
