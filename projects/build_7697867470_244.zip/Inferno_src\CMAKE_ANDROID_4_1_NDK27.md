# CMake 4.1 + Android NDK 27 configuration

Updated the project CMake files for CMake 4.1.x and Android NDK 27.x.

## Changes

- Raised `cmake_minimum_required` from `3.10.2` to `3.22...4.1` in both project CMake files.
- Added `CMAKE_WARN_DEPRECATED=OFF` before the top-level `project()` call. This suppresses the legacy-toolchain deprecation warning emitted by NDK 27 without editing files inside the Android SDK/NDK installation.
- Kept the existing Android target and compiler/linker optimization settings unchanged.

## Clean configure/build on Windows

From `Engine_Android\\Engine_Android`:

```bat
rmdir /s /q build_cmake

cmake -S . -B build_cmake -G Ninja ^
  -DCMAKE_TOOLCHAIN_FILE=%LOCALAPPDATA%\\Android\\Sdk\\ndk\\27.0.12077973\\build\\cmake\\android.toolchain.cmake ^
  -DANDROID_ABI=arm64-v8a ^
  -DANDROID_PLATFORM=android-24

cmake --build build_cmake --parallel
```

If the NDK is installed elsewhere, adjust `CMAKE_TOOLCHAIN_FILE` accordingly.

## Note

The deprecation warning originates in NDK 27's `android-legacy.toolchain.cmake`; the project does **not** modify that SDK file.
