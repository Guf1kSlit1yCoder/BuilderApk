#pragma once
#include <vector>
#include <string>
#include <cstdint>
#include "Memory/Tools.h"
#include "SDK/SDK.hpp"
#include "UE4Helper.h"

namespace ActorPipeline {

    enum class EntityType : uint8_t {
        Unknown = 0,
        LocalPlayer,
        EnemyPlayer,
        Teammate,
        Bot,
        NPC,        // MFNPCAI package — shown as "ACTOR" on screen
        DeadBody,
        Item,
        LootBox,
        Vehicle
    };

    struct EntityData {
        SDK::AActor* rawActor = nullptr;
        SDK::ASGCharacter* character = nullptr;
        EntityType type = EntityType::Unknown;

        SDK::FVector rootPos{0, 0, 0};
        SDK::FVector headPos{0, 0, 0};
        SDK::FVector feetPos{0, 0, 0};
        float capsuleHalfHeight = 88.0f;
        float capsuleRadius = 34.0f;

        float health = -1.0f;
        float maxHealth = -1.0f;
        int32_t teamId = 0;
        float distance = 0.0f;

        bool isBot = false;
        bool isNPC = false;      // MFNPCAI actor — subset of isBot, shown as "ACTOR"
        bool isTeammate = false;
        bool isKnocked = false;
        bool isDead = false;
        bool isVisible = false;
        bool stale = false;      // proxy position frozen > ~2s: player left relevancy (ghost)
        bool proxyOnly = false;  // emitted from a fast-rep proxy with no loaded character
        // Per-bone ray visibility (ESP skeleton order); valid only when boneVisLive.
        uint16_t boneVisible = 0;
        bool boneVisLive = false;

        std::string name;

        // 2D Screen Cache
        SDK::FVector2D screenRoot{0, 0};
        SDK::FVector2D screenHead{0, 0};
        SDK::FVector2D screenFeet{0, 0};
        bool onScreen = false;
        float boxLeft = 0.0f;
        float boxTop = 0.0f;
        float boxWidth = 0.0f;
        float boxHeight = 0.0f;
    };

    // Reject destroyed objects before dereferencing cached actor pointers.
    inline bool IsObjectValid(SDK::UObject* obj) {
        if (!obj || !Tools::IsPtrValid(obj) || !Tools::IsReadable(obj, sizeof(SDK::UObject))) return false;
        auto objects = SDK::UObject::GObjects;
        if (!objects || !Tools::IsPtrValid(objects)) return false;
        auto item = objects->GetItemByIndex(obj->InternalIndex);
        if (!item || item->Object != obj || item->IsUnreachable() || item->IsPendingKill()) return false;
        return obj->ClassPrivate && Tools::IsPtrValid(obj->ClassPrivate) &&
            Tools::IsReadable(obj->ClassPrivate, sizeof(SDK::UClass));
    }

    // Pipeline interface (render-thread owned).
    void Init();
    void Reset();
    void Update(SDK::UWorld* world, SDK::ASGCharacter* localPlayer, SDK::ASGPlayerController* controller,
                const UE4Helper::ScreenProjection& projection);

    const std::vector<EntityData>& GetEnemies();
    const std::vector<EntityData>& GetDeadBodies();
    const std::vector<EntityData>& GetItems();
    const std::vector<EntityData>& GetLootBoxes();

    SDK::ASGCharacterFastRepProxy* GetFastRepForChar(SDK::ASGCharacter* character);
}
