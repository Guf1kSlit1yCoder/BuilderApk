#pragma once
#include <cstdint>
#include <string>
#include <cstdint>
#include "AntiCrack/ObfStr.h"

struct ConfigState {
    // Player ESP
    bool esp_enabled = false;
    bool esp_box = true;
    int  esp_box_type = 1; // 1: 2D, 2: 3D
    bool esp_skeleton = true;
    bool esp_name = true;
    bool esp_distance = true;
    bool esp_health = true;
    int  esp_health_type = 1; // 0: Numeric, 1: Bar
    bool esp_weapon = false;
    bool esp_team_id = false;
    bool esp_line = false;
    int  esp_line_origin = 0; // 0: top-centre, 1: screen centre, 2: bottom-centre
    bool esp_head_dot = false;
    bool esp_bots = true;
    bool esp_teammates = true;   // Show teammates in ESP (green)
    bool esp_outline = false;
    float esp_box_thickness = 1.5f;
    float esp_skeleton_thickness = 1.5f;
    int esp_text_size = 14;
    // ESP diagnostics: logs when a live enemy exists but ESP doesn't draw it
    // (missing box, off-screen projection, filtered out, or the list suddenly
    // emptying while a player is near) — written to the crash log for analysis.
    bool esp_log = false;
    // Anti-ghost: hide ESP and skip aim for players whose fast-rep position froze
    // (they left network relevancy). Otherwise ESP/skeleton/box stick to a stale
    // spot the player already left — you run there and nobody is there.
    bool esp_anti_ghost = true;
    float esp_ghost_seconds = 2.0f; // freeze time before a target counts as a ghost
    // Calibration overlay: on each PLAYER draw 3 letters at 3 position sources so
    // it is visible which one sits on the real player — T=body(RootComponent),
    // S=skeleton(pelvis bone), B=box(fast-rep rootPos). Bots are skipped.
    bool esp_calibrate = false;
    // Enemy counter own colour pair (independent of the menu theme). The counter
    // text animates (shimmers) between these two colours.
    float col_counter_a[4] = { 1.00f, 1.00f, 1.00f, 1.0f };  // counter colour 1
    float col_counter_b[4] = { 0.86f, 0.24f, 0.24f, 1.0f };  // counter colour 2

    // Items & Vehicles ESP
    bool esp_items = false;              // Enable item ESP (off by default to avoid screen clutter)
    int  item_esp_max_distance = 150;    // Max distance in meters for item display
    bool esp_vehicles = false;
    bool esp_vehicle_hp = false;
    bool esp_vehicle_fuel = false;
    bool esp_airdrop = false;
    bool esp_lootbox = false;
    bool esp_dead_bodies = false;        // Отображать трупы (Corpse ESP)
    bool esp_filter_opened_boxes = true; // Скрывать открытые / обысканные ящики
    bool ammo_hud_enabled = true;        // Плавающий счетчик патронов
    bool ammo_hud_locked = false;        // Зафиксировать позицию счетчика патронов
    float ammo_hud_x = 180.0f;           // X позиция счетчика патронов
    float ammo_hud_y = 400.0f;           // Y позиция счетчика патронов
    bool esp_grenade_warning = false;
    bool esp_ar = false;
    bool esp_smg = false;
    bool esp_sniper = false;
    bool esp_shotgun = false;
    bool esp_ammo = false;
    bool esp_armor = false;
    bool esp_meds = false;
    bool esp_scopes = false;


    // Radar & Offscreen
    bool esp_radar = false;
    int radar_distance = 150;
    int radar_center_x = 120;
    int radar_center_y = 120;
    int radar_size = 100;
    bool esp_offscreen = false;
    int offscreen_range = 40;
    int max_distance_offscreen = 400;

    // Aimbot
    bool aimbot_enabled = false;
    bool aimbot_fov = false;
    float aimbot_fov_radius = 240.0f;
    float col_aimbot_fov[4] = { 1.0f, 1.0f, 1.0f, 0.60f };
    float aimbot_smooth = 8.0f;
    int aimbot_bone = 0; // 0: Auto (Open Bones), 1: Head, 2: Neck, 3: Chest, 4: Pelvis
    int aimbot_priority = 0; // 0: Distance (Closest), 1: Crosshair
    bool aimbot_open_bones_first = true; // Priority iteration over open bones (Head top priority)
    bool aimbot_ignore_bots = false;
    bool aimbot_ignore_knocked = true;
    bool aimbot_visible_only = true;
    bool aimbot_prediction = true;
    float aimbot_bullet_speed = 80000.0f; // cm/s, for bullet-lead + drop prediction
    bool aimbot_auto_fire = false;
    int aimbot_auto_fire_interval = 1;
    bool aimbot_silent = false;
    bool aimbot_trigger = false;
    bool aimbot_on_fire = false; // Aim while shooting in game
    bool aimbot_touch_zone = false; // Separate touch trigger zone (Scope / ADS)
    float aimbot_fire_zone_x = 0.85f;  // center X, fraction of screen width
    float aimbot_fire_zone_y = 0.72f;  // center Y, fraction of screen height
    float aimbot_fire_zone_r = 130.0f; // radius in display pixels
    bool  aimbot_fire_zone_locked = false; // false: draggable; true: fixed & active
    // Vertical aim adjust: shift the aim point up/down in cm along world Z.
    // Negative lowers the aim (fix "hits above the head"), positive raises it.
    bool  aimbot_vertical = false;
    float aimbot_vertical_offset = 0.0f; // cm, range e.g. -50..+50
    bool  aimbot_log = false;            // write aim analysis to the crash log

    // Memory Hacks
    bool mem_no_recoil = false;
    bool mem_fast_shoot = false;
    bool mem_instant_hit = false;
    bool mem_fast_bullet = false;
    bool mem_wide_view = false;
    float mem_wide_view_fov = 105.0f;
    bool mem_no_camera_shake = false;
    bool mem_crosshair = false;

    // UI & System
    bool menu_open = false;
    bool arabic_language = false;
    float menu_scale = 1.0f;
    int target_fps = 60;
    bool russian_language = false;

    // ESP colours (ImU32, ABGR). Used for enemies when esp_custom_colors is on.
    bool esp_custom_colors = true;
    uint32_t col_box_vis  = 0xFF2828FF;   // red
    uint32_t col_box_hid  = 0xFFF03CB4;   // purple
    uint32_t col_line_vis = 0xFF2828FF;
    uint32_t col_line_hid = 0xFFF03CB4;
    uint32_t col_skel_vis = 0xFF5AFF28;   // green
    uint32_t col_skel_hid = 0xD2969696;   // grey

    // Player & Bot specific colors: Skeletons and Lines (Separated into Open/Visible & Covered/Hidden)
    float col_player_skel_vis[4] = { 1.00f, 0.20f, 0.20f, 1.0f }; // Player Skeleton (Open / Visible)
    float col_player_skel_hid[4] = { 0.85f, 0.25f, 0.85f, 0.85f }; // Player Skeleton (Covered / Hidden)
    float col_player_line_vis[4] = { 1.00f, 0.25f, 0.25f, 1.0f }; // Player Snapline (Open / Visible)
    float col_player_line_hid[4] = { 0.75f, 0.20f, 0.75f, 0.80f }; // Player Snapline (Covered / Hidden)

    float col_bot_skel_vis[4]    = { 0.20f, 0.85f, 0.35f, 1.0f }; // Bot Skeleton (Open / Visible)
    float col_bot_skel_hid[4]    = { 0.80f, 0.80f, 0.80f, 0.85f }; // Bot Skeleton (Covered / Hidden)
    float col_bot_line_vis[4]    = { 0.25f, 0.90f, 0.40f, 1.0f }; // Bot Snapline (Open / Visible)
    float col_bot_line_hid[4]    = { 0.70f, 0.70f, 0.70f, 0.80f }; // Bot Snapline (Covered / Hidden)

    float touch_scale_x = 1.0f;
    float touch_scale_y = 1.0f;
    std::string config_path = (const char*)OBFSTR("/sdcard/Download/.acfg");

    // Login
    bool        is_logged_in  = false;
    char        login_key[128] = {};
    std::string login_expiry  = "";
};

#include <vector>

extern ConfigState g_Config;

namespace ConfigManager {
    void LoadConfig(const std::string& path = "");
    void SaveConfig(const std::string& path = "");
    void ResetToDefaults();
    void RequestAutoSave();
    void UpdateAutoSave(float dt);

    // Multi-Config System with shareable file support
    std::string GetConfigDirectory();
    std::vector<std::string> GetConfigList();
    bool SaveNamedConfig(const std::string& name);
    bool LoadNamedConfig(const std::string& name);
    bool DeleteNamedConfig(const std::string& name);

    extern bool g_AutoSaveMode;
    extern char g_ActiveConfigName[64];
    extern char g_NewConfigName[64];
}
