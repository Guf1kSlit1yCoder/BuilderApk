#define IMGUI_DEFINE_MATH_OPERATORS
#include "Menu.h"
#include "VandalAuth.h"
#include "Lang.h"
#include "../Login.h"
#include "../Core/UE4Helper.h"
#include <thread>
#include <atomic>
#include "bg_texture.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_internal.h"
#include "MirageMenu.hpp"
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <cctype>
#include <string>
#include <unordered_map>
#include <vector>

// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
//  MONOCHROME TERMINAL PALETTE
// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
#define HK_BLACK       IM_COL32(  3,   3,   3, 255)
#define HK_BG          IM_COL32(  8,   8,   8, 248)
#define HK_PANEL       IM_COL32( 13,  13,  13, 242)
#define HK_PANEL2      IM_COL32( 20,  20,  20, 235)
#define HK_WHITE       IM_COL32(255, 255, 255, 255)
#define HK_WHITE2      IM_COL32(220, 220, 220, 255)
#define HK_GRAY        IM_COL32(160, 160, 160, 200)
#define HK_GRAY_DARK   IM_COL32( 55,  55,  55, 255)
#define HK_LIGHT       IM_COL32(200, 200, 200, 255)
#define HK_LIGHT_DIM   IM_COL32(140, 140, 140, 160)
#define HK_DANGER      IM_COL32(190, 190, 190, 255)
#define HK_TEXT        IM_COL32(240, 240, 240, 230)
#define HK_TEXT_DIM    IM_COL32(150, 150, 150, 180)
#define HK_TEXT_FAINT  IM_COL32( 80,  80,  80, 120)
#define HK_BORDER      IM_COL32(200, 200, 200,  80)
#define HK_SCANLINE    IM_COL32(255, 255, 255,   6)

// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
//  UTILITIES
// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
static inline ImU32 HkA(ImU32 col, float a) {
    if (a <= 0.0f) return col & 0x00FFFFFF;
    if (a >= 1.0f) return col;
    ImU32 alpha = (ImU32)(((col >> IM_COL32_A_SHIFT) & 0xFF) * a + 0.5f);
    return (col & ~(0xFFu << IM_COL32_A_SHIFT)) | (alpha << IM_COL32_A_SHIFT);
}

static inline float HkPulse(float freq = 2.0f, float phase = 0.0f) {
    return 0.5f + 0.5f * sinf((float)ImGui::GetTime() * freq + phase);
}

static inline float HkClamp01(float v) { return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v); }

static float g_Dpi       = 1.0f;
static int   g_ActiveTab = 0;

// True once the current press has turned into a vertical scroll; widgets then
// ignore the release so scrolling never toggles anything.
static bool  s_ScrollGesture = false;
static float s_ScrollVel     = 0.0f;

static bool HkVerticalDrag() {
    const ImVec2 d = ImGui::GetMouseDragDelta(0, 0.0f);
    return fabsf(d.y) > 4.0f && fabsf(d.y) > fabsf(d.x);
}

// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
//  MATRIX HEADER
// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
struct HkMCol { float x, y, spd; int len; char ch[20]; };

static HkMCol s_MCols[20];
static bool   s_MColsInit = false;

static const char s_MChars[] = "0123456789ABCDEF><|/\\:;[]@#!?";
static const int  s_MCharsN  = (int)(sizeof(s_MChars) - 1);

static void InitMatrixCols(float w, float h) {
    for (int i = 0; i < 20; ++i) {
        float spacing = w / 20.0f;
        s_MCols[i].x   = spacing * i + spacing * 0.5f;
        s_MCols[i].y   = -(h * ((float)(i * 37 % 100) / 100.0f));
        s_MCols[i].spd = 50.0f + (float)((i * 47) % 70);
        s_MCols[i].len = 4 + (i % 5);
        for (int j = 0; j < 20; j++)
            s_MCols[i].ch[j] = s_MChars[(i * 13 + j * 7) % s_MCharsN];
    }
    s_MColsInit = true;
}

static void DrawMatrixRain(ImDrawList* dl, ImVec2 p0, float w, float h) {
    if (!s_MColsInit) InitMatrixCols(w, h);

    static float s_Prev = 0.0f;
    float t  = (float)ImGui::GetTime();
    float dt = t - s_Prev;
    s_Prev   = t;
    if (dt > 0.08f) dt = 0.08f;

    float charH = ImGui::GetTextLineHeight();

    for (int i = 0; i < 20; ++i) {
        HkMCol& c = s_MCols[i];
        c.y += c.spd * dt;
        if (c.y > h + charH * c.len) {
            c.y   = -charH * c.len;
            c.spd = 45.0f + (float)(((i + (int)(t * 3)) * 53) % 75);
            c.len = 3 + (((int)(t * 7) + i) % 6);
        }
        if (((int)(t * 8 + i) & 31) == 0) {
            int r = (int)(t * 23 + i * 11) % 20;
            c.ch[r % 20] = s_MChars[(int)(t * 17 + r) % s_MCharsN];
        }
        float cx = p0.x + c.x;
        for (int j = 0; j < c.len; ++j) {
            float cy = p0.y + c.y - j * charH;
            if (cy < p0.y || cy > p0.y + h) continue;
            float fade = 1.0f - (float)j / c.len;
            ImU32 col = j == 0 ? HkA(HK_WHITE, 0.55f)
                      : j == 1 ? HkA(HK_WHITE, fade * 0.32f)
                               : HkA(HK_WHITE, fade * 0.15f);
            char buf[2] = { c.ch[j % 20], 0 };
            dl->AddText(ImVec2(cx, cy), col, buf);
        }
    }

    static float s_Scan = 0.0f;
    s_Scan += dt * 120.0f * g_Dpi;
    if (s_Scan > h) s_Scan = 0.0f;
    dl->AddRectFilled(ImVec2(p0.x, p0.y + s_Scan - 2.0f),
                      ImVec2(p0.x + w, p0.y + s_Scan + 3.0f), HK_SCANLINE);
}

static void DrawScanlines(ImDrawList* dl, ImVec2 p0, ImVec2 p1) {
    for (float y = p0.y + 5.0f; y < p1.y; y += 5.0f)
        dl->AddLine(ImVec2(p0.x, y), ImVec2(p1.x, y), HK_SCANLINE);
}

static void DrawGlowBorder(ImDrawList* dl, ImVec2 p0, ImVec2 p1, ImU32 col, float rounding = 4.0f) {
    float pulse = HkPulse(1.8f);
    dl->AddRect(ImVec2(p0.x-3,p0.y-3), ImVec2(p1.x+3,p1.y+3), HkA(col, 0.10f + 0.06f * pulse), rounding + 3.0f, 0, 1.0f);
    dl->AddRect(ImVec2(p0.x-2,p0.y-2), ImVec2(p1.x+2,p1.y+2), HkA(col, 0.18f + 0.08f * pulse), rounding + 2.0f, 0, 1.0f);
    dl->AddRect(ImVec2(p0.x-1,p0.y-1), ImVec2(p1.x+1,p1.y+1), HkA(col, 0.40f + 0.15f * pulse), rounding + 1.0f, 0, 1.3f);
    dl->AddRect(p0, p1,                                          HkA(col, 0.70f + 0.20f * pulse), rounding, 0, 1.5f);
}

static void DrawCorners(ImDrawList* dl, ImVec2 p0, ImVec2 p1, ImU32 col, float sz = 12.0f) {
    float t = 1.5f;
    dl->AddLine(p0, ImVec2(p0.x + sz, p0.y), col, t);
    dl->AddLine(p0, ImVec2(p0.x, p0.y + sz), col, t);
    dl->AddLine(ImVec2(p1.x, p0.y), ImVec2(p1.x - sz, p0.y), col, t);
    dl->AddLine(ImVec2(p1.x, p0.y), ImVec2(p1.x, p0.y + sz), col, t);
    dl->AddLine(ImVec2(p0.x, p1.y), ImVec2(p0.x + sz, p1.y), col, t);
    dl->AddLine(ImVec2(p0.x, p1.y), ImVec2(p0.x, p1.y - sz), col, t);
    dl->AddLine(p1, ImVec2(p1.x - sz, p1.y), col, t);
    dl->AddLine(p1, ImVec2(p1.x, p1.y - sz), col, t);
}

// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
//  WIDGETS
// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
static void HkSection(const char* label) {
    ImDrawList* dl    = ImGui::GetWindowDrawList();
    ImVec2      pos   = ImGui::GetCursorScreenPos();
    float       avail = ImGui::GetContentRegionAvail().x;
    float       lh    = ImGui::GetTextLineHeight();

    float lineY = pos.y + lh * 0.5f;
    dl->AddLine(ImVec2(pos.x + 4.0f, lineY), ImVec2(pos.x + 20.0f, lineY), HK_BORDER, 1.0f);
    dl->AddText(ImVec2(pos.x + 24.0f, pos.y), HK_GRAY, label);
    ImVec2 ts = ImGui::CalcTextSize(label);
    dl->AddLine(ImVec2(pos.x + 28.0f + ts.x, lineY), ImVec2(pos.x + avail - 4.0f, lineY), HK_BORDER, 1.0f);
    ImGui::Dummy(ImVec2(avail, lh + 6.0f));
}

static bool HkToggle(const char* label, bool* value) {
    ImDrawList* dl    = ImGui::GetWindowDrawList();
    float       avail = ImGui::GetContentRegionAvail().x;
    float       rowH  = 50.0f;
    float       swW   = 84.0f, swH = 30.0f;

    ImGui::PushID(label);
    ImVec2 p0 = ImGui::GetCursorScreenPos();

    bool clicked = ImGui::InvisibleButton("##t", ImVec2(avail, rowH)) && !s_ScrollGesture;
    if (clicked) *value = !(*value);
    bool hov = ImGui::IsItemHovered() && !s_ScrollGesture;
    ImVec2 p1(p0.x + avail, p0.y + rowH);

    if (hov) dl->AddRectFilled(p0, p1, HkA(HK_WHITE, 0.045f));

    ImVec2 ls = ImGui::CalcTextSize(label);
    dl->AddText(ImVec2(p0.x + 12.0f, p0.y + (rowH - ls.y) * 0.5f), hov ? HK_TEXT : HK_TEXT_DIM, label);

    float sx0 = p1.x - swW - 10.0f;
    float sy0 = p0.y + (rowH - swH) * 0.5f;
    float sx1 = sx0 + swW;
    float sy1 = sy0 + swH;

    bool  on    = *value;
    float pulse = HkPulse(3.2f);
    ImU32 trackC = on ? HK_GRAY_DARK : IM_COL32(12, 12, 12, 255);
    ImU32 bordC  = on ? HkA(HK_WHITE, 0.65f + 0.30f * pulse) : HkA(HK_BORDER, hov ? 0.75f : 0.45f);

    dl->AddRectFilled(ImVec2(sx0, sy0), ImVec2(sx1, sy1), trackC, 3.0f);
    dl->AddRect(      ImVec2(sx0, sy0), ImVec2(sx1, sy1), bordC,  3.0f, 0, 1.3f);

    const char* lbl = on ? Lang::T("ON", "ВКЛ") : Lang::T("OFF", "ВЫКЛ");
    ImVec2      lsz = ImGui::CalcTextSize(lbl);
    dl->AddText(ImVec2(sx0 + (swW - lsz.x) * 0.5f, sy0 + (swH - lsz.y) * 0.5f), on ? HK_WHITE : HK_TEXT_FAINT, lbl);

    float dotX = on ? sx1 - 9.0f : sx0 + 9.0f;
    float dotY = sy0 + swH * 0.5f;
    dl->AddCircleFilled(ImVec2(dotX, dotY), 5.0f, on ? HkA(HK_WHITE, 0.75f + 0.22f * pulse) : HK_TEXT_FAINT, 8);
    if (on) dl->AddCircle(ImVec2(dotX, dotY), 7.5f, HkA(HK_WHITE, 0.30f * pulse), 8, 1.0f);

    ImGui::PopID();
    return clicked;
}

static void HkSliderBar(ImDrawList* dl, ImVec2 p0, float avail, float t01, bool act, bool hov) {
    const float lh   = ImGui::GetTextLineHeight();
    const float barH = 10.0f;
    const float barW = avail - 10.0f - 84.0f;
    const float barY = p0.y + lh + 14.0f;
    const float bx0  = p0.x + 10.0f;
    const float bx1  = bx0 + barW;
    const float bxF  = bx0 + barW * t01;

    dl->AddRectFilled(ImVec2(bx0, barY), ImVec2(bx1, barY + barH), IM_COL32(12, 12, 12, 255), 2.0f);
    for (int seg = 1; seg < 4; seg++) {
        float sx = bx0 + barW * seg / 4.0f;
        dl->AddLine(ImVec2(sx, barY + 1), ImVec2(sx, barY + barH - 1), HkA(HK_BORDER, 0.35f), 1.0f);
    }
    if (bxF > bx0)
        dl->AddRectFilled(ImVec2(bx0, barY), ImVec2(bxF, barY + barH), HK_GRAY_DARK, 2.0f);
    dl->AddRect(ImVec2(bx0, barY), ImVec2(bx1, barY + barH),
                HkA(HK_BORDER, act ? 0.90f : hov ? 0.65f : 0.40f), 2.0f, 0, 1.0f);

    float kR = act ? 8.0f : hov ? 7.0f : 6.0f;
    float kY = barY + barH * 0.5f;
    dl->AddCircleFilled(ImVec2(bxF, kY), kR, act ? HK_WHITE : hov ? HK_WHITE2 : HK_GRAY, 12);
    if (act) dl->AddCircle(ImVec2(bxF, kY), kR + 3.0f, HkA(HK_WHITE, 0.40f + 0.30f * HkPulse(4.0f)), 12, 1.2f);
}

// Returns the new 0..1 position while the slider is being dragged sideways, or -1.
static float HkSliderInput(ImVec2 p0, float avail, bool act) {
    if (!act || s_ScrollGesture || HkVerticalDrag()) return -1.0f;
    const float barW = avail - 10.0f - 84.0f;
    return HkClamp01((ImGui::GetIO().MousePos.x - (p0.x + 10.0f)) / barW);
}

static bool HkSliderF(const char* label, float* v, float vmin, float vmax, const char* fmt = "%.1f") {
    ImDrawList* dl    = ImGui::GetWindowDrawList();
    float       avail = ImGui::GetContentRegionAvail().x;

    ImGui::PushID(label);
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##sl", ImVec2(avail, 62.0f));
    bool act = ImGui::IsItemActive() && !s_ScrollGesture;
    bool hov = ImGui::IsItemHovered() && !s_ScrollGesture;

    bool changed = false;
    float t = HkSliderInput(p0, avail, act);
    if (t >= 0.0f) {
        float nv = vmin + (vmax - vmin) * t;
        if (nv != *v) { *v = nv; changed = true; }
    }

    dl->AddText(ImVec2(p0.x + 10.0f, p0.y + 4.0f), hov || act ? HK_TEXT : HK_TEXT_DIM, label);
    char vbuf[32];
    snprintf(vbuf, 32, fmt, *v);
    ImVec2 vSz = ImGui::CalcTextSize(vbuf);
    dl->AddText(ImVec2(p0.x + avail - vSz.x - 8.0f, p0.y + 4.0f), act ? HK_WHITE : HK_LIGHT, vbuf);
    HkSliderBar(dl, p0, avail, HkClamp01((*v - vmin) / (vmax - vmin)), act, hov);

    ImGui::PopID();
    return changed;
}

static bool HkSliderI(const char* label, int* v, int vmin, int vmax, const char* suffix = "") {
    ImDrawList* dl    = ImGui::GetWindowDrawList();
    float       avail = ImGui::GetContentRegionAvail().x;

    ImGui::PushID(label);
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##si", ImVec2(avail, 62.0f));
    bool act = ImGui::IsItemActive() && !s_ScrollGesture;
    bool hov = ImGui::IsItemHovered() && !s_ScrollGesture;

    bool changed = false;
    float t = HkSliderInput(p0, avail, act);
    if (t >= 0.0f) {
        int nv = vmin + (int)((vmax - vmin) * t + 0.5f);
        if (nv != *v) { *v = nv; changed = true; }
    }

    dl->AddText(ImVec2(p0.x + 10.0f, p0.y + 4.0f), hov || act ? HK_TEXT : HK_TEXT_DIM, label);
    char vbuf[32];
    snprintf(vbuf, 32, "%d%s", *v, suffix);
    ImVec2 vSz = ImGui::CalcTextSize(vbuf);
    dl->AddText(ImVec2(p0.x + avail - vSz.x - 8.0f, p0.y + 4.0f), act ? HK_WHITE : HK_LIGHT, vbuf);
    HkSliderBar(dl, p0, avail, HkClamp01((float)(*v - vmin) / (float)(vmax - vmin)), act, hov);

    ImGui::PopID();
    return changed;
}

static bool HkCombo(const char* label, const char* const items[], int count, int* cur) {
    ImDrawList* dl    = ImGui::GetWindowDrawList();
    float       avail = ImGui::GetContentRegionAvail().x;
    float       rowH  = 50.0f, dropW = 200.0f, dropH = 34.0f;
    float       lh    = ImGui::GetTextLineHeight();

    ImGui::PushID(label);
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    bool clicked = ImGui::InvisibleButton("##cb", ImVec2(avail, rowH)) && !s_ScrollGesture;
    bool hov     = ImGui::IsItemHovered() && !s_ScrollGesture;

    if (hov) dl->AddRectFilled(p0, ImVec2(p0.x + avail, p0.y + rowH), HkA(HK_WHITE, 0.040f));

    ImVec2 ls = ImGui::CalcTextSize(label);
    dl->AddText(ImVec2(p0.x + 12.0f, p0.y + (rowH - ls.y) * 0.5f), hov ? HK_TEXT : HK_TEXT_DIM, label);

    float dbx0 = p0.x + avail - dropW - 10.0f;
    float dby0 = p0.y + (rowH - dropH) * 0.5f;
    float dbx1 = dbx0 + dropW;
    float dby1 = dby0 + dropH;
    dl->AddRectFilled(ImVec2(dbx0, dby0), ImVec2(dbx1, dby1), IM_COL32(12, 12, 12, 255), 2.0f);
    dl->AddRect(ImVec2(dbx0, dby0), ImVec2(dbx1, dby1), hov ? HkA(HK_WHITE, 0.80f) : HkA(HK_BORDER, 0.55f), 2.0f, 0, 1.2f);

    const char* cur_str = (*cur >= 0 && *cur < count) ? items[*cur] : "?";
    ImVec2      csz     = ImGui::CalcTextSize(cur_str);
    dl->AddText(ImVec2(dbx0 + 8.0f, dby0 + (dropH - csz.y) * 0.5f), HK_TEXT, cur_str);
    dl->AddText(ImVec2(dbx1 - 18.0f, dby0 + dropH * 0.5f - lh * 0.5f), HK_GRAY, ">");

    if (clicked) *cur = (*cur + 1) % count;

    ImGui::PopID();
    return clicked;
}

static bool HkButton(const char* label, float w = 0.0f, float h = 44.0f, bool danger = false) {
    ImDrawList* dl    = ImGui::GetWindowDrawList();
    float       avail = ImGui::GetContentRegionAvail().x;
    if (w <= 0.0f) w = avail;

    ImGui::PushID(label);
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    ImVec2 p1(p0.x + w, p0.y + h);

    bool clicked = ImGui::InvisibleButton("##btn", ImVec2(w, h)) && !s_ScrollGesture;
    bool hov     = ImGui::IsItemHovered() && !s_ScrollGesture;
    bool act     = ImGui::IsItemActive() && !s_ScrollGesture;

    ImU32 accent = danger ? HK_DANGER : HK_WHITE;
    ImU32 bg = act ? HkA(accent, 0.18f) : hov ? HkA(accent, 0.09f) : IM_COL32(12, 12, 12, 240);
    ImU32 bd = act ? accent : hov ? HkA(accent, 0.85f) : HkA(accent, 0.40f);

    dl->AddRectFilled(p0, p1, bg, 3.0f);
    dl->AddRect(p0, p1, bd, 3.0f, 0, danger ? 2.0f : 1.3f);
    DrawCorners(dl, p0, p1, hov ? accent : HkA(accent, 0.55f), 10.0f);

    ImVec2 ts = ImGui::CalcTextSize(label);
    dl->AddText(ImVec2(p0.x + (w - ts.x) * 0.5f, p0.y + (h - ts.y) * 0.5f),
                act || hov ? accent : HkA(accent, 0.80f), label);

    ImGui::PopID();
    return clicked;
}

// Colour row: swatch on the right; tap expands a 16-colour palette plus R/G/B sliders.
static void HkColor(const char* label, uint32_t* col) {
    static const uint32_t* s_Open = nullptr;
    static const ImU32 kPalette[16] = {
        IM_COL32(255,255,255,255), IM_COL32(190,190,190,255), IM_COL32(120,120,120,255), IM_COL32( 30, 30, 30,255),
        IM_COL32(255, 40, 40,255), IM_COL32(255,140,  0,255), IM_COL32(255,230, 30,255), IM_COL32(170,255, 40,255),
        IM_COL32( 40,255, 90,255), IM_COL32( 30,240,240,255), IM_COL32( 40,160,255,255), IM_COL32( 40, 70,255,255),
        IM_COL32(180, 60,240,255), IM_COL32(255, 50,220,255), IM_COL32(255,140,180,255), IM_COL32(150, 90, 40,255),
    };

    ImDrawList* dl    = ImGui::GetWindowDrawList();
    float       avail = ImGui::GetContentRegionAvail().x;
    const float rowH  = 50.0f, swW = 84.0f, swH = 30.0f;

    ImGui::PushID(label);
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    const bool clicked = ImGui::InvisibleButton("##c", ImVec2(avail, rowH)) && !s_ScrollGesture;
    const bool hov     = ImGui::IsItemHovered() && !s_ScrollGesture;
    const bool open    = (s_Open == col);
    if (clicked) s_Open = open ? nullptr : col;

    if (hov || open) dl->AddRectFilled(p0, ImVec2(p0.x + avail, p0.y + rowH), HkA(HK_WHITE, 0.045f));
    ImVec2 ls = ImGui::CalcTextSize(label);
    dl->AddText(ImVec2(p0.x + 12.0f, p0.y + (rowH - ls.y) * 0.5f), hov || open ? HK_TEXT : HK_TEXT_DIM, label);

    const float sx0 = p0.x + avail - swW - 10.0f, sy0 = p0.y + (rowH - swH) * 0.5f;
    dl->AddRectFilled(ImVec2(sx0, sy0), ImVec2(sx0 + swW, sy0 + swH), *col | 0xFF000000u, 3.0f);
    dl->AddRect(ImVec2(sx0, sy0), ImVec2(sx0 + swW, sy0 + swH), open ? HK_WHITE : HkA(HK_BORDER, 0.8f), 3.0f, 0, 1.5f);

    if (s_Open == col) {
        const float pad = 10.0f, gap = 6.0f;
        const float cellW = (avail - pad * 2.0f - gap * 7.0f) / 8.0f, cellH = 40.0f;
        ImVec2 g0(p0.x + pad, p0.y + rowH + 4.0f);
        for (int i = 0; i < 16; ++i) {
            ImVec2 c0(g0.x + (i % 8) * (cellW + gap), g0.y + (i / 8) * (cellH + gap));
            ImVec2 c1(c0.x + cellW, c0.y + cellH);
            ImGui::SetCursorScreenPos(c0);
            ImGui::PushID(i);
            if (ImGui::InvisibleButton("##p", ImVec2(cellW, cellH)) && !s_ScrollGesture)
                *col = (*col & 0xFF000000u) | (kPalette[i] & 0x00FFFFFFu);
            ImGui::PopID();
            const bool sel = ((*col ^ kPalette[i]) & 0x00FFFFFFu) == 0;
            dl->AddRectFilled(c0, c1, kPalette[i], 3.0f);
            dl->AddRect(c0, c1, sel ? HK_WHITE : HkA(HK_BORDER, 0.6f), 3.0f, 0, sel ? 2.5f : 1.0f);
        }
        ImGui::SetCursorScreenPos(ImVec2(p0.x, g0.y + cellH * 2.0f + gap + 6.0f));

        int r = (int)(*col & 0xFF), g = (int)((*col >> 8) & 0xFF), b = (int)((*col >> 16) & 0xFF);
        bool changed = false;
        changed |= HkSliderI("R", &r, 0, 255);
        changed |= HkSliderI("G", &g, 0, 255);
        changed |= HkSliderI("B", &b, 0, 255);
        if (changed) *col = (*col & 0xFF000000u) | ((uint32_t)b << 16) | ((uint32_t)g << 8) | (uint32_t)r;
        ImGui::Dummy(ImVec2(0, 4.0f));
    }
    ImGui::PopID();
}

static bool HkTab(const char* label, bool active, float w, float h) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2      p0 = ImGui::GetCursorScreenPos();
    ImVec2      p1(p0.x + w, p0.y + h);

    bool clicked = ImGui::InvisibleButton(label, ImVec2(w, h));
    bool hov     = ImGui::IsItemHovered();

    float pulse = HkPulse(2.5f);
    ImU32 bg = active ? HK_GRAY_DARK : hov ? HkA(HK_WHITE, 0.06f) : IM_COL32(0, 0, 0, 0);
    ImU32 tx = active ? HK_WHITE : hov ? HK_WHITE2 : HK_TEXT_DIM;

    dl->AddRectFilled(p0, p1, bg, 2.0f);
    if (active)
        dl->AddRectFilled(ImVec2(p0.x + 8.0f, p1.y - 3.0f), ImVec2(p1.x - 8.0f, p1.y),
                          HkA(HK_WHITE, 0.70f + 0.28f * pulse), 1.0f);

    ImVec2 ts = ImGui::CalcTextSize(label);
    dl->AddText(ImVec2(p0.x + (w - ts.x) * 0.5f, p0.y + (h - ts.y) * 0.5f), tx, label);
    return clicked;
}

// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
//  TABS вЂ” only features that are implemented in Core/
// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
//  ARABIC: contextual shaping + right-to-left reordering (ImGui does neither)
// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
namespace Arabic {
    // isolated, final, initial, medial presentation forms for U+0621..U+064A (0 = none).
    struct Forms { uint16_t iso, fin, ini, med; };
    static const Forms kForms[] = {
        /*0621*/{0xFE80,0,0,0},           /*0622*/{0xFE81,0xFE82,0,0},      /*0623*/{0xFE83,0xFE84,0,0},
        /*0624*/{0xFE85,0xFE86,0,0},      /*0625*/{0xFE87,0xFE88,0,0},      /*0626*/{0xFE89,0xFE8A,0xFE8B,0xFE8C},
        /*0627*/{0xFE8D,0xFE8E,0,0},      /*0628*/{0xFE8F,0xFE90,0xFE91,0xFE92}, /*0629*/{0xFE93,0xFE94,0,0},
        /*062A*/{0xFE95,0xFE96,0xFE97,0xFE98}, /*062B*/{0xFE99,0xFE9A,0xFE9B,0xFE9C}, /*062C*/{0xFE9D,0xFE9E,0xFE9F,0xFEA0},
        /*062D*/{0xFEA1,0xFEA2,0xFEA3,0xFEA4}, /*062E*/{0xFEA5,0xFEA6,0xFEA7,0xFEA8}, /*062F*/{0xFEA9,0xFEAA,0,0},
        /*0630*/{0xFEAB,0xFEAC,0,0},      /*0631*/{0xFEAD,0xFEAE,0,0},      /*0632*/{0xFEAF,0xFEB0,0,0},
        /*0633*/{0xFEB1,0xFEB2,0xFEB3,0xFEB4}, /*0634*/{0xFEB5,0xFEB6,0xFEB7,0xFEB8}, /*0635*/{0xFEB9,0xFEBA,0xFEBB,0xFEBC},
        /*0636*/{0xFEBD,0xFEBE,0xFEBF,0xFEC0}, /*0637*/{0xFEC1,0xFEC2,0xFEC3,0xFEC4}, /*0638*/{0xFEC5,0xFEC6,0xFEC7,0xFEC8},
        /*0639*/{0xFEC9,0xFECA,0xFECB,0xFECC}, /*063A*/{0xFECD,0xFECE,0xFECF,0xFED0},
        /*063B*/{0,0,0,0}, /*063C*/{0,0,0,0}, /*063D*/{0,0,0,0}, /*063E*/{0,0,0,0}, /*063F*/{0,0,0,0}, /*0640*/{0,0,0,0},
        /*0641*/{0xFED1,0xFED2,0xFED3,0xFED4}, /*0642*/{0xFED5,0xFED6,0xFED7,0xFED8}, /*0643*/{0xFED9,0xFEDA,0xFEDB,0xFEDC},
        /*0644*/{0xFEDD,0xFEDE,0xFEDF,0xFEE0}, /*0645*/{0xFEE1,0xFEE2,0xFEE3,0xFEE4}, /*0646*/{0xFEE5,0xFEE6,0xFEE7,0xFEE8},
        /*0647*/{0xFEE9,0xFEEA,0xFEEB,0xFEEC}, /*0648*/{0xFEED,0xFEEE,0,0},      /*0649*/{0xFEEF,0xFEF0,0,0},
        /*064A*/{0xFEF1,0xFEF2,0xFEF3,0xFEF4},
    };

    static const Forms* FormsOf(uint32_t c) {
        if (c < 0x0621 || c > 0x064A) return nullptr;
        const Forms* f = &kForms[c - 0x0621];
        return f->iso ? f : nullptr;
    }
    static bool JoinsNext(uint32_t c) { const Forms* f = FormsOf(c); return f && f->ini; }
    static bool IsRtl(uint32_t c) { return (c >= 0x0600 && c <= 0x06FF) || (c >= 0xFB50 && c <= 0xFEFF); }

    static std::vector<uint32_t> Decode(const char* s) {
        std::vector<uint32_t> out;
        const unsigned char* p = reinterpret_cast<const unsigned char*>(s);
        while (*p) {
            uint32_t c = *p++;
            int extra = c >= 0xF0 ? 3 : c >= 0xE0 ? 2 : c >= 0xC0 ? 1 : 0;
            if (extra) c &= (0x3F >> extra);
            for (int i = 0; i < extra && (*p & 0xC0) == 0x80; ++i) c = (c << 6) | (*p++ & 0x3F);
            out.push_back(c);
        }
        return out;
    }

    static void Encode(uint32_t c, std::string& out) {
        if (c < 0x80) out += (char)c;
        else if (c < 0x800) { out += (char)(0xC0 | (c >> 6)); out += (char)(0x80 | (c & 0x3F)); }
        else { out += (char)(0xE0 | (c >> 12)); out += (char)(0x80 | ((c >> 6) & 0x3F)); out += (char)(0x80 | (c & 0x3F)); }
    }

    static uint32_t Mirror(uint32_t c) {
        switch (c) {
            case '[': return ']'; case ']': return '[';
            case '(': return ')'; case ')': return '(';
            case '<': return '>'; case '>': return '<';
            default:  return c;
        }
    }

    // Logical UTF-8 -> visual UTF-8 for a right-to-left paragraph.
    static std::string Shape(const char* text) {
        const std::vector<uint32_t> in = Decode(text);
        std::vector<uint32_t> shaped;
        shaped.reserve(in.size());
        for (size_t i = 0; i < in.size(); ++i) {
            const uint32_t c = in[i];
            const Forms* f = FormsOf(c);
            if (!f) { shaped.push_back(c); continue; }
            const bool prevJoins = i > 0 && JoinsNext(in[i - 1]);
            const uint32_t next = i + 1 < in.size() ? in[i + 1] : 0;
            if (c == 0x0644 && (next == 0x0622 || next == 0x0623 || next == 0x0625 || next == 0x0627)) {
                const uint16_t lig = next == 0x0622 ? 0xFEF5 : next == 0x0623 ? 0xFEF7 : next == 0x0625 ? 0xFEF9 : 0xFEFB;
                shaped.push_back(prevJoins ? lig + 1 : lig);
                ++i;
                continue;
            }
            const bool nextJoins = f->ini && FormsOf(next) != nullptr;
            if (prevJoins && f->fin) shaped.push_back(nextJoins ? f->med : f->fin);
            else shaped.push_back(nextJoins ? f->ini : f->iso);
        }

        // Reverse the order of directional runs; reverse characters only inside RTL runs.
        // Strong types: R = Arabic, L = ASCII letters/digits, N = neutral. A neutral
        // stays LTR only when both surrounding strong characters are LTR.
        const size_t n = shaped.size();
        std::vector<char> type(n);
        for (size_t i = 0; i < n; ++i) {
            const uint32_t c = shaped[i];
            type[i] = IsRtl(c) ? 'R' : (c < 0x80 && std::isalnum((int)c)) ? 'L' : 'N';
        }
        std::vector<bool> rtl(n);
        for (size_t i = 0; i < n; ++i) {
            if (type[i] != 'N') { rtl[i] = type[i] == 'R'; continue; }
            char prev = 'R', next = 'R';
            for (size_t j = i; j-- > 0;) if (type[j] != 'N') { prev = type[j]; break; }
            for (size_t j = i + 1; j < n; ++j) if (type[j] != 'N') { next = type[j]; break; }
            rtl[i] = !(prev == 'L' && next == 'L');
        }
        std::vector<std::pair<bool, std::vector<uint32_t>>> runs;
        for (size_t i = 0; i < n; ++i) {
            if (runs.empty() || runs.back().first != rtl[i]) runs.push_back({ rtl[i], {} });
            runs.back().second.push_back(shaped[i]);
        }
        std::string out;
        for (auto r = runs.rbegin(); r != runs.rend(); ++r) {
            if (r->first) for (auto c = r->second.rbegin(); c != r->second.rend(); ++c) Encode(Mirror(*c), out);
            else for (uint32_t c : r->second) Encode(c, out);
        }
        return out;
    }
}

// Arabic strings keyed by the English text (logical order, unshaped).
static const char* ArabicLogical(const char* en) {
    static const std::unordered_map<std::string, const char*> kAr = {
        {"[ PLAYER ESP ]", "[ ESP اللاعبين ]"}, {"ESP Enabled", "تفعيل ESP"}, {"Box ESP", "الصناديق"},
        {"Skeleton", "الهيكل العظمي"}, {"Names", "الأسماء"}, {"Distance", "المسافة"}, {"Health Bar", "الصحة"},
        {"Numeric", "أرقام"}, {"Bar", "شريط"}, {"Health Style", "نمط الصحة"}, {"Head Dot", "نقطة الرأس"},
        {"Snap Lines", "الخطوط"}, {"Show Bots", "إظهار البوتات"}, {"Show Teammates", "إظهار الفريق"},
        {"Box Thickness", "سماكة الصندوق"}, {"Skeleton Thickness", "سماكة الهيكل"},
        {"[ RADAR & OFFSCREEN ]", "[ الرادار والأسهم ]"}, {"Radar", "الرادار"}, {"Radar Distance", "مدى الرادار"},
        {"m", "م"}, {"Radar Size", "حجم الرادار"}, {"Radar Center X", "موضع الرادار X"},
        {"Radar Center Y", "موضع الرادار Y"}, {"Offscreen Arrows", "أسهم خارج الشاشة"}, {"Max Offscreen Dist", "مدى الأسهم"},
        {"[ AIMBOT ]", "[ التصويب التلقائي ]"}, {"Aimbot Enabled", "تفعيل التصويب"}, {"FOV Circle", "دائرة FOV"},
        {"FOV Radius", "نصف قطر FOV"}, {"Smooth Factor", "النعومة"}, {"[ TARGET ]", "[ الهدف ]"},
        {"Head", "الرأس"}, {"Neck", "الرقبة"}, {"Chest", "الصدر"}, {"Pelvis", "الحوض"},
        {"Target Bone", "عظمة الهدف"}, {"Ignore Bots", "تجاهل البوتات"}, {"Ignore Knocked", "تجاهل المصابين"},
        {"Visible Only", "المرئيون فقط"}, {"[ WEAPON ]", "[ السلاح ]"}, {"No Recoil", "بدون ارتداد"},
        {"Fast Shoot", "إطلاق سريع"}, {"[ VIEW ]", "[ الرؤية ]"}, {"Wide FOV", "رؤية واسعة"},
        {"Wide FOV Value", "قيمة الرؤية"}, {"Custom Crosshair", "علامة التصويب"}, {"[ LOOT ]", "[ الغنائم ]"},
        {"Item ESP", "ESP الأغراض"}, {"Item Max Distance", "مدى الأغراض"}, {"Dead Bodies / Boxes", "الجثث / الصناديق"},
        {"[ LANGUAGE ]", "[ اللغة ]"}, {"Language", "اللغة"}, {"[ ESP COLORS ]", "[ ألوان ESP ]"},
        {"Custom Colors", "ألوان مخصصة"}, {"Box - visible", "الصندوق - مكشوف"},
        {"Box - behind cover", "الصندوق - خلف ساتر"}, {"Line - visible", "الخط - مكشوف"},
        {"Line - behind cover", "الخط - خلف ساتر"}, {"Skeleton - visible", "الهيكل - مكشوف"},
        {"Skeleton - behind cover", "الهيكل - خلف ساتر"}, {"[ CONFIG ]", "[ الإعدادات ]"},
        {"> SAVE CONFIG", "> حفظ"}, {"> LOAD CONFIG", "> تحميل"}, {"> RESET DEFAULTS", "> إعادة ضبط"},
        {"[ SYSTEM ]", "[ النظام ]"}, {"> UNLOAD MOD", "> إلغاء التحميل"},
        {"> HIDE", "> إخفاء"}, {"> MENU", "> القائمة"},
        // Menu chrome
        {"> MIRAGE  v2.2.0", "> ميراج  v2.2.0"}, {"[ESP]", "[كشف]"},
        {"[AIM]", "[تصويب]"}, {"[MEM]", "[ذاكرة]"}, {"[ITM]", "[غنائم]"}, {"[SYS]", "[نظام]"},
        {"ON", "تشغيل"}, {"OFF", "إيقاف"}, {"[PROCESS: ATTACHED]", "[العملية: متصلة]"},
        {"AIM", "تصويب"}, {"RECOIL", "ارتداد"},
        // ESP overlay
        {"PLAYER", "لاعب"}, {"BOT", "بوت"}, {"[DOWN]", "[مصاب]"}, {"[TEAM]", "[فريق]"},
        {"ACTOR", "شخصية"}, {"ENM", "عدو"}, {"DEAD BOX", "جثة"}, {"ITEM", "غرض"},
        {"[PMC]", "[PMC]"}, {"[NPC]", "[NPC]"}, {"[BOT]", "[BOT]"},
        // MIRAGE Menu
        {"AIMBOT & WEAPONS", "التصويب والأسلحة"}, {"VISUALS & ESP", "الرؤية و ESP"},
        {"PLAYER ROSTER", "قائمة اللاعبين"}, {"CUSTOM STUDIO", "التخصيص والتصويب"},
        {"SETTINGS & SYSTEM", "الإعدادات والنظام"},
        {"AIMBOT", "تصويب"}, {"VISUALS", "رؤية"}, {"PLAYERS", "لاعبين"},
        {"CUSTOM", "تخصيص"}, {"SETTINGS", "إعدادات"},
        {"AIMBOT CORE", "التصويب الأساسي"}, {"RCS", "مانع الارتداد"},
        {"WALLHACK ESP", "إعدادات ESP"}, {"CHAMS & WORLD", "العناصر والعالم"},
        {"ROSTER LIST", "قائمة اللاعبين"}, {"TARGET FILTERS", "تصفية الأهداف"},
        {"SYSTEM", "النظام"}, {"CONFIGURATION", "الإعدادات"},
        {"Enable Aimbot Target", "تفعيل التصويب"}, {"Targeting FOV Radius", "نصف قطر التصويب"},
        {"Draw FOV Circle", "إظهار دائرة FOV"}, {"Target Hitbox Bone", "عظمة الهدف"},
        {"Ignore Bots / NPCs", "تجاهل البوتات"}, {"Ignore Knocked Players", "تجاهل المصابين"},
        {"Bullet Lead Prediction", "توقع مسار الرصاص"}, {"Visible Check Only", "المرئيون فقط"},
        {"Aim on Fire Only", "تصويب عند الإطلاق فقط"}, {"Recoil Compensation", "مانع الارتداد"},
        {"No Camera Shake", "بدون اهتزاز الكاميرا"}, {"Instant Hit", "إصابة فورية"},
        {"Fast Bullet Velocity", "سرعة رصاص فائقة"}, {"Rapid Fire Rate", "إطلاق سريع"},
        {"Aim Smooth Interpolation", "سلاسة التصويب"}, {"Enable Wallhack ESP", "تفعيل كشف الأعداء"},
        {"Draw Skeleton ESP", "إظهار الهيكل العظمي"}, {"Draw Player Boxes", "إظهار الصناديق"},
        {"Draw Player Names", "إظهار الأسماء"}, {"Draw Health Bar", "إظهار شريط الصحة"},
        {"Draw Distance (m)", "إظهار المسافة"}, {"Show Bots on ESP", "إظهار البوتات"},
        {"Show Teammates", "إظهار أعضاء الفريق"}, {"Skeleton Thickness", "سماكة الهيكل"},
        {"Box Thickness", "سماكة الصندوق"}, {"Item ESP Engine", "كشف العناصر"},
        {"Loot Boxes / Crates", "صناديق الغنائم"}, {"Drop Items / Weapons", "الأسلحة والعناصر"},
        {"Wide FOV Camera", "كاميرا عريضة"}, {"Custom Crosshair Engine", "علامة تصويب مخصصة"},
        {"Background Particles", "جزيئات الخلفية"}, {"Primary Accent Color", "لون السمة الأساسي"},
        {"Save Mode Engine", "وضع الحفظ"}, {"Auto-Save Mode (Default)", "حفظ تلقائي (افتراضي)"},
        {"Manual Save Mode", "حفظ يدوي"}, {"SAVE ACTIVE CONFIG", "حفظ التكوين الحالي"},
        {"CREATE NEW PROFILE", "إنشاء تكوين جديد"}, {"RESET DEFAULTS", "إعادة ضبط الإعدادات"},
    };
    auto it = kAr.find(en);
    return it == kAr.end() ? en : it->second;
}

// Shaped Arabic, cached per English key.
static const char* ArabicFor(const char* en) {
    static std::unordered_map<std::string, std::string> s_Cache;
    auto c = s_Cache.find(en);
    if (c != s_Cache.end()) return c->second.c_str();
    return s_Cache.emplace(en, Arabic::Shape(ArabicLogical(en))).first->second.c_str();
}

namespace Lang {
    int Current() {
        return g_Config.arabic_language ? 2 : g_Config.russian_language ? 1 : 0;
    }
    const char* T(const char* en, const char* ru) {
        switch (Current()) {
            case 1:  return ru;
            case 2:  return ArabicFor(en);
            default: return en;
        }
    }
    const char* Raw(const char* en, const char* ru) {
        switch (Current()) {
            case 1:  return ru;
            case 2:  return ArabicLogical(en);
            default: return en;
        }
    }
    std::string Display(const std::string& logical) {
        return Current() == 2 ? Arabic::Shape(logical.c_str()) : logical;
    }
    const char* Shape(const char* ar_text) {
        if (!ar_text || !*ar_text) return "";
        static std::unordered_map<std::string, std::string> s_ShapeCache;
        auto it = s_ShapeCache.find(ar_text);
        if (it != s_ShapeCache.end()) return it->second.c_str();
        return s_ShapeCache.emplace(ar_text, Arabic::Shape(ar_text)).first->second.c_str();
    }
}

static inline int CurrentLanguage() { return Lang::Current(); }
static inline const char* T(const char* en, const char* ru) { return Lang::T(en, ru); }

static void TabESP() {
    ConfigState& c = g_Config;

    HkSection(T((const char*)OBFSTR("[ PLAYER ESP ]"), (const char*)OBFSTR("[ ESP ИГРОКОВ ]")));
    HkToggle(T((const char*)OBFSTR("ESP Enabled"), (const char*)OBFSTR("Включить ESP")),        &c.esp_enabled);
    HkToggle(T((const char*)OBFSTR("Box ESP"), (const char*)OBFSTR("Боксы")),                   &c.esp_box);
    HkToggle(T("Skeleton", "Скелет"),                 &c.esp_skeleton);
    HkToggle(T("Names", "Имена"),                     &c.esp_name);
    HkToggle(T("Distance", "Дистанция"),              &c.esp_distance);
    HkToggle(T("Health Bar", "Здоровье"),             &c.esp_health);
    const char* hpTypes[] = { T("Numeric", "Цифры"), T("Bar", "Полоса") };
    HkCombo(T("Health Style", "Вид здоровья"), hpTypes, 2, &c.esp_health_type);
    HkToggle(T("Head Dot", "Точка на голове"),        &c.esp_head_dot);
    HkToggle(T("Snap Lines", "Линии"),                &c.esp_line);
    if (c.esp_line) {
        const char* lineOrig[] = { T("Top", "Сверху"), T("Center", "Центр"), T("Bottom", "Снизу") };
        HkCombo(T("Line Origin", "Начало линий"), lineOrig, 3, &c.esp_line_origin);
    }
    HkToggle(T("Show Bots", "Показывать ботов"),      &c.esp_bots);
    HkToggle(T("Show Teammates", "Показывать тиммейтов"), &c.esp_teammates);
    HkSliderF(T("Box Thickness", "Толщина бокса"),        &c.esp_box_thickness,      0.5f, 4.0f);
    HkSliderF(T("Skeleton Thickness", "Толщина скелета"), &c.esp_skeleton_thickness, 0.5f, 4.0f);

    HkSection(T("[ RADAR & OFFSCREEN ]", "[ РАДАР И СТРЕЛКИ ]"));
    HkToggle(T("Radar", "Радар"),                          &c.esp_radar);
    HkSliderI(T("Radar Distance", "Дальность радара"),     &c.radar_distance,  50, 500, T("m", "м"));
    HkSliderI(T("Radar Size", "Размер радара"),            &c.radar_size,      60, 300);
    HkSliderI(T("Radar Center X", "Радар позиция X"),      &c.radar_center_x,  60, 300);
    HkSliderI(T("Radar Center Y", "Радар позиция Y"),      &c.radar_center_y,  60, 300);
    HkToggle(T("Offscreen Arrows", "Стрелки за экраном"),  &c.esp_offscreen);
    HkSliderI(T("Max Offscreen Dist", "Дальность стрелок"), &c.max_distance_offscreen, 100, 1000, T("m", "м"));
}

static void TabAimbot() {
    ConfigState& c = g_Config;

    HkSection(T((const char*)OBFSTR("[ AIMBOT ]"), (const char*)OBFSTR("[ АИМБОТ ]")));
    HkToggle(T((const char*)OBFSTR("Aimbot Enabled"), (const char*)OBFSTR("Включить аимбот")), &c.aimbot_enabled);
    HkToggle(T("FOV Circle", "Круг FOV"),            &c.aimbot_fov);
    HkSliderF(T("FOV Radius", "Радиус FOV"),         &c.aimbot_fov_radius, 40.0f, 600.0f, "%.0f");
    HkSliderF(T("Smooth Factor", "Плавность"),       &c.aimbot_smooth,      1.0f,  30.0f);
    HkToggle(T("Prediction", "Предсказание"),        &c.aimbot_prediction);
    if (c.aimbot_prediction)
        HkSliderF(T("Bullet Speed", "Скорость пули"), &c.aimbot_bullet_speed, 20000.0f, 150000.0f, "%.0f");

    HkSection(T("[ TARGET ]", "[ ЦЕЛЬ ]"));
    const char* boneNames[] = { T("Auto", "Авто"), T("Head", "Голова"), T("Neck", "Шея"), T("Chest", "Грудь"), T("Pelvis", "Таз") };
    HkCombo(T("Target Bone", "Кость цели"), boneNames, 5, &c.aimbot_bone);
    HkToggle(T("Ignore Bots", "Игнор ботов"),        &c.aimbot_ignore_bots);
    HkToggle(T("Ignore Knocked", "Игнор нокнутых"),  &c.aimbot_ignore_knocked);
    HkToggle(T("Visible Only", "Только видимые"),    &c.aimbot_visible_only);

    HkSection(T("[ FIRE ]", "[ ОГОНЬ ]"));
    // Red ON/OFF button for "aim while firing".
    if (HkButton(c.aimbot_on_fire ? T((const char*)OBFSTR("AIM ON FIRE: ON"), (const char*)OBFSTR("АИМ ПРИ СТРЕЛЬБЕ: ВКЛ"))
                                  : T((const char*)OBFSTR("AIM ON FIRE: OFF"), (const char*)OBFSTR("АИМ ПРИ СТРЕЛЬБЕ: ВЫКЛ")),
                 0.0f, 46.0f, /*danger=*/true)) {
        c.aimbot_on_fire = !c.aimbot_on_fire;
    }
    if (c.aimbot_on_fire) {
        HkSliderF(T("Zone Size", "Размер зоны"), &c.aimbot_fire_zone_r, 30.0f, 400.0f, "%.0f");
        // Lock / unlock the red zone. While unlocked, drag the red circle onto your
        // in-game fire button; lock to fix it and activate the trigger.
        if (HkButton(c.aimbot_fire_zone_locked ? T("Unlock zone (edit)", "Разблокировать (правка)")
                                               : T("Lock zone", "Зафиксировать зону"),
                     0.0f, 44.0f, /*danger=*/!c.aimbot_fire_zone_locked)) {
            c.aimbot_fire_zone_locked = !c.aimbot_fire_zone_locked;
        }
        if (!c.aimbot_fire_zone_locked) {
            ImGui::PushStyleColor(ImGuiCol_Text, HkA(HK_GRAY, 0.9f));
            ImGui::TextWrapped("%s", T("Drag the red circle onto your fire button, then Lock.",
                                       "Перетащи красный круг на кнопку огня, затем Зафиксируй."));
            ImGui::PopStyleColor();
        }
    }
}

static void TabMemory() {
    ConfigState& c = g_Config;

    HkSection(T("[ WEAPON ]", "[ ОРУЖИЕ ]"));
    HkToggle(T("No Recoil", "Без отдачи"),           &c.mem_no_recoil);
    HkToggle(T("Fast Shoot", "Быстрая стрельба"),    &c.mem_fast_shoot);

    HkSection(T("[ VIEW ]", "[ ОБЗОР ]"));
    HkToggle(T("Wide FOV", "Широкий обзор"),         &c.mem_wide_view);
    HkSliderF(T("Wide FOV Value", "Значение обзора"), &c.mem_wide_view_fov, 60.0f, 160.0f, "%.0f");
    HkToggle(T("Custom Crosshair", "Прицел"),        &c.mem_crosshair);
}

static void TabItems() {
    ConfigState& c = g_Config;

    HkSection(T("[ LOOT ]", "[ ЛУТ ]"));
    HkToggle(T((const char*)OBFSTR("Item ESP"), (const char*)OBFSTR("ESP предметов")),                    &c.esp_items);
    HkSliderI(T("Item Max Distance", "Дальность предметов"),    &c.item_esp_max_distance, 20, 500, T("m", "м"));
    HkToggle(T("Dead Bodies / Boxes", "Трупы / ящики"),         &c.esp_lootbox);
}

static void TabSettings() {
    ConfigState& c = g_Config;

    HkSection(T("[ LANGUAGE ]", "[ ЯЗЫК ]"));
    int lang = CurrentLanguage();
    static std::string s_ArabicName = Arabic::Shape("العربية");
    const char* langs[] = { "English", "Русский", s_ArabicName.c_str() };
    if (HkCombo(T("Language", "Язык"), langs, 3, &lang)) {
        c.russian_language = (lang == 1);
        c.arabic_language  = (lang == 2);
    }

    HkSection(T("[ CONFIG ]", "[ КОНФИГ ]"));
    if (HkButton(T("> SAVE CONFIG", "> СОХРАНИТЬ"))) ConfigManager::SaveConfig(c.config_path);
    ImGui::Dummy(ImVec2(0, 8.0f));
    if (HkButton(T("> LOAD CONFIG", "> ЗАГРУЗИТЬ"))) ConfigManager::LoadConfig(c.config_path);
    ImGui::Dummy(ImVec2(0, 8.0f));
    if (HkButton(T("> RESET DEFAULTS", "> СБРОСИТЬ"))) ConfigManager::ResetToDefaults();

    HkSection(T("[ SYSTEM ]", "[ СИСТЕМА ]"));
    if (HkButton(T("> UNLOAD MOD", "> ВЫГРУЗИТЬ"), 0.0f, 44.0f, true)) RequestUnload();
}

// Set while the finger is dragging the left scrollbar thumb/track.
static bool s_ScrollbarDrag = false;

// Touch drag-to-scroll with inertia for the current child window.
static void HkTouchScroll() {
    ImGuiIO& io = ImGui::GetIO();
    if (s_ScrollbarDrag) return;   // the left scrollbar owns this gesture
    if (ImGui::IsMouseClicked(0)) { s_ScrollGesture = false; s_ScrollVel = 0.0f; }

    const bool hovered = ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows |
                                                ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);
    if (io.MouseDown[0] && (hovered || s_ScrollGesture)) {
        if (!s_ScrollGesture && HkVerticalDrag() && fabsf(ImGui::GetMouseDragDelta(0, 0.0f).y) > 14.0f)
            s_ScrollGesture = true;
        if (s_ScrollGesture) {
            ImGui::SetScrollY(ImGui::GetScrollY() - io.MouseDelta.y * 4.0f);
            s_ScrollVel = -io.MouseDelta.y * 4.0f;
        }
    } else if (!io.MouseDown[0] && fabsf(s_ScrollVel) > 0.5f) {
        ImGui::SetScrollY(ImGui::GetScrollY() + s_ScrollVel);
        s_ScrollVel *= 0.95f;
    }
}

// Thick, finger-draggable scrollbar on the LEFT of the content window.
// Grab the thumb (or tap the track) and drag — the menu scrolls to match.
// Call at the TOP of the child, before content, so claiming the gesture
// blocks button activation on the same frame (controls honour s_ScrollGesture).
static constexpr float kScrollbarGutter = 30.0f;
static void HkScrollbar() {
    const float maxY = ImGui::GetScrollMaxY();
    ImGuiIO& io = ImGui::GetIO();
    const ImVec2 wp = ImGui::GetWindowPos();
    const ImVec2 ws = ImGui::GetWindowSize();
    const float x0 = wp.x + 3.0f;
    const float barW = 26.0f;            // thick enough to grab with a finger
    const float x1 = x0 + barW;
    const float trackTop = wp.y + 6.0f;
    const float trackH = ws.y - 12.0f;

    if (maxY <= 0.5f) { s_ScrollbarDrag = false; return; }  // nothing to scroll

    const float thumbH = std::max(48.0f, trackH * (ws.y / (ws.y + maxY)));

    // ── Input (manual, so it also works under touch) ──
    const ImVec2 m = io.MousePos;
    const bool over = m.x >= x0 - 10.0f && m.x <= x1 + 10.0f &&
                      m.y >= trackTop - 4.0f && m.y <= trackTop + trackH + 4.0f;
    if (ImGui::IsMouseClicked(0) && over) s_ScrollbarDrag = true;
    if (!io.MouseDown[0]) s_ScrollbarDrag = false;
    if (s_ScrollbarDrag) {
        s_ScrollGesture = true;   // suppress content controls while dragging
        s_ScrollVel = 0.0f;
        const float denom = (trackH - thumbH);
        float t = denom > 0.0f ? (m.y - trackTop - thumbH * 0.5f) / denom : 0.0f;
        t = HkClamp01(t);
        ImGui::SetScrollY(t * maxY);
    }

    // ── Draw ──
    const float scrollPct = HkClamp01(ImGui::GetScrollY() / maxY);
    const float thumbY = trackTop + (trackH - thumbH) * scrollPct;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->PushClipRect(wp, ImVec2(wp.x + ws.x, wp.y + ws.y), false);
    dl->AddRectFilled(ImVec2(x0, trackTop), ImVec2(x1, trackTop + trackH), HkA(HK_WHITE, 0.08f), 6.0f);
    dl->AddRect      (ImVec2(x0, trackTop), ImVec2(x1, trackTop + trackH), HkA(HK_BORDER, 0.35f), 6.0f, 0, 1.0f);
    const ImU32 tc = s_ScrollbarDrag ? HkA(HK_WHITE, 0.85f) : HkA(HK_WHITE, 0.42f);
    dl->AddRectFilled(ImVec2(x0 + 2.0f, thumbY), ImVec2(x1 - 2.0f, thumbY + thumbH), tc, 6.0f);
    // Grip lines on the thumb.
    const float gx = (x0 + x1) * 0.5f, gy = thumbY + thumbH * 0.5f;
    for (int i = -1; i <= 1; ++i)
        dl->AddLine(ImVec2(gx - 6.0f, gy + i * 5.0f), ImVec2(gx + 6.0f, gy + i * 5.0f), HkA(HK_WHITE, 0.55f), 2.0f);
    dl->PopClipRect();
}

// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
//  NAMESPACE  Menu
// в•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђв•ђ
namespace Menu {

bool g_ShowMenu    = true;
bool g_Initialized = false;

char  g_KeyInput[128] = {};
bool  g_LoginBusy     = false;
bool  g_LoginFailed   = false;
static std::atomic<bool> s_LoginThreadRunning{false};

void InitStyle() {
    ImGuiIO&    io = ImGui::GetIO();
    ImGuiStyle& st = ImGui::GetStyle();

    io.IniFilename     = nullptr;
    io.FontGlobalScale = 2.0f;

    // The built-in ProggyClean bitmap font looks pixelated when scaled up and has
    // no Cyrillic; rasterize a system TTF at the final size instead.
    // Extra padding so the glyph dilation below can't bleed into neighbours
    io.Fonts->TexGlyphPadding = 3;
    io.Fonts->Flags |= ImFontAtlasFlags_NoBakedLines;
    // Try bold variants first, then fall back to regular
    static const char* kFonts[] = {
        "/system/fonts/Roboto-Bold.ttf",
        "/system/fonts/Roboto-Medium.ttf",
        "/system/fonts/NotoSans-Bold.ttf",
        "/system/fonts/NotoSansCJK-Bold.ttc",
        "/system/fonts/Roboto-Regular.ttf",
        "/system/fonts/NotoSans-Regular.ttf",
        "/system/fonts/DroidSans.ttf",
    };
    for (const char* path : kFonts) {
        FILE* f = fopen(path, "rb");
        if (!f) continue;
        fclose(f);
        ImFontConfig cfg;
        cfg.OversampleH   = 3;
        cfg.OversampleV   = 3;
        if (io.Fonts->AddFontFromFileTTF(path, 27.0f, &cfg, io.Fonts->GetGlyphRangesCyrillic())) {
            io.FontGlobalScale = 1.0f;
            break;
        }
    }

    // Arabic glyphs (base block + presentation forms) merged into the main font.
    if (io.FontGlobalScale == 1.0f) {
        static const ImWchar kArabicRanges[] = { 0x0600, 0x06FF, 0xFB50, 0xFDFF, 0xFE70, 0xFEFF, 0 };
        static const char* kArabicFonts[] = {
            "/system/fonts/NotoNaskhArabicUI-Bold.ttf",
            "/system/fonts/NotoNaskhArabic-Bold.ttf",
            "/system/fonts/NotoNaskhArabicUI-Regular.ttf",
            "/system/fonts/NotoNaskhArabic-Regular.ttf",
            "/system/fonts/NotoSansArabicUI-Regular.ttf",
            "/system/fonts/NotoSansArabic-Regular.ttf",
            "/system/fonts/DroidNaskh-Regular.ttf",
        };
        for (const char* path : kArabicFonts) {
            FILE* f = fopen(path, "rb");
            if (!f) continue;
            fclose(f);
            ImFontConfig cfg;
            cfg.MergeMode   = true;
            cfg.OversampleH = 3;
            cfg.OversampleV = 3;
            if (io.Fonts->AddFontFromFileTTF(path, 27.0f, &cfg, kArabicRanges)) break;
        }
    }

    // Merge VANDAL MOD Icomoon icons into atlas
    VandalAuth::InitFonts(io);

    ImFont* mainFont = io.Fonts->Fonts.Size > 0 ? io.Fonts->Fonts[0] : nullptr;
    font::inter_regular   = mainFont;
    font::inter_medium    = mainFont;
    font::inter_semibold  = mainFont;
    font::inter_bold      = mainFont;
    font::logo_font       = mainFont;
    font::small_font      = mainFont;
    font::icon_font       = mainFont;
    font::big_font        = mainFont;
    font::regular_l       = mainFont;
    font::regular_m       = mainFont;
    font::regular_s       = mainFont;
    font::semibold_s      = mainFont;
    font::icomoon_logo    = mainFont;
    font::description_font= mainFont;
    font::esp_font        = mainFont;
    font::default_r       = mainFont;
    font::default_m       = mainFont;
    font::default_s       = mainFont;
    font::icomoon_page    = mainFont;
    font::s_inter_semibold= mainFont;
    font::icon_notify     = mainFont;

    c::lang = g_Config.russian_language;

    // Faux bold: dilate glyph alpha by 1px right and 1px down in the atlas.
    // Works on any device, even when no Bold TTF exists (Android 12+ ships only variable Roboto).
    {
        unsigned char* px = nullptr;
        int tw = 0, th = 0;
        io.Fonts->GetTexDataAsRGBA32(&px, &tw, &th);
        if (px) {
            for (int y = 0; y < th; ++y)
                for (int x = tw - 1; x > 0; --x) {
                    unsigned char& a = px[(y * tw + x) * 4 + 3];
                    unsigned char  l = px[(y * tw + x - 1) * 4 + 3];
                    if (l > a) a = l;
                }
            for (int y = th - 1; y > 0; --y)
                for (int x = 0; x < tw; ++x) {
                    unsigned char& a = px[(y * tw + x) * 4 + 3];
                    unsigned char  u = px[((y - 1) * tw + x) * 4 + 3];
                    if (u > a) a = u;
                }
        }
    }

    st.WindowPadding    = ImVec2(0, 0);
    st.FramePadding     = ImVec2(8, 4);
    st.ItemSpacing      = ImVec2(6, 4);
    st.ItemInnerSpacing = ImVec2(4, 4);
    st.ScrollbarSize    = 0.0f;
    st.WindowBorderSize = 0.0f;
    st.ChildBorderSize  = 0.0f;
    st.PopupBorderSize  = 0.0f;
    st.FrameBorderSize  = 0.0f;
    st.WindowRounding   = 4.0f;
    st.FrameRounding    = 3.0f;
    st.ChildRounding    = 3.0f;
    st.IndentSpacing    = 0.0f;

    ImVec4* cl = st.Colors;
    auto C4 = [](ImU32 u) -> ImVec4 { return ImGui::ColorConvertU32ToFloat4(u); };
    cl[ImGuiCol_WindowBg]       = C4(HK_BG);
    cl[ImGuiCol_ChildBg]        = C4(HK_PANEL);
    cl[ImGuiCol_PopupBg]        = C4(HK_PANEL2);
    cl[ImGuiCol_Border]         = C4(HK_BORDER);
    cl[ImGuiCol_Text]           = C4(HK_TEXT);
    cl[ImGuiCol_TextDisabled]   = C4(HK_TEXT_FAINT);
    cl[ImGuiCol_Button]         = C4(HK_GRAY_DARK);
    cl[ImGuiCol_ButtonHovered]  = C4(HkA(HK_WHITE, 0.20f));
    cl[ImGuiCol_ButtonActive]   = C4(HkA(HK_WHITE, 0.35f));
    cl[ImGuiCol_FrameBg]        = C4(HK_PANEL2);
    cl[ImGuiCol_FrameBgHovered] = C4(HkA(HK_WHITE, 0.08f));
    cl[ImGuiCol_FrameBgActive]  = C4(HkA(HK_WHITE, 0.15f));
    cl[ImGuiCol_CheckMark]      = C4(HK_WHITE);
    cl[ImGuiCol_SliderGrab]     = C4(HK_GRAY);
    cl[ImGuiCol_SliderGrabActive] = C4(HK_WHITE);
    cl[ImGuiCol_Separator]      = C4(HK_BORDER);
    cl[ImGuiCol_NavHighlight]   = C4(HkA(HK_WHITE, 0.0f));

    g_Initialized = true;
}

void UpdateInput(SDK::APlayerController* ctrl) {
    if (!ctrl) return;
    ImGui::GetIO().MouseDrawCursor = false;
}

// в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ
//  FLOATING BUTTON вЂ” drag to move, tap to toggle
// в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ
void RenderFloatingButton(int screenWidth, int screenHeight) {
    const float btnW = 130.0f, btnH = 64.0f, pad = 12.0f;
    static ImVec2 s_Pos(-1.0f, -1.0f);
    static bool   s_Dragged = false;

    if (s_Pos.x < 0.0f) s_Pos = ImVec2((float)screenWidth - btnW - 28.0f, (float)screenHeight * 0.38f);
    s_Pos.x = std::clamp(s_Pos.x, 0.0f, std::max(0.0f, (float)screenWidth  - btnW));
    s_Pos.y = std::clamp(s_Pos.y, 0.0f, std::max(0.0f, (float)screenHeight - btnH));

    ImGui::SetNextWindowPos(ImVec2(s_Pos.x - pad, s_Pos.y - pad), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(btnW + pad * 2.0f, btnH + pad * 2.0f));
    ImGui::SetNextWindowBgAlpha(0.0f);

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::Begin("##floatbtn", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
                 ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImGui::SetCursorScreenPos(s_Pos);
    const bool pressed = ImGui::InvisibleButton("##fb", ImVec2(btnW, btnH));
    if (ImGui::IsItemActivated()) s_Dragged = false;
    if (ImGui::IsItemActive() && ImGui::IsMouseDragging(0, 10.0f)) {
        s_Dragged = true;
        const ImVec2 d = ImGui::GetIO().MouseDelta;
        s_Pos.x += d.x;
        s_Pos.y += d.y;
    }
    if (pressed && !s_Dragged) g_ShowMenu = !g_ShowMenu;
    const bool hov = ImGui::IsItemHovered();
    const bool act = ImGui::IsItemActive();

    ImVec2 p0 = s_Pos;
    ImVec2 p1(p0.x + btnW, p0.y + btnH);
    float pulse = HkPulse(1.8f);
    for (int i = 3; i >= 1; --i) {
        float e = (float)i * 3.0f;
        dl->AddRect(ImVec2(p0.x - e, p0.y - e), ImVec2(p1.x + e, p1.y + e),
                    HkA(HK_WHITE, (0.06f + 0.05f * pulse) / (float)i), 4.0f + e, 0, 1.0f);
    }

    ImU32 bdc = (hov || act) ? HK_WHITE : HkA(HK_WHITE, 0.50f + 0.35f * pulse);
    dl->AddRectFilled(p0, p1, act ? HkA(HK_WHITE, 0.14f) : HkA(HK_BLACK, 0.85f), 3.0f);
    dl->AddRect(p0, p1, bdc, 3.0f, 0, 1.5f);
    DrawCorners(dl, p0, p1, bdc, 9.0f);

    const char* lbl = g_ShowMenu ? T("> HIDE", "> СКРЫТЬ") : T("> MENU", "> МЕНЮ");
    ImVec2      lsz = ImGui::CalcTextSize(lbl);
    dl->AddText(ImVec2(p0.x + (btnW - lsz.x) * 0.5f, p0.y + (btnH - lsz.y) * 0.5f), HK_WHITE, lbl);
    dl->AddCircleFilled(ImVec2(p0.x + 10.0f, p0.y + 10.0f), 4.0f, HkA(HK_WHITE, 0.45f + 0.50f * pulse), 8);

    ImGui::End();
    ImGui::PopStyleVar(2);
}

// в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ
//  MAIN UI
// в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ
void RenderMainUI(int screenWidth, int screenHeight) {
    const float winW  = std::min(960.0f, (float)screenWidth  - 20.0f);
    const float winH  = std::min(780.0f, (float)screenHeight - 20.0f);
    const float headH = 82.0f;
    const float tabH  = 58.0f;
    const float statH = 34.0f;
    const float contH = winH - headH - tabH - statH;

    static ImVec2 s_MenuPos(-1.0f, -1.0f);
    static bool   s_DraggingMenu = false;
    static ImVec2 s_MenuDragOffset(0.0f, 0.0f);

    if (s_MenuPos.x < 0.0f || s_MenuPos.y < 0.0f) {
        s_MenuPos = ImVec2((float)screenWidth * 0.5f - winW * 0.5f,
                           (float)screenHeight * 0.5f - winH * 0.5f);
    }

    // Process drag BEFORE SetNextWindowPos and Begin so clip rect and content stay 100% matched
    if (ImGui::IsMouseClicked(0)) {
        ImVec2 mp = ImGui::GetIO().MouseClickedPos[0];
        ImRect head_rect(s_MenuPos, ImVec2(s_MenuPos.x + winW, s_MenuPos.y + headH));
        ImRect foot_rect(ImVec2(s_MenuPos.x, s_MenuPos.y + winH - statH), ImVec2(s_MenuPos.x + winW, s_MenuPos.y + winH));
        if (head_rect.Contains(mp) || foot_rect.Contains(mp)) {
            s_DraggingMenu = true;
            s_MenuDragOffset = ImVec2(mp.x - s_MenuPos.x, mp.y - s_MenuPos.y);
        }
    }

    if (s_DraggingMenu) {
        if (ImGui::IsMouseDown(0)) {
            s_MenuPos = ImVec2(ImGui::GetIO().MousePos.x - s_MenuDragOffset.x,
                               ImGui::GetIO().MousePos.y - s_MenuDragOffset.y);
            s_MenuPos.x = std::clamp(s_MenuPos.x, 0.0f, std::max(0.0f, (float)screenWidth  - winW));
            s_MenuPos.y = std::clamp(s_MenuPos.y, 0.0f, std::max(0.0f, (float)screenHeight - winH));
        } else {
            s_DraggingMenu = false;
        }
    }

    ImGui::SetNextWindowPos(s_MenuPos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(winW, winH));
    ImGui::SetNextWindowBgAlpha(0.0f);

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,    ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::Begin("##hk_main", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                 ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                 ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2      wp0 = ImGui::GetWindowPos();
    ImVec2      wp1(wp0.x + winW, wp0.y + winH);

    // Solid dark cyber background (zero distortion, no edge clipping)
    dl->AddRectFilled(wp0, wp1, IM_COL32(10, 10, 14, 250), 4.0f);
    // Hex image as the window background, glass slightly visible through it
    if (unsigned int bgTex = BgTexture::GetTex())
        dl->AddImageRounded((ImTextureID)(intptr_t)bgTex, wp0, wp1, ImVec2(0, 0), ImVec2(1, 1),
                            IM_COL32(255, 255, 255, 225), 4.0f);
    dl->AddRectFilled(wp0, wp1, IM_COL32(0, 0, 0, 60), 4.0f);
    DrawScanlines(dl, wp0, wp1);
    DrawGlowBorder(dl, wp0, wp1, HK_WHITE, 4.0f);

    // в”Ђв”Ђ HEADER
    ImVec2 hp1(wp1.x, wp0.y + headH);
    dl->AddRectFilled(wp0, hp1, HkA(HK_BLACK, 0.45f), 0.0f);
    dl->AddLine(ImVec2(wp0.x, hp1.y), hp1, HkA(HK_WHITE, 0.45f), 1.0f);
    dl->PushClipRect(wp0, hp1, true);
    DrawMatrixRain(dl, wp0, winW, headH);
    dl->PopClipRect();
    {
        float pulse = HkPulse(1.5f);
        const char* title = T("> MIRAGE  v2.2.0", "> МИРАЖ  v2.2.0");
        ImVec2 tsz = ImGui::CalcTextSize(title);
        dl->AddText(ImVec2(wp0.x + 20.0f, wp0.y + 14.0f), HkA(HK_WHITE, 0.88f + 0.12f * pulse), title);
        float curX = wp0.x + 20.0f + tsz.x + 4.0f;
        if (HkPulse(2.5f) > 0.5f)
            dl->AddRectFilled(ImVec2(curX, wp0.y + 14.0f), ImVec2(curX + 12.0f, wp0.y + 14.0f + tsz.y), HkA(HK_WHITE, 0.75f));

        const char* badge = T((const char*)OBFSTR("[PROCESS: ATTACHED]"), (const char*)OBFSTR("[ПРОЦЕСС: ПОДКЛЮЧЁН]"));
        ImVec2 bsz = ImGui::CalcTextSize(badge);
        dl->AddText(ImVec2(wp0.x + 20.0f, wp0.y + headH - bsz.y - 12.0f), HkA(HK_GRAY, 0.80f), badge);

        char fpsbuf[32];
        snprintf(fpsbuf, 32, "[FPS: %.0f]", ImGui::GetIO().Framerate);
        ImVec2 fsz = ImGui::CalcTextSize(fpsbuf);
        dl->AddText(ImVec2(wp1.x - fsz.x - 20.0f, wp0.y + headH - fsz.y - 12.0f), HkA(HK_LIGHT_DIM, 0.85f), fpsbuf);
    }

    // в”Ђв”Ђ TABS
    ImVec2 tp0(wp0.x, wp0.y + headH);
    ImVec2 tp1(wp1.x, tp0.y + tabH);
    dl->AddRectFilled(tp0, tp1, IM_COL32(10, 10, 10, 120));
    dl->AddLine(ImVec2(tp0.x, tp1.y), tp1, HkA(HK_BORDER, 0.55f), 1.0f);

    const char* tabLabels[] = {
        T((const char*)OBFSTR("[ESP]"), (const char*)OBFSTR("[ВХ]")), T((const char*)OBFSTR("[AIM]"), (const char*)OBFSTR("[АИМ]")), T("[MEM]", "[ПАМЯТЬ]"), T("[ITM]", "[ЛУТ]"), T("[SYS]", "[НАСТР]")
    };
    constexpr int kTabCount = 5;
    float tabW = winW / (float)kTabCount;
    for (int i = 0; i < kTabCount; ++i) {
        ImGui::SetCursorScreenPos(ImVec2(tp0.x + tabW * i, tp0.y));
        if (HkTab(tabLabels[i], g_ActiveTab == i, tabW, tabH) && g_ActiveTab != i) {
            g_ActiveTab = i;
            s_ScrollVel = 0.0f;
            ImGui::SetNextWindowScroll(ImVec2(0.0f, 0.0f));
        }
        if (i < kTabCount - 1) {
            float sx = tp0.x + tabW * (i + 1);
            dl->AddLine(ImVec2(sx, tp0.y + 8.0f), ImVec2(sx, tp1.y - 8.0f), HkA(HK_BORDER, 0.30f), 1.0f);
        }
    }

    // в”Ђв”Ђ CONTENT (scrollable)
    ImGui::SetCursorScreenPos(ImVec2(wp0.x + 4.0f, tp1.y + 4.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10.0f, 8.0f));
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0, 0, 0, 0));
    if (ImGui::BeginChild("##content", ImVec2(winW - 8.0f, contH - 8.0f), false, ImGuiWindowFlags_NoScrollbar)) {
        HkTouchScroll();
        HkScrollbar();   // left draggable bar — claims the gesture if grabbed
        // Shift content right so the left scrollbar gutter stays clear.
        ImGui::Indent(kScrollbarGutter);
        switch (g_ActiveTab) {
            case 0: TabESP();      break;
            case 1: TabAimbot();   break;
            case 2: TabMemory();   break;
            case 3: TabItems();    break;
            case 4: TabSettings(); break;
        }
        ImGui::Unindent(kScrollbarGutter);
        ImGui::Dummy(ImVec2(0, 16.0f));
    }
    ImGui::EndChild();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar();

    // в”Ђв”Ђ STATUS BAR
    ImVec2 sp0(wp0.x, wp1.y - statH);
    dl->AddRectFilled(sp0, wp1, HkA(HK_BLACK, 0.65f), 0.0f);
    dl->AddLine(sp0, ImVec2(wp1.x, sp0.y), HkA(HK_BORDER, 0.50f), 1.0f);
    auto onOff = [](bool v) { return std::string(v ? Lang::Raw("ON", "ВКЛ") : Lang::Raw("OFF", "ВЫКЛ")); };
    const std::string stat = Lang::Display(
        std::string("  > ESP:") + onOff(g_Config.esp_enabled) +
        "  " + Lang::Raw("AIM", "АИМ") + ":" + onOff(g_Config.aimbot_enabled) +
        "  " + Lang::Raw("RECOIL", "ОТДАЧА") + ":" + onOff(g_Config.mem_no_recoil));
    ImVec2 ssz = ImGui::CalcTextSize(stat.c_str());
    dl->AddText(ImVec2(sp0.x + 4.0f, sp0.y + (statH - ssz.y) * 0.5f), HkA(HK_GRAY, 0.80f), stat.c_str());

    static float s_HexScroll = 0.0f;
    s_HexScroll += ImGui::GetIO().DeltaTime * 28.0f;
    const char* hexstat = "0xF3A1C7 0xDE7B22 0x4C2FA8 0xBEEF13 0x1337AB 0xCAFED0";
    ImVec2 hssz = ImGui::CalcTextSize(hexstat);
    float  hsx  = wp1.x - hssz.x - 10.0f - fmodf(s_HexScroll, hssz.x + 30.0f);
    dl->PushClipRect(ImVec2(sp0.x + winW * 0.55f, sp0.y), ImVec2(wp1.x - 4.0f, wp1.y), true);
    dl->AddText(ImVec2(hsx, sp0.y + (statH - hssz.y) * 0.5f), HkA(HK_TEXT_FAINT, 0.55f), hexstat);
    dl->PopClipRect();

    ImGui::End();
    ImGui::PopStyleVar(2);
}

void RenderLoginUI(int screenWidth, int screenHeight) {
    VandalAuth::Render(screenWidth, screenHeight);
}

// Draggable red fire-zone handle. Shown while "aim on fire" is on and the zone is
// NOT locked: the user drags this red circle onto their in-game fire button. The
// window is exactly the size of the zone, so it captures touches only there; the
// rest of the screen keeps playing. Position is read back into the config.
static void RenderFireZoneEditor(int screenWidth, int screenHeight) {
    ConfigState& c = g_Config;
    if (!c.aimbot_enabled || !c.aimbot_touch_zone || c.aimbot_fire_zone_locked) return;

    const float r  = c.aimbot_fire_zone_r;
    const float cx = screenWidth  * c.aimbot_fire_zone_x;
    const float cy = screenHeight * c.aimbot_fire_zone_y;

    // Re-center the window when the radius changes; otherwise let the user drag it.
    static float s_lastR = -1.0f;
    const bool resized = (s_lastR != r);
    s_lastR = r;
    ImGui::SetNextWindowPos(ImVec2(cx - r, cy - r), resized ? ImGuiCond_Always : ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(r * 2.0f, r * 2.0f), ImGuiCond_Always);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, IM_COL32(0, 0, 0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::Begin("##firezone_handle", nullptr,
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing);

    const ImVec2 wp = ImGui::GetWindowPos();
    const float ncx = wp.x + r, ncy = wp.y + r;
    c.aimbot_fire_zone_x = std::clamp(ncx / (float)screenWidth,  0.0f, 1.0f);
    c.aimbot_fire_zone_y = std::clamp(ncy / (float)screenHeight, 0.0f, 1.0f);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 ctr(ncx, ncy);
    const bool active = ImGui::IsWindowFocused() || ImGui::IsWindowHovered();
    dl->AddCircleFilled(ctr, r, IM_COL32(0, 200, 255, active ? 80 : 50));
    dl->AddCircle(ctr, r, IM_COL32(0, 220, 255, 240), 48, 3.0f);
    const char* lbl = T("SCOPE", "ПРИЦЕЛ");
    const ImVec2 ts = ImGui::CalcTextSize(lbl);
    dl->AddText(ImVec2(ctr.x - ts.x * 0.5f, ctr.y - ts.y * 0.5f), IM_COL32(100, 240, 255, 240), lbl);

    ImGui::End();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor();
}

void Render(int screenWidth, int screenHeight) {
    g_Dpi = std::min(screenWidth, screenHeight) / 1080.0f;
    if (!g_Initialized) InitStyle();

    // Security gate: authorization panel
    if (!Login::Authorized() || !VandalAuth::IsDone()) {
        RenderLoginUI(screenWidth, screenHeight);
        if (!VandalAuth::IsDone()) return;
    }

    // VANDAL MOD 1:1 floating dual-card menu completely rebranded to MIRAGE
    mirage::RenderMirageMenu(&g_ShowMenu, screenWidth, screenHeight);

    // In-game custom crosshair overlay
    mirage::DrawInGameCrosshair(ImGui::GetBackgroundDrawList(), screenWidth, screenHeight);

    // Draggable aimbot fire zone editor handle
    RenderFireZoneEditor(screenWidth, screenHeight);
}

} // namespace Menu
