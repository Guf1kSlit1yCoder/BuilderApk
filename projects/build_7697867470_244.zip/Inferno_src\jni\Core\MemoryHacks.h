#pragma once
#include "Config.h"
#include "UE4Helper.h"

namespace MemoryHacks {
    void Update();
    bool HasPendingRestore();
    void ApplyNoRecoil(bool enable);
    void ApplyWideView(bool enable, float fov);
    void ApplyInstantHit(bool enable);
    void ApplyFastShoot(bool enable);
}
