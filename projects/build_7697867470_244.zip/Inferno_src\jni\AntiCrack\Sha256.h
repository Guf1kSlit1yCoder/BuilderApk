#pragma once
// ──────────────────────────────────────────────────────────────────────────────
//  Native SHA-256 — self-contained, no external deps, no JNI.
//  Used by the native RSA verifier and the branchless auth gate so that no part
//  of the license check routes through a Java method an attacker can hook.
// ──────────────────────────────────────────────────────────────────────────────
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <string>

namespace AntiCrack {

class Sha256 {
public:
    Sha256() { Reset(); }

    void Reset() {
        m_len = 0; m_curlen = 0;
        m_state[0]=0x6a09e667; m_state[1]=0xbb67ae85; m_state[2]=0x3c6ef372; m_state[3]=0xa54ff53a;
        m_state[4]=0x510e527f; m_state[5]=0x9b05688c; m_state[6]=0x1f83d9ab; m_state[7]=0x5be0cd19;
    }

    void Update(const void* data, size_t n) {
        const uint8_t* p = static_cast<const uint8_t*>(data);
        while (n > 0) {
            if (m_curlen == 0 && n >= 64) {
                Transform(p);
                p += 64; n -= 64; m_len += 64 * 8;
            } else {
                size_t take = 64 - m_curlen;
                if (take > n) take = n;
                memcpy(m_buf + m_curlen, p, take);
                m_curlen += take; p += take; n -= take;
                if (m_curlen == 64) { Transform(m_buf); m_len += 64 * 8; m_curlen = 0; }
            }
        }
    }

    // Writes 32 bytes of digest into out[].
    void Final(uint8_t out[32]) {
        m_len += m_curlen * 8;
        m_buf[m_curlen++] = 0x80;
        if (m_curlen > 56) {
            while (m_curlen < 64) m_buf[m_curlen++] = 0;
            Transform(m_buf); m_curlen = 0;
        }
        while (m_curlen < 56) m_buf[m_curlen++] = 0;
        for (int i = 7; i >= 0; --i) m_buf[m_curlen++] = (uint8_t)(m_len >> (i * 8));
        Transform(m_buf);
        for (int i = 0; i < 8; ++i) {
            out[i*4+0] = (uint8_t)(m_state[i] >> 24);
            out[i*4+1] = (uint8_t)(m_state[i] >> 16);
            out[i*4+2] = (uint8_t)(m_state[i] >> 8);
            out[i*4+3] = (uint8_t)(m_state[i]);
        }
        Reset();
    }

    static void Hash(const void* data, size_t n, uint8_t out[32]) {
        Sha256 h; h.Update(data, n); h.Final(out);
    }
    static void Hash(const std::string& s, uint8_t out[32]) { Hash(s.data(), s.size(), out); }

private:
    static uint32_t Ror(uint32_t v, int n) { return (v >> n) | (v << (32 - n)); }

    void Transform(const uint8_t* block) {
        static const uint32_t K[64] = {
            0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
            0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
            0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
            0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
            0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
            0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
            0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
            0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
        };
        uint32_t w[64];
        for (int i = 0; i < 16; ++i)
            w[i] = ((uint32_t)block[i*4] << 24) | ((uint32_t)block[i*4+1] << 16)
                 | ((uint32_t)block[i*4+2] << 8) | ((uint32_t)block[i*4+3]);
        for (int i = 16; i < 64; ++i) {
            uint32_t s0 = Ror(w[i-15],7) ^ Ror(w[i-15],18) ^ (w[i-15] >> 3);
            uint32_t s1 = Ror(w[i-2],17) ^ Ror(w[i-2],19) ^ (w[i-2] >> 10);
            w[i] = w[i-16] + s0 + w[i-7] + s1;
        }
        uint32_t a=m_state[0],b=m_state[1],c=m_state[2],d=m_state[3],
                 e=m_state[4],f=m_state[5],g=m_state[6],h=m_state[7];
        for (int i = 0; i < 64; ++i) {
            uint32_t S1 = Ror(e,6) ^ Ror(e,11) ^ Ror(e,25);
            uint32_t ch = (e & f) ^ (~e & g);
            uint32_t t1 = h + S1 + ch + K[i] + w[i];
            uint32_t S0 = Ror(a,2) ^ Ror(a,13) ^ Ror(a,22);
            uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            uint32_t t2 = S0 + maj;
            h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
        }
        m_state[0]+=a; m_state[1]+=b; m_state[2]+=c; m_state[3]+=d;
        m_state[4]+=e; m_state[5]+=f; m_state[6]+=g; m_state[7]+=h;
    }

    uint32_t m_state[8];
    uint64_t m_len;
    uint8_t  m_buf[64];
    size_t   m_curlen;
};

} // namespace AntiCrack
