#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/uio.h>
#include <dirent.h>
#include <string>
#include <vector>

static pid_t g_Pid = -1;
static uintptr_t g_LibBase = 0;
static uintptr_t g_GNames = 0;

static bool ReadMem(uintptr_t addr, void* buf, size_t size) {
    if (addr < 0x10000ULL || addr > 0x00007FFFFFFFFFFFULL) return false;
    struct iovec local = { buf, size };
    struct iovec remote = { (void*)addr, size };
    ssize_t n = process_vm_readv(g_Pid, &local, 1, &remote, 1, 0);
    return (n == (ssize_t)size);
}

template<typename T>
static T ReadVal(uintptr_t addr, T defVal = T()) {
    T val = defVal;
    ReadMem(addr, &val, sizeof(T));
    return val;
}

static uintptr_t ReadPtr(uintptr_t addr) { return ReadVal<uintptr_t>(addr, 0); }
static int32_t ReadI32(uintptr_t addr) { return ReadVal<int32_t>(addr, 0); }
static uint16_t ReadU16(uintptr_t addr) { return ReadVal<uint16_t>(addr, 0); }

static std::string GetName(int32_t id) {
    if (id <= 0 || !g_GNames) return "None";
    uint32_t block = static_cast<uint32_t>(id) >> 16;
    uint32_t offset = (static_cast<uint32_t>(id) & 0xFFFF) * 2;
    if (block >= 8192) return "None";
    uintptr_t blockPtrAddr = g_GNames + 0x48 + block * sizeof(uint8_t*);
    uintptr_t chunk = ReadPtr(blockPtrAddr);
    if (!chunk) return "None";
    uintptr_t entry = chunk + offset;
    uint16_t header = ReadU16(entry);
    size_t len = header >> 6;
    if (len == 0 || len > 512) return "None";
    char buf[512] = {};
    ReadMem(entry + 2, buf, len);
    return std::string(buf, len);
}

static std::string GetObjClass(uintptr_t obj) {
    if (!obj) return "null";
    uintptr_t cls = ReadPtr(obj + 0x10);
    if (!cls) return "no_class";
    return GetName(ReadI32(cls + 0x18));
}

static std::string GetObjName(uintptr_t obj) {
    if (!obj) return "null";
    return GetName(ReadI32(obj + 0x18));
}

int main() {
    DIR* dir = opendir("/proc");
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type != DT_DIR) continue;
        int pid = atoi(entry->d_name);
        if (pid <= 0) continue;
        char cmdlinePath[64];
        snprintf(cmdlinePath, sizeof(cmdlinePath), "/proc/%d/cmdline", pid);
        FILE* fp = fopen(cmdlinePath, "r");
        if (fp) {
            char cmdline[256] = {};
            fread(cmdline, 1, sizeof(cmdline) - 1, fp);
            fclose(fp);
            if (strstr(cmdline, "com.eu.mf.uamo")) { g_Pid = pid; break; }
        }
    }
    closedir(dir);
    if (g_Pid <= 0) return 1;

    char mapsPath[64];
    snprintf(mapsPath, sizeof(mapsPath), "/proc/%d/maps", g_Pid);
    FILE* f = fopen(mapsPath, "r");
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, "libUE4.so") && strstr(line, "r--p") && !strstr(line, "anon")) {
            sscanf(line, "%lx-", &g_LibBase);
            break;
        }
    }
    fclose(f);
    g_GNames = g_LibBase + 0x0F36BEC0;

    uintptr_t gEngine = ReadPtr(g_LibBase + 0x0F5D3138);
    uintptr_t vp = ReadPtr(gEngine + 0x788);
    uintptr_t world = ReadPtr(vp + 0x70);
    uintptr_t gi = ReadPtr(world + 0x180);
    uintptr_t lpArray = ReadPtr(gi + 0x38);
    uintptr_t lp = ReadPtr(lpArray);
    uintptr_t pc = ReadPtr(lp + 0x30);
    uintptr_t pawn = ReadPtr(pc + 0x990);
    if (!pawn) pawn = ReadPtr(pc + 0xA10);
    if (!pawn) pawn = ReadPtr(pc + 0x2A0);
    printf("Pawn: 0x%lx (%s)\n", pawn, GetObjClass(pawn).c_str());

    uintptr_t wm = ReadPtr(pawn + 0x1838);
    if (!wm || GetObjClass(wm).find("WeaponManager") == std::string::npos) {
        wm = ReadPtr(pawn + 0x19A0);
    }
    if (!wm || GetObjClass(wm).find("WeaponManager") == std::string::npos) {
        wm = ReadPtr(pawn + 0x1F68);
    }
    printf("WeaponManager: 0x%lx (%s)\n", wm, GetObjClass(wm).c_str());
    if (!wm) return 1;

    uintptr_t curWp = ReadPtr(wm + 0x130);
    printf("CurrentWeapon (wm + 0x130): 0x%lx (%s, Name: %s)\n",
           curWp, GetObjClass(curWp).c_str(), GetObjName(curWp).c_str());

    // Check MainWeaponList (wm + 0x4B0)
    uintptr_t mainWpData = ReadPtr(wm + 0x4B0);
    int32_t mainWpNum = ReadI32(wm + 0x4B8);
    printf("--- MainWeaponList (wm + 0x4B0): Data=0x%lx, Num=%d ---\n", mainWpData, mainWpNum);
    std::vector<uintptr_t> weaponsToTest;
    if (curWp) weaponsToTest.push_back(curWp);
    for (int i = 0; i < mainWpNum && i < 10; i++) {
        uintptr_t wp = ReadPtr(mainWpData + i * 8);
        printf("  MainWeapon[%d]: 0x%lx (%s, Name: %s)\n", i, wp, GetObjClass(wp).c_str(), GetObjName(wp).c_str());
        if (wp && wp != curWp) weaponsToTest.push_back(wp);
    }

    // Check CarriedMagazineList (wm + 0x4E0)
    uintptr_t magData = ReadPtr(wm + 0x4E0);
    int32_t magNum = ReadI32(wm + 0x4E8);
    printf("--- CarriedMagazineList (wm + 0x4E0): Data=0x%lx, Num=%d ---\n", magData, magNum);
    for (int i = 0; i < magNum && i < 10; i++) {
        uintptr_t mg = ReadPtr(magData + i * 8);
        printf("  CarriedMag[%d]: 0x%lx (%s, Name: %s)\n", i, mg, GetObjClass(mg).c_str(), GetObjName(mg).c_str());
    }

    // Now test ammo extraction for each weapon
    for (size_t wi = 0; wi < weaponsToTest.size(); wi++) {
        uintptr_t wp = weaponsToTest[wi];
        printf("\n========================================\n");
        printf("ANALYZING WEAPON: 0x%lx (%s, Name: %s)\n", wp, GetObjClass(wp).c_str(), GetObjName(wp).c_str());

        // Check weapon container component (wp + 0x810)
        uintptr_t wpContainer = ReadPtr(wp + 0x810);
        printf("  wp + 0x810 (USGWeaponContainerComponent): 0x%lx (%s)\n", wpContainer, GetObjClass(wpContainer).c_str());
        if (wpContainer) {
            int32_t maxStack = ReadI32(wpContainer + 0x118);
            uintptr_t contData = ReadPtr(wpContainer + 0x1D0);
            int32_t contNum = ReadI32(wpContainer + 0x1D8);
            int32_t totalBullets = 0;
            printf("    MaxStackCount: %d, ContainDataList: Data=0x%lx, Num=%d\n", maxStack, contData, contNum);
            for (int k = 0; k < contNum && k < 30; k++) {
                uint64_t bId = ReadVal<uint64_t>(contData + k * 16);
                int32_t bStack = ReadI32(contData + k * 16 + 8);
                printf("      Bullet[%d]: ItemID=%llu, StackCount=%d\n", k, (unsigned long long)bId, bStack);
                totalBullets += bStack;
            }
            printf("    >>> WP CONTAINER AMMO: %d / %d <<<\n", totalBullets, maxStack);
        }

        // Check WeaponCmpCacheArray at wp + 0xAF8 (19 elements)
        printf("  --- Weapon Components (wp + 0xAF8) ---\n");
        for (int i = 0; i < 19; i++) {
            uintptr_t comp = ReadPtr(wp + 0xAF8 + i * 8);
            if (!comp) continue;
            std::string cCls = GetObjClass(comp);
            std::string cName = GetObjName(comp);
            printf("    Slot[%d]: 0x%lx | Class: %s | Name: %s\n", i, comp, cCls.c_str(), cName.c_str());

            // Check if this is Assemble component
            if (cCls.find("Assemble") != std::string::npos || cName.find("Assemble") != std::string::npos) {
                uintptr_t cachedMag = ReadPtr(comp + 0x270);
                uintptr_t clientMag = ReadPtr(comp + 0x278);
                printf("      >>> ASSEMBLE COMPONENT: CachedMag=0x%lx (%s), ClientMag=0x%lx (%s)\n",
                       cachedMag, GetObjClass(cachedMag).c_str(), clientMag, GetObjClass(clientMag).c_str());

                uintptr_t mag = cachedMag ? cachedMag : clientMag;
                if (mag) {
                    uintptr_t magContainer = ReadPtr(mag + 0x810);
                    printf("        Mag + 0x810: 0x%lx (%s)\n", magContainer, GetObjClass(magContainer).c_str());
                    if (magContainer) {
                        int32_t maxStack = ReadI32(magContainer + 0x118);
                        uintptr_t contData = ReadPtr(magContainer + 0x1D0);
                        int32_t contNum = ReadI32(magContainer + 0x1D8);
                        int32_t totalBullets = 0;
                        printf("        Mag MaxStack: %d, ContainDataList: Data=0x%lx, Num=%d\n", maxStack, contData, contNum);
                        for (int k = 0; k < contNum && k < 30; k++) {
                            uint64_t bId = ReadVal<uint64_t>(contData + k * 16);
                            int32_t bStack = ReadI32(contData + k * 16 + 8);
                            printf("          Mag Bullet[%d]: ItemID=%llu, StackCount=%d\n", k, (unsigned long long)bId, bStack);
                            totalBullets += bStack;
                        }
                        printf("        >>> MAG CONTAINER AMMO: %d / %d <<<\n", totalBullets, maxStack);
                    }
                }
            }

            // Check if this is Ammo component
            if (cCls.find("Ammo") != std::string::npos || cName.find("Ammo") != std::string::npos) {
                int32_t clip = ReadI32(comp + 0x10C);
                int32_t origClip = ReadI32(comp + 0x0E8);
                uint8_t reloading = ReadVal<uint8_t>(comp + 0x118, 0);
                printf("      >>> AMMO COMPONENT: Clip=%d, OrigClip=%d, Reloading=%d\n", clip, origClip, (int)reloading);
            }
        }
    }

    return 0;
}
