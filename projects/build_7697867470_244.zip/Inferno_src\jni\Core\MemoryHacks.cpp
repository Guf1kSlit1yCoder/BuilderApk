#include "MemoryHacks.h"
#include "Memory/Tools.h"
#include <algorithm>
#include <cmath>

namespace MemoryHacks {

    void ApplyNoRecoil(bool enable) {
        if (!enable) return;
        // Memory recoil optimization without ProcessEvent spam
    }

    namespace {
        SDK::FWeakObjectPtr s_Camera{-1, 0};
        float s_OriginalFov = 0.0f;
        float s_AppliedFov = 0.0f;
        bool s_HasOverride = false;

        void RestoreWideView() {
            auto camera = static_cast<SDK::APlayerCameraManager*>(s_Camera.Get());
            // Restore only our own last value. Never overwrite a newer game/zoom
            // change or dereference a camera from a previous match after GC.
            if (s_HasOverride && camera &&
                std::abs(camera->DefaultFOV - s_AppliedFov) < 0.1f) {
                camera->DefaultFOV = s_OriginalFov;
            }
            s_Camera = {-1, 0};
            s_HasOverride = false;
        }
    }

    bool HasPendingRestore() { return s_HasOverride; }

    void ApplyWideView(bool enable, float fov) {
        if (!enable || !std::isfinite(fov) || !UE4Helper::GetLocalPlayer()) {
            RestoreWideView();
            return;
        }
        auto controller = UE4Helper::GetPlayerController();
        auto camera = controller ? controller->PlayerCameraManager : nullptr;
        auto objects = SDK::UObject::GObjects;
        if (!camera || !Tools::IsPtrValid(camera) ||
            !Tools::IsReadable(camera, sizeof(*camera)) || !objects || camera->PCOwner != controller) {
            RestoreWideView();
            return;
        }
        auto item = objects->GetItemByIndex(camera->InternalIndex);
        if (!item || item->Object != camera || item->IsPendingKill() || item->IsUnreachable()) {
            RestoreWideView();
            return;
        }
        fov = std::clamp(fov, 80.0f, 130.0f);
        if (s_Camera.Get() != camera) {
            RestoreWideView();
            const float original = camera->DefaultFOV;
            if (!std::isfinite(original) || original <= 0.0f || original >= 180.0f) return;
            s_Camera = {camera->InternalIndex, item->SerialNumber};
            s_OriginalFov = original;
        } else if (s_HasOverride && std::abs(s_AppliedFov - fov) < 0.1f) {
            return; // do not fight the camera update on every render frame
        } else if (s_HasOverride && std::abs(camera->DefaultFOV - s_AppliedFov) >= 0.1f) {
            // The game changed the base FOV since our last slider update.
            const float original = camera->DefaultFOV;
            if (!std::isfinite(original) || original <= 0.0f || original >= 180.0f) return;
            s_OriginalFov = original;
        }
        camera->DefaultFOV = fov;
        s_AppliedFov = fov;
        s_HasOverride = true;
        // ASGCharacter::DesiredFOV is game-owned; never write the pawn for a
        // visual camera preference. Some game cameras ignore DefaultFOV.
    }

    void ApplyInstantHit(bool enable) {
    }

    void ApplyFastShoot(bool enable) {
    }

    void Update() {
        if (g_Config.mem_no_recoil) ApplyNoRecoil(true);
        ApplyWideView(g_Config.mem_wide_view, g_Config.mem_wide_view_fov);
        if (g_Config.mem_fast_shoot) ApplyFastShoot(true);
    }
}
