#include <jni.h>
#include <pthread.h>
#include <android/input.h>
#include <cstdlib>
#include <iostream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
#include <iomanip>
#include <cctype>
#include <cstring>
#include <array>
#include <unistd.h>
#include <sys/system_properties.h>
#include <GLES3/gl3.h>
#include <EGL/egl.h>
#include <vector>
#include <cfloat>
#include <thread>
#include <mutex>
#include <atomic>
#include <ctime>
#include <dlfcn.h>
#include <link.h>
#include <signal.h>
#include <setjmp.h>
#include <algorithm>

#include "xdl.h"
#include "dobby.h"
#include "Include.h"
#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_android.h"
#include "Roboto-Regular.h"
#include "Icon.h"
#include "Iconcpp.h"
#include "Vector3.h"

#include "Il2Cpp/il2cpp_dump.h"

#include "include/Hook/KittyMemory/KittyMemory.h"
#include "include/Hook/KittyMemory/MemoryPatch.h"
#include "include/Hook/KittyMemory/KittyScanner.h"
#include "include/Hook/KittyMemory/KittyUtils.h"

#include "obfuscate.h"
#include "Utils.h"
#include "style.h"
#include "imgui_touch.hpp"

#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "modd", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "modd", __VA_ARGS__)

using namespace ImGui;

// ==================================================================
//  LOGGER
// ==================================================================
static FILE*       g_log    = nullptr;
static std::mutex  g_log_mtx;
static bool        g_log_ok = false;

static void log_init()
{
    const char* paths[] = {
        "/sdcard/Documents/rrq_owner.log",
        "/storage/emulated/0/Documents/rrq_owner.log",
        "/data/local/tmp/rrq_owner.log",
    };
    for (auto p : paths) {
        g_log = fopen(p, "a");
        if (g_log) { setvbuf(g_log, nullptr, _IOLBF, 0); g_log_ok = true; break; }
    }
}

static void logf(const char* fmt, ...)
{
    time_t t = time(nullptr);
    struct tm tm_buf; localtime_r(&t, &tm_buf);
    char ts[32]; strftime(ts, sizeof(ts), "%H:%M:%S", &tm_buf);

    va_list ap1; va_start(ap1, fmt);
    __android_log_vprint(ANDROID_LOG_INFO, "modd", fmt, ap1);
    va_end(ap1);

    if (!g_log_ok || !g_log) return;
    std::lock_guard<std::mutex> lk(g_log_mtx);
    fprintf(g_log, "[%s] ", ts);
    va_list ap2; va_start(ap2, fmt);
    vfprintf(g_log, fmt, ap2);
    va_end(ap2);
    fputc('\n', g_log);
    fflush(g_log);
}
#define LOGF(...) logf(__VA_ARGS__)

// ==================================================================
//  OFFSETS — game build v1.13.11924 (Unity 2022.3.62f2)
//  UPDATE THESE AFTER EVERY GAME PATCH
// ==================================================================
static const uintptr_t OFF_get_main           = 0xC81CE00;   // Camera::get_main
static const uintptr_t OFF_WorldToScreenPoint = 0xC81C354;   // Camera::WorldToScreenPoint
static const uintptr_t OFF_get_transform      = 0xC89848C;   // Component::get_transform
static const uintptr_t OFF_get_position       = 0xC8B1B94;   // Transform::get_position
static const uintptr_t OFF_PlayerUpdate       = 0x6754B80;   // PlayerManager::Update
static const uintptr_t OFF_PlayerOnDisable    = 0x675C300;   // PlayerManager::OnDisable
static const uintptr_t OFF_get_isMine         = 0xBCD59CC;   // Mirror.NetworkBehaviour::get_isLocalPlayer

// ==================================================================
//  SIGSEGV GUARDS (thread-local)
// ==================================================================
static thread_local sigjmp_buf            g_resolve_jmp;
static thread_local volatile sig_atomic_t g_in_resolve = 0;

static thread_local sigjmp_buf            g_esp_jmp;
static thread_local volatile sig_atomic_t g_in_esp = 0;

static std::atomic<int>      g_esp_crashes{0};
static std::atomic<int64_t>  g_esp_last_crash_time{0};
static std::atomic<void*>    g_current_player{nullptr};
static std::atomic<void*>    g_bad_player{nullptr};

static void universal_crash_handler(int sig, siginfo_t* info, void* uctx)
{
    if (g_in_resolve) siglongjmp(g_resolve_jmp, 1);
    if (g_in_esp) {
        void* bad = g_current_player.load();
        if (bad) g_bad_player.store(bad);
        siglongjmp(g_esp_jmp, 1);
    }
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = SIG_DFL;
    sigemptyset(&sa.sa_mask);
    sigaction(sig, &sa, nullptr);
    raise(sig);
}

static void install_signal_handlers()
{
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = universal_crash_handler;
    sa.sa_flags     = SA_SIGINFO | SA_NODEFER;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, nullptr);
    sigaction(SIGBUS,  &sa, nullptr);
}

static void* safe_get_offset(const char* dll, const char* ns,
                             const char* cls, const char* method, int param_count)
{
    if (sigsetjmp(g_resolve_jmp, 1) != 0) { g_in_resolve = 0; return nullptr; }
    g_in_resolve = 1;
    void* addr = (void*)(uintptr_t) Il2CppGetMethodOffset(dll, ns, cls, method, param_count);
    g_in_resolve = 0;
    return addr;
}

// ==================================================================
//  GLOBALS
// ==================================================================
static const char* kTargetPkg = "com.catsbit.oxidesurvivalisland";
static JavaVM*     g_vm = nullptr;

// ==================================================================
//  THEMES
// ==================================================================
struct Theme {
    const char* name;
    ImU32 bg, bg_bar, bg_panel, bg_hover, bg_input, border;
    ImU32 accent, accent_hi, accent_text;
    ImU32 text, text_dim, text_muted;
    ImU32 switch_off, danger;
};

static const Theme g_themes[] = {
    { "White",
      IM_COL32(252,252,254,255), IM_COL32(242,243,248,255),
      IM_COL32(255,255,255,255), IM_COL32(228,230,238,255),
      IM_COL32(245,246,250,255), IM_COL32(204,208,220,255),
      IM_COL32( 62, 84,230,255), IM_COL32( 96,120,245,255), IM_COL32(255,255,255,255),
      IM_COL32( 14, 16, 24,255), IM_COL32( 62, 68, 88,255), IM_COL32(110,116,134,255),
      IM_COL32(196,200,212,255), IM_COL32(220, 55, 55,255) },
    { "Dark",
      IM_COL32( 22, 24, 30,252), IM_COL32( 30, 33, 40,255),
      IM_COL32( 38, 42, 52,255), IM_COL32( 50, 55, 68,255),
      IM_COL32( 32, 36, 44,255), IM_COL32( 58, 62, 78,255),
      IM_COL32( 92,138,255,255), IM_COL32(130,165,255,255), IM_COL32(255,255,255,255),
      IM_COL32(238,240,245,255), IM_COL32(155,160,175,255), IM_COL32(100,105,120,255),
      IM_COL32( 60, 64, 78,255), IM_COL32(240, 82, 82,255) },
    { "Midnight",
      IM_COL32( 12, 20, 36,252), IM_COL32( 18, 28, 48,255),
      IM_COL32( 24, 36, 60,255), IM_COL32( 34, 48, 78,255),
      IM_COL32( 18, 28, 50,255), IM_COL32( 40, 58, 90,255),
      IM_COL32( 56,189,248,255), IM_COL32(125,211,252,255), IM_COL32(  8, 20, 40,255),
      IM_COL32(225,235,250,255), IM_COL32(140,165,200,255), IM_COL32( 90,115,150,255),
      IM_COL32( 40, 56, 84,255), IM_COL32(248,113,113,255) },
    { "Purple",
      IM_COL32( 18, 14, 26,252), IM_COL32( 24, 18, 36,255),
      IM_COL32( 30, 22, 45,255), IM_COL32( 42, 32, 62,255),
      IM_COL32( 26, 20, 40,255), IM_COL32( 48, 36, 72,255),
      IM_COL32(167,139,250,255), IM_COL32(192,168,255,255), IM_COL32( 20, 14, 30,255),
      IM_COL32(232,228,244,255), IM_COL32(150,140,175,255), IM_COL32( 96, 88,120,255),
      IM_COL32( 52, 44, 74,255), IM_COL32(248, 89, 89,255) },
    { "Emerald",
      IM_COL32( 14, 26, 22,252), IM_COL32( 20, 36, 30,255),
      IM_COL32( 26, 46, 38,255), IM_COL32( 36, 60, 50,255),
      IM_COL32( 20, 38, 32,255), IM_COL32( 40, 70, 58,255),
      IM_COL32( 52,211,153,255), IM_COL32(110,231,183,255), IM_COL32( 10, 30, 24,255),
      IM_COL32(220,245,235,255), IM_COL32(140,180,165,255), IM_COL32( 85,130,115,255),
      IM_COL32( 42, 70, 58,255), IM_COL32(248,113,113,255) },
    { "Crimson",
      IM_COL32( 26, 14, 16,252), IM_COL32( 36, 18, 22,255),
      IM_COL32( 46, 24, 28,255), IM_COL32( 62, 32, 38,255),
      IM_COL32( 38, 20, 24,255), IM_COL32( 72, 38, 44,255),
      IM_COL32(239, 68, 68,255), IM_COL32(252,129,129,255), IM_COL32(255,255,255,255),
      IM_COL32(245,228,228,255), IM_COL32(190,150,155,255), IM_COL32(130, 90, 95,255),
      IM_COL32( 70, 40, 45,255), IM_COL32(252,165, 90,255) },
};
static const int g_theme_count    = sizeof(g_themes) / sizeof(g_themes[0]);
static int       g_theme_idx      = 1;
static int       g_last_theme_idx = -1;

#define COL(name) (g_themes[g_theme_idx].name)

// ==================================================================
//  GAME STATE
// ==================================================================
std::vector<MemoryPatch> memoryPatches;
std::vector<uint64_t>    offsetVector;

int screenWidth  = 0;
int screenHeight = 0;
ANativeWindow* g_native_window = nullptr;

bool showMainMenu = true;
bool setup;
std::atomic<bool> esp{false};

void* (*get_main)()                             = nullptr;
Vector3 (*WorldToScreenPoint)(void*, Vector3)   = nullptr;
void* (*get_transform)(void*)                   = nullptr;
Vector3 (*get_position)(void*)                  = nullptr;

void* (*old_dlopen)(const char*, int)           = nullptr;
bool  (*get_isMine)(void*)                      = nullptr;
void  (*_PlayerUpdate)(void*)                   = nullptr;
void  (*old_Player_OnDisable)(void*)            = nullptr;

bool  EspBox = false;
bool  EspLine = false;
bool  Esp3DBox = false;
float depthFactor = 0.3f;
bool  snapEnabled = false;
bool  autoKillEnabled = false;
float teleKillMaxDistance = 50.0f;
float teleportOffsetY = 1.5f;

float boxColor[4]     = {1.0f, 1.0f, 1.0f, 1.0f};
float outlineColor[4] = {0.0f, 0.0f, 0.0f, 0.0f};
float lineColor[4]    = {1.0f, 1.0f, 1.0f, 1.0f};
float lineThickness   = 2.0f;

void* myPlayer = nullptr;
std::vector<void*> players;
static std::mutex        g_players_mtx;
static std::atomic<bool> g_gfx_thread_attached{false};
static std::atomic<bool> g_il2cpp_ready{false};
static std::atomic<int64_t> g_il2cpp_ready_time{0};

static int   g_menu_tab = 0;
static bool  g_drag_scrolling        = false;
static float g_drag_scroll_start_y   = 0;
static float g_drag_scroll_start_val = 0;

static const float kToggleSize = 60.0f;
static const float kToggleX    = 20.0f;
static const float kToggleY    = 20.0f;

static std::atomic<float> g_menu_x0{0}, g_menu_y0{0};
static std::atomic<float> g_menu_x1{0}, g_menu_y1{0};

// ==================================================================
//  TOUCH
// ==================================================================
struct touch_snapshot_t {
    std::mutex mtx;
    float x = -FLT_MAX;
    float y = -FLT_MAX;
    bool  down = false;
    int   hold_frames = 0;
};
static touch_snapshot_t g_touch;

typedef jboolean (*nativeInjectEvent_t)(JNIEnv*, jobject, jobject, jint);
static nativeInjectEvent_t old_nativeInjectEvent = nullptr;
static std::atomic<bool>   g_native_hooked{false};
static jclass              g_motionEventClass   = nullptr;

typedef jint (*RegisterNatives_t)(JNIEnv*, jclass, const JNINativeMethod*, jint);
static RegisterNatives_t old_RegisterNatives = nullptr;

static bool g_toggle_press = false;

// ==================================================================
//  PLAYER HOOKS
// ==================================================================
bool playerFind(void* player) {
    for (auto& p : players) if (p == player) return true;
    return false;
}

void new_PlayerUpdate(void* player) {
    if (player) {
        std::lock_guard<std::mutex> lk(g_players_mtx);
        if (get_isMine && get_isMine(player)) {
            myPlayer = player;
        } else if (!playerFind(player)) {
            players.push_back(player);
            static int added = 0;
            added++;
            if (added <= 3 || added % 25 == 0)
                LOGF("PlayerUpdate: added #%d (total=%d, ptr=%p)",
                     added, (int)players.size(), player);
        }
    }
    if (_PlayerUpdate) _PlayerUpdate(player);
}

void new_PlayerOnDisable(void* player) {
    if (player) {
        std::lock_guard<std::mutex> lk(g_players_mtx);
        for (auto it = players.begin(); it != players.end(); ++it) {
            if (*it == player) { players.erase(it); break; }
        }
        if (myPlayer == player) myPlayer = nullptr;
    }
    if (old_Player_OnDisable) old_Player_OnDisable(player);
}

// ==================================================================
//  Pointer sanity
// ==================================================================
static inline bool ptr_ok(const void* p)
{
    uintptr_t v = (uintptr_t)p;
    if (v < 0x1000ULL) return false;
    if (v > 0x7FFFFFFFFFFFULL) return false;
    if ((v & 0x7) != 0) return false;
    return true;
}

// ==================================================================
//  ESP
// ==================================================================
static void DrawESP_inner(ImDrawList* draw, int W, int H)
{
    if (!get_main || !get_position || !WorldToScreenPoint || !get_transform) return;

    void* camera = get_main();
    if (!ptr_ok(camera)) return;

    std::vector<void*> local_players;
    void* local_me = nullptr;
    {
        std::lock_guard<std::mutex> lk(g_players_mtx);
        local_players = players;
        local_me = myPlayer;
    }

    void* bad = g_bad_player.load();

    for (size_t i = 0; i < local_players.size(); ++i) {
        void* player = local_players[i];
        if (!ptr_ok(player)) continue;
        if (player == local_me) continue;
        if (player == bad) continue;

        g_current_player.store(player);

        void* transform = get_transform(player);
        if (!ptr_ok(transform)) { g_current_player.store(nullptr); continue; }

        Vector3 PlayerPos = get_position(transform);
        Vector3 Head   = Vector3(PlayerPos.x, PlayerPos.y + 1.6f, PlayerPos.z);
        Vector3 Bottom = Vector3(PlayerPos.x, PlayerPos.y, PlayerPos.z);

        Vector3 HeadPos   = WorldToScreenPoint(camera, Head);
        Vector3 BottomPos = WorldToScreenPoint(camera, Bottom);

        g_current_player.store(nullptr);

        if (HeadPos.z < 1.0f || BottomPos.z < 1.0f) continue;

        float boxHeight = fabsf(HeadPos.y - BottomPos.y);
        if (boxHeight < 0.1f) continue;

        float boxWidth = boxHeight * 0.65f;
        float rectX = HeadPos.x - (boxWidth / 2);
        float rectY = H - HeadPos.y;

        ImVec2 rectMin(rectX, rectY);
        ImVec2 rectMax(rectX + boxWidth, rectY + boxHeight);

        ImU32 boxColorU32  = ImGui::GetColorU32(ImVec4(boxColor[0], boxColor[1], boxColor[2], boxColor[3]));
        ImU32 lineColorU32 = ImGui::GetColorU32(ImVec4(lineColor[0], lineColor[1], lineColor[2], lineColor[3]));

        if (EspBox)  draw->AddRect(rectMin, rectMax, boxColorU32, 0.0f, 14, 1.5f);
        if (EspLine) draw->AddLine(ImVec2(W / 2, 0),
                                    ImVec2(HeadPos.x, H - HeadPos.y),
                                    lineColorU32, lineThickness);

        if (Esp3DBox) {
            float depth   = boxWidth * depthFactor;
            float offsetX = depth * 0.5f;
            float offsetY = depth * 0.25f;

            ImVec2 frontTL = rectMin;
            ImVec2 frontTR(rectMin.x + boxWidth, rectMin.y);
            ImVec2 frontBL(rectMin.x, rectMin.y + boxHeight);
            ImVec2 frontBR(rectMin.x + boxWidth, rectMin.y + boxHeight);

            ImVec2 backTL(rectMin.x - offsetX, rectMin.y - offsetY);
            ImVec2 backTR(rectMin.x + boxWidth - offsetX, rectMin.y - offsetY);
            ImVec2 backBL(rectMin.x - offsetX, rectMin.y + boxHeight - offsetY);
            ImVec2 backBR(rectMin.x + boxWidth - offsetX, rectMin.y + boxHeight - offsetY);

            draw->AddLine(frontTL, frontTR, boxColorU32, 1.5f);
            draw->AddLine(frontTR, frontBR, boxColorU32, 1.5f);
            draw->AddLine(frontBR, frontBL, boxColorU32, 1.5f);
            draw->AddLine(frontBL, frontTL, boxColorU32, 1.5f);
            draw->AddLine(backTL, backTR, boxColorU32, 1.5f);
            draw->AddLine(backTR, backBR, boxColorU32, 1.5f);
            draw->AddLine(backBR, backBL, boxColorU32, 1.5f);
            draw->AddLine(backBL, backTL, boxColorU32, 1.5f);
            draw->AddLine(frontTL, backTL, boxColorU32, 1.5f);
            draw->AddLine(frontTR, backTR, boxColorU32, 1.5f);
            draw->AddLine(frontBL, backBL, boxColorU32, 1.5f);
            draw->AddLine(frontBR, backBR, boxColorU32, 1.5f);
        }
    }

    g_current_player.store(nullptr);
}

void DrawESP(ImDrawList* draw, int W, int H)
{
    int64_t now = (int64_t)time(nullptr);

    static int64_t last_log = 0;
    if (now - last_log >= 5) {
        last_log = now;
        int np;
        void* mp;
        {
            std::lock_guard<std::mutex> lk(g_players_mtx);
            np = (int)players.size();
            mp = myPlayer;
        }
        LOGF("DrawESP: esp=%d players=%d ready=%d self=%p crashes=%d",
             esp.load() ? 1 : 0, np,
             g_il2cpp_ready.load() ? 1 : 0,
             mp, g_esp_crashes.load());
    }

    if (!esp.load()) return;
    if (W == 0 || H == 0) return;
    if (!g_il2cpp_ready.load()) return;
    if (!get_main || !WorldToScreenPoint) return;

    int64_t ready_at = g_il2cpp_ready_time.load();
    if (ready_at == 0 || (now - ready_at) < 8) return;

    int64_t last_crash = g_esp_last_crash_time.load();
    if (last_crash != 0 && (now - last_crash) < 2) return;

    if (sigsetjmp(g_esp_jmp, 1) != 0) {
        g_in_esp = 0;
        int total = ++g_esp_crashes;
        g_esp_last_crash_time.store(now);

        void* bad = g_bad_player.load();
        if (bad) {
            std::lock_guard<std::mutex> lk(g_players_mtx);
            players.erase(std::remove(players.begin(), players.end(), bad),
                          players.end());
            g_bad_player.store(nullptr);
            LOGF("DrawESP: crash #%d — removed player %p", total, bad);
        } else if (total % 10 == 1) {
            LOGF("DrawESP: crash #%d (unknown) — 2s pause", total);
        }
        return;
    }

    g_in_esp = 1;
    DrawESP_inner(draw, W, H);
    g_in_esp = 0;
}

// ==================================================================
//  ICONS
// ==================================================================
namespace Icon {
    inline void Crosshair(ImDrawList* dl, ImVec2 c, float s, ImU32 col) {
        dl->AddCircle(c, s * 0.55f, col, 20, 1.8f);
        dl->AddLine(ImVec2(c.x - s, c.y), ImVec2(c.x - s * 0.25f, c.y), col, 1.8f);
        dl->AddLine(ImVec2(c.x + s * 0.25f, c.y), ImVec2(c.x + s, c.y), col, 1.8f);
        dl->AddLine(ImVec2(c.x, c.y - s), ImVec2(c.x, c.y - s * 0.25f), col, 1.8f);
        dl->AddLine(ImVec2(c.x, c.y + s * 0.25f), ImVec2(c.x, c.y + s), col, 1.8f);
    }
    inline void Eye(ImDrawList* dl, ImVec2 c, float s, ImU32 col) {
        dl->PathLineTo(ImVec2(c.x - s, c.y));
        dl->PathBezierCubicCurveTo(ImVec2(c.x - s*0.4f, c.y - s*0.7f),
                                    ImVec2(c.x + s*0.4f, c.y - s*0.7f),
                                    ImVec2(c.x + s, c.y));
        dl->PathBezierCubicCurveTo(ImVec2(c.x + s*0.4f, c.y + s*0.7f),
                                    ImVec2(c.x - s*0.4f, c.y + s*0.7f),
                                    ImVec2(c.x - s, c.y));
        dl->PathStroke(col, 0, 1.8f);
        dl->AddCircleFilled(c, s * 0.28f, col);
    }
    inline void Bolt(ImDrawList* dl, ImVec2 c, float s, ImU32 col) {
        ImVec2 p[] = {
            {c.x - s*0.1f, c.y - s}, {c.x + s*0.5f, c.y - s},
            {c.x + s*0.05f, c.y - s*0.1f}, {c.x + s*0.55f, c.y - s*0.1f},
            {c.x - s*0.05f, c.y + s}, {c.x - s*0.5f, c.y + s},
        };
        dl->AddConvexPolyFilled(p, 6, col);
    }
    inline void Palette(ImDrawList* dl, ImVec2 c, float s, ImU32 col) {
        dl->AddCircle(c, s * 0.75f, col, 24, 1.8f);
        dl->AddCircleFilled(ImVec2(c.x - s*0.3f, c.y - s*0.25f), 2.0f, col);
        dl->AddCircleFilled(ImVec2(c.x + s*0.3f, c.y - s*0.25f), 2.0f, col);
        dl->AddCircleFilled(ImVec2(c.x, c.y + s*0.35f), 2.0f, col);
    }
    inline void Gear(ImDrawList* dl, ImVec2 c, float s, ImU32 col) {
        dl->AddCircle(c, s * 0.7f, col, 24, 1.8f);
        dl->AddCircle(c, s * 0.28f, col, 16, 1.8f);
        for (int i = 0; i < 8; i++) {
            float a = i * (3.14159f / 4.0f);
            dl->AddLine(ImVec2(c.x + cosf(a) * s * 0.7f, c.y + sinf(a) * s * 0.7f),
                        ImVec2(c.x + cosf(a) * s * 1.0f, c.y + sinf(a) * s * 1.0f),
                        col, 1.8f);
        }
    }
}

// ==================================================================
//  UI WIDGETS
// ==================================================================
static void Section(const char* title)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 p = ImGui::GetCursorScreenPos();
    float avail = ImGui::GetContentRegionAvail().x;
    dl->AddRectFilled(ImVec2(p.x, p.y + 3), ImVec2(p.x + 3, p.y + 17), COL(accent), 2.0f);
    dl->AddText(ImVec2(p.x + 12, p.y + 1), COL(accent), title);
    ImGui::Dummy(ImVec2(avail, ImGui::GetTextLineHeight() + 8));
}

static bool SettingRow(const char* label, bool* value)
{
    ImGui::PushID(label);
    const float row_h = ImGui::GetTextLineHeight() + 20.0f;
    ImVec2 p = ImGui::GetCursorScreenPos();
    float avail = ImGui::GetContentRegionAvail().x;
    ImDrawList* dl = ImGui::GetWindowDrawList();

    ImGui::InvisibleButton("##row", ImVec2(avail, row_h));
    bool hovered = ImGui::IsItemHovered();
    bool clicked = ImGui::IsItemClicked();
    if (clicked) *value = !*value;

    if (hovered)
        dl->AddRectFilled(p, ImVec2(p.x + avail, p.y + row_h), COL(bg_hover), 8.0f);

    dl->AddText(ImVec2(p.x + 14, p.y + (row_h - ImGui::GetTextLineHeight()) * 0.5f),
                COL(text), label);

    float sw_w = 46, sw_h = 26;
    ImVec2 sp(p.x + avail - sw_w - 14, p.y + (row_h - sw_h) * 0.5f);
    ImU32 track = *value ? COL(accent) : COL(switch_off);
    dl->AddRectFilled(sp, ImVec2(sp.x + sw_w, sp.y + sw_h), track, sw_h * 0.5f);

    float knob_r = sw_h * 0.5f - 3.0f;
    float kx = *value ? (sp.x + sw_w - knob_r - 3.0f) : (sp.x + knob_r + 3.0f);
    float ky = sp.y + sw_h * 0.5f;
    dl->AddCircleFilled(ImVec2(kx, ky + 1.5f), knob_r, IM_COL32(0, 0, 0, 60), 24);
    dl->AddCircleFilled(ImVec2(kx, ky), knob_r, IM_COL32(255, 255, 255, 255), 24);

    ImGui::PopID();
    return clicked;
}

static void SliderRow(const char* label, const char* id,
                      float* v, float lo, float hi, const char* fmt)
{
    ImGui::TextDisabled("%s", label);
    ImGui::SetNextItemWidth(-1);
    ImGui::SliderFloat(id, v, lo, hi, fmt);
}

static bool NavButton(const char* id, const char* label,
                      void (*icon)(ImDrawList*, ImVec2, float, ImU32),
                      bool active, ImVec2 size)
{
    ImGui::PushID(id);
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    ImGui::InvisibleButton("##nb", size);
    bool clicked = ImGui::IsItemClicked();
    bool hovered = ImGui::IsItemHovered();

    ImVec2 p1(p.x + size.x, p.y + size.y);
    ImU32 fg = active ? COL(accent) : (hovered ? COL(text) : COL(text_muted));
    if (active) {
        dl->AddRectFilled(p, p1, COL(bg_hover), 10.0f);
        dl->AddRect(p, p1, COL(accent), 10.0f, 0, 1.0f);
    }
    if (icon) icon(dl, ImVec2(p.x + size.x * 0.5f, p.y + size.y * 0.38f), 9.0f, fg);

    ImVec2 ts = ImGui::CalcTextSize(label);
    dl->AddText(ImVec2(p.x + (size.x - ts.x) * 0.5f, p.y + size.y * 0.68f), fg, label);

    ImGui::PopID();
    return clicked;
}

// ==================================================================
//  THEME APPLY
// ==================================================================
static void apply_imgui_theme()
{
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* c = style.Colors;
    c[ImGuiCol_WindowBg]             = ImGui::ColorConvertU32ToFloat4(COL(bg));
    c[ImGuiCol_ChildBg]              = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_PopupBg]              = ImGui::ColorConvertU32ToFloat4(COL(bg_panel));
    c[ImGuiCol_Border]               = ImGui::ColorConvertU32ToFloat4(COL(border));
    c[ImGuiCol_Text]                 = ImGui::ColorConvertU32ToFloat4(COL(text));
    c[ImGuiCol_TextDisabled]         = ImGui::ColorConvertU32ToFloat4(COL(text_dim));
    c[ImGuiCol_FrameBg]              = ImGui::ColorConvertU32ToFloat4(COL(bg_input));
    c[ImGuiCol_FrameBgHovered]       = ImGui::ColorConvertU32ToFloat4(COL(bg_hover));
    c[ImGuiCol_FrameBgActive]        = ImGui::ColorConvertU32ToFloat4(COL(accent));
    c[ImGuiCol_Button]               = ImGui::ColorConvertU32ToFloat4(COL(bg_input));
    c[ImGuiCol_ButtonHovered]        = ImGui::ColorConvertU32ToFloat4(COL(accent));
    c[ImGuiCol_ButtonActive]         = ImGui::ColorConvertU32ToFloat4(COL(accent_hi));
    c[ImGuiCol_CheckMark]            = ImGui::ColorConvertU32ToFloat4(COL(accent));
    c[ImGuiCol_SliderGrab]           = ImGui::ColorConvertU32ToFloat4(COL(accent));
    c[ImGuiCol_SliderGrabActive]     = ImGui::ColorConvertU32ToFloat4(COL(accent_hi));
    c[ImGuiCol_Separator]            = ImGui::ColorConvertU32ToFloat4(COL(border));
    c[ImGuiCol_ScrollbarBg]          = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_ScrollbarGrab]        = ImGui::ColorConvertU32ToFloat4(COL(accent));
    c[ImGuiCol_ScrollbarGrabHovered] = ImGui::ColorConvertU32ToFloat4(COL(accent_hi));
    c[ImGuiCol_ScrollbarGrabActive]  = ImGui::ColorConvertU32ToFloat4(COL(accent_hi));
}

// ==================================================================
//  WATERMARK
// ==================================================================
static void DrawWatermark()
{
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    ImGuiIO& io = ImGui::GetIO();

    const char* text = "@RrQ_Owner";
    ImVec2 ts = ImGui::CalcTextSize(text);
    float pill_h = ts.y + 16.0f;
    float pad_x = 16.0f;
    float box_w = 6 + ts.y + 8 + ts.x + pad_x * 2;
    float box_x = (io.DisplaySize.x - box_w) * 0.5f;
    float box_y = 14.0f;

    ImVec2 p0(box_x, box_y);
    ImVec2 p1(box_x + box_w, box_y + pill_h);

    dl->AddRectFilled(ImVec2(p0.x - 2, p0.y - 2), ImVec2(p1.x + 2, p1.y + 2),
                      IM_COL32(0, 0, 0, 80), 10.0f);
    dl->AddRectFilled(p0, p1, IM_COL32(14, 16, 22, 235), 10.0f);
    dl->AddRect(p0, p1, COL(accent), 10.0f, 0, 1.5f);

    ImVec2 tile_p(p0.x + 6, p0.y + 6);
    ImVec2 tile_s(ts.y, ts.y);
    dl->AddRectFilled(tile_p, ImVec2(tile_p.x + tile_s.x, tile_p.y + tile_s.y),
                      COL(accent), 6.0f);

    const char* r = "R";
    ImVec2 rs = ImGui::CalcTextSize(r);
    dl->AddText(ImVec2(tile_p.x + (tile_s.x - rs.x) * 0.5f,
                       tile_p.y + (tile_s.y - rs.y) * 0.5f),
                COL(accent_text), r);

    dl->AddText(ImVec2(tile_p.x + tile_s.x + 8, p0.y + (pill_h - ts.y) * 0.5f),
                COL(text), text);
}

// ==================================================================
//  MENU
// ==================================================================
static const char*  g_nav_names[] = { "Aimbot", "ESP", "Misc", "Visuals", "Settings" };
static void (*g_nav_icons[])(ImDrawList*, ImVec2, float, ImU32) = {
    Icon::Crosshair, Icon::Eye, Icon::Bolt, Icon::Palette, Icon::Gear
};
static const int g_nav_count = 5;

static void draw_tab_content(ImGuiIO& io)
{
    switch (g_menu_tab)
    {
    case 0:
        Section("General");
        SettingRow("Enable Aimbot", &snapEnabled);
        SettingRow("Auto Kill",     &autoKillEnabled);
        Section("Tuning");
        SliderRow("Kill Distance",     "##kd", &teleKillMaxDistance, 5.0f, 200.0f, "%.0f m");
        SliderRow("Teleport Y Offset", "##ty", &teleportOffsetY,     0.0f,   5.0f, "%.2f");
        break;

    case 1:
    {
        Section("General");
        bool esp_now = esp.load();
        if (SettingRow("Enable ESP", &esp_now)) {
            esp.store(esp_now);
            LOGF("ESP toggle: %d", esp_now ? 1 : 0);
            if (esp_now && !EspBox && !EspLine && !Esp3DBox) {
                EspBox = true;
                LOGF("ESP: auto-enabled Draw Box");
            }
        }
        Section("Elements");
        SettingRow("Draw Box",  &EspBox);
        SettingRow("Draw Line", &EspLine);
        SettingRow("3D Box",    &Esp3DBox);
        Section("3D Depth");
        SliderRow("Depth Factor", "##df", &depthFactor, 0.05f, 1.0f, "%.2f");
        break;
    }

    case 2:
        Section("Combat");
        SettingRow("Snap Enabled", &snapEnabled);
        SettingRow("Auto Kill",    &autoKillEnabled);
        Section("Utility");
        ImGui::TextDisabled("More features coming soon");
        break;

    case 3:
        Section("Box");
        ImGui::ColorEdit4("Box Color",     boxColor,     ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaPreview);
        ImGui::ColorEdit4("Outline Color", outlineColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaPreview);
        Section("Snapline");
        ImGui::ColorEdit4("Line Color", lineColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaPreview);
        SliderRow("Line Thickness", "##lt", &lineThickness, 1.0f, 8.0f, "%.1f");
        break;

    case 4:
    {
        Section("Theme");
        {
            float avail = ImGui::GetContentRegionAvail().x;
            float gap = 10.0f;
            float bw = (avail - gap) * 0.5f;
            float bh = ImGui::GetTextLineHeight() + 32.0f;

            for (int i = 0; i < g_theme_count; i++) {
                bool active = (g_theme_idx == i);
                ImGui::PushID(i);
                ImVec2 p = ImGui::GetCursorScreenPos();
                ImDrawList* cdl = ImGui::GetWindowDrawList();

                ImGui::InvisibleButton("##theme", ImVec2(bw, bh));
                if (ImGui::IsItemClicked()) g_theme_idx = i;
                bool hov = ImGui::IsItemHovered();

                const Theme& th = g_themes[i];
                ImVec2 pm(p.x + bw, p.y + bh);

                cdl->AddRectFilled(p, pm, th.bg_panel, 8.0f);
                cdl->AddRectFilled(ImVec2(p.x, p.y + bh - 4), pm,
                                   th.accent, 8.0f, ImDrawFlags_RoundCornersBottom);
                cdl->AddCircleFilled(ImVec2(p.x + 18, p.y + bh * 0.5f), 9.0f, th.accent);
                cdl->AddText(ImVec2(p.x + 34, p.y + bh * 0.5f - ImGui::GetTextLineHeight() * 0.5f),
                             th.text, th.name);

                if (active) {
                    cdl->AddRect(ImVec2(p.x - 2, p.y - 2), ImVec2(pm.x + 2, pm.y + 2),
                                 th.accent, 10.0f, 0, 2.5f);
                } else if (hov) {
                    cdl->AddRect(p, pm, th.accent_hi, 8.0f, 0, 1.5f);
                }

                ImGui::PopID();
                if (i % 2 == 0 && i < g_theme_count - 1) ImGui::SameLine(0, gap);
            }
            ImGui::Dummy(ImVec2(0, 6));
        }

        Section("System");
        ImGui::Text("Display     : %.0f x %.0f", io.DisplaySize.x, io.DisplaySize.y);
        ImGui::Text("Framerate   : %.1f FPS",    io.Framerate);
        ImGui::Text("Theme       : %s",          g_themes[g_theme_idx].name);

        int np;
        void* mp;
        { std::lock_guard<std::mutex> lk(g_players_mtx); np = (int)players.size(); mp = myPlayer; }
        ImGui::Text("Players     : %d tracked", np);
        ImGui::Text("Self        : %s",         mp ? "found" : "none");
        ImGui::Text("ESP crashes : %d",         g_esp_crashes.load());
        ImGui::Text("Il2Cpp      : %s",         g_il2cpp_ready.load() ? "ready" : "waiting");
        break;
    }
    }
}

static void DrawMenu()
{
    ImGuiIO& io = ImGui::GetIO();

    if (g_last_theme_idx != g_theme_idx) {
        apply_imgui_theme();
        g_last_theme_idx = g_theme_idx;
    }

    const float fh = ImGui::GetTextLineHeight();
    const float kWinW   = 920.0f;
    const float kWinH   = 640.0f;
    const float kTopBar = fh + 34.0f;
    const float kBottom = fh + 62.0f;

    static bool first_open = true;
    if (first_open) {
        ImGui::SetNextWindowSize(ImVec2(kWinW, kWinH), ImGuiCond_Always);
        ImGui::SetNextWindowPos(
            ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f),
            ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        first_open = false;
    }
    ImGui::SetNextWindowSize(ImVec2(kWinW, kWinH), ImGuiCond_FirstUseEver);

    ImGui::Begin("@RrQ_Owner", nullptr,
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse |
        ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoScrollWithMouse);

    ImVec2 wp = ImGui::GetWindowPos();
    ImVec2 ws = ImGui::GetWindowSize();

    g_menu_x0.store(wp.x); g_menu_y0.store(wp.y);
    g_menu_x1.store(wp.x + ws.x); g_menu_y1.store(wp.y + ws.y);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(wp, ImVec2(wp.x + ws.x, wp.y + ws.y), COL(bg), 16.0f);
    dl->AddRect(wp, ImVec2(wp.x + ws.x, wp.y + ws.y), COL(accent), 16.0f, 0, 1.5f);

    dl->AddRectFilled(wp, ImVec2(wp.x + ws.x, wp.y + kTopBar),
                      COL(bg_bar), 16.0f, ImDrawFlags_RoundCornersTop);
    dl->AddLine(ImVec2(wp.x, wp.y + kTopBar - 1),
                ImVec2(wp.x + ws.x, wp.y + kTopBar - 1),
                COL(border), 1.0f);

    {
        float ls = fh;
        ImVec2 lp(wp.x + 22, wp.y + (kTopBar - ls) * 0.5f);
        dl->AddRectFilled(lp, ImVec2(lp.x + ls, lp.y + ls), COL(accent), 8.0f);
        const char* r = "R";
        ImVec2 rs = ImGui::CalcTextSize(r);
        dl->AddText(ImVec2(lp.x + (ls - rs.x) * 0.5f, lp.y + (ls - rs.y) * 0.5f),
                    COL(accent_text), r);
    }

    {
        const char* title = "@RrQ_Owner";
        const char* sub   = "v1.0";
        ImVec2 tsz = ImGui::CalcTextSize(title);
        ImVec2 ssz = ImGui::CalcTextSize(sub);
        float cx = wp.x + ws.x * 0.5f;
        float y_c = wp.y + kTopBar * 0.5f;
        float total = tsz.x + 8.0f + ssz.x;
        float x = cx - total * 0.5f;
        dl->AddText(ImVec2(x, y_c - tsz.y * 0.5f), COL(text), title);
        dl->AddText(ImVec2(x + tsz.x + 8.0f, y_c - ssz.y * 0.5f + 1.0f),
                    COL(text_dim), sub);
    }

    {
        float cs = fh;
        ImVec2 cp(wp.x + ws.x - 22 - cs, wp.y + (kTopBar - cs) * 0.5f);
        ImGui::SetCursorScreenPos(cp);
        ImGui::InvisibleButton("##close", ImVec2(cs, cs));
        bool hov = ImGui::IsItemHovered();
        if (ImGui::IsItemClicked()) showMainMenu = false;
        ImU32 bg = hov ? COL(danger) : COL(bg_hover);
        dl->AddRectFilled(cp, ImVec2(cp.x + cs, cp.y + cs), bg, 8.0f);
        float pad = cs * 0.3f;
        ImU32 xcol = hov ? IM_COL32(255, 255, 255, 255) : COL(text_dim);
        dl->AddLine(ImVec2(cp.x + pad, cp.y + pad),
                    ImVec2(cp.x + cs - pad, cp.y + cs - pad), xcol, 2.0f);
        dl->AddLine(ImVec2(cp.x + cs - pad, cp.y + pad),
                    ImVec2(cp.x + pad, cp.y + cs - pad), xcol, 2.0f);
    }

    {
        ImGui::SetCursorScreenPos(ImVec2(wp.x, wp.y));
        ImGui::InvisibleButton("##drag", ImVec2(ws.x - kTopBar, kTopBar));
        if (ImGui::IsItemActive() && ImGui::IsMouseDragging(0)) {
            ImVec2 d = ImGui::GetIO().MouseDelta;
            ImGui::SetWindowPos(ImVec2(wp.x + d.x, wp.y + d.y));
        }
    }

    ImVec2 content_p(wp.x + 22, wp.y + kTopBar + 10);
    ImVec2 content_s(ws.x - 44, ws.y - kTopBar - kBottom - 20);

    ImGui::SetCursorScreenPos(content_p);
    ImGui::BeginChild("##content", content_s, false, 0);
    {
        bool window_hovered = ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows);
        bool any_item_hovered = ImGui::IsAnyItemHovered();

        if (window_hovered && ImGui::IsMouseClicked(0) && !any_item_hovered) {
            g_drag_scrolling = true;
            g_drag_scroll_start_y   = ImGui::GetIO().MousePos.y;
            g_drag_scroll_start_val = ImGui::GetScrollY();
        }
        if (g_drag_scrolling) {
            if (ImGui::IsMouseDown(0)) {
                float dy = ImGui::GetIO().MousePos.y - g_drag_scroll_start_y;
                ImGui::SetScrollY(g_drag_scroll_start_val - dy);
            } else {
                g_drag_scrolling = false;
            }
        }
        draw_tab_content(io);
    }
    ImGui::EndChild();

    ImVec2 bn_p(wp.x, wp.y + ws.y - kBottom);
    dl->AddRectFilled(bn_p, ImVec2(wp.x + ws.x, wp.y + ws.y),
                      COL(bg_bar), 16.0f, ImDrawFlags_RoundCornersBottom);
    dl->AddLine(bn_p, ImVec2(wp.x + ws.x, bn_p.y), COL(border), 1.0f);

    {
        float pad_x = 20, gap = 8;
        float avail = ws.x - pad_x * 2 - gap * (g_nav_count - 1);
        float bw = avail / (float)g_nav_count;
        ImVec2 bsize(bw, kBottom - 26);

        ImGui::SetCursorScreenPos(ImVec2(bn_p.x + pad_x, bn_p.y + 15));
        for (int i = 0; i < g_nav_count; i++) {
            if (i > 0) ImGui::SameLine(0, gap);
            char id[16];
            snprintf(id, sizeof(id), "nav%d", i);
            if (NavButton(id, g_nav_names[i], g_nav_icons[i],
                          g_menu_tab == i, bsize)) {
                g_menu_tab = i;
                g_drag_scrolling = false;
            }
        }
    }

    ImGui::End();
}

// ==================================================================
//  IMGUI SETUP
// ==================================================================
static int screen_width_fallback  = 1220;
static int screen_height_fallback = 2712;

int get_width()  { return screen_width_fallback; }
int get_height() { return screen_height_fallback; }

void SetupImgui() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    apply_imgui_theme();

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(
        screenWidth  > 0 ? (float)screenWidth  : 1920.0f,
        screenHeight > 0 ? (float)screenHeight : 1080.0f
    );
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;

    ImGuiStyle* style = &ImGui::GetStyle();
    style->Alpha = 1.0f;
    style->WindowTitleAlign = ImVec2(0.5f, 0.5f);
    style->PopupRounding    = 3;
    style->WindowPadding    = ImVec2(4, 4);
    style->FramePadding     = ImVec2(6, 4);
    style->ItemSpacing      = ImVec2(6, 4);
    style->ScrollbarSize    = 14;
    style->WindowBorderSize = 0;
    style->ChildBorderSize  = 0;
    style->PopupBorderSize  = 1;
    style->FrameBorderSize  = 1;
    style->WindowRounding    = 3;
    style->ChildRounding     = 3;
    style->FrameRounding     = 3;
    style->ScrollbarRounding = 2;
    style->GrabRounding      = 3;

    ImGui_ImplOpenGL3_Init("#version 100");

    ImFontConfig font_cfg;
    io.Fonts->AddFontFromMemoryTTF(&Roboto_Regular, sizeof(Roboto_Regular),
                                   28.0f, &font_cfg,
                                   io.Fonts->GetGlyphRangesCyrillic());
    ImGui::GetStyle().ScaleAllSizes(1.0f);

    apply_imgui_theme();
    g_last_theme_idx = g_theme_idx;
    LOGF("SetupImgui: done (font 28pt)");
}

// ==================================================================
//  ANativeWindow HOOKS
// ==================================================================
int32_t (*orig_ANativeWindow_getWidth)(ANativeWindow* window);
int32_t _ANativeWindow_getWidth(ANativeWindow* window) {
    if (window) g_native_window = window;
    screenWidth = orig_ANativeWindow_getWidth(window);
    return orig_ANativeWindow_getWidth(window);
}

int32_t (*orig_ANativeWindow_getHeight)(ANativeWindow* window);
int32_t _ANativeWindow_getHeight(ANativeWindow* window) {
    if (window) g_native_window = window;
    screenHeight = orig_ANativeWindow_getHeight(window);
    return orig_ANativeWindow_getHeight(window);
}

// ==================================================================
//  TOGGLE HIT TEST
// ==================================================================
static bool is_in_toggle(float x, float y)
{
    float cx = kToggleX + kToggleSize * 0.5f;
    float cy = kToggleY + kToggleSize * 0.5f;
    float r  = kToggleSize * 0.55f;
    float dx = x - cx, dy = y - cy;
    return (dx * dx + dy * dy) <= (r * r);
}

// ==================================================================
//  nativeInjectEvent HOOK
// ==================================================================
static bool update_touch_from_inputevent(JNIEnv* env, jobject ev)
{
    if (!ev) return false;

    if (!g_motionEventClass) {
        jclass local = env->FindClass("android/view/MotionEvent");
        if (!local) { env->ExceptionClear(); return false; }
        g_motionEventClass = (jclass)env->NewGlobalRef(local);
        env->DeleteLocalRef(local);
    }
    if (!g_motionEventClass) return false;
    if (!env->IsInstanceOf(ev, g_motionEventClass)) return false;

    jclass mc = env->GetObjectClass(ev);
    if (!mc) return false;

    jmethodID getAction = env->GetMethodID(mc, "getActionMasked", "()I");
    jmethodID getX      = env->GetMethodID(mc, "getX", "(I)F");
    jmethodID getY      = env->GetMethodID(mc, "getY", "(I)F");
    if (!getAction || !getX || !getY) { env->DeleteLocalRef(mc); return false; }

    jint   action = env->CallIntMethod(ev, getAction);
    jfloat x      = env->CallFloatMethod(ev, getX, 0);
    jfloat y      = env->CallFloatMethod(ev, getY, 0);

    if (action == 0 && is_in_toggle(x, y)) {
        showMainMenu = !showMainMenu;
        LOGF("toggle: menu=%d", showMainMenu ? 1 : 0);
        g_toggle_press = true;
        env->DeleteLocalRef(mc);
        return true;
    }
    if (g_toggle_press) {
        if (action == 1 || action == 3) g_toggle_press = false;
        env->DeleteLocalRef(mc);
        return true;
    }

    {
        std::lock_guard<std::mutex> lk(g_touch.mtx);
        if (action == 0 || action == 2 || action == 5) {
            g_touch.x = x; g_touch.y = y;
            g_touch.down = true;
            g_touch.hold_frames = 6;
        } else if (action == 1 || action == 3 || action == 6) {
            g_touch.down = false;
        }
    }

    env->DeleteLocalRef(mc);

    if (showMainMenu) {
        float x0 = g_menu_x0.load(), y0 = g_menu_y0.load();
        float x1 = g_menu_x1.load(), y1 = g_menu_y1.load();
        if (x1 > x0 && y1 > y0 && x >= x0 && x <= x1 && y >= y0 && y <= y1)
            return true;
    }
    return false;
}

static jboolean hooked_nativeInjectEvent(JNIEnv* env, jobject thiz,
                                         jobject ev, jint type)
{
    bool consumed = update_touch_from_inputevent(env, ev);
    if (consumed) return JNI_TRUE;
    if (old_nativeInjectEvent) return old_nativeInjectEvent(env, thiz, ev, type);
    return JNI_FALSE;
}

// ==================================================================
//  RegisterNatives HOOK
// ==================================================================
static jint hook_RegisterNatives(JNIEnv* env, jclass clazz,
                                 const JNINativeMethod* methods, jint nMethods)
{
    if (methods && nMethods > 0) {
        JNINativeMethod* mut = const_cast<JNINativeMethod*>(methods);
        for (jint i = 0; i < nMethods; i++) {
            const char* name = mut[i].name;
            if (!name) continue;
            const char* sig = mut[i].signature;
            void* fn = mut[i].fnPtr;

            if (strcmp(name, "nativeInjectEvent") == 0) {
                LOGF("*** nativeInjectEvent @ %p sig=%s ***", fn, sig ? sig : "?");
                if (sig && strcmp(sig, "(Landroid/view/InputEvent;I)Z") == 0) {
                    old_nativeInjectEvent = (nativeInjectEvent_t)fn;
                    mut[i].fnPtr = (void*)hooked_nativeInjectEvent;
                    LOGF("swapped -> hooked_nativeInjectEvent");
                    g_native_hooked.store(true);
                }
            }
        }
    }
    return old_RegisterNatives(env, clazz, methods, nMethods);
}

static void install_registernatives_hook(JNIEnv* env)
{
    if (!env || !env->functions) { LOGF("RegisterNatives: no env"); return; }
    void* target = (void*)env->functions->RegisterNatives;
    if (!target) { LOGF("RegisterNatives: null"); return; }
    DobbyHook(target, (void*)hook_RegisterNatives, (void**)&old_RegisterNatives);
    LOGF("hooked RegisterNatives @ %p", target);
}

// ==================================================================
//  EGL SWAP HOOK
// ==================================================================
EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    if (!g_gfx_thread_attached.exchange(true)) {
        Il2CppAttach("libil2cpp.so");
        LOGF("eglSwapBuffers: attached GfxDevice thread to il2cpp");
    }

    static bool is_setup = false;
    if (!is_setup) { SetupImgui(); is_setup = true; }

    ImGuiIO& io = ImGui::GetIO();
    if (screenWidth > 0 && screenHeight > 0)
        io.DisplaySize = ImVec2((float)screenWidth, (float)screenHeight);

    {
        std::lock_guard<std::mutex> lk(g_touch.mtx);
        if (g_touch.down || g_touch.hold_frames > 0) {
            io.MousePos     = ImVec2(g_touch.x, g_touch.y);
            io.MouseDown[0] = true;
            if (g_touch.hold_frames > 0) g_touch.hold_frames--;
        } else {
            io.MouseDown[0] = false;
        }
    }

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();

    {
        ImGui::SetNextWindowPos(ImVec2(kToggleX, kToggleY), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(kToggleSize, kToggleSize), ImGuiCond_Always);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
        ImGui::Begin("##ToggleBtn", nullptr,
                     ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                     ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
                     ImGuiWindowFlags_NoScrollWithMouse |
                     ImGuiWindowFlags_NoBringToFrontOnFocus |
                     ImGuiWindowFlags_NoSavedSettings);

        ImVec2 p = ImGui::GetCursorScreenPos();
        ImDrawList* tdl = ImGui::GetWindowDrawList();
        ImGui::Dummy(ImVec2(kToggleSize, kToggleSize));

        ImVec2 c(p.x + kToggleSize * 0.5f, p.y + kToggleSize * 0.5f);
        tdl->AddCircleFilled(c, kToggleSize * 0.55f, IM_COL32(0, 0, 0, 70));
        tdl->AddCircleFilled(c, kToggleSize * 0.5f,
            showMainMenu ? COL(accent) : IM_COL32(18, 20, 26, 235), 32);
        tdl->AddCircle(c, kToggleSize * 0.5f, COL(accent), 32, 2.0f);

        if (showMainMenu) {
            ImU32 xcol = COL(accent_text);
            float s = 12.0f;
            tdl->AddLine(ImVec2(c.x - s, c.y - s), ImVec2(c.x + s, c.y + s), xcol, 3.0f);
            tdl->AddLine(ImVec2(c.x + s, c.y - s), ImVec2(c.x - s, c.y + s), xcol, 3.0f);
        } else {
            const char* r = "R";
            ImVec2 ts = ImGui::CalcTextSize(r);
            tdl->AddText(ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), COL(accent), r);
        }
        ImGui::End();
        ImGui::PopStyleColor();
        ImGui::PopStyleVar();
    }

    DrawWatermark();
    DrawESP(ImGui::GetBackgroundDrawList(), screenWidth, screenHeight);
    if (showMainMenu) DrawMenu();

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    return old_eglSwapBuffers(dpy, surface);
}

// ==================================================================
//  LIB UNITY DETECTION
// ==================================================================
static bool is_lib_loaded(const char* needle)
{
    struct ctx_t { const char* needle; bool found; } ctx { needle, false };
    dl_iterate_phdr([](struct dl_phdr_info* info, size_t, void* data) -> int {
        ctx_t* c = (ctx_t*)data;
        if (info->dlpi_name && strstr(info->dlpi_name, c->needle)) {
            c->found = true; return 1;
        }
        return 0;
    }, &ctx);
    return ctx.found;
}

static uintptr_t get_lib_base(const char* name)
{
    struct ctx_t { const char* needle; uintptr_t base; } ctx { name, 0 };
    dl_iterate_phdr([](struct dl_phdr_info* info, size_t, void* data) -> int {
        ctx_t* c = (ctx_t*)data;
        if (info->dlpi_name && strstr(info->dlpi_name, c->needle)) {
            c->base = (uintptr_t)info->dlpi_addr;
            return 1;
        }
        return 0;
    }, &ctx);
    return ctx.base;
}

// ==================================================================
//  BOOTSTRAP
// ==================================================================
void *imgui_go(void*) {
    LOGF("imgui_go: waiting for libunity.so");
    for (int i = 0; i < 180; i++) {
        if (is_lib_loaded("libunity.so")) { LOGF("imgui_go: game after %ds", i); break; }
        sleep(1);
    }
    if (!is_lib_loaded("libunity.so")) { LOGF("imgui_go: launcher exit"); pthread_exit(nullptr); }

    LOGF("imgui_go: installing EGL hooks");
    void *handle_egl  = xdl_open("libEGL.so", XDL_DEFAULT);
    void *xdl_sym_egl = xdl_sym(handle_egl, "eglSwapBuffers", nullptr);
    DobbyHook(xdl_sym_egl, (void*)hook_eglSwapBuffers, (void**)&old_eglSwapBuffers);
    LOGF("imgui_go: eglSwapBuffers hooked");

    DobbyHook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"),
                                           OBFUSCATE("ANativeWindow_getWidth")),
              (void *) _ANativeWindow_getWidth,
              (void **) &orig_ANativeWindow_getWidth);
    DobbyHook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"),
                                           OBFUSCATE("ANativeWindow_getHeight")),
              (void *) _ANativeWindow_getHeight,
              (void **) &orig_ANativeWindow_getHeight);
    LOGF("imgui_go: ANativeWindow hooked");

    pthread_exit(nullptr);
}

void* Dlopen(const char* filename, int flags) {
    if (strstr(filename, "libvulkan.so")) {
        LOGF("dlopen: blocked %s", filename);
        return nullptr;
    }
    return old_dlopen(filename, flags);
}

void *hack_thread(void*) {
    LOGF("hack_thread: waiting for libunity.so");
    for (int i = 0; i < 180; i++) {
        if (is_lib_loaded("libunity.so")) { LOGF("hack_thread: game after %ds", i); break; }
        sleep(1);
    }
    if (!is_lib_loaded("libunity.so")) { LOGF("hack_thread: launcher exit"); pthread_exit(nullptr); }

    install_signal_handlers();

    void* libc = dlopen("libc.so", RTLD_NOW);
    DobbyHook(dlsym(libc, "dlopen"), (void*)Dlopen, (void**)&old_dlopen);
    LOGF("hack_thread: dlopen hooked");

    do { sleep(1); } while (!isLibraryLoaded("libil2cpp.so"));
    LOGF("hack_thread: libil2cpp loaded");

    if (sigsetjmp(g_resolve_jmp, 1) != 0) {
        LOGF("hack_thread: Il2CppAttach crashed");
        g_in_resolve = 0;
    } else {
        g_in_resolve = 1;
        Il2CppAttach("libil2cpp.so");
        g_in_resolve = 0;
        LOGF("hack_thread: Il2CppAttach done");
    }

    sleep(3);

    uintptr_t il2cpp_base = get_lib_base("libil2cpp.so");
    LOGF("hack_thread: il2cpp base = 0x%lx", (unsigned long)il2cpp_base);
    if (!il2cpp_base) { LOGF("hack_thread: no base, abort"); pthread_exit(nullptr); }

    // ================================================================
    //  Resolve Unity methods (name lookup → hardcoded fallback)
    // ================================================================
    LOGF("hack_thread: resolving Unity methods...");

    get_main = (void *(*)()) safe_get_offset("UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "get_main", 0);
    if (!get_main) get_main = (void *(*)()) (il2cpp_base + OFF_get_main);
    LOGF("  get_main = %p (offset 0x%lx)", (void*)get_main, (unsigned long)OFF_get_main);

    WorldToScreenPoint = (Vector3 (*)(void*, Vector3)) safe_get_offset("UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "WorldToScreenPoint", 1);
    if (!WorldToScreenPoint) WorldToScreenPoint = (Vector3 (*)(void*, Vector3)) (il2cpp_base + OFF_WorldToScreenPoint);
    LOGF("  WorldToScreenPoint = %p (offset 0x%lx)", (void*)WorldToScreenPoint, (unsigned long)OFF_WorldToScreenPoint);

    get_transform = (void *(*)(void *)) safe_get_offset("UnityEngine.CoreModule.dll", "UnityEngine", "Component", "get_transform", 0);
    if (!get_transform) get_transform = (void *(*)(void *)) (il2cpp_base + OFF_get_transform);
    LOGF("  get_transform = %p (offset 0x%lx)", (void*)get_transform, (unsigned long)OFF_get_transform);

    get_position = (Vector3 (*)(void *)) safe_get_offset("UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "get_position", 0);
    if (!get_position) get_position = (Vector3 (*)(void *)) (il2cpp_base + OFF_get_position);
    LOGF("  get_position = %p (offset 0x%lx)", (void*)get_position, (unsigned long)OFF_get_position);

    // get_isMine — Mirror.NetworkBehaviour::get_isLocalPlayer
    get_isMine = (bool (*)(void*)) safe_get_offset("Mirror.dll", "Mirror", "NetworkBehaviour", "get_isLocalPlayer", 0);
    if (!get_isMine) get_isMine = (bool (*)(void*)) safe_get_offset("Assembly-CSharp.dll", "", "NetworkBehaviour", "get_isLocalPlayer", 0);
    if (!get_isMine) get_isMine = (bool (*)(void*)) (il2cpp_base + OFF_get_isMine);
    LOGF("  get_isMine = %p (offset 0x%lx)", (void*)get_isMine, (unsigned long)OFF_get_isMine);

    // ================================================================
    //  Hook PlayerManager
    // ================================================================
    LOGF("hack_thread: resolving PlayerManager methods...");

    void* update_addr = safe_get_offset("Assembly-CSharp.dll", "Oxide", "PlayerManager", "Update", 0);
    if (!update_addr) update_addr = (void*)(il2cpp_base + OFF_PlayerUpdate);
    LOGF("  PlayerManager::Update = %p (offset 0x%lx)", update_addr, (unsigned long)OFF_PlayerUpdate);
    if (update_addr) {
        DobbyHook(update_addr, (void*) new_PlayerUpdate, (void**) &_PlayerUpdate);
        LOGF("  hooked PlayerManager::Update");
    }

    void* ondisable_addr = safe_get_offset("Assembly-CSharp.dll", "Oxide", "PlayerManager", "OnDisable", 0);
    if (!ondisable_addr) ondisable_addr = (void*)(il2cpp_base + OFF_PlayerOnDisable);
    LOGF("  PlayerManager::OnDisable = %p (offset 0x%lx)", ondisable_addr, (unsigned long)OFF_PlayerOnDisable);
    if (ondisable_addr) {
        DobbyHook(ondisable_addr, (void*) new_PlayerOnDisable, (void**) &old_Player_OnDisable);
        LOGF("  hooked PlayerManager::OnDisable");
    }

    if (get_main && WorldToScreenPoint && get_transform && get_position) {
        g_il2cpp_ready_time.store((int64_t)time(nullptr));
        g_il2cpp_ready.store(true);
        LOGF("hack_thread: il2cpp READY (8s warm-up)");
    } else {
        LOGF("hack_thread: WARNING — missing pointers");
    }

    sleep(5);
    return nullptr;
}

// ==================================================================
//  JNI_OnLoad
// ==================================================================
extern "C" jint JNIEXPORT JNI_OnLoad(JavaVM *vm, void *key) {
    g_vm = vm;
    log_init();
    LOGF("========================================");
    LOGF("@RrQ_Owner loaded -- JNI_OnLoad");
    LOGF("========================================");

    JNIEnv *env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) return JNI_VERSION_1_6;

    install_signal_handlers();
    install_registernatives_hook(env);

    pthread_t hacks;
    pthread_create(&hacks, NULL, imgui_go,    NULL);
    pthread_create(&hacks, NULL, hack_thread, NULL);

    LOGF("threads launched");
    return JNI_VERSION_1_6;
}
