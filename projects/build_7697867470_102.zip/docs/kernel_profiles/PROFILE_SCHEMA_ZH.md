# Kernel profile 结构文档（配置系统）

> English: [PROFILE_SCHEMA.md](PROFILE_SCHEMA.md)

本文是 `app/src/main/assets/kernel_profiles/` 下 profile 的参考：字段含义、路由、
校验规则，以及配置在 Kotlin 与 native 之间的流转。

> 适配新内核的操作步骤见 [README_ZH.md](README_ZH.md)；`execution` 调优默认值见
> [defaults_ZH.md](defaults_ZH.md)。

> **两个版本名不是同一条序列**：
> - **Profile schema 版本**：HOCON 配置代际，由每份 profile 的 `schema_version`
>   字段表达（见第 2 节）。
> - **Binary wire 版本**：magic `0x0D000721` 之后的 GLK1 传输版本。writer 写
>   wire version `2`（对象分段，见第 9 节）。Kotlin 与 native 版本绑定。
>
> 第 0 到 10 节描述当前 v2 配置。旧 v1 JSON 导入路径仅在 Kotlin 侧，集中见第 11 节。

## 0. 文件格式（HOCON）

内置配置、`index.conf`、共享配置与导入的偏移文件都按 **HOCON** 解析：

- JSON 是 HOCON 的子集。支持 `#`、`//` 注释、尾逗号、`${var}` 变量替换（可选写
  `${?var}`）。
- 支持 `include "file.conf"`（相对同目录、可嵌套、防循环）。读取 assets 时由
  `AssetConfigLoader` 展开。导入时优先用一并选中的文件，其次查包内共享文件，
  缺失会报错并要求重新选择。
- Kotlin 侧解析文本（`HoconSupport`），随后把类型化二进制结构体传给 native
  （见第 9 节）。应用内部存储与导出均为 HOCON。
- `ghostlock-extract --format conf` 输出 flatten、自包含的 profile（凭据与
  KernelSnitch 常量内联，无 `include` 行），走常规导入路径。
- 提取器输出是**候选来源**：写出所选路由的全部字段与公共几何，无法取得的值写
  显式 `null`，不会借用相邻内核族的猜测值。导入后由 App 的字段校验填充 `invalidPaths` 并在
  执行前拦截，生成成功不等于设备受支持。

## 1. 数据流总览

```
assets/kernel_profiles/<release>.conf     内置配置（HOCON）
assets/kernel_profiles/execution-tuning.conf   execution 通用调优（所有内核）
assets/kernel_profiles/execution-<route>.conf   各路由的 execution 调优 preset（由 resolver 加载）
assets/kernel_profiles/credential-6x.conf      6.x 凭据模板共享值
assets/kernel_profiles/kernelsnitch-6x.conf    6.x KernelSnitch 共享值
assets/kernel_profiles/<major.minor>-template.conf  参考模板（登记 index，调试页可手动加载；不参与设备匹配与自动回退）
filesDir/offsets.conf                     解析/导入的偏移（imported，HOCON）
内部覆盖（advanced override，sparse）    高级参数覆盖页写入
        │
        ▼  ProfileConfigController.resolve（Kotlin）
   resolved profile（单对象，全字段已合并）
        │
        ├──▶ 运行：类型化二进制（direct 与 Shizuku 都把字节写入 native 的 stdin）
        │      native 只解析并使用几何；不做参数校验
        ├──▶ 快照：filesDir/<release>.conf（HOCON，导出配置的源）
        └──▶ UI：参数覆盖页 / 高级参数覆盖树
```

合并优先级（低 → 高）：`execution-tuning`（+ 按路由的 `execution-<route>.conf`）
→ 内置 profile + imported offsets → 高级覆盖。最后强制写入
`execution.selected_cpus`（来自手动选择或 imported/覆盖中的显式值）。

## 2. 顶层结构

```hocon
# GhostLock kernel profile (HOCON; JSON stays valid)
release = "6.6.77-android15-8-gca30f3b4bef6-abogki440974771-4k"
schema_version = 1
kernel_major = 6
route {
  select_stack { waiter_shift = -2 }
}
fallback { to = "none" }
kernelsnitch { collisions = 4, mm_struct_sz = 4096 }
task_struct { prio = 132, cred = 2080, pi_lock = 2316 }
cred { copy_size = 136, caps_offset = 48, caps_count = 5 }
offset { init_task = 34464384, init_cred = 34538824 }
# execution 调优由 resolver 从 preset 文件提供；只写差异
```

| 字段 | 类型 | 说明 |
|---|---|---|
| `release` | string | 必须与设备 `uname -r` 完全一致（区分大小写/后缀）。模板文件不参与匹配 |
| `schema_version` | int | 固定为 `1` |
| `kernel_major` | int | `5` 或 `6`；用于地址解析与合法性检查，不决定路由 |
| `route` | object | 显式路由父项，只含一个分支，见第 3 节 |
| `fallback` | object | 回退声明（`to` + 可选 `route` 分支），见第 3 节 |
| 几何字段 | object/int | 按命名空间分组：`task_struct` / `cred` / `offset` / `kernelsnitch`。当前路由的全字段与公共几何必须全部出现；无法提供的值写显式 `null`（不要用 `0` 占位）；非当前路由的分支省略，声明的 fallback 除外 |
| `execution` | object | 调优参数（advisory）。通用项来自 `execution-tuning.conf`，路由项来自 `execution-<route>.conf`；两者由 resolver 作为 preset 加载，设备 profile 不 include。只写差异 |

## 3. 路由（route）机制

路由由配置显式声明。缺失或未知的路由会被 native 拒绝，不做推断。`route` 是父项，
**只允许一个分支**：

```hocon
route { tcp_zerocopy { compact_waiter = 1 } }
route { select_stack { waiter_shift = -2 } }
route { multicast_waiter { waiter_off = 96, buffer_size = 264 } }
```

- 每个路由只要求自己的分支。未采用的路由分支完全不写，分支之间不得并存
  （一个配置一种 path）。
- `fallback` 父项声明回退：`"to"` 取 `"none"` 或路由名。声明目标时同时给出
  `"route"` 分支，存放回退执行所需的字段：
  ```hocon
  fallback {
    to = "select_stack"
    route { select_stack { waiter_shift = 1 } }
  }
  ```
  当前实现支持 `tcp_zerocopy` 失败后回退 `select_stack`。写 `"to": "none"` 即关闭。
- native 侧 `RouteKind` 枚举与 Kotlin 侧取值一一对应（`profile.h` /
  `ProfileConfig.Routes`）。

### 必填矩阵

| 字段组 | tcp_zerocopy | select_stack | multicast_waiter |
|---|:---:|:---:|:---:|
| `offset.init_task` / `offset.init_cred` / `offset.root_task_group` / `offset.selinux_enforcing` | 必填 | 必填 | 必填 |
| `task_struct.prio` / `task_struct.pi_lock` / `task_struct.pi_waiters` / `task_struct.pi_blocked_on` / `task_struct.cred` / `task_struct.seccomp` | 必填 | 必填 | 必填 |
| `kernel_major` ∈ {5,6}、`cred.copy_size`、`cred.caps_count` 及凭据模板边界 | 必填 | 必填 | 必填 |
| `route.tcp_zerocopy.compact_waiter` / `route.multicast_waiter.compact_waiter` | 必填 | | 必填 |
| `route.select_stack.waiter_shift` | | 必填（0 合法） | |
| `route.multicast_waiter.waiter_off`（>0）、`route.multicast_waiter.buffer_size`、`route.multicast_waiter.task_offset`、`route.multicast_waiter.lock_offset`、`offset.empty_zero_page`、`kernelsnitch.mm_struct_sz`、`cred.ref_count`（>0） | | | 必填 |

凭据模板边界（通用）：`cred.usage_offset + 4 ≤ cred.copy_size`；
`cred.caps_offset + cred.caps_count × 8 ≤ cred.copy_size`；`cred.ref_count ≤ 4`；
每个 `cred.refN_image` 非零、`cred.refN_offset + 8 ≤ cred.copy_size`。
`multicast_waiter` 还要求 `cred.copy_size ≥ 0xa0` 且
`route.multicast_waiter.waiter_off + route.multicast_waiter.lock_offset + 8 ≤ route.multicast_waiter.buffer_size`。

## 4. 几何字段分组

### 4.0 字段命名

配置字段名即内核结构成员名（`struct` 内偏移）。`offset` 命名空间是内核映像符号
偏移（`init_task`、`init_cred`、`empty_zero_page` 等）。`offset.slide_*` 是 KASLR
滑移探测锚点，与 `kernel_phys_load` 一起把符号地址换算为运行地址。

### 4.1 任务结构偏移（`task_struct`）

| 字段 | 含义 |
|---|---|
| `task_struct.prio` / `task_struct.normal_prio` | 任务优先级 / 常规优先级（PI 提升判定） |
| `task_struct.sched_task_group` | `sched_task_group` 偏移 |
| `task_struct.pi_lock` / `task_struct.pi_waiters` / `task_struct.pi_top_task` / `task_struct.pi_blocked_on` | `pi_lock`、`pi_waiters`、`pi_top_task`、`pi_blocked_on` |
| `task_struct.pid` / `task_struct.tgid` | PID / TGID |
| `task_struct.atomic_flags` | `atomic_flags`（用于现场清理判定） |
| `task_struct.real_cred` / `task_struct.cred` | real cred / cred 指针 |
| `task_struct.comm` / `task_struct.tasks` / `task_struct.seccomp` | `comm`、任务链表、`seccomp` |

### 4.2 凭据模板（`cred`）

| 字段 | 含义 |
|---|---|
| `cred.copy_size` | 凭据结构整体拷贝大小 |
| `cred.usage_offset` / `cred.usage_value` | 引用计数字段偏移 / 目标值 |
| `cred.caps_offset` / `cred.caps_count` / `cred.caps_value` | capability 集合偏移 / 数量 / 填充值 |
| `cred.ref_count` | 需要修复的引用字段数量（≤4） |
| `cred.refN_offset` / `cred.refN_image`（N=0..3） | 各引用字段偏移 / 应恢复的镜像值 |

### 4.3 内核符号与滑移（`offset`）

| 字段 | 含义 |
|---|---|
| `offset.init_task` / `offset.init_cred` | `init_task` / `init_cred` 相对内核镜像基址的偏移 |
| `offset.root_task_group` | `root_task_group` 偏移 |
| `offset.selinux_enforcing` | `selinux_state.enforcing` 偏移（W1 写 0） |
| `offset.selinux_blob_sizes` / `offset.security_hook_heads` | SELinux/安全钩子相关偏移 |
| `offset.slide_nfulnl_logger` / `offset.slide_boot_id` / `offset.slide_loggers_0_1` | 地址滑移（KASLR）定位点 |
| `kernel_phys_load` | 内核物理加载地址（0 时按 SoC 公式回退） |
| `kernel_phys_offset` | DRAM 基址 / linear-map `PHYS_OFFSET`，用于 image→direct-map 换算（缺省用编译期 `P0_PHYS_OFFSET = 0x80000000`）。DRAM 基址不同的设备需填写（如 MTK `0x40000000`）。仅凭 `boot.img` 无法取得，取自 `/proc/iomem`（提取器可用 `--iomem`，或 MediaTek 的 `vendor_boot.img`） |
| `recommend_shizuku` | 该内核是否建议走 Shizuku（0/1，省略时为 0；仅提示不强制）。不在任何编辑器中显示：推荐内核在**每次启动时自动打开**主页“Run via Shizuku”开关，会话内可手动关闭，关闭后本次会话不再要求 Shizuku |

### 4.4 select_stack / tcp 路由字段

| 字段 | 含义 |
|---|---|
| `route.select_stack.waiter_shift` | select 路由 waiter 在栈上的相对位移（0 合法）；回退声明下对应 `fallback.route.select_stack.waiter_shift` |
| `route.tcp_zerocopy.compact_waiter` | tcp 路由的紧凑 waiter 布局标记；multicast 分支下同样需要（`route.multicast_waiter.compact_waiter`） |

### 4.5 multicast_waiter 路由字段（`route.multicast_waiter`）

| 字段 | 含义 |
|---|---|
| `route.multicast_waiter.waiter_off` | 多播缓冲区中 waiter 的偏移（必须 > 0） |
| `route.multicast_waiter.buffer_size` | 伪造缓冲区大小 |
| `route.multicast_waiter.task_offset` / `route.multicast_waiter.lock_offset` | 缓冲区中任务 / 锁字段偏移 |
| `offset.empty_zero_page` | `empty_zero_page` 偏移 |

### 4.6 KernelSnitch 参数（`kernelsnitch`）

所有路由通用（KernelSnitch 用于 `mm_struct` 泄漏搜索）：

| 字段 | 含义 |
|---|---|
| `kernelsnitch.collisions` | 需要的 futex 碰撞数量 |
| `kernelsnitch.mm_struct_sz` | `mm_struct` 的 SLUB 大小（未填写时使用内置默认） |

## 5. execution 调优参数（advisory）

`execution` 全部为建议值，随 profile 合并后传入 native；数值语义与默认值见
[defaults_ZH.md](defaults_ZH.md)。通用分组来自 `execution-tuning.conf`。路由
preset 由 resolver（以及 Gradle exporter）直接加载，设备 profile 不 include：

- `recommended_cpus` / `selected_cpus`：推荐与本地选定核心（`selected_cpus` 由
  参数覆盖页或主页 CPU 选择维护）
- `heap`：KernelSnitch 搜索的尝试次数与超时
- `race`：路由竞态等待/稳定/轮询间隔
- `stages`：W1/W2/W3 尝试次数与稳定时间
- `routes.tcp_zerocopy` / `routes.select_stack`：各路由的重试与等待参数，位于
  `execution-tcp-zerocopy.conf` / `execution-select-stack.conf`。
  `multicast_waiter` 只有几何字段，没有 execution preset，也没有
  `routes.multicast_waiter` 分组。Kotlin 在合成 native 文档时会为缺失的路由组
  补默认值，因此 native 始终收到完整的 `routes` 对象
- `handoff`：root 交接与 KernelSU 加载轮询

## 6. 校验与反馈

校验在 Kotlin（`AndroidProfileConfigController.validateProfileFields`）完成：

1. 按第 3 节矩阵检查公共与所选路由的字段。缺失（`null`）或为 `0` 的必填项、
   越界组合（凭据/多播边界）都会记录到 `ProfileConfig.invalidPaths`。
2. 参数覆盖页与高级参数覆盖中，非法项以红色 label 显示（未填写同样标红）；
   已覆盖且合法项为黄色。
3. `fallback.to` 必须是 `"none"` 或合法路由名。声明回退时，目标分支的必填字段
   同样会被校验（如回退 `select_stack` 需要
   `fallback.route.select_stack.waiter_shift` 存在，0 合法）。
4. 主页“执行”按钮在 `invalidPaths` 非空时置灰，点击提示修正红色项。即使绕过，
   `runExploit` 也会在启动 native 前拦截并写入日志。
5. native 不做几何校验，只解析 v2 二进制并按给定的组件选择与字段执行。

## 7. 加载层次与存储位置

| 层 | 来源 | 位置 | 写入者 |
|---|---|---|---|
| shared | 共享值；tuning preset 由 resolver/exporter 加载，core 共享值由设备 profile `include` | `execution-tuning.conf` / `execution-<route>.conf` / `credential-6x.conf` / `kernelsnitch-6x.conf` | 随包发布 |
| builtin | 精确 `uname -r` 命中；未命中即视为不支持 | `assets/kernel_profiles/*.conf` | 随包发布 |
| imported | 解析/导入的偏移（同一 release entry） | `filesDir/offsets.conf` | 解析 OTA / 导入配置文件 |
| general override | `execution.*` | `filesDir/offsets.conf` 的 release entry | 参数覆盖页“一般参数覆盖 / 重设参数” |
| route override | `route` / `fallback.to` | `filesDir/offsets.conf` 的 release entry | 高级配置覆盖页“路由 / 回退” |
| advanced override | 任意数值路径（sparse，HOCON 文本） | 内部 `debug_profile_overrides` | 高级配置覆盖（自动保存） |
| 快照 | 合并后的完整 HOCON | `filesDir/<release>.conf` | 任何覆盖保存后、导出前 |
| 手动内置来源 | 指定其他真实 release（危险） | 内部 `debug_builtin_release` | 参数页“加载其他内置配置（危险）”；覆盖仍绑定本机 release |

导出配置：把该 release 的合并快照（HOCON 单文件，include 已合并、已按路由精简
调优项）写入用户选择的文件夹（SAF）。

## 8. 模板配置（*-template）

- 每个大版本一个：`5.15-template` / `6.1-template` / `6.6-template` /
  `6.12-template`，登记在 `index.conf`，仅作**开发与调试参考**。
- 所有几何/偏移字段为 `null`（未填写），`route` / `fallback` 给出完整分支
  结构；每个字段上方都有中文说明注释，可直接复制填写。
- 在内置选择页的“模板（参考，未填写）”分区可手动加载，用于查看字段结构。
  模板**不参与设备匹配，也不做自动回退**。设备无精确命中且无 imported 时视为
  不支持。
- 模板只含 core 字段（以及 core 的 include）；execution 调优由 resolver 从
  `execution-*.conf` 提供，复制模板无需补 tuning include。仓库内的同步副本见
  `docs/kernel_profiles/templates/`，assets 中的原文件可用 adb 查看。

## 9. native 传输与解析

运行时的配置传输是**类型化二进制结构体**（v2，对象分段），不是 JSON 文本。
v2 是唯一版本：Kotlin 与 native 版本绑定，不做旧版本兼容解码。

- Kotlin 侧由 `NativeProfileDocument` 经 `toBinary()` 序列化：先是 16 字节小端头
  `u32 magic(0x0D000721) + u16 version(2) + u16 frontend + u16 backend + u16 middleware + u16 release_len + u16 reserved`，
  随后是 `release` 文本、`u16 section_count`，每个 section 为
  `u8 name_len + name + u32 entry_count`，每个条目为
  `u8 key_len + key + u64 value`。
  presence 由键是否出现表达（缺席 ≠ 提供的 0）；值为 u64 原始位型（有符号为
  二补数），不做 clamp；只写/接受**当前 route** 的 `route.*` section；未知
  section/键忽略；重复键 last-wins。`middleware` 承载 route。权威 section/键表在
  `profile/binary.cpp`（`kSections`），`NativeProfile.kt` 的对象 section 必须
  逐字对齐。
- App 调用：direct 与 Shizuku 均通过 `--ghostlock-app-call` 从 **stdin** 传入
  profile，不写入 `active-profile.bin`。命令行运行时，
  `--load-prebuilt-profile <bin>` 从导出的 GLK1 文件读取。
- native 只有一条解码路径：`profile/entry.cpp` 把 stdin（或文件）字节交给
  `profile/binary.cpp::parse`。它不检测 magic 之外的格式，也没有 JSON 回退。
- 内部存储与“导出配置”均为 HOCON（人类可读）。旧 v1 `offsets.json` 只在
  Kotlin 侧转成 v2，见第 11 节。
- 运行时路由与能力判断（`TargetProfile::route()`、`TargetProfile::supports()`、
  `route_capability`）全部基于解析后的 route。

## 10. 修改配置的检查清单

1. 每份 profile 都要包含当前路由的全字段与公共几何，且每项都必须出现；镜像或
   设备无法提供的值写显式 `null`（不要用 `0` 占位，除非 0 就是真实值）。非当前
   路由（及其声明的 fallback）的字段省略。`ghostlock-extract --format conf` 会
   输出这份完整骨架；`null` 使字段在 app 中可见可编辑，而不是悄无声息地缺失。
2. `route` 只能有一个分支，且分支内必须给出该路由的必填字段；`fallback.to`
   声明了回退目标时，`fallback.route` 分支内同样要补齐。
   共享 core 值通过 `include` 引入，不要复制：`credential-6x.conf`（6.x 凭据
   模板）、`kernelsnitch-6x.conf`（6.x collisions）。execution 调优
   （`execution-tuning.conf` / `execution-<route>.conf`）由 resolver 作为 preset
   加载，设备 profile 不要 include。
3. 修改 `execution` 需要设备实测依据；否则保持 defaults。
4. 本地验证：`make -C src native-host-tests`（profiles 解码/校验向量）与
   `./gradlew :app:assembleDebug`。
5. 修改字段命名/分组时同步更新：`FieldLabels.kt` + `values*/strings.xml`、
   可能的 `docs/kernel_profiles/defaults*.md`。

## 11. 旧 v1 JSON 导入（兼容）

本节集中说明 **v1 JSON** 兼容层。第 0 到 10 节只描述当前 v2 配置。native 只读
v2（见第 9 节），v1 路径仅在 Kotlin 侧且自包含。

- **v1 是旧 JSON 格式**：remote/main 时代的 `offsets.json`，即提取器报告
  （`symbols` / `struct_fields`、4 个顶层标量，以及 `kimage_text_base` /
  `btf_size` / `kallsyms` 等元数据）。`ghostlock-extract --format json` 仍按此
  形状输出给外部工具。
- 加载时由 `LegacyProfileConverter` 把 v1 文档归一为 v2（幂等）：

  | v1 内容 | 转换结果 |
  |---|---|
  | `symbols` 对象（`off_*` 键） | `offset.*` 命名空间 |
  | `struct_fields` 对象（`task_*` 键） | `task_struct.*` 命名空间；`rt_mutex_waiter` / `cred_uid` / `seccomp_*` 等字段保留原处，不参与校验与比较 |
  | 顶层 `pselect_waiter_shift` | `route.select_stack.waiter_shift`；tcp 配置则保留为 `fallback.route.select_stack.waiter_shift` |
  | 顶层 `compact_waiter` / `mm_struct_sz` | `route.tcp_zerocopy.compact_waiter` / `kernelsnitch.mm_struct_sz` |
  | `kimage_text_base` / `btf_size` / `kallsyms` | 丢弃 |
  | 无 `route` 字段 | 按 6.x 几何推断：`compact_waiter` → tcp，否则 select |
  | 无 cred 模板 | 写入内置 6.x 常量（`credential-6x.conf` / `kernelsnitch-6x.conf`）；5.x 凭据字段仍由作者提供 |

- 旧版扁平键（`kernelsnitch_collisions` / `mm_struct_sz` / `task_*` / `cred_*` /
  `off_*` / `mcast_*`）在导入旧 `offsets.json`、解析 extractor 输出或读取高级
  覆盖时自动归入对应命名空间。
- 旧配置缺少 `route` 时同样按此推断：`kernel_major==5 且 mcast.waiter_off>0`
  → `multicast_waiter`；否则 `compact_waiter!=0` → `tcp_zerocopy`；否则
  `select_stack`。v1 文档不可能选中 5.x 分支（`multicast_waiter` 仅作为受保护
  推断保留）。
- 旧版 JSON 缓存**不迁移、启动即丢弃**。内部存储、快照与导出始终为 HOCON。
- native 无 v1 解析器：native 侧 `legacy/` JSON 解码器已删除；v1 文档在传输前
  已由 Kotlin 侧转成 v2。
