import asyncio
import json
import logging
import os
import random
import re
import sqlite3
import string
import time
from aiohttp import web
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

# ==========================================
# КОНФИГУРАЦИЯ БОТА И СЕРВЕРА
# ==========================================
BOT_TOKEN = os.getenv("BOT_TOKEN", "ВАШ_ТОКЕН_БОТА")
ADMIN_IDS = [int(i.strip()) for i in os.getenv("ADMIN_IDS", "123456789").split(",") if i.strip()]
API_PORT = int(os.getenv("PORT", "26801"))
DB_PATH = "sakura_keys.db"

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("SaKuRaBot")

# ==========================================
# БАЗА ДАННЫХ SQLITE
# ==========================================
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    # Таблица лицензионных ключей
    cur.execute("""
        CREATE TABLE IF NOT EXISTS keys (
            key_code TEXT PRIMARY KEY,
            duration_hours INTEGER,
            created_at INTEGER,
            activated_at INTEGER,
            expires_at INTEGER,
            hwid TEXT,
            device_model TEXT,
            is_active INTEGER DEFAULT 1,
            created_by INTEGER
        )
    """)
    # Таблица привязки устройств к Telegram пользователям
    cur.execute("""
        CREATE TABLE IF NOT EXISTS device_bindings (
            hwid TEXT PRIMARY KEY,
            chat_id INTEGER,
            username TEXT,
            bound_at INTEGER
        )
    """)
    # Таблица модификаций (.sh скрипты и ссылки)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS mods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            description TEXT,
            sh_url TEXT,
            image_url TEXT,
            created_at INTEGER
        )
    """)
    conn.commit()
    conn.close()

def generate_key_string():
    parts = [''.join(random.choices(string.ascii_uppercase + string.digits, k=4)) for _ in range(2)]
    return f"SKR-{parts[0]}-{parts[1]}"

def add_key(duration_hours: int, admin_id: int):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    key_code = generate_key_string()
    now = int(time.time())
    cur.execute("""
        INSERT INTO keys (key_code, duration_hours, created_at, is_active, created_by)
        VALUES (?, ?, ?, 1, ?)
    """, (key_code, duration_hours, now, admin_id))
    conn.commit()
    conn.close()
    return key_code

def verify_key_in_db(key_code: str, hwid: str, device_model: str):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT key_code, duration_hours, activated_at, expires_at, hwid, is_active FROM keys WHERE key_code = ?", (key_code,))
    row = cur.fetchone()

    now = int(time.time())

    if not row:
        conn.close()
        return {"valid": False, "error": "Ключ не найден"}

    key_code, duration_hours, activated_at, expires_at, bound_hwid, is_active = row

    if is_active != 1:
        conn.close()
        return {"valid": False, "error": "Ключ заблокирован"}

    if not activated_at or not bound_hwid:
        new_expires = now + (duration_hours * 3600)
        cur.execute("""
            UPDATE keys
            SET activated_at = ?, expires_at = ?, hwid = ?, device_model = ?
            WHERE key_code = ?
        """, (now, new_expires, hwid, device_model, key_code))
        conn.commit()
        conn.close()
        return {
            "valid": True,
            "activated_now": True,
            "expires_at": new_expires,
            "time_left_sec": duration_hours * 3600,
            "message": "Ключ успешно активирован"
        }

    if bound_hwid != hwid:
        conn.close()
        return {
            "valid": False,
            "error": "Ключ уже привязан к другому устройству!"
        }

    if expires_at and now > expires_at:
        conn.close()
        return {"valid": False, "error": "Срок действия лицензии истёк"}

    time_left = max(0, expires_at - now)
    conn.close()
    return {
        "valid": True,
        "activated_now": False,
        "expires_at": expires_at,
        "time_left_sec": time_left,
        "message": "Лицензия активна"
    }

def get_all_keys():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT key_code, duration_hours, activated_at, expires_at, hwid, device_model, is_active FROM keys ORDER BY created_at DESC LIMIT 50")
    rows = cur.fetchall()
    conn.close()
    return rows

def reset_key_hwid(key_code: str):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("UPDATE keys SET hwid = NULL, device_model = NULL WHERE key_code = ?", (key_code,))
    affected = cur.rowcount
    conn.commit()
    conn.close()
    return affected > 0

def delete_key(key_code: str):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("DELETE FROM keys WHERE key_code = ?", (key_code,))
    affected = cur.rowcount
    conn.commit()
    conn.close()
    return affected > 0

# --- Функции привязки устройств ---
def bind_device_to_user(hwid: str, chat_id: int, username: str = ""):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    now = int(time.time())
    cur.execute("""
        INSERT OR REPLACE INTO device_bindings (hwid, chat_id, username, bound_at)
        VALUES (?, ?, ?, ?)
    """, (hwid, chat_id, username, now))
    conn.commit()
    conn.close()

def get_chat_id_by_hwid(hwid: str):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT chat_id FROM device_bindings WHERE hwid = ?", (hwid,))
    row = cur.fetchone()
    conn.close()
    return row[0] if row else None

def get_all_bound_chats():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT chat_id FROM device_bindings")
    rows = cur.fetchall()
    conn.close()
    return [r[0] for r in rows]

# --- Функции модификаций ---
def add_modification(title: str, description: str, sh_url: str, image_url: str):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    now = int(time.time())
    cur.execute("""
        INSERT INTO mods (title, description, sh_url, image_url, created_at)
        VALUES (?, ?, ?, ?, ?)
    """, (title, description, sh_url, image_url, now))
    mod_id = cur.lastrowid
    conn.commit()
    conn.close()
    return mod_id

def get_all_modifications():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id, title, description, sh_url, image_url, created_at FROM mods ORDER BY id DESC")
    rows = cur.fetchall()
    conn.close()
    mods = []
    for r in rows:
        mods.append({
            "id": r[0],
            "title": r[1],
            "description": r[2],
            "sh_url": r[3],
            "image_url": r[4],
            "created_at": r[5]
        })
    return mods

def delete_modification(mod_id: int):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("DELETE FROM mods WHERE id = ?", (mod_id,))
    affected = cur.rowcount
    conn.commit()
    conn.close()
    return affected > 0

# ==========================================
# HTTP REST API ДЛЯ ПРИЛОЖЕНИЯ SAKURAROOT
# ==========================================
async def handle_verify(request):
    try:
        if request.method == "POST":
            data = await request.json()
        else:
            data = request.query

        key = data.get("key", "").strip()
        hwid = data.get("hwid", "unknown").strip()
        device = data.get("device", "Android Device").strip()

        # Разрешаем мастер-ключи разработчика и админ-ключ Altrincham
        if key in ["Altrincham", "777777", "SAKURA-DEV", "MASTER", "OXIDE", "PRO"]:
            is_admin = (key.lower() == "altrincham")
            return web.json_response({
                "valid": True,
                "is_admin": is_admin,
                "message": "Вход администратора Altrincham" if is_admin else "Разработчик / Мастер-ключ",
                "expires_at": int(time.time()) + 315360000,
                "subscription": "Oxide"
            })

        if not key:
            return web.json_response({"valid": False, "error": "Ключ не передан"}, status=400)

        result = verify_key_in_db(key, hwid, device)
        result["is_admin"] = False
        return web.json_response(result)
    except Exception as e:
        logger.error(f"API Error: {e}")
        return web.json_response({"valid": False, "error": str(e)}, status=500)

async def handle_notify_root(request):
    try:
        if request.method == "POST":
            data = await request.json()
        else:
            data = request.query

        key = data.get("key", "Unknown").strip()
        hwid = data.get("hwid", "Unknown").strip()
        device = data.get("device", "Android Device").strip()
        now_str = time.strftime("%Y-%m-%d %H:%M:%S")

        # 1. Уведомление администраторам
        alert_text = (
            "🔥 **[НОВЫЙ ROOT] Устройство получило Root-права!**\n\n"
            f"📱 **Модель:** `{device}`\n"
            f"🔑 **Ключ:** `{key}`\n"
            f"🆔 **HWID:** `{hwid}`\n"
            f"⏰ **Время:** `{now_str}`"
        )
        for admin_id in ADMIN_IDS:
            try:
                await bot.send_message(admin_id, alert_text, parse_mode="Markdown")
            except Exception as ex:
                logger.error(f"Failed to send admin alert to {admin_id}: {ex}")

        # 2. Персональное уведомление привязанному пользователю
        user_chat_id = get_chat_id_by_hwid(hwid)
        if user_chat_id:
            try:
                user_msg = (
                    "🎉 **Поздравляем! Ваше устройство получило Root-права!**\n\n"
                    f"📱 **Модель:** `{device}`\n"
                    "Все модули и функции ядра успешно активированы."
                )
                await bot.send_message(user_chat_id, user_msg, parse_mode="Markdown")
            except Exception as ex:
                logger.error(f"Failed to notify user {user_chat_id}: {ex}")

        return web.json_response({"status": "ok", "message": "Root status notified"})
    except Exception as e:
        logger.error(f"Notify root error: {e}")
        return web.json_response({"status": "error", "error": str(e)}, status=500)

async def handle_get_mods(request):
    try:
        mods = get_all_modifications()
        return web.json_response({"status": "ok", "mods": mods})
    except Exception as e:
        logger.error(f"Get mods error: {e}")
        return web.json_response({"status": "error", "error": str(e)}, status=500)

async def handle_add_mod(request):
    try:
        data = await request.json()
        admin_key = data.get("admin_key", "").strip()
        if admin_key.lower() != "altrincham":
            return web.json_response({"status": "error", "error": "Доступ запрещен. Требуется ключ Altrincham"}, status=403)

        title = data.get("title", "").strip()
        description = data.get("description", "").strip()
        sh_url = data.get("sh_url", "").strip()
        image_url = data.get("image_url", "").strip()

        if not title or not sh_url:
            return web.json_response({"status": "error", "error": "Название и ссылка на .sh обязательны"}, status=400)

        mod_id = add_modification(title, description, sh_url, image_url)
        logger.info(f"Добавлена модификация #{mod_id}: {title}")

        # Оповещаем всех привязанных пользователей о новой модификации
        bound_chats = get_all_bound_chats()
        broadcast_text = (
            "🚀 **Новая модификация в SaKuRaRoot!**\n\n"
            f"📦 **{title}**\n"
            f"📝 {description}\n\n"
            "Зайдите в раздел «Модификации» в приложении, чтобы скачать и запустить!"
        )
        for cid in bound_chats:
            try:
                await bot.send_message(cid, broadcast_text, parse_mode="Markdown")
            except Exception:
                pass

        return web.json_response({"status": "ok", "mod_id": mod_id, "message": "Модификация успешно опубликована"})
    except Exception as e:
        logger.error(f"Add mod error: {e}")
        return web.json_response({"status": "error", "error": str(e)}, status=500)

# ==========================================
# TELEGRAM БОТ
# ==========================================
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

def admin_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="⏳ 1 День", callback_data="gen_24"),
            InlineKeyboardButton(text="⚡ 7 Дней", callback_data="gen_168"),
        ],
        [
            InlineKeyboardButton(text="🔥 30 Дней", callback_data="gen_720"),
            InlineKeyboardButton(text="👑 Навсегда (365д)", callback_data="gen_8760"),
        ],
        [
            InlineKeyboardButton(text="📋 Список ключей", callback_data="list_keys"),
        ]
    ])

@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    text_parts = message.text.split()
    # Проверяем, передан ли параметр привязки устройства через диплинк (/start bind_HWID)
    if len(text_parts) > 1 and text_parts[1].startswith("bind_"):
        hwid = text_parts[1].replace("bind_", "").strip()
        bind_device_to_user(hwid, message.chat.id, message.from_user.username or "")
        await message.answer(
            "✅ **Устройство успешно привязано к вашему Telegram!**\n\n"
            f"📱 **HWID:** `{hwid}`\n\n"
            "🔔 Теперь вам будут приходить:\n"
            "• Уведомления об успешном получении Root-прав на планшете/телефоне;\n"
            "• Оповещения о выходе новых модификаций и обновлений ядра.",
            parse_mode="Markdown"
        )
        return

    # Если обычный старт для админа
    if message.from_user.id in ADMIN_IDS:
        await message.answer(
            "🌸 **Панель управления SaKuRaRoot:**\n\n"
            "Выберите срок для генерации нового ключа:",
            reply_markup=admin_keyboard(),
            parse_mode="Markdown"
        )
    else:
        await message.answer(
            "🌸 **SaKuRaRoot Bot**\n\n"
            "• Для привязки устройства нажмите кнопку «Привязать Telegram» в приложении.\n"
            "• Для покупки ключа обратитесь к администратору.",
            parse_mode="Markdown"
        )

# Обработка сообщений, если пользователь просто скинул ссылку вида https://t.me/bot?start=bind_xxx
@dp.message(F.text.contains("bind_"))
async def handle_manual_bind_link(message: types.Message):
    match = re.search(r"bind_([a-zA-Z0-9_\-]+)", message.text)
    if match:
        hwid = match.group(1).strip()
        bind_device_to_user(hwid, message.chat.id, message.from_user.username or "")
        await message.answer(
            "✅ **Устройство успешно привязано к Telegram!**\n\n"
            f"📱 **HWID:** `{hwid}`\n\n"
            "Вам будут приходить личные уведомления о получении Root и выходе обновлений.",
            parse_mode="Markdown"
        )
    else:
        await message.answer("❌ Не удалось распознать код привязки.")

@dp.callback_query(F.data.startswith("gen_"))
async def cb_gen_key(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("У вас нет прав администратора!", show_alert=True)
        return

    hours = int(callback.data.split("_")[1])
    key = add_key(hours, callback.from_user.id)
    time_label = f"{hours // 24} дн." if hours >= 24 else f"{hours} ч."
    await callback.message.answer(
        f"✅ **Ключ создан!**\n\n"
        f"🔑 `{key}`\n"
        f"⏳ **Срок:** {time_label}\n"
        f"📱 **Привязка:** зафиксируется при первом вводе.",
        parse_mode="Markdown",
        reply_markup=admin_keyboard()
    )
    await callback.answer()

@dp.callback_query(F.data == "list_keys")
async def cb_list_keys(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return

    keys = get_all_keys()
    if not keys:
        await callback.message.answer("Ключей пока нет.", reply_markup=admin_keyboard())
        await callback.answer()
        return

    lines = ["📋 **Последние ключи:**\n"]
    for row in keys[:15]:
        k, hours, act, exp, hwid, dev, active = row
        status = "🟢" if act else "⚪"
        lines.append(f"• `{k}` ({hours // 24}д) {status}")
    await callback.message.answer("\n".join(lines), parse_mode="Markdown", reply_markup=admin_keyboard())
    await callback.answer()

@dp.message(Command("notify_all"))
async def cmd_notify_all(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    text = message.text.replace("/notify_all", "").strip()
    if not text:
        await message.answer("Использование: `/notify_all Текст обновления`")
        return
    chats = get_all_bound_chats()
    sent = 0
    for cid in chats:
        try:
            await bot.send_message(cid, f"📢 **Обновление SaKuRaRoot:**\n\n{text}", parse_mode="Markdown")
            sent += 1
        except Exception:
            pass
    await message.answer(f"✅ Уведомление разослано {sent} пользователям!")

@dp.message(Command("reset"))
async def cmd_reset_hwid(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    args = message.text.split()
    if len(args) < 2:
        await message.answer("Использование: `/reset SKR-XXXX-XXXX`")
        return
    key = args[1].strip()
    if reset_key_hwid(key):
        await message.answer(f"✅ Привязка устройства для ключа `{key}` успешно сброшена!")
    else:
        await message.answer("❌ Ключ не найден.")

@dp.message(Command("del"))
async def cmd_del_key(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    args = message.text.split()
    if len(args) < 2:
        await message.answer("Использование: `/del SKR-XXXX-XXXX`")
        return
    key = args[1].strip()
    if delete_key(key):
        await message.answer(f"🗑 Ключ `{key}` удалён.")
    else:
        await message.answer("❌ Ключ не найден.")

# ==========================================
# ТОЧКА ВХОДА
# ==========================================
async def main():
    init_db()
    app = web.Application()
    app.router.add_get("/api/verify", handle_verify)
    app.router.add_post("/api/verify", handle_verify)
    app.router.add_get("/api/notify_root", handle_notify_root)
    app.router.add_post("/api/notify_root", handle_notify_root)
    app.router.add_get("/api/mods", handle_get_mods)
    app.router.add_post("/api/mods", handle_add_mod)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", API_PORT)
    await site.start()
    logger.info(f"API запущен на порту {API_PORT}")

    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
