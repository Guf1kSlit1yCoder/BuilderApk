package com.altro.root.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircleOutline
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.altro.root.R
import com.altro.root.data.ManagerScanner
import com.altro.root.domain.model.CpuPair
import com.altro.root.domain.model.ExecutionFieldValue
import com.altro.root.domain.model.ProfileFieldNode
import com.altro.root.domain.model.ShizukuStatus
import com.altro.root.domain.model.UserProfileFile
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONArray
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.CardDefaults
import top.yukonga.miuix.kmp.basic.DropdownItem
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.ScrollBehavior
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.basic.TextFieldDefaults
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.basic.rememberTopAppBarState
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.Close
import top.yukonga.miuix.kmp.icon.extended.Copy
import top.yukonga.miuix.kmp.nav.core.NavBackStack
import top.yukonga.miuix.kmp.nav.core.NavDisplay
import top.yukonga.miuix.kmp.nav.core.NavDisplayEffects
import top.yukonga.miuix.kmp.nav.core.NavKey
import top.yukonga.miuix.kmp.nav.core.navBackStackOf
import top.yukonga.miuix.kmp.nav.core.rememberNavSystemCornerRadius
import top.yukonga.miuix.kmp.nav.transition.NavSwipeDirection
import top.yukonga.miuix.kmp.overlay.OverlayBottomSheet
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.OverlaySpinnerPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.theme.darkColorScheme
import top.yukonga.miuix.kmp.theme.lightColorScheme
import top.yukonga.miuix.kmp.utils.PressFeedbackType
import top.yukonga.miuix.kmp.utils.overScrollVertical
import top.yukonga.miuix.kmp.utils.scrollEndHaptic

data class GhostlockUiState(
    val deviceName: String = "",
    val kernelRelease: String = "",
    val socName: String = "",
    val kernelSupported: Boolean = false,
    val shizukuEnabled: Boolean = false,
    val shizukuStatus: ShizukuStatus = ShizukuStatus.NOT_REQUIRED,
    val running: Boolean = false,
    val cpuPairLabels: List<String> = emptyList(),
    val cpuPairIndex: Int = 0,
    /** CPU pair from the resolved profile when it differs from the device pick. */
    val customCpuPair: CpuPair? = null,
    val safeModeEnabled: Boolean = false,
    val forceAttackTestEnabled: Boolean = false,
    val tcpRouteEnabled: Boolean = true,
    val compact: Boolean = false,
    val executionSheetVisible: Boolean = false,
    val executionSheetDismissible: Boolean = false,
    val dialogVisible: Boolean = false,
    val dialogType: DialogType = DialogType.NONE,
    val dialogTitleRes: Int = 0,
    val dialogMessage: String = "",
    val dialogMessageRes: Int = 0,
    val dialogItems: List<String> = emptyList(),
    val dialogItemResIds: List<Int> = emptyList(),
    val dialogCurrentItemIndex: Int = -1,
    val dialogInput: String = "",
    val dialogConfirmLabelRes: Int = R.string.parse_start,
    /** Documentation URL shown as an extra button on a NOTICE dialog. */
    val dialogDocUrl: String? = null,
    val overwriteDialogVisible: Boolean = false,
    val overwriteMessage: String = "",
    val logLines: List<GhostlockLogLine> = emptyList(),
    val executionRelease: String = "",
    val executionHasProfile: Boolean = false,
    val executionFields: List<ExecutionFieldValue> = emptyList(),
    val executionEditing: Map<String, String> = emptyMap(),
    val advancedScreenVisible: Boolean = false,
    val debugExportEnabled: Boolean = true,
    val debugExportLocation: String = "",
    val debugKernelLogEnabled: Boolean = true,
    val aboutVisible: Boolean = false,
    val parametersVisible: Boolean = false,
    val profileOverrideVisible: Boolean = false,
    val advancedOverrideVisible: Boolean = false,
    /** Stored document edited by the open session; null for the builtin. */
    val editTargetName: String? = null,
    val profileOverrideRelease: String = "",
    val profileOverrideRoots: List<ProfileFieldNode> = emptyList(),
    val profileOverrideEditing: Map<String, String> = emptyMap(),
    /** Controller-reported geometry violations, dotted paths. */
    val profileInvalidPaths: Set<String> = emptySet(),
    /** Explicit route from the profile; null means geometry inference. */
    val profileRoute: String? = null,
    /** Declared fallback route; null/"none" means disabled. */
    val profileFallback: String? = null,
    /** Manually selected builtin source; null means automatic matching. */
    val activeBuiltinProfile: String? = null,
    val builtinScreenVisible: Boolean = false,
    /** Unfilled reference templates, listed separately on the builtin picker. */
    val builtinTemplates: List<String> = emptyList(),
    /** Builtin releases sorted by similarity to the device kernel. */
    val builtinProfiles: List<String> = emptyList(),
    val loadConfigVisible: Boolean = false,
    /** Verbatim documents in the user profile folder, newest first. */
    val userProfiles: List<UserProfileFile> = emptyList(),
    /** Loaded user document feeding the imported layer; null means none. */
    val activeUserProfile: String? = null,
    /** File name of the open user-profile detail screen, null when closed. */
    val userProfileDetail: String? = null,
    val userProfileRenameTarget: String? = null,
    val userProfileDeleteTarget: String? = null,
    val managerCandidates: List<ManagerScanner.Candidate> = emptyList(),
    val selectedManagerPackage: String? = null,
    val managerPickerVisible: Boolean = false,
)

enum class DialogType { NONE, LIST, INPUT, CONFIRM, NOTICE }

data class GhostlockLogLine(val text: String, val color: Int)

interface GhostlockActions {
    fun onRun()
    fun onProfileInvalid()
    fun onStatusClick()
    fun onCloseExecutionSheet()
    fun onCopyLogs()
    fun onImportOffsetsHocon()
    fun onImportOffsetsJson()
    fun onDocumentsResult(request: DocumentRequest, uris: List<String>)
    fun onParseOta()
    fun onParseImage()
    fun onCpuPairSelected(index: Int)
    fun onSafeModeChanged(enabled: Boolean)
    fun onForceAttackTestChanged(enabled: Boolean)
    fun onShizukuChanged(enabled: Boolean)
    fun onOpenManagerPicker()
    fun onCloseManagerPicker()
    fun onManagerSelected(pkg: String?)
    fun onDialogItemSelected(index: Int)
    fun onDialogInputChange(value: String)
    fun onDialogConfirm(value: String)
    fun onDialogDismiss()
    fun onDialogDismissFinished()
    fun onOverwriteConfirm()
    fun onOverwriteDismiss()
    fun onExecutionFieldChanged(path: String, value: String)
    fun onRouteChanged(index: Int)
    fun onFallbackChanged(index: Int)
    fun onExportProfile()
    fun onSaveProfileEdits()
    fun onSaveProfileAs()
    fun onExportProfileEdits()
    fun onRevertProfileEdits()
    fun onOpenAdvanced()
    fun onCloseAdvanced()
    fun onShowAbout()
    fun onCloseAbout()
    fun onDebugExportChanged(enabled: Boolean)
    fun onDebugExportLocationPick()
    fun onDebugKernelLogChanged(enabled: Boolean)
    fun onOpenParameters()
    fun onCloseParameters()
    fun onOpenLoadConfig()
    fun onCloseLoadConfig()
    fun onOpenUserProfileDetail(name: String)
    fun onCloseUserProfileDetail()
    fun onLoadUserProfile(name: String)
    fun onUnloadUserProfile()
    fun onEditUserProfile(name: String)
    fun onUserProfileRename(name: String)
    fun onUserProfileExport(name: String)
    fun onConvertUserProfile(name: String)
    fun onUserProfileDelete(name: String)
    fun onUserProfileDeleteConfirm()
    fun onUserProfileDeleteDismiss()
    fun onOpenBuiltinProfiles()
    fun onCloseBuiltinProfiles()
    fun onSelectBuiltinProfile(release: String?)
    fun onOpenProfileOverrides()
    fun onCloseProfileOverrides()
    fun onOpenAdvancedOverrides()
    fun onCloseAdvancedOverrides()
    fun onProfileOverrideChanged(path: String, value: String)
}

internal sealed interface GhostlockScreen : NavKey {
    data object Main : GhostlockScreen
    data object Advanced : GhostlockScreen
    data object About : GhostlockScreen
    data object Parameters : GhostlockScreen
    data object LoadConfig : GhostlockScreen
    data object Builtin : GhostlockScreen
    data class UserProfileDetail(val name: String) : GhostlockScreen
    data object ProfileOverride : GhostlockScreen
    data object AdvancedOverride : GhostlockScreen
}

internal fun navigationPath(state: GhostlockUiState): List<GhostlockScreen> {
    val path = mutableListOf<GhostlockScreen>(GhostlockScreen.Main)
    if (!state.advancedScreenVisible) return path
    path += GhostlockScreen.Advanced
    if (state.aboutVisible) {
        path += GhostlockScreen.About
        return path
    }
    if (!state.parametersVisible) return path
    path += GhostlockScreen.Parameters
    if (state.loadConfigVisible) {
        path += GhostlockScreen.LoadConfig
        when {
            state.builtinScreenVisible -> path += GhostlockScreen.Builtin
            state.userProfileDetail != null ->
                path += GhostlockScreen.UserProfileDetail(state.userProfileDetail)
        }
    }
    if (state.profileOverrideVisible) {
        path += GhostlockScreen.ProfileOverride
        if (state.advancedOverrideVisible) path += GhostlockScreen.AdvancedOverride
    }
    return path
}

internal fun syncNavigationPath(backStack: NavBackStack, desired: List<GhostlockScreen>) {
    var common = 0
    while (common < backStack.size && common < desired.size &&
        backStack[common] == desired[common]
    ) {
        common++
    }
    while (backStack.size > common) backStack.removeAt(backStack.lastIndex)
    backStack.addAll(desired.drop(common))
}

private fun closeScreen(screen: GhostlockScreen, actions: GhostlockActions) {
    when (screen) {
        GhostlockScreen.Main -> Unit
        GhostlockScreen.Advanced -> actions.onCloseAdvanced()
        GhostlockScreen.About -> actions.onCloseAbout()
        GhostlockScreen.Parameters -> actions.onCloseParameters()
        GhostlockScreen.LoadConfig -> actions.onCloseLoadConfig()
        GhostlockScreen.Builtin -> actions.onCloseBuiltinProfiles()
        is GhostlockScreen.UserProfileDetail -> actions.onCloseUserProfileDetail()
        GhostlockScreen.ProfileOverride -> actions.onCloseProfileOverrides()
        GhostlockScreen.AdvancedOverride -> actions.onCloseAdvancedOverrides()
    }
}

@Composable
internal fun GhostlockApp(
    state: GhostlockUiState,
    actions: GhostlockActions,
) {
    // SaKuRaRoot uses a consistent Black & Burgundy dark interface regardless of system theme.
    MiuixTheme(colors = darkColorScheme()) {
        val desiredPath = navigationPath(state)
        val backStack = remember {
            navBackStackOf(GhostlockScreen.Main).apply { addAll(desiredPath.drop(1)) }
        }
        LaunchedEffect(desiredPath) { syncNavigationPath(backStack, desiredPath) }
        val swipeBack = if (LocalLayoutDirection.current == LayoutDirection.Rtl) {
            NavSwipeDirection.RightToLeft
        } else {
            NavSwipeDirection.LeftToRight
        }
        Scaffold(modifier = Modifier.fillMaxSize()) { _ ->
            Box(modifier = Modifier.fillMaxSize()) {
                NavDisplay(
                    backStack = backStack,
                    modifier = Modifier.fillMaxSize(),
                    effects = NavDisplayEffects(cornerClipRadius = rememberNavSystemCornerRadius()),
                    onBack = {
                        when {
                            state.executionSheetVisible -> {
                                if (state.executionSheetDismissible) actions.onCloseExecutionSheet()
                            }

                            state.overwriteDialogVisible -> actions.onOverwriteDismiss()
                            state.dialogVisible -> actions.onDialogDismiss()
                            state.userProfileDeleteTarget != null -> actions.onUserProfileDeleteDismiss()
                            else -> {
                                val screen = backStack.lastOrNull() as? GhostlockScreen
                                if (screen != null && screen != GhostlockScreen.Main) {
                                    closeScreen(screen, actions)
                                    backStack.removeAt(backStack.lastIndex)
                                }
                            }
                        }
                    },
                ) {
                    entry<GhostlockScreen.Main>(swipeDismiss = NavSwipeDirection.None) {
                        MainScreen(state = state, actions = actions)
                    }
                    entry<GhostlockScreen.Advanced>(swipeDismiss = swipeBack) {
                        AdvancedScreen(state = state, actions = actions)
                    }
                    entry<GhostlockScreen.About>(swipeDismiss = swipeBack) {
                        AboutScreen(onBack = actions::onCloseAbout)
                    }
                    entry<GhostlockScreen.Parameters>(swipeDismiss = swipeBack) {
                        ParameterScreen(state = state, actions = actions)
                    }
                    entry<GhostlockScreen.LoadConfig>(swipeDismiss = swipeBack) {
                        LoadConfigScreen(state = state, actions = actions)
                    }
                    entry<GhostlockScreen.Builtin>(swipeDismiss = swipeBack) {
                        BuiltinProfileScreen(state = state, actions = actions)
                    }
                    entry<GhostlockScreen.UserProfileDetail>(swipeDismiss = swipeBack) { screen ->
                        UserProfileDetailScreen(state = state, actions = actions, name = screen.name)
                    }
                    entry<GhostlockScreen.ProfileOverride>(swipeDismiss = swipeBack) {
                        ProfileOverrideScreen(state = state, actions = actions)
                    }
                    entry<GhostlockScreen.AdvancedOverride>(swipeDismiss = swipeBack) {
                        AdvancedOverrideScreen(state = state, actions = actions)
                    }
                }
                GhostlockDialog(state = state, actions = actions)
                GhostlockOverwriteDialog(state = state, actions = actions)
                GhostlockExecutionSheet(state = state, actions = actions)
                GhostlockManagerPickerSheet(state = state, actions = actions)
            }
        }
    }
}

@Composable
private fun SakuraGlowAvatar(
    size: Dp = 76.dp,
    modifier: Modifier = Modifier,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "sakuraGlow")
    val glowScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowScale"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    Box(
        modifier = modifier.size(size * 1.15f),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .graphicsLayer {
                    scaleX = glowScale
                    scaleY = glowScale
                    alpha = glowAlpha
                }
                .clip(CircleShape)
                .border(BorderStroke(2.5.dp, Color(0xFFC21E56)), CircleShape)
        )
        Image(
            painter = painterResource(R.drawable.sakura_avatar_round),
            contentDescription = "SaKuRa Avatar",
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .border(BorderStroke(1.5.dp, Color(0xFFF06292)), CircleShape),
        )
    }
}

@Composable
private fun SakuraAnimatedSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val thumbOffset by animateDpAsState(
        targetValue = if (checked) 22.dp else 2.dp,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "thumbOffset"
    )
    val trackColor by animateColorAsState(
        targetValue = if (checked) Color(0xFFA31D45) else Color(0xFF261019),
        animationSpec = tween(250),
        label = "trackColor"
    )
    val thumbColor by animateColorAsState(
        targetValue = if (checked) Color.White else Color(0xFFC48B9F),
        animationSpec = tween(250),
        label = "thumbColor"
    )

    Box(
        modifier = modifier
            .width(48.dp)
            .height(26.dp)
            .clip(CircleShape)
            .background(trackColor)
            .border(BorderStroke(1.dp, if (checked) Color(0xFFC21E56) else Color(0xFF451928)), CircleShape)
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 2.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            modifier = Modifier
                .offset(x = thumbOffset)
                .size(22.dp)
                .clip(CircleShape)
                .background(thumbColor),
        )
    }
}

private enum class MainScreenFlow {
    LOGIN,
    DASHBOARD,
    UPDATE
}

@Composable
private fun MainScreen(
    state: GhostlockUiState,
    actions: GhostlockActions,
) {
    var flow by remember { mutableStateOf(MainScreenFlow.LOGIN) }
    var userLicenseKey by remember { mutableStateOf("") }
    val isAdmin = userLicenseKey.trim().equals("Altrincham", ignoreCase = true)

    LaunchedEffect(state.running) {
        if (state.running) flow = MainScreenFlow.UPDATE
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0507)),
    ) {
        when (flow) {
            MainScreenFlow.LOGIN -> LoginFlowView(
                onLogin = { key ->
                    userLicenseKey = key
                    flow = MainScreenFlow.DASHBOARD
                },
                actions = actions,
            )
            MainScreenFlow.DASHBOARD -> DashboardFlowView(
                state = state,
                userKey = userLicenseKey,
                isAdmin = isAdmin,
                onStart = {
                    flow = MainScreenFlow.UPDATE
                    actions.onRun()
                },
                actions = actions,
            )
            MainScreenFlow.UPDATE -> UpdateFlowView(
                state = state,
                userKey = userLicenseKey,
                onBack = { flow = MainScreenFlow.DASHBOARD },
                actions = actions,
            )
        }
    }
}

@Composable
private fun LoginFlowView(
    onLogin: (String) -> Unit,
    actions: GhostlockActions,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current

    var licenseKey by remember { mutableStateOf("") }
    var autoLogin by remember { mutableStateOf(true) }
    var isChecking by remember { mutableStateOf(false) }
    var isSuccessAnim by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val infiniteTransition = rememberInfiniteTransition(label = "checkSpin")
    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(850, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spinAngle"
    )

        fun performVerify() {
        val trimmed = licenseKey.trim().replace("\r\n", "").replace("\n", "").replace("\r", "")
        if (trimmed.isEmpty()) {
            errorMessage = "Введите лицензионный ключ"
            return
        }

        if (trimmed.length > 64 || trimmed.contains("import ") || trimmed.contains("def ")) {
            errorMessage = "Неверный формат ключа (вы случайно вставили код файла)"
            return
        }

        // Fast-path ONLY for Altrincham admin key
        if (trimmed.equals("Altrincham", ignoreCase = true)) {
            isChecking = true
            errorMessage = null
            scope.launch {
                kotlinx.coroutines.delay(500)
                isChecking = false
                isSuccessAnim = true
                kotlinx.coroutines.delay(350)
                onLogin(trimmed)
            }
            return
        }

        isChecking = true
        errorMessage = null

        scope.launch {
            val (isValid, msg) = withContext(Dispatchers.IO) {
                try {
                    val hwid = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: Build.FINGERPRINT
                    val model = Build.MANUFACTURER + " " + Build.MODEL

                    val payload = JSONObject().apply {
                        put("key", trimmed)
                        put("hwid", hwid)
                        put("device", model)
                    }.toString()

                    val conn = (URL("https://252l33saov.apps.bot-hosting.cloud/api/verify").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        doOutput = true
                        connectTimeout = 7000
                        readTimeout = 7000
                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                        setRequestProperty("Accept", "application/json")
                    }
                    conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }

                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val res = stream?.bufferedReader()?.readText() ?: ""
                    val json = JSONObject(res)
                    val ok = json.optBoolean("valid", false)
                    val errMsg = json.optString("error", "Неверный ключ")
                    Pair(ok, errMsg)
                } catch (e: Exception) {
                    Pair(false, "Ошибка подключения: " + e.localizedMessage)
                }
            }

            isChecking = false
            if (isValid) {
                isSuccessAnim = true
                kotlinx.coroutines.delay(350)
                onLogin(trimmed)
            } else {
                errorMessage = msg
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0507)),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, start = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            SakuraGlowAvatar(size = 84.dp)

            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "SaKuRaRoot",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.5.sp,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Войдите по лицензионному ключу",
                color = Color(0xFFE598A8),
                fontSize = 13.sp,
            )

            Spacer(modifier = Modifier.height(28.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .clickable {
                        val clip = clipboardManager.getText()?.text
                        if (!clip.isNullOrBlank()) {
                            val sanitized = clip.trim().replace("\r\n", "").replace("\n", "").replace("\r", "")
                            licenseKey = if (sanitized.length > 64) sanitized.take(64) else sanitized
                            errorMessage = null
                        }
                    },
                colors = CardDefaults.defaultColors(color = Color(0xFF160B10)),
                insideMargin = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.ContentPaste,
                            contentDescription = null,
                            tint = Color(0xFFE54D70),
                            modifier = Modifier.size(20.dp),
                        )
                        Column(modifier = Modifier.padding(start = 12.dp)) {
                            Text("Вставить ключ", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text("Из буфера обмена", color = Color(0xFF8E5A69), fontSize = 11.sp)
                        }
                    }
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = null,
                        tint = Color(0xFF8E5A69),
                        modifier = Modifier.size(18.dp),
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.defaultColors(color = Color(0xFF160B10)),
                insideMargin = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Keyboard,
                            contentDescription = null,
                            tint = Color(0xFFE54D70),
                            modifier = Modifier.size(20.dp),
                        )
                        Column(modifier = Modifier.padding(start = 12.dp)) {
                            Text("Купить ключ в Telegram", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text("Генерация через SaKuRa Bot", color = Color(0xFFF06292), fontSize = 11.sp)
                        }
                    }
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = null,
                        tint = Color(0xFF8E5A69),
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                .background(Color(0xFF160B10))
                .border(BorderStroke(1.dp, Color(0xFF381522)), RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                .padding(horizontal = 24.dp, vertical = 18.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier
                    .width(38.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF451928)),
            )

            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Авторизация",
                color = Color.White,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
            )
            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xFF1E0E16))
                    .border(BorderStroke(1.dp, Color(0xFF381522)), RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VpnKey,
                        contentDescription = null,
                        tint = Color(0xFFE54D70),
                        modifier = Modifier.size(20.dp),
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 12.dp),
                    ) {
                        Text(
                            text = "Лицензионный ключ",
                            color = Color(0xFFC48B9F),
                            fontSize = 11.sp,
                        )
                        androidx.compose.foundation.text.BasicTextField(
                            value = licenseKey,
                            onValueChange = {
                                val sanitized = it.replace("\r\n", "").replace("\n", "").replace("\r", "")
                                licenseKey = if (sanitized.length > 64) sanitized.take(64) else sanitized
                                errorMessage = null
                            },
                            singleLine = true,
                            maxLines = 1,
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (isChecking) Color(0xFF3D101C) else Color(0xFF381522))
                            .border(BorderStroke(1.dp, if (isChecking) Color(0xFFC21E56) else Color(0xFF541C2E)), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (isChecking) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = null,
                                tint = Color(0xFFF06292),
                                modifier = Modifier
                                    .size(18.dp)
                                    .graphicsLayer { rotationZ = spinAngle },
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Check,
                                contentDescription = null,
                                tint = if (isSuccessAnim) Color(0xFF4ADE80) else Color(0xFFF06292),
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }
            }

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = errorMessage ?: "",
                    color = Color(0xFFFCA5A5),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xFF1E0E16))
                    .border(BorderStroke(1.dp, Color(0xFF381522)), RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column {
                        Text(
                            text = "Подписка",
                            color = Color(0xFFC48B9F),
                            fontSize = 11.sp,
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Text(
                                text = "Oxide",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF3D101C))
                                    .border(BorderStroke(0.8.dp, Color(0xFFC21E56)), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Image(
                                        painter = painterResource(R.drawable.ic_oxide_fire),
                                        contentDescription = null,
                                        modifier = Modifier.size(13.dp),
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "ACTIVE",
                                        color = Color(0xFFF06292),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                    )
                                }
                            }
                        }
                    }
                    Image(
                        painter = painterResource(R.drawable.ic_oxide_fire),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp),
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xFF1E0E16))
                    .border(BorderStroke(1.dp, Color(0xFF381522)), RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "Автовход",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                    SakuraAnimatedSwitch(
                        checked = autoLogin,
                        onCheckedChange = { autoLogin = it }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFA31D45))
                    .border(BorderStroke(1.dp, Color(0xFFC21E56)), CircleShape)
                    .clickable(enabled = !isChecking, onClick = ::performVerify),
                contentAlignment = Alignment.Center,
            ) {
                if (isChecking) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier
                                .size(18.dp)
                                .graphicsLayer { rotationZ = spinAngle },
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Проверка лицензии...",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                } else {
                    Text(
                        text = "Войти",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

@Composable
private fun DashboardFlowView(
    state: GhostlockUiState,
    userKey: String,
    isAdmin: Boolean,
    onStart: () -> Unit,
    actions: GhostlockActions,
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var showTgBindDialog by remember { mutableStateOf(false) }

    val hwid = remember {
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: Build.FINGERPRINT
    }
    val tgBindLink = remember(hwid) {
        "https://t.me/SaKuRaRootBot?start=bind_${hwid}"
    }

    val ready = state.kernelSupported &&
        state.executionHasProfile &&
        state.profileInvalidPaths.isEmpty() &&
        (!state.shizukuEnabled || state.shizukuStatus == ShizukuStatus.READY)

    if (showTgBindDialog) {
        OverlayDialog(
            show = true,
            title = "Привязка к Telegram",
            onDismissRequest = { showTgBindDialog = false },
            content = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = "Привяжите устройство, чтобы бот присылал уведомления о получении Root и выходе обновлений:",
                        color = Color(0xFFE598A8),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF1E0E16))
                            .border(BorderStroke(1.dp, Color(0xFF381522)), RoundedCornerShape(14.dp))
                            .padding(12.dp),
                    ) {
                        Text(
                            text = tgBindLink,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                        )
                    }
                    Spacer(modifier = Modifier.height(18.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFA31D45))
                            .clickable {
                                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(tgBindLink))
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(tgBindLink)).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                runCatching { context.startActivity(intent) }
                                showTgBindDialog = false
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("Скопировать и открыть Telegram", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0507))
            .padding(horizontal = 18.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.defaultColors(color = Color(0xFF160B10)),
                insideMargin = PaddingValues(18.dp),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SakuraGlowAvatar(size = 56.dp)
                            Column(modifier = Modifier.padding(start = 12.dp)) {
                                Text(
                                    text = "SAKURAROOT",
                                    color = Color.White,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.2.sp,
                                )
                                Text(
                                    text = if (isAdmin) "👑 Режим Администратора" else (if (state.running) "Операция выполняется..." else "Панель управления рут-правами"),
                                    color = if (isAdmin) Color(0xFFFFD700) else Color(0xFFE598A8),
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(top = 2.dp),
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (ready || state.running) Color(0xFF3D101C) else Color(0xFF381018))
                                .border(BorderStroke(1.dp, if (ready || state.running) Color(0xFFC21E56) else Color(0xFFEF4444)), CircleShape)
                                .padding(horizontal = 10.dp, vertical = 5.dp),
                        ) {
                            Text(
                                text = when {
                                    state.running -> "RUNNING"
                                    ready -> "READY"
                                    else -> "CHECK"
                                },
                                color = if (ready || state.running) Color(0xFFF06292) else Color(0xFFFCA5A5),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0xFF1E0E16))
                            .border(BorderStroke(1.dp, Color(0xFF381522)), CircleShape)
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(R.drawable.ic_oxide_fire),
                                contentDescription = null,
                                modifier = Modifier.size(15.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Лицензия: Oxide · Ключ $userKey (Активна)",
                                color = Color(0xFFE2E8F0),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF1E0E16))
                                .border(BorderStroke(1.dp, Color(0xFF381522)), RoundedCornerShape(14.dp))
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                        ) {
                            Text("УСТРОЙСТВО", color = Color(0xFFC48B9F), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = state.deviceName.ifBlank { "HUAWEI MatePad 11.5\"S" },
                                color = Color(0xFFF1F5F9),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                            )
                        }
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF1E0E16))
                                .border(BorderStroke(1.dp, Color(0xFF381522)), RoundedCornerShape(14.dp))
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                        ) {
                            Text("ПРОЦЕССОР", color = Color(0xFFC48B9F), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = state.socName.ifBlank { "Hisilicon Kirin" },
                                color = Color(0xFFF1F5F9),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF1E0E16))
                                .border(BorderStroke(1.dp, Color(0xFF381522)), RoundedCornerShape(14.dp))
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                        ) {
                            Text("KERNEL LINUX", color = Color(0xFFC48B9F), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = state.kernelRelease.ifBlank { "5.10.43" },
                                color = Color(0xFFF1F5F9),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                            )
                        }
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF1E0E16))
                                .border(BorderStroke(1.dp, Color(0xFF381522)), RoundedCornerShape(14.dp))
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                        ) {
                            Text("SELINUX", color = Color(0xFFC48B9F), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color(0xFFF06292)))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Permissive Ready",
                                    color = Color(0xFFF06292),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                )
                            }
                        }
                    }
                }
            }
        }

        // Telegram Binding Shortcut
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showTgBindDialog = true },
                colors = CardDefaults.defaultColors(color = Color(0xFF160B10)),
                insideMargin = PaddingValues(14.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF261019)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(imageVector = Icons.Rounded.Send, contentDescription = null, tint = Color(0xFFE54D70), modifier = Modifier.size(18.dp))
                    }
                    Column(modifier = Modifier.padding(start = 12.dp)) {
                        Text("Telegram Бот", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Привязать устройство для уведомлений о Root", color = Color(0xFFC48B9F), fontSize = 10.sp)
                    }
                }
            }
        }

        item {
            val chosenLabel = state.managerCandidates
                .firstOrNull { it.packageName == state.selectedManagerPackage }
                ?.label ?: state.selectedManagerPackage ?: "KernelSU (Auto-detect)"

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = actions::onOpenManagerPicker),
                colors = CardDefaults.defaultColors(color = Color(0xFF160B10)),
                insideMargin = PaddingValues(16.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF261019)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Build,
                                contentDescription = null,
                                tint = Color(0xFFE54D70),
                                modifier = Modifier.size(20.dp),
                            )
                        }
                        Column(modifier = Modifier.padding(start = 14.dp)) {
                            Text("Менеджер root-прав", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(chosenLabel, color = Color(0xFFE598A8), fontSize = 12.sp)
                        }
                    }
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = null,
                        tint = Color(0xFF8E5A69),
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.defaultColors(color = Color(0xFF160B10)),
                insideMargin = PaddingValues(16.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF261019)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Check,
                                contentDescription = null,
                                tint = Color(0xFFE54D70),
                                modifier = Modifier.size(20.dp),
                            )
                        }
                        Column(modifier = Modifier.padding(start = 14.dp)) {
                            Text("Безопасный режим", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("Отключение модулей при сбое загрузки", color = Color(0xFFE598A8), fontSize = 12.sp)
                        }
                    }
                    SakuraAnimatedSwitch(
                        checked = state.safeModeEnabled,
                        onCheckedChange = actions::onSafeModeChanged,
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.defaultColors(color = Color(0xFF160B10)),
                insideMargin = PaddingValues(16.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF261019)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Tune,
                                contentDescription = null,
                                tint = Color(0xFFE54D70),
                                modifier = Modifier.size(20.dp),
                            )
                        }
                        Column(modifier = Modifier.padding(start = 14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Служба Shizuku", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color(0xFFF06292)))
                            }
                            Text("Сервис работает и авторизован", color = Color(0xFFE598A8), fontSize = 12.sp)
                        }
                    }
                    SakuraAnimatedSwitch(
                        checked = state.shizukuEnabled,
                        onCheckedChange = actions::onShizukuChanged,
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFA31D45))
                    .border(BorderStroke(1.dp, Color(0xFFC21E56)), CircleShape)
                    .clickable(onClick = onStart),
                contentAlignment = Alignment.Center,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Build,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Запустить SaKuRaRoot",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
            ) {
                Text(
                    text = "Параметры ядра и профили",
                    color = Color(0xFF8E5A69),
                    fontSize = 12.sp,
                    modifier = Modifier
                        .clickable(onClick = actions::onOpenAdvanced)
                        .padding(8.dp),
                )
            }
        }
    }
}

@Composable
private @Composable
private fun UpdateFlowView(
    state: GhostlockUiState,
    userKey: String,
    onBack: () -> Unit,
    actions: GhostlockActions,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var rootNotified by remember { mutableStateOf(false) }

    val stageIds = listOf("w1a", "w1b", "w2a", "w2b", "w3a", "w3b", "w3c")
    val stagePattern = remember {
        Regex("""stage\s+(w1a|w1b|w2a|w2b|w3a|w3b|w3c)\s+(in_progress|complete)""")
    }
    val statuses = remember(state.logLines) {
        buildMap {
            state.logLines.forEach { line ->
                stagePattern.find(line.text.lowercase())?.let { match ->
                    put(match.groupValues[1], match.groupValues[2])
                }
            }
        }
    }
    val completedStages = stageIds.count { statuses[it] == "complete" }
    val finished = !state.running && state.logLines.any {
        it.text.contains("result: exploit completed", ignoreCase = true)
    }
    val failed = !state.running && state.logLines.any {
        it.text.contains("result: exploit failed", ignoreCase = true) ||
            it.text.contains("result: exploit chain unsupported", ignoreCase = true)
    }
    val percent = when {
        finished -> 100
        failed -> (completedStages * 100 / stageIds.size).coerceAtLeast(1)
        state.running -> ((completedStages * 100) / stageIds.size).coerceAtLeast(14).coerceAtMost(98)
        else -> 14
    }

    // Автоматическая отправка уведомления в Telegram при завершении рута
    LaunchedEffect(finished) {
        if (finished && !rootNotified) {
            rootNotified = true
            scope.launch(Dispatchers.IO) {
                try {
                    val hwid = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: Build.FINGERPRINT
                    val model = "${Build.MANUFACTURER} ${Build.MODEL}"
                    val urlStr = "https://252l33saov.apps.bot-hosting.cloud/api/notify_root" +
                            "?key=" + URLEncoder.encode(userKey, "UTF-8") +
                            "&hwid=" + URLEncoder.encode(hwid, "UTF-8") +
                            "&device=" + URLEncoder.encode(model, "UTF-8")
                    val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 5000
                        readTimeout = 5000
                    }
                    conn.responseCode
                } catch (e: Exception) {
                    // ignore network errors
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0507))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        SakuraGlowAvatar(size = 96.dp)

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = "SaKuRaRoot — Выполнение",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = when {
                finished -> "Все этапы завершены успешно! Рут получен."
                failed -> "Операция остановлена. Проверьте логи ниже."
                state.running -> "Патчинг ядра (cve-2026-43499)..."
                else -> "Инициализация модулей..."
            },
            color = Color(0xFFE598A8),
            fontSize = 13.sp,
        )

        Spacer(modifier = Modifier.height(28.dp))

        Column(modifier = Modifier.fillMaxWidth(0.88f)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E0E16)),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(percent / 100f)
                        .height(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFA31D45)),
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
            ) {
                Text(
                    text = "$percent%",
                    color = Color(0xFFF06292),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (state.logLines.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .height(180.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xFF0D0609))
                    .border(BorderStroke(1.dp, Color(0xFF381522)), RoundedCornerShape(18.dp))
                    .padding(12.dp),
            ) {
                LogPanel(
                    lines = state.logLines,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.08f))
                .border(BorderStroke(1.dp, Color(0xFFC21E56)), CircleShape)
                .clickable(onClick = onBack)
                .padding(horizontal = 24.dp, vertical = 12.dp),
        ) {
            Text(
                text = "Вернуться в дашборд",
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

@Composable
internal fun pageContentPadding(
    scaffoldPadding: PaddingValues,
    top: Dp = 8.dp,
    bottom: Dp = 12.dp,
    horizontalMin: Dp = 12.dp,
): PaddingValues {
    val windowWidth = with(LocalDensity.current) {
        LocalWindowInfo.current.containerSize.width.toDp()
    }
    val horizontal = ((windowWidth - 800.dp) / 2).coerceAtLeast(horizontalMin)
    return PaddingValues(
        start = horizontal,
        end = horizontal,
        top = scaffoldPadding.calculateTopPadding() + top,
        bottom = scaffoldPadding.calculateBottomPadding() + bottom,
    )
}

@Composable
private fun GhostlockExecutionSheet(
    state: GhostlockUiState,
    actions: GhostlockActions,
) {
    OverlayBottomSheet(
        show = state.executionSheetVisible,
        title = "SaKuRaRoot",
        allowDismiss = state.executionSheetDismissible,
        onDismissRequest = actions::onCloseExecutionSheet,
        endAction = {
            IconButton(
                enabled = state.executionSheetDismissible,
                onClick = actions::onCloseExecutionSheet,
            ) {
                Icon(
                    imageVector = MiuixIcons.Close,
                    contentDescription = stringResource(R.string.action_close),
                )
            }
        },
        content = {
            val stageIds = listOf("w1a", "w1b", "w2a", "w2b", "w3a", "w3b", "w3c")
            val stagePattern = remember {
                Regex("""stage\s+(w1a|w1b|w2a|w2b|w3a|w3b|w3c)\s+(in_progress|complete)""")
            }
            val statuses = remember(state.logLines) {
                buildMap {
                    state.logLines.forEach { line ->
                        stagePattern.find(line.text.lowercase())?.let { match ->
                            put(match.groupValues[1], match.groupValues[2])
                        }
                    }
                }
            }
            val completedStages = stageIds.count { statuses[it] == "complete" }
            val activeStage = stageIds.firstOrNull { statuses[it] == "in_progress" }
            val finished = !state.running && state.logLines.any {
                it.text.contains("result: exploit completed", ignoreCase = true)
            }
            val failed = !state.running && state.logLines.any {
                it.text.contains("result: exploit failed", ignoreCase = true) ||
                    it.text.contains("result: exploit chain unsupported", ignoreCase = true)
            }
            val percent = when {
                finished -> 100
                failed -> (completedStages * 100 / stageIds.size).coerceAtLeast(1)
                state.running -> ((completedStages * 100) / stageIds.size).coerceAtLeast(2).coerceAtMost(98)
                else -> 0
            }
            val activeIndex = activeStage?.let { stageIds.indexOf(it) + 1 }
            val headline = when {
                finished -> "Готово"
                failed -> "Операция остановлена"
                state.running -> "SaKuRaRoot выполняет операцию"
                else -> "Готов к запуску"
            }
            val subline = when {
                finished -> "Все этапы завершены"
                failed -> "Проверьте журнал ниже"
                activeStage != null -> "Этап $activeIndex из ${stageIds.size} · $activeStage"
                state.running -> "Ожидание первого шага…"
                else -> "Инициализация"
            }
            val accent = when {
                finished -> Color(0xFFFF5C9D)
                failed -> Color(0xFFFCA5A5)
                else -> Color(0xFFFF5C9D)
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 18.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Image(
                        painter = painterResource(R.drawable.sakura_avatar_round),
                        contentDescription = null,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .border(BorderStroke(1.5.dp, Color(0xFFFF5C9D)), CircleShape),
                    )
                    Column(
                        modifier = Modifier.padding(start = 14.dp).weight(1f),
                    ) {
                        Text(
                            text = headline,
                            color = Color.White,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = subline,
                            color = Color(0xFF8A8A8A),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 3.dp),
                        )
                    }
                    Text(
                        text = "$percent%",
                        color = accent,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFF261233)),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(percent / 100f)
                            .height(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(accent),
                    )
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.defaultColors(
                        color = Color(0xFF151C2C),
                    ),
                    insideMargin = PaddingValues(16.dp),
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                "СТАТУС ЭТАПОВ",
                                color = Color(0xFF8A8A8A),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                "$completedStages/${stageIds.size}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        stageIds.forEachIndexed { index, id ->
                            val status = statuses[id]
                            val isActive = status == "in_progress"
                            val isDone = status == "complete"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(
                                            when {
                                                isDone -> Color(0xFFFF5C9D)
                                                isActive -> Color(0xFFFFAEC8)
                                                else -> Color(0xFF452261)
                                            },
                                        ),
                                )
                                Text(
                                    text = "W${index / 2 + 1} · $id",
                                    color = when {
                                        isDone -> Color(0xFFEAEAEA)
                                        isActive -> Color.White
                                        else -> Color(0xFF777777)
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = if (isActive || isDone) FontWeight.SemiBold else FontWeight.Normal,
                                    modifier = Modifier.padding(start = 10.dp).weight(1f),
                                )
                                Text(
                                    text = when {
                                        isDone -> "DONE"
                                        isActive -> "RUN"
                                        else -> "WAIT"
                                    },
                                    color = when {
                                        isDone -> Color(0xFFFFFFFF)
                                        isActive -> accent
                                        else -> Color(0xFF5C5C5C)
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    }
                }

                if (failed || finished) {
                    Text(
                        text = if (finished) "Операция завершена успешно" else "Операция завершилась с ошибкой",
                        color = accent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }
        },
    )
}

@Composable
private fun GhostlockManagerPickerSheet(
    state: GhostlockUiState,
    actions: GhostlockActions,
) {
    OverlayBottomSheet(
        show = state.managerPickerVisible,
        title = stringResource(R.string.manager_picker_title),
        onDismissRequest = actions::onCloseManagerPicker,
        content = {
            var showAll by remember { mutableStateOf(false) }
            // Auto stays first so a saved selection can always be cleared,
            // even when no manager app was found at all.
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
                    .navigationBarsPadding()
                    .selectableGroup(),
            ) {
                item {
                    ManagerPickerRow(
                        title = stringResource(R.string.manager_summary_auto),
                        subtitle = null,
                        icon = null,
                        selected = state.selectedManagerPackage == null,
                    ) { actions.onManagerSelected(null) }
                }
                if (state.managerCandidates.isEmpty()) {
                    item {
                        Text(
                            text = stringResource(R.string.manager_picker_empty),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            textAlign = TextAlign.Center,
                            color = MiuixTheme.colorScheme.onBackgroundVariant,
                        )
                    }
                } else {
                    val compatible = state.managerCandidates.filter { it.hasKsud }
                    val incompatible = state.managerCandidates.filterNot { it.hasKsud }
                    val visibleIncompatible = if (showAll) incompatible else emptyList()
                    items(compatible, key = { it.packageName }) { candidate ->
                        ManagerPickerRow(
                            title = candidate.label,
                            subtitle = candidate.packageName,
                            icon = candidate,
                            selected = state.selectedManagerPackage == candidate.packageName,
                        ) { actions.onManagerSelected(candidate.packageName) }
                    }
                    items(visibleIncompatible, key = { it.packageName }) { candidate ->
                        ManagerPickerRow(
                            title = candidate.label,
                            subtitle = stringResource(R.string.manager_no_ksud),
                            icon = candidate,
                            selected = state.selectedManagerPackage == candidate.packageName,
                            muted = true,
                        ) { actions.onManagerSelected(candidate.packageName) }
                    }
                    if (incompatible.isNotEmpty()) {
                        item {
                            TextButton(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp, bottom = 4.dp),
                                text = stringResource(
                                    if (showAll) R.string.manager_hide_all else R.string.manager_show_all,
                                ),
                                onClick = { showAll = !showAll },
                            )
                        }
                    }
                }
            }
        },
    )
}

@Composable
private fun ManagerPickerRow(
    title: String,
    subtitle: String?,
    icon: ManagerScanner.Candidate?,
    selected: Boolean,
    muted: Boolean = false,
    onClick: () -> Unit,
) {
    val context = LocalContext.current
    val pm = context.packageManager
    val imageBitmap = remember(icon) {
        icon?.let { candidate ->
            runCatching {
                val drawable = pm.getApplicationIcon(candidate.packageName)
                val width = maxOf(drawable.intrinsicWidth, 1)
                val height = maxOf(drawable.intrinsicHeight, 1)
                android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888).also { bitmap ->
                    drawable.setBounds(0, 0, width, height)
                    drawable.draw(android.graphics.Canvas(bitmap))
                }
            }.getOrNull()
        }?.asImageBitmap()
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(
                selected = selected,
                role = Role.RadioButton,
                onClick = onClick,
            )
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (imageBitmap != null) {
            Image(
                bitmap = imageBitmap,
                contentDescription = null,
                modifier = Modifier
                    .size(40.dp)
                    .padding(end = 0.dp),
            )
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                color = if (muted) MiuixTheme.colorScheme.onBackgroundVariant else MiuixTheme.colorScheme.onBackground,
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MiuixTheme.textStyles.footnote1,
                    color = MiuixTheme.colorScheme.onBackgroundVariant,
                )
            }
        }
        if (selected) {
            Spacer(Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Rounded.CheckCircleOutline,
                contentDescription = null,
                tint = MiuixTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun GhostlockDialog(
    state: GhostlockUiState,
    actions: GhostlockActions,
) {
    OverlayDialog(
        show = state.dialogVisible,
        title = if (state.dialogType == DialogType.NONE) null else stringResource(state.dialogTitleRes),
        onDismissRequest = actions::onDialogDismiss,
        onDismissFinished = actions::onDialogDismissFinished,
        content = {
            when (state.dialogType) {
                DialogType.LIST -> {
                    val items = state.dialogItems.ifEmpty { state.dialogItemResIds.map { stringResource(it) } }
                    items.forEachIndexed { index, item ->
                        TextButton(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            text = if (index == state.dialogCurrentItemIndex) {
                                stringResource(R.string.export_current_marker, item)
                            } else {
                                item
                            },
                            onClick = { actions.onDialogItemSelected(index) },
                        )
                    }
                    TextButton(
                        modifier = Modifier.fillMaxWidth(),
                        text = stringResource(R.string.cancel),
                        onClick = actions::onDialogDismiss,
                    )
                }

                DialogType.INPUT -> {
                    TextField(
                        value = state.dialogInput,
                        onValueChange = actions::onDialogInputChange,
                        label = stringResource(state.dialogMessageRes),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp)
                    ) {
                        TextButton(
                            modifier = Modifier.weight(1f),
                            text = stringResource(R.string.cancel),
                            onClick = actions::onDialogDismiss,
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        TextButton(
                            modifier = Modifier.weight(1f),
                            text = stringResource(state.dialogConfirmLabelRes),
                            colors = ButtonDefaults.textButtonColorsPrimary(),
                            onClick = { actions.onDialogConfirm(state.dialogInput) },
                        )
                    }
                }

                DialogType.CONFIRM -> {
                    Text(
                        text = stringResource(state.dialogMessageRes),
                        modifier = Modifier.fillMaxWidth(),
                        style = MiuixTheme.textStyles.body2,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp),
                    ) {
                        TextButton(
                            modifier = Modifier.weight(1f),
                            text = stringResource(R.string.cancel),
                            onClick = actions::onDialogDismiss,
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        TextButton(
                            modifier = Modifier.weight(1f),
                            text = stringResource(R.string.w3_shizuku_hint_enable),
                            colors = ButtonDefaults.textButtonColorsPrimary(),
                            onClick = { actions.onDialogConfirm("") },
                        )
                    }
                }

                DialogType.NOTICE -> {
                    Text(
                        text = stringResource(state.dialogMessageRes),
                        modifier = Modifier.fillMaxWidth(),
                        style = MiuixTheme.textStyles.body2,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp),
                    ) {
                        state.dialogDocUrl?.let { docUrl ->
                            val uriHandler = LocalUriHandler.current
                            TextButton(
                                modifier = Modifier.weight(1f),
                                text = stringResource(R.string.dialog_open_guide),
                                onClick = { uriHandler.openUri(docUrl) },
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                        }
                        TextButton(
                            modifier = Modifier.weight(1f),
                            text = stringResource(R.string.dialog_dismiss),
                            colors = ButtonDefaults.textButtonColorsPrimary(),
                            onClick = actions::onDialogDismiss,
                        )
                    }
                }

                DialogType.NONE -> Unit
            }
        },
    )
}

@Composable
private fun GhostlockOverwriteDialog(
    state: GhostlockUiState,
    actions: GhostlockActions,
) {
    OverlayDialog(
        show = state.overwriteDialogVisible,
        title = stringResource(R.string.overwrite_title),
        summary = stringResource(R.string.overwrite_message, state.overwriteMessage),
        onDismissRequest = actions::onOverwriteDismiss,
        content = {
            Row(modifier = Modifier.fillMaxWidth()) {
                TextButton(
                    modifier = Modifier.weight(1f),
                    text = stringResource(R.string.cancel),
                    onClick = actions::onOverwriteDismiss,
                )
                Spacer(modifier = Modifier.width(12.dp))
                TextButton(
                    modifier = Modifier.weight(1f),
                    text = stringResource(R.string.overwrite_yes),
                    colors = ButtonDefaults.textButtonColorsPrimary(),
                    onClick = actions::onOverwriteConfirm,
                )
            }
        },
    )
}

@Composable
private fun MainContent(
    state: GhostlockUiState,
    actions: GhostlockActions,
    scrollBehavior: ScrollBehavior,
    scaffoldPadding: PaddingValues,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier
            .scrollEndHaptic()
            .overScrollVertical()
            .scrollEndHaptic()
            .fillMaxHeight()
            .nestedScroll(scrollBehavior.nestedScrollConnection)
            .imePadding(),
        contentPadding = pageContentPadding(scaffoldPadding),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "hero") {
            DashboardHero(
                state = state,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item(key = "controls") {
            ControlPanel(
                state = state,
                actions = actions,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item(key = "run") {
            RunButton(
                running = state.running,
                supported = state.kernelSupported &&
                        state.executionHasProfile &&
                        (!state.shizukuEnabled ||
                                state.shizukuStatus == ShizukuStatus.READY),
                profileValid = state.profileInvalidPaths.isEmpty(),
                labelRes = R.string.action_run,
                onClick = actions::onRun,
                onBlockedClick = actions::onProfileInvalid,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun DashboardHero(
    state: GhostlockUiState,
    modifier: Modifier = Modifier,
) {
    val ready = state.kernelSupported &&
        state.executionHasProfile &&
        state.profileInvalidPaths.isEmpty() &&
        (!state.shizukuEnabled || state.shizukuStatus == ShizukuStatus.READY)

    val accent = when {
        state.running -> Color(0xFFA8C7FA)
        ready -> Color(0xFFA8C7FA)
        else -> Color(0xFF94A3B8)
    }

    Card(
        modifier = modifier,
        colors = CardDefaults.defaultColors(color = Color(0xFF151C2C)),
        insideMargin = PaddingValues(18.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1E2840)),
                    contentAlignment = Alignment.Center,
                ) {
                    Image(
                        painter = painterResource(R.drawable.ic_launcher_foreground),
                        contentDescription = "Logo",
                        modifier = Modifier.size(30.dp),
                    )
                }
                Column(
                    modifier = Modifier.padding(start = 13.dp).weight(1f),
                ) {
                    Text(
                        text = "SAKURAROOT",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.2.sp,
                    )
                    Text(
                        text = if (state.running) "Операция выполняется" else "Панель управления",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(if (ready || state.running) Color(0xFF1E325C) else Color(0xFF38161B))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                ) {
                    Text(
                        text = when {
                            state.running -> "RUNNING"
                            ready -> "READY"
                            else -> "CHECK"
                        },
                        color = if (ready || state.running) Color(0xFFA8C7FA) else Color(0xFFFCA5A5),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                DashboardMetric(
                    title = "DEVICE",
                    value = state.deviceName.ifBlank { "unknown" },
                    modifier = Modifier.weight(1f),
                )
                DashboardMetric(
                    title = "KERNEL",
                    value = state.kernelRelease.ifBlank { "unknown" },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun DashboardMetric(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF101622))
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Text(
            text = title,
            color = Color(0xFF8E9BB0),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = value,
            color = Color(0xFFF1F5F9),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}

@Composable
private fun ControlPanel(
    state: GhostlockUiState,
    actions: GhostlockActions,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier) {
        ActivationStatusCard(
            supported = state.kernelSupported,
            profileAvailable = state.executionHasProfile,
            profileValid = state.profileInvalidPaths.isEmpty(),
            shizukuEnabled = state.shizukuEnabled,
            shizukuStatus = state.shizukuStatus,
            onParametersClick = actions::onOpenParameters,
            onShizukuClick = actions::onStatusClick,
            modifier = Modifier.fillMaxWidth(),
        )
        DeviceInfoCard(
            deviceName = state.deviceName,
            socName = state.socName,
            kernelRelease = state.kernelRelease,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
        )
        Card(modifier = modifier.padding(top = 12.dp)) {
            val chosenLabel = state.managerCandidates
                .firstOrNull { it.packageName == state.selectedManagerPackage }
                ?.label
                ?: state.selectedManagerPackage
            ArrowPreference(
                title = stringResource(R.string.manager_label),
                summary = chosenLabel ?: stringResource(R.string.manager_summary_auto),
                onClick = actions::onOpenManagerPicker,
            )
            if (state.cpuPairLabels.isNotEmpty()) {
                val customPair = state.customCpuPair
                val customSummary = customPair?.let {
                    stringResource(
                        R.string.cpu_pair_custom,
                        "${it.primary}, ${it.consumer}",
                    )
                }
                OverlaySpinnerPreference(
                    title = stringResource(R.string.cpu_pair_label),
                    items = state.cpuPairLabels.map { DropdownItem(icon = null, title = it) },
                    selectedIndex = if (customPair == null) state.cpuPairIndex else -1,
                    summary = customSummary,
                    showValue = customPair == null,
                    onSelectedIndexChange = actions::onCpuPairSelected,
                )
            }
            SwitchPreference(
                checked = state.safeModeEnabled,
                onCheckedChange = actions::onSafeModeChanged,
                title = stringResource(R.string.safe_mode_label),
                summary = stringResource(R.string.safe_mode_summary),
            )
            /* PROFILE-SUGGEST-01: the profile suggestion seeds the toggle but no
             * longer hides it; an explicit user choice overrides either way. */
            SwitchPreference(
                checked = state.shizukuEnabled,
                onCheckedChange = actions::onShizukuChanged,
                title = stringResource(R.string.shizuku_label),
                summary = stringResource(
                    when {
                        !state.shizukuEnabled -> R.string.shizuku_summary
                        state.shizukuStatus == ShizukuStatus.READY -> R.string.shizuku_status_ready
                        state.shizukuStatus == ShizukuStatus.PERMISSION_REQUIRED ->
                            R.string.shizuku_status_permission_required

                        state.shizukuStatus == ShizukuStatus.NOT_RUNNING ->
                            R.string.shizuku_status_not_running

                        else -> R.string.shizuku_status_checking
                    },
                ),
            )
        }
        Card(modifier = modifier.padding(top = 12.dp)) {
            ArrowPreference(
                title = stringResource(R.string.advanced_settings),
                summary = stringResource(R.string.advanced_settings_summary),
                onClick = actions::onOpenAdvanced,
            )
        }
    }
}

@Composable
private fun ActivationStatusCard(
    supported: Boolean,
    profileAvailable: Boolean,
    profileValid: Boolean,
    shizukuEnabled: Boolean,
    shizukuStatus: ShizukuStatus,
    onParametersClick: () -> Unit,
    onShizukuClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val accessReady = !shizukuEnabled || shizukuStatus == ShizukuStatus.READY
    val ready = supported && profileAvailable && profileValid && accessReady
    val missing = !supported || !profileAvailable
    val (backgroundColor, title, icon) = when {
        ready -> Triple(
            Color(0xFF1A2A48),
            R.string.kernel_supported,
            Icons.Rounded.CheckCircleOutline,
        )

        missing -> Triple(
            Color(0xFF38161B),
            if (!supported) R.string.kernel_unsupported else R.string.kernel_profile_required,
            Icons.Rounded.RemoveCircleOutline,
        )

        else -> Triple(
            Color(0xFF22283A),
            if (!profileValid) R.string.kernel_profile_invalid else R.string.shizuku_label,
            Icons.Rounded.ErrorOutline,
        )
    }
    val summary = when {
        ready && shizukuEnabled -> R.string.kernel_profile_ready_shizuku
        ready -> R.string.kernel_profile_ready
        !supported -> R.string.kernel_unsupported_summary
        !profileAvailable -> R.string.kernel_profile_required_summary
        !profileValid -> R.string.kernel_profile_invalid_summary
        shizukuStatus == ShizukuStatus.PERMISSION_REQUIRED ->
            R.string.shizuku_status_permission_required

        else -> R.string.shizuku_status_not_running
    }
    val action = if (supported && profileAvailable && profileValid && !accessReady) {
        onShizukuClick
    } else {
        onParametersClick
    }
    Card(
        modifier = modifier,
        colors = CardDefaults.defaultColors(color = backgroundColor),
        onClick = action,
        showIndication = true,
        pressFeedbackType = PressFeedbackType.Tilt,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 110.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = when (icon) {
                    Icons.Rounded.CheckCircleOutline -> Color(0xFFA8C7FA).copy(alpha = 0.9f)
                    Icons.Rounded.RemoveCircleOutline -> Color(0xFFFCA5A5).copy(alpha = 0.9f)
                    else -> Color(0xFFA8C7FA).copy(alpha = 0.9f)
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 27.dp, y = 31.dp)
                    .size(110.dp),
            )
            Column(
                modifier = Modifier.padding(start = 16.dp, top = 14.dp, end = 120.dp, bottom = 14.dp),
            ) {
                Text(
                    text = stringResource(title),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(modifier = Modifier.height(1.dp))
                Text(
                    text = stringResource(summary),
                    fontSize = 15.sp,
                )
            }
        }
    }
}

@Composable
private fun DeviceInfoCard(
    deviceName: String,
    socName: String,
    kernelRelease: String,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier,
        insideMargin = PaddingValues(16.dp),
    ) {
        SelectionContainer {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                DeviceInfoItem(
                    title = stringResource(R.string.device_label),
                    value = deviceName,
                )
                DeviceInfoItem(
                    title = stringResource(R.string.soc_label),
                    value = socName,
                )
                DeviceInfoItem(
                    title = stringResource(R.string.kernel_label),
                    value = kernelRelease,
                )
            }
        }
    }
}

@Composable
private fun DeviceInfoItem(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier) {
        Text(
            text = title,
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            color = MiuixTheme.colorScheme.onSurface,
        )
        Text(
            text = value,
            modifier = Modifier.padding(top = 2.dp),
            fontSize = 14.sp,
            color = MiuixTheme.colorScheme.onSurface.copy(alpha = 0.68f),
        )
    }
}

/* profile-ui: resolved execution view with auto-saved sparse overrides. */
@Composable
internal fun ExecutionEditor(
    state: GhostlockUiState,
    actions: GhostlockActions,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        for (field in state.executionFields) {
            val text = state.executionEditing[field.path] ?: field.value.toString()
            val invalid = isFieldInputInvalid(text) || field.path in state.profileInvalidPaths
            TextField(
                value = text,
                onValueChange = { value -> actions.onExecutionFieldChanged(field.path, value) },
                label = fieldLabel(field.path, field.path.substringAfterLast('.')),
                colors = when {
                    invalid ->
                        TextFieldDefaults.textFieldColors(labelColor = FieldErrorHighlight)

                    field.overridden ->
                        TextFieldDefaults.textFieldColors(labelColor = OverrideHighlight)

                    else -> TextFieldDefaults.textFieldColors()
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
            )
        }
    }
}

internal val OverrideHighlight = Color(0xFFD0D0D0)

/** Red marks an unfilled or non-numeric field in the parameter editors. */
internal val FieldErrorHighlight = Color(0xFFFFFFFF)

internal fun isFieldInputInvalid(text: String): Boolean = text.trim().toLongOrNull() == null

@Composable
private fun RunButton(
    running: Boolean,
    supported: Boolean,
    profileValid: Boolean,
    labelRes: Int,
    onClick: () -> Unit,
    onBlockedClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val enabled = supported && profileValid && !running
    val buttonBg = if (enabled) Color(0xFFA8C7FA) else Color(0xFF182236)
    val contentColor = if (enabled) Color(0xFF062E6F) else Color(0xFF64748B)

    Card(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .clickable {
                if (enabled) onClick() else if (!running) onBlockedClick()
            },
        colors = CardDefaults.defaultColors(
            color = buttonBg,
        ),
        insideMargin = PaddingValues(horizontal = 24.dp, vertical = 15.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(if (enabled) Color(0xFF062E6F).copy(alpha = 0.12f) else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = if (running) "…" else "→",
                    color = contentColor,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                )
            }
            Column(
                modifier = Modifier.padding(start = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = stringResource(if (running) R.string.action_running else labelRes),
                    color = contentColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = when {
                        running -> "Окно выполнения открыто"
                        !supported -> "Ядро или профиль не поддерживаются"
                        !profileValid -> "Исправьте параметры профиля"
                        else -> "Запустить SaKuRaRoot"
                    },
                    color = if (enabled) Color(0xFF062E6F).copy(alpha = 0.8f) else Color(0xFF64748B),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 1.dp),
                )
            }
        }
    }
}

@Composable
private fun LogPanel(
    lines: List<GhostlockLogLine>,
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()
    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.scrollToItem(lines.lastIndex)
    }
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0B0B0B))
            .padding(12.dp),
    ) {
        SelectionContainer {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(top = 8.dp),
            ) {
                items(lines) { line ->
                    Text(
                        text = line.text.trimEnd('\r', '\n'),
                        color = lineColor(line.color),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                    )
                }
            }
        }
    }
}

private fun lineColor(color: Int): Color = when (color) {
    0xFFFFFFFF.toInt() -> Color(0xFFFFFFFF)
    0xFFD8D8D8.toInt() -> Color(0xFFD8D8D8)
    0xFFBDBDBD.toInt() -> Color(0xFFBDBDBD)
    0xFFC8C8C8.toInt() -> Color(0xFFC8C8C8)
    else -> Color(0xFFD1D1D1)
}
